'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Web
Imports System.Text.RegularExpressions

Imports DotNetNuke.Common
Imports DotNetNuke.Common.Utilities
Imports DotnetNuke.Entities.Portals
Imports DotNetNuke.Services.Url.FriendlyUrl
Imports DotNetNuke.Entities.Tabs

Namespace DotNetNuke.Services.Url.FriendlyUrl

    Public Class DNNFriendlyUrlProvider

        Inherits FriendlyUrlProvider

        Public Overloads Overrides Function FriendlyUrl(ByVal path As String) As String

            Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings

            If Not (_portalSettings Is Nothing) Then

				Return FriendlyUrl(path, _portalSettings.PortalAlias.HTTPAlias, "Default.aspx")

            Else

                Return FriendlyUrl(path, HttpContext.Current.Items("UrlRewrite:PortalAlias").ToString(), "Default.aspx")

            End If

        End Function

        Public Overloads Overrides Function FriendlyUrl(ByVal path As String, ByVal pageName As String) As String

            Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings

            If Not (_portalSettings Is Nothing) Then

				Return FriendlyUrl(path, _portalSettings.PortalAlias.HTTPAlias, pageName)

            Else

                Return FriendlyUrl(path, HttpContext.Current.Items("UrlRewrite:PortalAlias").ToString(), pageName)

            End If

        End Function

        Private Overloads Function FriendlyUrl(ByVal path As String, ByVal portalAlias As String, ByVal pageName As String) As String

            Dim friendlyPath As String = path

            Dim matchString As String = ""

            If Not (portalAlias = Null.NullString) Then

                If Not (HttpContext.Current.Items("UrlRewrite:OriginalUrl") Is Nothing) Then

                    Dim originalUrl As String = HttpContext.Current.Items("UrlRewrite:OriginalUrl").ToString()
                    Dim arrAlias() As String = portalAlias.Split(Convert.ToChar(","))

                    Array.Sort(arrAlias)
                    Array.Reverse(arrAlias)

                    For Each entry As String In arrAlias

                        Dim portalMatch As Match = Regex.Match(originalUrl, "^" & AddHTTP(entry), RegexOptions.IgnoreCase)

                        If Not (portalMatch Is Match.Empty) Then

                            matchString = AddHTTP(entry)
                            Exit For

                        End If

                    Next

                End If

            End If

            If (matchString <> "") Then

                If (path.IndexOf("~") <> -1) Then

                    friendlyPath = friendlyPath.Replace("~", matchString)

                Else

                    friendlyPath = matchString & friendlyPath

                End If

            Else

                friendlyPath = ResolveUrl(friendlyPath)

            End If

            Dim queryStringMatch As Match = Regex.Match(friendlyPath, "(.[^\\?]*)\\?(.*)", RegexOptions.IgnoreCase)

            If Not (queryStringMatch Is Match.Empty) Then

                friendlyPath = queryStringMatch.Groups(1).Value
                friendlyPath = Regex.Replace(friendlyPath, glbDefaultPage, "", RegexOptions.IgnoreCase)
                Dim queryString As String = queryStringMatch.Groups(2).Value.Replace("&amp;", "&")

                If (queryString.StartsWith("?")) Then
                    queryString = queryString.TrimStart(Convert.ToChar("?"))
                End If

                Dim nameValuePairs As String() = queryString.Split(Convert.ToChar("&"))

                For i As Integer = 0 To nameValuePairs.Length - 1

                    Dim pathToAppend As String = ""

                    Dim pair As String() = nameValuePairs(i).Split(Convert.ToChar("="))

                    If (friendlyPath.EndsWith("/")) Then
                        pathToAppend = pathToAppend & pair(0)
                    Else
                        pathToAppend = pathToAppend & "/" & pair(0)
                    End If

                    If (pair.Length > 1) Then

                        If (pair(1).Length > 0 ) then
                            
                            if( pair(0).ToLower() = "tabid") Then
                                
                                If (IsNumeric(pair(1))) Then

                                    Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
                                    If Not (_portalSettings Is Nothing) Then

                                        Dim tabId As Integer = Convert.ToInt32(pair(1))
                                        If (_portalSettings.ActiveTab.TabId = tabId) Then

                                            If (_portalSettings.ActiveTab.TabPath <> Null.NullString) Then
												pathToAppend = _portalSettings.ActiveTab.TabPath.Replace("//", "/").TrimStart("/"c) & "/" & pathToAppend
                                            End If

                                        Else

                                            'Try to lookup Tab
                                            Dim tabs As ArrayList = _portalSettings.DesktopTabs

                                            For intIndex As Integer = 0 To tabs.Count - 1

                                                Dim objTab As TabInfo = CType(tabs(intIndex), TabInfo)
                                                If (objTab.TabId = tabId) Then

                                                    If (objTab.TabPath <> Null.NullString) Then
														pathToAppend = objTab.TabPath.Replace("//", "/").TrimStart("/"c) & "/" & pathToAppend
                                                    End If

                                                End If

                                            Next

                                        End If

                                    else
        
                                        ' No portalSettings, so it must be the portalSettings, (Get it from Context)
                                        If Not (HttpContext.Current.Items("UrlRewrite:TabPath") Is Nothing) Then
                                            If (HttpContext.Current.Items("UrlRewrite:TabPath").ToString() <> Null.NullString) Then
												pathToAppend = HttpContext.Current.Items("UrlRewrite:TabPath").ToString().Replace("//", "/").TrimStart("/"c) & "/" & pathToAppend
                                            End If
                                        End If
                        

                                    End If
                
                                End If

                            End If

                            pathToAppend = pathToAppend & "/" & pair(1)

                        Else

                            pathToAppend = pathToAppend & "/" & System.Web.HttpUtility.UrlEncode((Chr(32)).ToString())

                        End If

                    End If

                    friendlyPath = friendlyPath & pathToAppend

                Next

                If (friendlyPath.EndsWith("/")) Then

                    friendlyPath = friendlyPath & pageName

                Else

                    friendlyPath = friendlyPath & "/" & pageName

                End If


            End If
            'friendlyPath=RegEx.Replace(HTTPUtility.URLEncode(FriendlyPath, System.Text.Encoding.GetEncoding("iso-8859-1")),"[%..]","-")
            Return friendlyPath

        End Function

    End Class

End Namespace

