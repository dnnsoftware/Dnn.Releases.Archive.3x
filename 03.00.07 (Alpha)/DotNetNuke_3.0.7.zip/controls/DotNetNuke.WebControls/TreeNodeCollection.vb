'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Collections
Imports System.Web.UI

Namespace DotNetNuke.UI.WebControls
	''' <summary>
	''' Represents a collection of <see cref="TreeNode">TreeNode</see> objects.
	''' </summary>
	Public Class TreeNodeCollection
		Inherits CollectionBase
		Implements IStateManager

		Protected _owner As TreeNode
		Protected _isTrackingViewState As Boolean

		''' <summary>
		''' Initializes a new instance of the <see cref="TreeNodeCollection">TreeNodeCollection</see> class containing the specified array of <see cref="TreeNode">TreeNode</see> objects.
		''' </summary>
		''' <param name="value">An array of <see cref="TreeNode">TreeNode</see> objects with which to initialize the collection. </param>
		Public Sub New(ByVal Parent As TreeNode)
			MyBase.New()
			If Parent Is Nothing Then
				Throw New ArgumentNullException
			End If
			_owner = Parent
		End Sub

		''' <summary>
		''' Gets the <see cref="TreeNodeCollection">TreeNodeCollection</see> at the specified index in the collection.
		''' <para>
		''' In VB.Net, this property is the indexer for the <see cref="TreeNodeCollection">TreeNodeCollection</see> class.
		''' </para>
		''' </summary>
		Default Public Property Item(ByVal index As Integer) As TreeNode
			Get
				Return CType(List(index), TreeNode)
			End Get
			Set(ByVal Value As TreeNode)
				List(index) = Value
			End Set
		End Property

		''' <summary>
		''' Add an element of the specified <see cref="TreeNode">TreeNode</see> to the end of the collection.
		''' </summary>
		''' <param name="value">An object of type <see cref="TreeNode">TreeNode</see> to add to the collection.</param>
		Public Function Add(ByVal NodeText As String) As Integer
			Return AddAt(-1, New TreeNode(NodeText))
		End Function	   'Add

		''' <summary>
		''' Add an element of the specified <see cref="TreeNode">TreeNode</see> to the end of the collection.
		''' </summary>
		''' <param name="value">An object of type <see cref="TreeNode">TreeNode</see> to add to the collection.</param>
		Public Function Add(ByVal value As TreeNode) As Integer
			Return AddAt(-1, value)
		End Function	   'Add

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <param name="index"></param>
		''' <param name="node"></param>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Function AddAt(ByVal index As Integer, ByVal node As TreeNode) As Integer
			Dim NodeIndex As Integer = index
			If NodeIndex = -1 Then
				NodeIndex = list.Add(node)
			Else
				list.Insert(NodeIndex, node)
			End If
			ConfigureNewElement(node)
			Return NodeIndex
		End Function

		''' <summary>
		''' Gets the index in the collection of the specified <see cref="TreeNodeCollection">TreeNodeCollection</see>, if it exists in the collection.
		''' </summary>
		''' <param name="value">The <see cref="TreeNodeCollection">TreeNodeCollection</see> to locate in the collection.</param>
		''' <returns>The index in the collection of the specified object, if found; otherwise, -1.</returns>
		Public Function IndexOf(ByVal value As TreeNode) As Integer
			Return List.IndexOf(value)
		End Function	   'IndexOf

		''' <summary>
		''' Add an element of the specified <see cref="TreeNode">TreeNode</see> to the collection at the designated index.
		''' </summary>
		''' <param name="index">An <see cref="system.int32">Integer</see> to indicate the location to add the object to the collection.</param>
		''' <param name="value">An object of type <see cref="TreeNode">TreeNode</see> to add to the collection.</param>
		Public Sub Insert(ByVal index As Integer, ByVal value As TreeNode)
			List.Insert(index, value)
		End Sub	   'Insert

		''' <summary>
		''' Remove the specified object of type <see cref="TreeNode">TreeNode</see> from the collection.
		''' </summary>
		''' <param name="value">An object of type <see cref="TreeNode">TreeNode</see> to remove to the collection.</param>
		Public Sub Remove(ByVal value As TreeNode)
			List.Remove(value)
		End Sub	   'Remove

		''' <summary>
		''' Gets a value indicating whether the collection contains the specified <see cref="TreeNodeCollection">TreeNodeCollection</see>.
		''' </summary>
		''' <param name="value">The <see cref="TreeNodeCollection">TreeNodeCollection</see> to search for in the collection.</param>
		''' <returns><b>true</b> if the collection contains the specified object; otherwise, <b>false</b>.</returns>
		Public Function Contains(ByVal value As TreeNode) As Boolean
			' If value is not of type TreeNode, this will return false.
			Return List.Contains(value)
		End Function	   'Contains

		''' <summary>
		''' Copies the collection objects to a one-dimensional <see cref="T:System.Array">Array</see> instance beginning at the specified index.
		''' </summary>
		''' <param name="array">The one-dimensional <see cref="T:System.Array">Array</see> that is the destination of the values copied from the collection.</param>
		''' <param name="index">The index of the array at which to begin inserting.</param>
		Public Sub CopyTo(ByVal array As TreeNode(), ByVal index As Integer)
			List.CopyTo(array, index)
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public ReadOnly Property Owner() As TreeNode
			Get
				Return _owner
			End Get
		End Property

		''' <summary>
		''' Creates a one-dimensional <see cref="T:System.Array">Array</see> instance containing the collection items.
		''' </summary>
		''' <returns>Array of type TreeNode</returns>
		Public Function ToArray() As TreeNode()
			Dim arr As TreeNode()
			ReDim Preserve arr(Count - 1)
			CopyTo(arr, 0)

			Return arr
		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <param name="Node"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub ConfigureNewElement(ByVal Node As TreeNode)
			Node.SetParent(Owner)
			Node.SetDNNTree(Owner.DNNTree)
			Node.SetLevel(Owner.Level + 1)
			Node.NodeType = eNodeType.runTimeNode
			Dim TempNode As TreeNode
			For Each TempNode In Node.TreeNodes
				ConfigureNewElement(TempNode)
			Next
		End Sub

#Region "IStateManager Interface"
		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public ReadOnly Property IsTrackingViewState() As Boolean Implements IStateManager.IsTrackingViewState
			Get
				Return _isTrackingViewState
			End Get
		End Property

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <param name="state"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Sub LoadViewState(ByVal state As Object) Implements IStateManager.LoadViewState
			If Not (state Is Nothing) Then
				Dim nodeState As Object() = CType(state, Object())
				Dim index As Integer = 0
				While index < nodeState.Length
					Dim stateElement As Object() = CType(nodeState(index), Object())
					If Not (stateElement(0) Is Nothing) Then
						If CType(stateElement(1), eNodeType) = eNodeType.designTimeNode Then
							Me(index).LoadViewState(stateElement(0))
						Else
							If CType(stateElement(1), eNodeType) = eNodeType.runTimeNode Then
								Dim _node As New TreeNode
								Dim _nodeIndex As Integer = AddAt(CType(stateElement(2), Integer), _node)
								Me(_nodeIndex).TrackViewState()
								Me(_nodeIndex).LoadViewState(stateElement(0))
							End If
						End If
					End If
					index += 1
				End While
			End If
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Function SaveViewState() As Object Implements IStateManager.SaveViewState
			If Count = 0 Then
				Return Nothing
			End If
			Dim nodeState(Count - 1) As Object
			Dim index As Integer = 0
			Dim TempNode As TreeNode
			For Each TempNode In Me
				nodeState(index) = New Object(2) {TempNode.SaveViewState, TempNode.NodeType, index}
				index += 1
			Next
			Return nodeState
		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Sub TrackViewState() Implements IStateManager.TrackViewState
			_isTrackingViewState = True
			Dim TempNode As TreeNode
			For Each TempNode In Me
				TempNode.TrackViewState()
			Next
		End Sub
#End Region
	End Class
End Namespace

