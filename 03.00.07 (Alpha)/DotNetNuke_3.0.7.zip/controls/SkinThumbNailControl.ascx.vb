'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.IO

Namespace DotNetNuke.UI.Skins

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' SkinThumbNailControl is a user control that provides that displays the skins
	'''	as a Radio ButtonList with Thumbnail Images where available
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[cnurse]	10/12/2004	Created
	''' </history>
	''' -----------------------------------------------------------------------------
	Public MustInherit Class SkinThumbNailControl
        Inherits Framework.UserControlBase

#Region "Controls"

		Protected WithEvents optSkin As System.Web.UI.WebControls.RadioButtonList
		Protected WithEvents ControlContainer As System.Web.UI.HtmlControls.HtmlGenericControl

#End Region

#Region "Private Members"

		Private _Border As String = "black 1px solid"
		Private _Columns As Integer = -1
		Private _Height As String = "300px"
		Private _SkinRoot As String
		Private _SkinType As String
		Private _SkinName As String
		Private _SkinSrc As String
        Private _Width As String = "300px"

#End Region

#Region "Properties"

		Public Property Border() As String
			Get
				Border = Convert.ToString(ViewState("SkinControlBorder"))
			End Get
			Set(ByVal Value As String)
				_Border = Value
			End Set
		End Property

		Public Property Columns() As Integer
			Get
				Columns = Convert.ToInt32(ViewState("SkinControlColumns"))
			End Get
			Set(ByVal Value As Integer)
				_Columns = Value
			End Set
		End Property

		Public Property Height() As String
			Get
				Height = Convert.ToString(ViewState("SkinControlHeight"))
			End Get
			Set(ByVal Value As String)
				_Height = Value
			End Set
		End Property

		Public Property SkinRoot() As String
			Get
				SkinRoot = Convert.ToString(ViewState("SkinRoot"))
			End Get
			Set(ByVal Value As String)
				_SkinRoot = Value
			End Set
		End Property

		Public Property SkinSrc() As String
			Get
				If Not optSkin.SelectedItem Is Nothing Then
					SkinSrc = optSkin.SelectedItem.Value
				Else
					SkinSrc = ""
				End If
			End Get
			Set(ByVal Value As String)
				_SkinSrc = Value
			End Set
		End Property


		Public Property Width() As String
			Get
				Width = Convert.ToString(ViewState("SkinControlWidth"))
			End Get
			Set(ByVal Value As String)
				_Width = Value
			End Set
		End Property

#End Region

#Region "Private Methods"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' AddSkin adds the skin to the radio button list
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <param name="strFolder">The Skin Folder</param>
		''' <param name="strFile">The Skin File</param>
		''' <history>
		''' 	[cnurse]	9/8/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub AddSkin(ByVal root As String, ByVal strFolder As String, ByVal strFile As String)

			Dim strImage As String

			If File.Exists(strFile.Replace(".ascx", ".jpg")) Then
                strImage += "<a href=""" & CreateThumbnail(strFile.Replace(".ascx", ".jpg")).Replace("thumbnail_", "") & """ target=""_new""><img src=""" & CreateThumbnail(strFile.Replace(".ascx", ".jpg")) & """ border=""1""></a>"
			Else
                strImage += "<img src=""" & Common.Globals.ApplicationPath & "/images/thumbnail.jpg"" border=""1"">"
			End If

            optSkin.Items.Add(New ListItem(FormatSkinName(strFolder, Path.GetFileNameWithoutExtension(strFile)) & "<br>" & strImage, root & "/" & strFolder & "/" & Path.GetFileName(strFile)))

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' format skin name
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="strFolder">The Folder Name</param>
        ''' <param name="strFile">The File Name without extension</param>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function FormatSkinName(ByVal strSkinFolder As String, ByVal strSkinFile As String) As String
            If strSkinFolder.ToLower = "_default" Then
                ' host folder
                Return strSkinFile
            Else ' portal folder
                Select Case strSkinFile.ToLower
                    Case "skin", "container", "default"
                        Return strSkinFolder
                    Case Else
                        Return strSkinFolder & " - " & strSkinFile
                End Select
            End If
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' CreateThumbnail creates a thumbnail of the Preview Image
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="strImage">The Image File Name</param>
        ''' <history>
        ''' 	[cnurse]	9/8/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function CreateThumbnail(ByVal strImage As String) As String

            Dim blnCreate As Boolean = True

            Dim strThumbnail As String = strImage.Replace(Path.GetFileName(strImage), "thumbnail_" & Path.GetFileName(strImage))

            ' check if image has changed
            If File.Exists(strThumbnail) Then
                Dim d1 As Date = File.GetLastWriteTime(strThumbnail)
                Dim d2 As Date = File.GetLastWriteTime(strImage)
                If File.GetLastWriteTime(strThumbnail) = File.GetLastWriteTime(strImage) Then
                    blnCreate = False
                End If
            End If

            If blnCreate Then

                Dim dblScale As Double
                Dim intHeight As Integer
                Dim intWidth As Integer

                Dim intSize As Integer = 150    ' size of the thumbnail 

                Dim objImage As System.Drawing.Image
                Try
                    objImage = objImage.FromFile(strImage)

                    ' scale the image to prevent distortion
                    If objImage.Height > objImage.Width Then
                        'The height was larger, so scale the width 
                        dblScale = intSize / objImage.Height
                        intHeight = intSize
                        intWidth = CInt(objImage.Width * dblScale)
                    Else
                        'The width was larger, so scale the height 
                        dblScale = intSize / objImage.Width
                        intWidth = intSize
                        intHeight = CInt(objImage.Height * dblScale)
                    End If

                    ' create the thumbnail image
                    Dim objThumbnail As System.Drawing.Image
                    objThumbnail = objImage.GetThumbnailImage(intWidth, intHeight, Nothing, IntPtr.Zero)

                    ' delete the old file ( if it exists )
                    If File.Exists(strThumbnail) Then
                        File.Delete(strThumbnail)
                    End If

                    ' save the thumbnail image 
                    objThumbnail.Save(strThumbnail, objImage.RawFormat)

                    ' set the file attributes
                    File.SetAttributes(strThumbnail, FileAttributes.Normal)
                    File.SetLastWriteTime(strThumbnail, File.GetLastWriteTime(strImage))

                    ' tidy up
                    objImage.Dispose()
                    objThumbnail.Dispose()

                Catch

                    ' problem creating thumbnail

                End Try

            End If

            strThumbnail = Common.Globals.ApplicationPath & "\" & strThumbnail.Substring(strThumbnail.ToLower.IndexOf("portals\"))

            ' return thumbnail filename
            Return strThumbnail

        End Function

#End Region

#Region "Event Handlers"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Page_Load runs when the control is loaded
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	10/12/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try
				Dim strRoot As String
				Dim strFolder As String
				Dim arrFolders As String()
				Dim strFile As String
				Dim arrFiles As String()

                If Not Page.IsPostBack Then

                    ' save persistent values
                    ViewState("SkinControlColumns") = _Columns
                    ViewState("SkinControlWidth") = _Width
                    ViewState("SkinControlHeight") = _Height
                    ViewState("SkinRoot") = _SkinRoot
                    ViewState("SkinControlBorder") = _Border

                    ' set control properties
                    If _Border <> "" Then
                        ControlContainer.Style.Add("border-top", _Border)
                        ControlContainer.Style.Add("border-bottom", _Border)
                        ControlContainer.Style.Add("border-left", _Border)
                        ControlContainer.Style.Add("border-right", _Border)
                    End If
                    If _Columns <> -1 Then
                        optSkin.RepeatColumns = _Columns
                    End If
                    If _Width <> "" Then
                        ControlContainer.Style.Add("width", _Width)
                    End If
                    If _Height <> "" Then
                        ControlContainer.Style.Add("height", _Height)
                    End If

                    ' default value
                    Dim strDefault As String = Services.Localization.Localization.GetString("Not_Specified") & "<br>"
                    strDefault += "<img src=""" & Common.Globals.ApplicationPath & "/images/spacer.gif"" width=""140"" height=""135"" border=""0"">"
                    optSkin.Items.Insert(0, New ListItem(strDefault, ""))

                    ' load host skins
                    strRoot = Request.MapPath(Common.Globals.HostPath & _SkinRoot)
                    If Directory.Exists(strRoot) Then
                        arrFolders = Directory.GetDirectories(strRoot)
                        For Each strFolder In arrFolders
                            arrFiles = Directory.GetFiles(strFolder, "*.ascx")
                            For Each strFile In arrFiles
                                strFolder = Mid(strFolder, InStrRev(strFolder, "\") + 1)
                                AddSkin("[G]" & SkinRoot, strFolder, strFile)
                            Next
                        Next
                    End If

                    ' load portal skins
                    strRoot = Request.MapPath(PortalSettings.HomeDirectory & _SkinRoot)
                    If Directory.Exists(strRoot) Then
                        arrFolders = Directory.GetDirectories(strRoot)
                        For Each strFolder In arrFolders
                            arrFiles = Directory.GetFiles(strFolder, "*.ascx")
                            For Each strFile In arrFiles
                                strFolder = Mid(strFolder, InStrRev(strFolder, "\") + 1)
                                AddSkin("[L]" & SkinRoot, strFolder, strFile)
                            Next
                        Next
                    End If

                    ' select current skin
                    Dim intIndex As Integer
                    For intIndex = 0 To optSkin.Items.Count - 1
                        If optSkin.Items(intIndex).Value = _SkinSrc Then
                            optSkin.Items(intIndex).Selected = True
                            Exit For
                        End If
                    Next

                End If

            Catch exc As Exception    'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

#End Region

#Region " Web Form Designer Generated Code "


		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

	End Class

End Namespace
