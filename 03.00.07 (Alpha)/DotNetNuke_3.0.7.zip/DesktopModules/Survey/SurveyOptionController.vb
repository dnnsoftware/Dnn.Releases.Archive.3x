'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Data
Imports DotNetNuke

Namespace DotNetNuke.Modules.Survey

    Public Class SurveyOptionController

        Public Function GetSurveyOptions(ByVal SurveyId As Integer) As ArrayList

            Return CBO.FillCollection(DataProvider.Instance().GetSurveyOptions(SurveyId), GetType(SurveyOptionInfo))

        End Function

        Public Sub DeleteSurveyOption(ByVal SurveyOptionID As Integer)

            DataProvider.Instance().DeleteSurveyOption(SurveyOptionID)

        End Sub

        Public Function AddSurveyOption(ByVal objSurveyOption As SurveyOptionInfo) As Integer

            Return CType(DataProvider.Instance().AddSurveyOption(objSurveyOption.SurveyId, objSurveyOption.OptionName, objSurveyOption.ViewOrder), Integer)

        End Function

        Public Sub UpdateSurveyOption(ByVal objSurveyOption As SurveyOptionInfo)

            DataProvider.Instance().UpdateSurveyOption(objSurveyOption.SurveyOptionId, objSurveyOption.OptionName, objSurveyOption.ViewOrder)

        End Sub

        Public Sub AddSurveyResult(ByVal SurveyOptionID As Integer)

            DataProvider.Instance().AddSurveyResult(SurveyOptionID)

        End Sub

    End Class

End Namespace
