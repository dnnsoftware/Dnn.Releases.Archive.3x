'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports DotNetNuke

Namespace DotNetNuke.Modules.Contacts

  ''' -----------------------------------------------------------------------------
  ''' <summary>
	''' The EditContacts PortalModuleBase is used to manage Contacts
	''' </summary>
	''' <returns></returns>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[cnurse]	9/21/2004	Moved Contacts to a separate Project
	''' 	[cnurse]	9/21/2004	Updated to reflect design changes for Help, 508 support
	'''                       and localisation
	''' </history>
	''' -----------------------------------------------------------------------------
	Public MustInherit Class EditContacts
		Inherits Entities.Modules.PortalModuleBase

#Region "Controls"

		Protected plNameField As UI.UserControls.LabelControl
		Protected WithEvents NameField As System.Web.UI.WebControls.TextBox
		Protected WithEvents valName As System.Web.UI.WebControls.RequiredFieldValidator
		Protected WithEvents RoleField As System.Web.UI.WebControls.TextBox
		Protected WithEvents EmailField As System.Web.UI.WebControls.TextBox
		Protected WithEvents Contact1Field As System.Web.UI.WebControls.TextBox
		Protected WithEvents Contact2Field As System.Web.UI.WebControls.TextBox

		'tasks
		Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
		Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
		Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

		'footer
		Protected WithEvents ctlAudit As UI.UserControls.ModuleAuditControl

#End Region

#Region "Private Members"

		Private itemId As Integer = -1

#End Region

#Region "Event Handlers"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Page_Load runs when the control is loaded
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/21/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try
				' Determine ItemId of Contacts to Update
                If Not (Request.QueryString("ItemId") Is Nothing) Then
                    itemId = Int32.Parse(Request.QueryString("ItemId"))
                End If

                ' If the page is being requested the first time, determine if an
                ' contact itemId value is specified, and if so populate page
                ' contents with the contact details
                If Page.IsPostBack = False Then

                    cmdDelete.Attributes.Add("onClick", "javascript:return confirm('" & Localization.GetString("DeleteItem") & "');")

                    If itemId <> -1 Then
                        ' Obtain a single row of contact information
                        Dim objContacts As New ContactController
                        Dim objContact As ContactInfo = objContacts.GetContact(itemId, ModuleId)

                        ' Read first row from database
                        If Not objContact Is Nothing Then
                            NameField.Text = objContact.Name
                            RoleField.Text = objContact.Role
                            EmailField.Text = objContact.Email
                            Contact1Field.Text = objContact.Contact1
                            Contact2Field.Text = objContact.Contact2

                            ctlAudit.CreatedDate = objContact.CreatedDate.ToString
                            ctlAudit.CreatedByUser = objContact.CreatedByUser.ToString

                        Else       ' security violation attempt to access item not related to this Module

                            Response.Redirect(NavigateURL(), True)
                        End If
                    Else
                        cmdDelete.Visible = False
                        ctlAudit.Visible = False
                    End If

                End If
            Catch exc As Exception    'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdCancel_Click runs when the cancel button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/20/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
			Try
				Response.Redirect(NavigateURL(), True)
			Catch exc As Exception		  'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdDelete_Click runs when the delete button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/20/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
			Try
				If itemId <> -1 Then

					Dim objContacts As New ContactController
					objContacts.DeleteContact(itemId)

				End If

				' Redirect back to the portal home page
				Response.Redirect(NavigateURL(), True)
			Catch exc As Exception		  'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdUpdate_Click runs when the update button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/20/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
			Try
				' Only Update if Entered data is Valid
				If Page.IsValid = True Then

					' Create an instance of the ContactsDB component
					Dim objContacts As New ContactController
					Dim objContact As New ContactInfo
					objContact.ItemId = itemId
					objContact.ModuleId = ModuleId
					objContact.Name = NameField.Text
					objContact.Role = RoleField.Text
					objContact.Email = EmailField.Text
					objContact.Contact1 = Contact1Field.Text
					objContact.Contact2 = Contact2Field.Text
					objContact.CreatedByUser = UserInfo.UserID.ToString

					If itemId = -1 Then
						' Add the contact within the contacts table
						objContacts.AddContact(objContact)
					Else
						' Update the contact within the contacts table
						objContacts.UpdateContact(objContact)
					End If

					' Redirect back to the portal home page
					Response.Redirect(NavigateURL(), True)

				End If
			Catch exc As Exception		  'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

#End Region

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

	End Class

End Namespace