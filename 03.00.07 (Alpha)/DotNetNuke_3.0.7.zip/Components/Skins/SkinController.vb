'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data
Imports System.IO
Imports ICSharpCode.SharpZipLib.Zip
Imports System.Xml
Imports System.Text.RegularExpressions

Namespace DotNetNuke.UI.Skins

	''' -----------------------------------------------------------------------------
	''' Project	 : DotNetNuke
	''' Class	 : SkinController
	''' 
	''' -----------------------------------------------------------------------------
	''' <summary>
	'''     Handles the Business Control Layer for Skins
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[willhsc]	3/3/2004	Created
	''' </history>
	''' -----------------------------------------------------------------------------
	Public Class SkinController

		Public Shared Function FormatSkinPath(ByVal SkinSrc As String) As String
			Dim strSkinSrc As String = SkinSrc

			If strSkinSrc <> "" Then
				strSkinSrc = Left(strSkinSrc, InStrRev(strSkinSrc, "/"))
			End If

			Return strSkinSrc
		End Function

		Public Shared Function FormatSkinSrc(ByVal SkinSrc As String, ByVal PortalSettings As PortalSettings) As String
			Dim strSkinSrc As String = SkinSrc

			If strSkinSrc <> "" Then
				Select Case strSkinSrc.Substring(0, 3)
					Case "[G]"
						strSkinSrc = strSkinSrc.Replace("[G]", Common.Globals.HostPath)
					Case "[L]"
						strSkinSrc = strSkinSrc.Replace("[L]", PortalSettings.HomeDirectory)
				End Select
			End If

			Return strSkinSrc
		End Function

		Public Shared Function GetSkin(ByVal SkinRoot As String, ByVal PortalId As Integer, ByVal SkinType As UI.Skins.SkinType) As UI.Skins.SkinInfo
			Return CType(CBO.FillObject(DataProvider.Instance().GetSkin(SkinRoot, PortalId, SkinType), GetType(SkinInfo)), SkinInfo)
		End Function

		Public Shared Sub SetSkin(ByVal SkinRoot As String, ByVal PortalId As Integer, ByVal SkinType As UI.Skins.SkinType, ByVal SkinSrc As String)

			' remove skin assignment
			DataProvider.Instance().DeleteSkin(SkinRoot, PortalId, SkinType)

			' add new skin assignment if specified
			If SkinSrc <> "" Then
				DataProvider.Instance().AddSkin(SkinRoot, PortalId, SkinType, SkinSrc)
			End If
		End Sub

		Public Shared Function UploadSkin(ByVal RootPath As String, ByVal SkinRoot As String, ByVal SkinName As String, ByVal Path As String) As String

			Dim strMessage As String = ""

			Dim objFileStream As FileStream
			objFileStream = New FileStream(Path, FileMode.Open, FileAccess.Read)

			strMessage = UploadSkin(RootPath, SkinRoot, SkinName, CType(objFileStream, Stream))

			objFileStream.Close()

			Return strMessage

		End Function

		Public Shared Function UploadSkin(ByVal RootPath As String, ByVal SkinRoot As String, ByVal SkinName As String, ByVal objInputStream As Stream) As String

			Dim objZipInputStream As New ZipInputStream(objInputStream)

			Dim objZipEntry As ZipEntry
			Dim strExtension As String
			Dim strFileName As String
			Dim objFileStream As FileStream
			Dim intSize As Integer = 2048
			Dim arrData(2048) As Byte
			Dim strMessage As String = ""
			Dim arrSkinFiles As New ArrayList

			'Localized Strings
			Dim BEGIN_MESSAGE As String = Services.Localization.Localization.GetString("BeginZip")
			Dim CREATE_DIR As String = Services.Localization.Localization.GetString("CreateDir")
			Dim WRITE_FILE As String = Services.Localization.Localization.GetString("WriteFile")
			Dim FILE_ERROR As String = Services.Localization.Localization.GetString("FileError")
			Dim END_MESSAGE As String = Services.Localization.Localization.GetString("EndZip")
			Dim FILE_RESTICTED As String = Services.Localization.Localization.GetString("FileRestricted")

			strMessage += FormatMessage(BEGIN_MESSAGE, SkinName, -1, False)

			objZipEntry = objZipInputStream.GetNextEntry
			While Not objZipEntry Is Nothing
				If Not objZipEntry.IsDirectory Then
					' validate file extension
					strExtension = objZipEntry.Name.Substring(objZipEntry.Name.LastIndexOf(".") + 1)
					If InStr(1, ",ASCX,HTM,HTML,CSS,SWF," & Common.Globals.HostSettings("FileExtensions").ToString.ToUpper, "," & strExtension.ToUpper) <> 0 Then

						' process embedded zip files
						Select Case objZipEntry.Name.ToLower
							Case SkinInfo.RootSkin.ToLower & ".zip"
								Dim objMemoryStream As New MemoryStream
								intSize = objZipInputStream.Read(arrData, 0, arrData.Length)
								While intSize > 0
									objMemoryStream.Write(arrData, 0, intSize)
									intSize = objZipInputStream.Read(arrData, 0, arrData.Length)
								End While
								objMemoryStream.Seek(0, SeekOrigin.Begin)
								strMessage += UploadSkin(RootPath, SkinInfo.RootSkin, SkinName, CType(objMemoryStream, Stream))
							Case SkinInfo.RootContainer.ToLower & ".zip"
								Dim objMemoryStream As New MemoryStream
								intSize = objZipInputStream.Read(arrData, 0, arrData.Length)
								While intSize > 0
									objMemoryStream.Write(arrData, 0, intSize)
									intSize = objZipInputStream.Read(arrData, 0, arrData.Length)
								End While
								objMemoryStream.Seek(0, SeekOrigin.Begin)
								strMessage += UploadSkin(RootPath, SkinInfo.RootContainer, SkinName, CType(objMemoryStream, Stream))
							Case Else
								strFileName = RootPath & SkinRoot & "\" & SkinName & "\" & objZipEntry.Name

								' create the directory if it does not exist
								If Not Directory.Exists(Path.GetDirectoryName(strFileName)) Then
									strMessage += FormatMessage(CREATE_DIR, Path.GetDirectoryName(strFileName), 2, False)
									Directory.CreateDirectory(Path.GetDirectoryName(strFileName))
								End If

								' remove the old file
								If File.Exists(strFileName) Then
									File.SetAttributes(strFileName, FileAttributes.Normal)
									File.Delete(strFileName)
								End If
								' create the new file
								objFileStream = File.Create(strFileName)

								' unzip the file
								strMessage += FormatMessage(WRITE_FILE, Path.GetFileName(strFileName), 2, False)
								intSize = objZipInputStream.Read(arrData, 0, arrData.Length)
								While intSize > 0
									objFileStream.Write(arrData, 0, intSize)
									intSize = objZipInputStream.Read(arrData, 0, arrData.Length)
								End While
								objFileStream.Close()

								' save the skin file
								Select Case Path.GetExtension(strFileName)
									Case ".htm", ".html", ".ascx", ".css"
										arrSkinFiles.Add(strFileName)
								End Select
						End Select
					Else
						strMessage += FormatMessage(FILE_ERROR, String.Format(FILE_RESTICTED, objZipEntry.Name, Replace(Common.Globals.HostSettings("FileExtensions").ToString, ",", ", *.")), 2, True)
					End If
				End If
				objZipEntry = objZipInputStream.GetNextEntry
			End While
			strMessage += FormatMessage(END_MESSAGE, SkinName & ".zip", 1, False)
			objZipInputStream.Close()

			' process the list of skin files
			Dim NewSkin As New UI.Skins.SkinFileProcessor(RootPath, SkinRoot, SkinName)
			strMessage += NewSkin.ProcessList(arrSkinFiles)

			Return strMessage

		End Function

		Public Shared Function FormatMessage(ByVal Title As String, ByVal Body As String, ByVal Level As Integer, ByVal IsError As Boolean) As String
			Dim Message As String = Title

			If IsError Then
				Message = "<font class=""NormalRed"">" & Title & "</font>"
			End If

			Select Case Level
				Case -1
					Message = "<hr><br><b>" & Message & "</b>"
				Case 0
					Message = "<br><br><b>" & Message & "</b>"
				Case 1
					Message = "<br><b>" & Message & "</b>"
				Case Else
					Message = "<br><li>" & Message
			End Select

			Return Message & ": " & Body & vbCrLf

		End Function

	End Class

End Namespace