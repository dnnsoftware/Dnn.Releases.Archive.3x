'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data
Imports System.IO
Imports DotNetNuke.Entities.Tabs

Namespace DotNetNuke.Common.Utilities

	Public Enum CoreCacheType
		Host = 1
		Portal = 2
		Tab = 3
	End Enum

	Public Class DataCache

		Public Shared Function GetCache(ByVal CacheKey As String) As Object

			Dim objCache As System.Web.Caching.Cache = HttpRuntime.Cache

			Return objCache(CacheKey)

		End Function

		Public Shared Sub SetCache(ByVal CacheKey As String, ByVal objObject As Object)

			Dim objCache As System.Web.Caching.Cache = HttpRuntime.Cache

			objCache.Insert(CacheKey, objObject)

		End Sub

		Public Shared Sub SetCache(ByVal CacheKey As String, ByVal objObject As Object, ByVal objDependency As System.Web.Caching.CacheDependency)

			Dim objCache As System.Web.Caching.Cache = HttpRuntime.Cache

			objCache.Insert(CacheKey, objObject, objDependency)

		End Sub
		Public Shared Sub SetCache(ByVal CacheKey As String, ByVal objObject As Object, ByVal objDependency As System.Web.Caching.CacheDependency, ByVal AbsoluteExpiration As Date, ByVal SlidingExpiration As System.TimeSpan)

			Dim objCache As System.Web.Caching.Cache = HttpRuntime.Cache

			objCache.Insert(CacheKey, objObject, objDependency, AbsoluteExpiration, SlidingExpiration)

		End Sub


		Public Shared Sub SetCache(ByVal CacheKey As String, ByVal objObject As Object, ByVal SlidingExpiration As TimeSpan)

			Dim objCache As System.Web.Caching.Cache = HttpRuntime.Cache

			objCache.Insert(CacheKey, objObject, Nothing, System.Web.Caching.Cache.NoAbsoluteExpiration, SlidingExpiration)

		End Sub

		Public Shared Sub SetCache(ByVal CacheKey As String, ByVal objObject As Object, ByVal AbsoluteExpiration As Date)

			Dim objCache As System.Web.Caching.Cache = HttpRuntime.Cache

			objCache.Insert(CacheKey, objObject, Nothing, AbsoluteExpiration, System.Web.Caching.Cache.NoSlidingExpiration)

		End Sub

		Public Shared Sub RemoveCache(ByVal CacheKey As String)

			Dim objCache As System.Web.Caching.Cache = HttpRuntime.Cache

			If Not objCache(CacheKey) Is Nothing Then
				objCache.Remove(CacheKey)
			End If

		End Sub

		Public Shared Sub ClearCoreCache(ByVal Type As CoreCacheType, Optional ByVal ID As Integer = -1, Optional ByVal Cascade As Boolean = False)

			Select Case Type
				Case CoreCacheType.Host
					ClearHostCache(Cascade)
				Case CoreCacheType.Portal
					ClearPortalCache(ID, Cascade)
				Case CoreCacheType.Tab
					ClearTabCache(ID)
			End Select

		End Sub

		Private Shared Sub ClearHostCache(ByVal Cascade As Boolean)

			Dim objCache As System.Web.Caching.Cache = HttpRuntime.Cache

			If Not objCache("GetHostSettings") Is Nothing Then
				objCache.Remove("GetHostSettings")
			End If

			If Not objCache("GetPortalByAlias") Is Nothing Then
				objCache.Remove("GetPortalByAlias")
			End If

			If Not objCache("CSS") Is Nothing Then
				objCache.Remove("CSS")
			End If

			If Cascade Then
				Dim objPortals As New PortalController
				Dim objPortal As PortalInfo
				Dim arrPortals As ArrayList = objPortals.GetPortals

				Dim intIndex As Integer
				For intIndex = 0 To arrPortals.Count - 1
					objPortal = CType(arrPortals(intIndex), PortalInfo)
					ClearPortalCache(objPortal.PortalID, Cascade)
				Next
			End If

		End Sub

		Private Shared Sub ClearPortalCache(ByVal PortalId As Integer, ByVal Cascade As Boolean)

			Dim objCache As System.Web.Caching.Cache = HttpRuntime.Cache

			If Not objCache("GetPortalSettings" & PortalId.ToString) Is Nothing Then
				objCache.Remove("GetPortalSettings" & PortalId.ToString)
			End If

			If Not objCache("GetTabs" & PortalId.ToString) Is Nothing Then
				objCache.Remove("GetTabs" & PortalId.ToString)
			End If

			If Cascade Then
				Dim objTabs As New TabController
				Dim objTab As TabInfo
				Dim arrTabs As ArrayList = objTabs.GetTabs(PortalId)

				Dim intIndex As Integer
				For intIndex = 0 To arrTabs.Count - 1
					objTab = CType(arrTabs(intIndex), TabInfo)
					ClearTabCache(objTab.TabID)
				Next
			End If

		End Sub

		Private Shared Sub ClearTabCache(ByVal TabId As Integer)
			Dim _PortalSettings As PortalSettings = PortalController.GetCurrentPortalSettings

			Dim objCache As System.Web.Caching.Cache = HttpRuntime.Cache

			If Not objCache("GetTab" & TabId.ToString) Is Nothing Then
				objCache.Remove("GetTab" & TabId.ToString)
			End If

			If Not objCache("GetPortalTabModules" & TabId.ToString) Is Nothing Then
				objCache.Remove("GetPortalTabModules" & TabId.ToString)
			End If

			If Not _PortalSettings Is Nothing Then
				If Not objCache("GetTabPermissionsByPortal" & _PortalSettings.PortalId.ToString) Is Nothing Then
					objCache.Remove("GetTabPermissionsByPortal" & _PortalSettings.PortalId.ToString)
				End If

				If Not objCache("GetModulePermissionsByPortal" & _PortalSettings.PortalId.ToString) Is Nothing Then
					objCache.Remove("GetModulePermissionsByPortal" & _PortalSettings.PortalId.ToString)
				End If
			End If

		End Sub

	End Class

End Namespace