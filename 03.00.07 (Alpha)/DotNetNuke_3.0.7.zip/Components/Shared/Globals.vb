'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System
Imports System.Configuration
Imports System.IO
Imports System.Net
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Web.Mail
Imports ICSharpCode.SharpZipLib.Zip
Imports System.XML
Imports DotNetNuke.Framework.Providers
Imports DotNetNuke.Entities.Tabs
Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Security.Roles
Imports DotNetNuke.Services.FileSystem
Imports System.Web

Namespace DotNetNuke.Common

	'*********************************************************************
	'
	' Globals Module
	' This module contains global utility functions, constants, and enumerations.
	'
	'*********************************************************************

	Public Module Globals

        Public Const glbAppVersion As String = "03.00.07"
		Public Const glbAppTitle As String = "DotNetNuke"
		Public Const glbAppDescription As String = "ASP.NET Open Source Portal Application"
		Public Const glbAppCompany As String = "Perpetual Motion Interactive Systems Inc."
		Public Const glbAppProductName As String = "http://www.dotnetnuke.com"
		Public Const glbLegalCopyright As String = "Portal engine source code is copyright 2002-YYYY by DotNetNuke. All Rights Reserved"
		Public Const glbTrademark As String = "DotNetNuke"

		Public Const glbRoleAllUsers As String = "-1"
		Public Const glbRoleSuperUser As String = "-2"
		Public Const glbRoleUnauthUser As String = "-3"

		Public Const glbRoleAllUsersName As String = "All Users"
		Public Const glbRoleSuperUserName As String = "Superuser"
		Public Const glbRoleUnauthUserName As String = "Unauthenticated Users"

		Public Const glbDefaultPage As String = "Default.aspx"
        Public Const glbDefaultSkin As String = "DNN - Horizontal Menu.ascx"
        Public Const glbDefaultAdminSkin As String = "DNN - Horizontal Menu.ascx"
        Public Const glbDefaultContainer As String = "Header - Colored Background.ascx"
        Public Const glbDefaultAdminContainer As String = "Header - Colored Background.ascx"
		Public Const glbDefaultControlPanel As String = "Admin/ControlPanel/IconBar.ascx"
		Public Const glbDefaultPane As String = "ContentPane"
		Public Const glbImageFileTypes As String = "jpg,jpeg,jpe,gif,bmp,png"

		Public Const glbSuperUserAppName As String = "-1"

		' global constants for the life of the application ( set in Application_Start )
		Private _ApplicationPath As String
		Private _ApplicationMapPath As String
		Private _AssemblyPath As String
		Private _HostMapPath As String
		Private _HostPath As String
		Private _ServerName As String
		Private _HostSettings As Hashtable
		Private _PerformanceSetting As PerformanceSettings

		Public Property ApplicationPath() As String
			Get
				Return _ApplicationPath
			End Get
			Set(ByVal Value As String)
				_ApplicationPath = Value
			End Set
		End Property
		Public Property ApplicationMapPath() As String
			Get
				Return _ApplicationMapPath
			End Get
			Set(ByVal Value As String)
				_ApplicationMapPath = Value
			End Set
		End Property
		Public Property AssemblyPath() As String
			Get
				Return _AssemblyPath
			End Get
			Set(ByVal Value As String)
				_AssemblyPath = Value
			End Set
		End Property
		Public Property HostMapPath() As String
			Get
				Return _HostMapPath
			End Get
			Set(ByVal Value As String)
				_HostMapPath = Value
			End Set
		End Property
		Public Property HostPath() As String
			Get
				Return _HostPath
			End Get
			Set(ByVal Value As String)
				_HostPath = value
			End Set
		End Property

		Public Property ServerName() As String
			Get
				Return _ServerName
			End Get
			Set(ByVal Value As String)
				_ServerName = Value
			End Set
		End Property

		Public ReadOnly Property HostSettings() As Hashtable
			Get
				Return Entities.Host.HostSettings.GetHostSettings
			End Get
		End Property

		Public ReadOnly Property PerformanceSetting() As PerformanceSettings
			Get
				Return CType(Convert.ToInt32(IIf(Common.Globals.HostSettings("PerformanceSetting") Is Nothing, 3, Common.Globals.HostSettings("PerformanceSetting"))), PerformanceSettings)
			End Get
		End Property

		Public Enum PerformanceSettings
			'The values of the enum are used to calculate
			'cache settings throughout the portal.
			'Calculating based on these numbers keeps 
			'the scaling linear for all caching.
			NoCaching = 0
			LightCaching = 1
			ModerateCaching = 3
			HeavyCaching = 6
		End Enum

		Public Function GetApplicationName() As String
			Dim _PortalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
			If _PortalSettings Is Nothing Then
				Return "/"
			End If
			Return GetApplicationName(_PortalSettings.PortalId)
		End Function

		Public Function GetApplicationName(ByVal PortalID As Integer) As String
			Return Convert.ToString(PortalID)
		End Function

		Public Sub SetApplicationName(ByVal PortalID As Integer)
			HttpContext.Current.Items("ApplicationName") = GetApplicationName(PortalID)
		End Sub

		Public Sub SetApplicationName(ByVal ApplicationName As String)
			HttpContext.Current.Items("ApplicationName") = ApplicationName
		End Sub

		' returns the absolute server path to the root ( ie. D:\Inetpub\wwwroot\directory\ )
		Public Function GetAbsoluteServerPath(ByVal Request As HttpRequest) As String
			Dim strServerPath As String

			strServerPath = Request.MapPath(Request.ApplicationPath)
			If Not strServerPath.EndsWith("\") Then
				strServerPath += "\"
			End If

			GetAbsoluteServerPath = strServerPath
		End Function

		' returns the domain name of the current request ( ie. www.domain.com or 207.132.12.123 or www.domain.com/directory if subhost )
		' Actually, more to the point, returns the URL for the portal of this request.url.
		'   USE:
		'       Returns URI appropriate for checking against Portal Aliases.
		'   ASSUMPTIONS:
		'       portal access is always centric thru *.aspx or *.axd file;
		'       DotNetNuke application directory names are special (and not part of portal alias);
		'           only certain DNN top directory names are checked... so beware of the future!
		Public Function GetDomainName(ByVal Request As HttpRequest) As String
			Dim DomainName As StringBuilder = New StringBuilder
			Dim URL() As String
			Dim URI As String			' holds Request.Url, less the "?" parameters
			Dim intURL As Integer

			' split both URL separater, and parameter separator
			' We trim right of '?' so test for filename extensions can occur at END of URL-componenet.
			' Test:   'www.aspxforum.net'  should be returned as a valid domain name.
			' just consider left of '?' in URI
			' Binary, else '?' isn't taken literally; only interested in one (left) string
			URI = Request.Url.ToString()
			intURL = InStr(URI, "?", CompareMethod.Binary)
			If intURL > 0 Then
				URI = Left(URI, intURL - 1)
			End If

			URL = Split(URI, "/")

			For intURL = 2 To URL.GetUpperBound(0)
				Select Case URL(intURL).ToLower
					Case "admin", "controls", "desktopmodules", "mobilemodules", "premiummodules", "providers"
						Exit For
					Case Else
						' exclude filenames ENDing in ".aspx" or ".axd" --- 
						'   we'll use reverse match,
						'   - but that means we are checking position of left end of the match;
						'   - and to do that, we need to ensure the string we test against is long enough;
						If (URL(intURL).Length >= ".aspx".Length) Then						'long enough for both tests
							If InStrRev(URL(intURL), ".aspx") = (URL(intURL).Length - (".aspx".Length - 1)) _
							Or InStrRev(URL(intURL), ".axd") = (URL(intURL).Length - (".axd".Length - 1)) Then
								Exit For
							End If
						End If
						' non of the exclusionary names found
						DomainName.Append(IIf(DomainName.ToString <> "", "/", "").ToString & URL(intURL))
				End Select
			Next intURL

			Return DomainName.ToString

		End Function

		' stub included for legacy purposes
		''' -----------------------------------------------------------------------------
		''' <summary></summary>
		''' <returns></returns>
		''' <remarks></remarks>
		''' <history>
		''' 	[Nik Kalyani]	10/15/2004	Replaced square brackets in member names and
		'''                                 created method signatures to eliminate use of
		'''                                 optional parameters
		''' </history>
		''' -----------------------------------------------------------------------------

		Public Function SendNotification(ByVal MailFrom As String, ByVal MailTo As String, ByVal Bcc As String, ByVal Subject As String, ByVal Body As String) As String
			Return SendNotification(MailFrom, MailTo, Bcc, Subject, Body, "", "", "")
		End Function

		Public Function SendNotification(ByVal MailFrom As String, ByVal MailTo As String, ByVal Bcc As String, ByVal Subject As String, ByVal Body As String, ByVal Attachment As String) As String
			Return SendNotification(MailFrom, MailTo, Bcc, Subject, Body, Attachment, "", "")
		End Function

		Public Function SendNotification(ByVal MailFrom As String, ByVal MailTo As String, ByVal Bcc As String, ByVal Subject As String, ByVal Body As String, ByVal Attachment As String, ByVal BodyType As String) As String
			Return SendNotification(MailFrom, MailTo, Bcc, Subject, Body, Attachment, BodyType, "")
		End Function

		Public Function SendNotification(ByVal MailFrom As String, ByVal MailTo As String, ByVal Bcc As String, ByVal Subject As String, ByVal Body As String, ByVal Attachment As String, ByVal BodyType As String, ByVal SmtpServer As String) As String

			' Obtain PortalSettings from Current Context
			Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings

			' SMTP server
			If Common.Globals.HostSettings("SMTPServer").ToString <> "" Then
				SmtpServer = Common.Globals.HostSettings("SMTPServer").ToString
			End If
			Dim strSMTPUsername As String = ""
			If Convert.ToString(Common.Globals.HostSettings("SMTPUsername")) <> "" Then
				strSMTPUsername = Convert.ToString(Common.Globals.HostSettings("SMTPUsername"))
			End If
			Dim strSMTPPassword As String = ""
			If Convert.ToString(Common.Globals.HostSettings("SMTPPassword")) <> "" Then
				strSMTPPassword = Convert.ToString(Common.Globals.HostSettings("SMTPPassword"))
			End If

			' here we check if we want to format the email as html or plain text.
			Dim objBodyFormat As MailFormat
			If BodyType <> "" Then
				Select Case LCase(BodyType)
					Case "html"
						objBodyFormat = MailFormat.Html
					Case "text"
						objBodyFormat = MailFormat.Text
				End Select
			End If

			Return SendMail(MailFrom, MailTo, "", Bcc, MailPriority.Normal, Subject, objBodyFormat, System.Text.Encoding.Default, Body, Attachment, SmtpServer, strSMTPUsername, strSMTPPassword)

		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>Send a simple email.</summary>
		''' <returns></returns>
		''' <remarks></remarks>
		''' <history>
		''' 	[Nik Kalyani]	10/15/2004	Replaced brackets in member names
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Function SendMail(ByVal MailFrom As String, ByVal MailTo As String, ByVal Cc As String, ByVal Bcc As String, ByVal Priority As MailPriority, ByVal Subject As String, ByVal BodyFormat As MailFormat, ByVal BodyEncoding As System.Text.Encoding, ByVal Body As String, ByVal Attachment As String, ByVal SmtpServer As String, ByVal SmtpUsername As String, ByVal SmtpPassword As String) As String

			Dim objMail As New MailMessage

			' recipients
			objMail.From = MailFrom
			objMail.To = MailTo
			If Cc <> "" Then
				objMail.Cc = Cc
			End If
			If Bcc <> "" Then
				objMail.Bcc = Bcc
			End If

			' message
			objMail.Priority = Priority
			objMail.Subject = Subject
			objMail.BodyFormat = BodyFormat
			objMail.BodyEncoding = BodyEncoding
			objMail.Body = Body

			' attachment
			If Attachment <> "" Then
				objMail.Attachments.Add(New MailAttachment(Attachment))
			End If

			' external SMTP server
			If SmtpServer <> "" Then
				SmtpMail.SmtpServer = SmtpServer
				' with authentication
				If SmtpUsername <> "" And SmtpPassword <> "" Then
					objMail.Fields("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate") = 1
					objMail.Fields("http://schemas.microsoft.com/cdo/configuration/sendusername") = SmtpUsername
					objMail.Fields("http://schemas.microsoft.com/cdo/configuration/sendpassword") = SmtpPassword
				End If
			End If

			Try
				SmtpMail.Send(objMail)
			Catch objException As Exception
				' mail configuration problem
				SendMail = objException.Message
				LogException(objException)
			End Try

		End Function

		' encodes a URL for posting to an external site
		Public Function HTTPPOSTEncode(ByVal strPost As String) As String
			strPost = Replace(strPost, "\", "")
			strPost = System.Web.HttpUtility.UrlEncode(strPost)
			strPost = Replace(strPost, "%2f", "/")
			HTTPPOSTEncode = strPost
		End Function

		' retrieves the domain name of the portal ( ie. http://www.domain.com " )
		Public Function GetPortalDomainName(ByVal strPortalAlias As String, Optional ByVal Request As HttpRequest = Nothing, Optional ByVal blnAddHTTP As Boolean = True) As String

			Dim strDomainName As String

			Dim strURL As String = ""
			Dim arrPortalAlias() As String
			Dim intAlias As Integer

			If Not Request Is Nothing Then
				strURL = GetDomainName(Request)
			End If

			arrPortalAlias = Split(strPortalAlias, ",")
			For intAlias = 0 To arrPortalAlias.Length - 1
				If arrPortalAlias(intAlias) = strURL Then
					strDomainName = arrPortalAlias(intAlias)
				End If
			Next
			If strDomainName = "" Then
				strDomainName = arrPortalAlias(0)
			End If

			If blnAddHTTP Then
				strDomainName = AddHTTP(strDomainName)
			End If

			GetPortalDomainName = strDomainName

		End Function

		' adds HTTP to URL if no other protocol specified
		Public Function AddHTTP(ByVal strURL As String) As String
			If strURL <> "" Then
				If InStr(1, strURL, "://") = 0 And InStr(1, strURL, "~") = 0 And InStr(1, strURL, "\\") = 0 Then
					If HttpContext.Current.Request.IsSecureConnection Then
						strURL = "https://" & strURL
					Else
						strURL = "http://" & strURL
					End If
				End If
			End If
			Return strURL
		End Function

		' convert datareader to dataset
		Public Function ConvertDataReaderToDataSet(ByVal reader As IDataReader) As DataSet

			' add datatable to dataset
			Dim objDataSet As New DataSet
			objDataSet.Tables.Add(ConvertDataReaderToDataTable(reader))

			Return objDataSet

		End Function

		' convert datareader to dataset
		Public Function ConvertDataReaderToDataTable(ByVal reader As IDataReader) As DataTable

			' create datatable from datareader
			Dim objDataTable As New DataTable
			Dim intFieldCount As Integer = reader.FieldCount
			Dim intCounter As Integer
			For intCounter = 0 To intFieldCount - 1
				objDataTable.Columns.Add(reader.GetName(intCounter), reader.GetFieldType(intCounter))
			Next intCounter

			' populate datatable
			objDataTable.BeginLoadData()
			Dim objValues(intFieldCount - 1) As Object
			While reader.Read()
				reader.GetValues(objValues)
				objDataTable.LoadDataRow(objValues, True)
			End While
			reader.Close()
			objDataTable.EndLoadData()

			Return objDataTable

		End Function

		' convert datareader to crosstab dataset
		Public Function BuildCrossTabDataSet(ByVal DataSetName As String, ByVal result As IDataReader, ByVal FixedColumns As String, ByVal VariableColumns As String, ByVal KeyColumn As String, ByVal FieldColumn As String, ByVal FieldTypeColumn As String, ByVal StringValueColumn As String, ByVal NumericValueColumn As String) As DataSet

			Dim arrFixedColumns As String()
			Dim arrVariableColumns As String()
			Dim arrField As String()
			Dim FieldName As String
			Dim FieldType As String
			Dim intColumn As Integer
			Dim intKeyColumn As Integer

			' create dataset
			Dim crosstab As New DataSet(DataSetName)
			crosstab.Namespace = "NetFrameWork"

			' create table
			Dim tab As New DataTable(DataSetName)

			' split fixed columns
			arrFixedColumns = FixedColumns.Split(",".ToCharArray())

			' add fixed columns to table
			For intColumn = LBound(arrFixedColumns) To UBound(arrFixedColumns)
				arrField = arrFixedColumns(intColumn).Split("|".ToCharArray())
				Dim col As New DataColumn(arrField(0), System.Type.GetType("System." & arrField(1)))
				tab.Columns.Add(col)
			Next intColumn

			' split variable columns
			If VariableColumns <> "" Then
				arrVariableColumns = VariableColumns.Split(",".ToCharArray())

				' add varible columns to table
				For intColumn = LBound(arrVariableColumns) To UBound(arrVariableColumns)
					arrField = arrVariableColumns(intColumn).Split("|".ToCharArray())
					Dim col As New DataColumn(arrField(0), System.Type.GetType("System." & arrField(1)))
					col.AllowDBNull = True
					tab.Columns.Add(col)
				Next intColumn
			End If

			' add table to dataset
			crosstab.Tables.Add(tab)

			' add rows to table
			intKeyColumn = -1
			Dim row As DataRow
			While result.Read()
				' loop using KeyColumn as control break
				If Convert.ToInt32(result(KeyColumn)) <> intKeyColumn Then
					' add row
					If intKeyColumn <> -1 Then
						tab.Rows.Add(row)
					End If

					' create new row
					row = tab.NewRow()

					' assign fixed column values
					For intColumn = LBound(arrFixedColumns) To UBound(arrFixedColumns)
						arrField = arrFixedColumns(intColumn).Split("|".ToCharArray())
						row(arrField(0)) = result(arrField(0))
					Next intColumn

					' initialize variable column values
					If VariableColumns <> "" Then
						For intColumn = LBound(arrVariableColumns) To UBound(arrVariableColumns)
							arrField = arrVariableColumns(intColumn).Split("|".ToCharArray())
							Select Case arrField(1)
								Case "Decimal"
									row(arrField(0)) = 0
								Case "String"
									row(arrField(0)) = ""
							End Select
						Next intColumn
					End If

					intKeyColumn = Convert.ToInt32(result(KeyColumn))
				End If

				' assign pivot column value
				If FieldTypeColumn <> "" Then
					FieldType = result(FieldTypeColumn).ToString
				Else
					FieldType = "String"
				End If
				Select Case FieldType
					Case "Decimal"					  ' decimal
						row(Convert.ToInt32(result(FieldColumn))) = result(NumericValueColumn)
					Case "String"					  ' string
						row(result(FieldColumn).ToString) = result(StringValueColumn)
				End Select
			End While

			result.Close()

			' add row
			If intKeyColumn <> -1 Then
				tab.Rows.Add(row)
			End If

			' finalize dataset
			crosstab.AcceptChanges()

			' return the dataset
			Return crosstab

		End Function

		Public Class FileItem
			Private _Value As String
			Private _Text As String

			Public Sub New(ByVal Value As String, ByVal Text As String)
				_Value = Value
				_Text = Text
			End Sub

			Public ReadOnly Property Value() As String
				Get
					Return _Value
				End Get
			End Property

			Public ReadOnly Property Text() As String
				Get
					Return _Text
				End Get
			End Property

		End Class

		' get list of files from folder matching criteria
		Public Function GetFileList(Optional ByVal PortalId As Integer = -1, Optional ByVal strExtensions As String = "", Optional ByVal NoneSpecified As Boolean = True, Optional ByVal Folder As String = "") As ArrayList
			Dim arrFileList As New ArrayList

			If NoneSpecified Then
				arrFileList.Add(New FileItem("", "<" + Services.Localization.Localization.GetString("None_Specified") + ">"))
			End If

			Dim objFiles As New FileController

			Dim dr As IDataReader = objFiles.GetFiles(PortalId, Folder)
			While dr.Read()
				If InStr(1, strExtensions.ToUpper, dr("Extension").ToString.ToUpper) <> 0 Or strExtensions = "" Then
					arrFileList.Add(New FileItem(dr("FileID").ToString, dr("FileName").ToString))
				End If
			End While
			dr.Close()

			GetFileList = arrFileList
		End Function

		' get list of files from folder matching criteria
		Public Function GetFileList(ByVal CurrentDirectory As DirectoryInfo, Optional ByVal strExtensions As String = "", Optional ByVal NoneSpecified As Boolean = True) As ArrayList
			Dim arrFileList As New ArrayList
			Dim strExtension As String

			If NoneSpecified Then
				arrFileList.Add(New FileItem("", "<" + Services.Localization.Localization.GetString("None_Specified") + ">"))
			End If

			Dim File As String
			Dim Files As String() = Directory.GetFiles(CurrentDirectory.FullName)
			For Each File In Files
				If Convert.ToBoolean(InStr(1, File, ".")) Then
					strExtension = Mid(File, InStrRev(File, ".") + 1)
				End If
				Dim FileName As String = File.Substring(CurrentDirectory.FullName.Length)
				If InStr(1, strExtensions.ToUpper, strExtension.ToUpper) <> 0 Or strExtensions = "" Then
					arrFileList.Add(New FileItem(FileName, FileName))
				End If
			Next

			GetFileList = arrFileList
		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' AddFile Uploads a single file
		''' </summary>
		''' <param name="strFileNamePath">The File Name of the File</param>
		''' <param name="strExtension">The extension of the file</param>
		''' <param name="strContentType">The mime type of the file</param>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''   [cnurse] 16/9/2004  Updated for localization, Help and 508
		'''   [Philip Beadle] 6 October 2004 Moved to Globals from WebUpload.ascx.vb so can be accessed by URLControl.ascx
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Sub AddFile(ByVal strFileNamePath As String, ByVal strExtension As String, Optional ByVal strContentType As String = "")

			' Obtain PortalSettings from Current Context
			Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings

			Dim strFileName As String = Path.GetFileName(strFileNamePath)
			Dim strFolderpath As String = GetSubFolderPath(strFileNamePath)

			If strContentType = "" Then
				Select Case strExtension
					Case "txt" : strContentType = "text/plain"
					Case "htm", "html" : strContentType = "text/html"
					Case "rtf" : strContentType = "text/richtext"
					Case "jpg", "jpeg" : strContentType = "image/jpeg"
					Case "gif" : strContentType = "image/gif"
					Case "bmp" : strContentType = "image/bmp"
					Case "mpg", "mpeg" : strContentType = "video/mpeg"
					Case "avi" : strContentType = "video/avi"
					Case "pdf" : strContentType = "application/pdf"
					Case "doc", "dot" : strContentType = "application/msword"
					Case "csv", "xls", "xlt" : strContentType = "application/x-msexcel"
					Case Else : strContentType = "application/octet-stream"
				End Select
			End If

			Dim imgImage As System.Drawing.Image
			Dim imageWidth As Integer
			Dim imageHeight As Integer

			'<bh> Added to lower to make case insenstive Bug # 266
			If Convert.ToBoolean(InStr(1, glbImageFileTypes & ",", strExtension.ToLower & ",")) Then
				Try
					imgImage = imgImage.FromFile(strFileNamePath)
					imageHeight = imgImage.Height
					imageWidth = imgImage.Width
					imgImage.Dispose()
				Catch
					' error loading image file
					strContentType = "application/octet-stream"
				End Try
			End If

			Dim objFiles As New FileController
			Dim finfo As New System.IO.FileInfo(strFileNamePath)
			If _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
				objFiles.AddFile(-1, strFileName, strExtension, finfo.Length, imageWidth, imageHeight, strContentType, strFolderpath)
			Else
				objFiles.AddFile(_portalSettings.PortalId, strFileName, strExtension, finfo.Length, imageWidth, imageHeight, strContentType, strFolderpath)
			End If

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Returns the folder path under the root for the portal 
		''' </summary>
		''' <param name="strFileNamePath">The folder the absolute path</param>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''   [cnurse] 16/9/2004  Updated for localization, Help and 508
		'''   [Philip Beadle] 6 October 2004 Moved to Globals from WebUpload.ascx.vb so can be accessed by URLControl.ascx
		''' </history>
		''' -----------

		Public Function GetSubFolderPath(ByVal strFileNamePath As String) As String
			' Obtain PortalSettings from Current Context
			Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
			Dim ParentFolderName As String
			If _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
				ParentFolderName = HttpContext.Current.Request.MapPath(Common.Globals.HostPath.Replace("/", "\"))
			Else
				ParentFolderName = HttpContext.Current.Request.MapPath(_portalSettings.HomeDirectory.Replace("/", "\"))
			End If
			Dim strFolderpath As String = strFileNamePath.Substring(0, strFileNamePath.LastIndexOf("\") + 1)

			GetSubFolderPath = strFolderpath.Substring(ParentFolderName.Length).Replace("\", "/")

		End Function
		''' -----------------------------------------------------------------------------
		''' <summary>
		''' UploadFile pocesses a single file 
		''' </summary>
		''' <param name="RootPath">The folder wherr the file will be put</param>
		''' <param name="HttpPostedFile">The file to upload</param>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''   [cnurse] 16/9/2004  Updated for localization, Help and 508
		'''   [Philip Beadle] 6 October 2004 Moved to Globals from WebUpload.ascx.vb so can be accessed by URLControl.ascx
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Function UploadFile(ByVal RootPath As String, ByVal objHtmlInputFile As HttpPostedFile, Optional ByVal Unzip As Boolean = False) As String

			' Obtain PortalSettings from Current Context
			Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
			Dim objPortalController As New PortalController
			Dim strMessage As String

			Dim strFileName As String = RootPath & Path.GetFileName(objHtmlInputFile.FileName)
			Dim strExtension As String = Replace(Path.GetExtension(strFileName), ".", "")

			If ((((objPortalController.GetPortalSpaceUsed(_portalSettings.PortalId) + objHtmlInputFile.ContentLength) / 1000000) <= _portalSettings.HostSpace) Or _portalSettings.HostSpace = 0) Or (_portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId) Then

				If InStr(1, "," & _portalSettings.HostSettings("FileExtensions").ToString.ToUpper, "," & strExtension.ToUpper) <> 0 Or _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
					'Save Uploaded file to server
					Try
						If File.Exists(strFileName) Then
							File.SetAttributes(strFileName, FileAttributes.Normal)
							File.Delete(strFileName)
						End If
						objHtmlInputFile.SaveAs(strFileName)
						'<bh> Added Tolower on extension to make case insenstive bug# 266
						If Path.GetExtension(strFileName).ToLower = ".zip" And Unzip = True Then
							strMessage += UnzipFiles(strFileName, RootPath)
						Else
							AddFile(strFileName, strExtension, objHtmlInputFile.ContentType)
						End If
					Catch Exc As Exception
						' save error - can happen if the security settings are incorrect
						strMessage += "<br>An Error Has Occurred When Attempting To Save The File " & strFileName & ". Please Contact Your Hosting Provider To Ensure The Appropriate Security Settings Have Been Enabled On The Server."
					End Try
				Else
					' restricted file type
					strMessage += "<br>The File " & strFileName & " Is A Restricted File Type. Valid File Types Include ( *." & Replace(_portalSettings.HostSettings("FileExtensions").ToString, ",", ", *.") & " ). Please Contact Your Hosting Provider If You Need To Upload A File Type Which Is Not Supported."
				End If
			Else			 ' file too large
				strMessage += "<br>The File " & strFileName & " Exceeds The Amount Of Disk Space You Currently Have Available. Please Contact Your Hosting Provider For Inquiries Related To Increasing Your Portal Disk Space."
			End If

			Return strMessage
		End Function

		Private Function UnzipFiles(ByVal strZIPFile As String, ByVal RootPath As String) As String

			' Obtain PortalSettings from Current Context
			Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
			Dim objPortalController As New PortalController

			' save zip file name
			Dim strMessage As String = ""
			Dim strFileName As String
			Dim strExtension As String

			Dim objZipEntry As ZipEntry
			Dim objZipInputStream As New ZipInputStream(File.OpenRead(strZIPFile))

			objZipEntry = objZipInputStream.GetNextEntry
			While Not objZipEntry Is Nothing
				If ((((objPortalController.GetPortalSpaceUsed(_portalSettings.PortalId) + objZipEntry.Size) / 1000000) <= _portalSettings.HostSpace) Or _portalSettings.HostSpace = 0) Or (_portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId) Then
					strFileName = Path.GetFileName(objZipEntry.Name)

					If strFileName <> "" Then
						strFileName = RootPath & strFileName

						strExtension = Path.GetExtension(strFileName).Replace(".", "")

						If InStr(1, "," & _portalSettings.HostSettings("FileExtensions").ToString, "," & strExtension) <> 0 Or _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
							If File.Exists(strFileName) Then
								File.SetAttributes(strFileName, FileAttributes.Normal)
								File.Delete(strFileName)
							End If
							Dim objFileStream As FileStream = File.Create(strFileName)

							Dim intSize As Integer = 2048
							Dim arrData(2048) As Byte

							intSize = objZipInputStream.Read(arrData, 0, arrData.Length)
							While intSize > 0
								objFileStream.Write(arrData, 0, intSize)
								intSize = objZipInputStream.Read(arrData, 0, arrData.Length)
							End While

							objFileStream.Close()

							AddFile(strFileName, strExtension)
						Else
							' restricted file type
							strMessage += "<br>The File " & strFileName & " Is A Restricted File Type. Valid File Types Include ( *." & Replace(_portalSettings.HostSettings("FileExtensions").ToString, ",", ", *.") & " ). Please Contact Your Hosting Provider If You Need To Upload A File Type Which Is Not Supported."
						End If
					End If
				Else				' file too large
					strMessage += "<br>The File " & strFileName & " Exceeds The Amount Of Disk Space You Currently Have Available. Please Contact Your Hosting Provider For Inquiries Related To Increasing Your Portal Disk Space."
				End If

				objZipEntry = objZipInputStream.GetNextEntry
			End While
			objZipInputStream.Close()

			' delete the zip file
			File.Delete(strZIPFile)

			Return strMessage
		End Function

		' format an address on a single line ( ie. Unit, Street, City, Region, Country, PostalCode )
		Public Function FormatAddress(ByVal Unit As Object, ByVal Street As Object, ByVal City As Object, ByVal Region As Object, ByVal Country As Object, ByVal PostalCode As Object) As String

			Dim strAddress As String = ""

			If Not Unit Is Nothing Then
				If Trim(Unit.ToString()) <> "" Then
					strAddress += ", " & Unit.ToString
				End If
			End If
			If Not Street Is Nothing Then
				If Trim(Street.ToString()) <> "" Then
					strAddress += ", " & Street.ToString
				End If
			End If
			If Not City Is Nothing Then
				If Trim(City.ToString()) <> "" Then
					strAddress += ", " & City.ToString
				End If
			End If
			If Not Region Is Nothing Then
				If Trim(Region.ToString()) <> "" Then
					strAddress += ", " & Region.ToString
				End If
			End If
			If Not Country Is Nothing Then
				If Trim(Country.ToString()) <> "" Then
					strAddress += ", " & Country.ToString
				End If
			End If
			If Not PostalCode Is Nothing Then
				If Trim(PostalCode.ToString()) <> "" Then
					strAddress += ", " & PostalCode.ToString
				End If
			End If
			If Trim(strAddress) <> "" Then
				strAddress = Mid(strAddress, 3)
			End If

			FormatAddress = strAddress

		End Function

		' format an email address including link
		Public Function FormatEmail(ByVal Email As String) As String

			If Not Email.Length = 0 Then
				If Trim(Email) <> "" Then
					If Email.IndexOf("@") <> -1 Then
						FormatEmail = "<a href=""mailto:" & Email & """>" & Email & "</a>"
					Else
						FormatEmail = Email
					End If
				End If
			End If

			Return CloakText(FormatEmail)

		End Function

		' format a domain name including link
		Public Function FormatWebsite(ByVal Website As Object) As String

			If Not IsDBNull(Website) Then
				If Trim(Website.ToString()) <> "" Then
					If Convert.ToBoolean(InStr(1, Website.ToString(), ".")) Then
						FormatWebsite = "<a href=""" & IIf(Convert.ToBoolean(InStr(1, Website.ToString(), "://")), "", "http://").ToString & Website.ToString() & """>" & Website.ToString() & "</a>"
					Else
						FormatWebsite = Website.ToString()
					End If
				End If
			End If

		End Function

		' obfuscate sensitive data to prevent collection by robots and spiders and crawlers
		Public Function CloakText(ByVal PersonalInfo As String) As String

			If Not PersonalInfo Is Nothing Then
				Dim sb As New StringBuilder

				' convert to ASCII character codes
				sb.Remove(0, sb.Length)
				Dim StringLength As Integer = PersonalInfo.Length - 1
				For i As Integer = 0 To StringLength
					sb.Append(Asc(PersonalInfo.Substring(i, 1)).ToString)
					If i < StringLength Then
						sb.Append(",")
					End If
				Next

				' build script block
				Dim sbScript As New StringBuilder

				sbScript.Append(vbCrLf & "<script language=""javascript"">" & vbCrLf)
				sbScript.Append("<!-- " & vbCrLf)
				sbScript.Append("   document.write(String.fromCharCode(" & sb.ToString & "))" & vbCrLf)
				sbScript.Append("// -->" & vbCrLf)
				sbScript.Append("</script>" & vbCrLf)

				Return sbScript.ToString
			Else : Return Null.NullString
			End If

		End Function

		Public Function GetPortalTabs(ByVal objDesktopTabs As ArrayList, Optional ByVal blnNoneSpecified As Boolean = False, Optional ByVal blnHidden As Boolean = False, Optional ByVal blnDeleted As Boolean = False, Optional ByVal blnURL As Boolean = False) As ArrayList

			Dim arrPortalTabs As ArrayList = New ArrayList
			Dim objTab As TabInfo

			If blnNoneSpecified Then
				objTab = New TabInfo
				objTab.TabID = -1
				objTab.TabName = "<" + Services.Localization.Localization.GetString("None_Specified") + ">"
				objTab.TabOrder = 0
				objTab.ParentId = -2
				arrPortalTabs.Add(objTab)
			End If

			Dim intCounter As Integer
			Dim strIndent As String

			For Each objTab In objDesktopTabs
                If IsAdminTab(objTab.TabID, objTab.ParentId) = False And (objTab.IsVisible = True Or blnHidden = True) And (objTab.IsDeleted = False Or blnDeleted = True) Then
                    Dim tabTemp As TabInfo = objTab.Clone
                    strIndent = ""
                    For intCounter = 1 To tabTemp.Level
                        strIndent += "..."
                    Next
                    tabTemp.TabName = strIndent & tabTemp.TabName
                    arrPortalTabs.Add(tabTemp)
                End If
            Next

			Return arrPortalTabs

		End Function

		' returns a SQL Server compatible date
		Public Function GetMediumDate(ByVal strDate As String) As String

			If strDate <> "" Then
				Dim datDate As Date = Convert.ToDateTime(strDate)

				Dim strYear As String = Year(datDate).ToString
				Dim strMonth As String = MonthName(Month(datDate), True)
				Dim strDay As String = Day(datDate).ToString

				strDate = strDay & "-" & strMonth & "-" & strYear
			End If

			Return strDate

		End Function

		' returns a SQL Server compatible date
		Public Function GetShortDate(ByVal strDate As String) As String

			If strDate <> "" Then
				Dim datDate As Date = Convert.ToDateTime(strDate)

				Dim strYear As String = Year(datDate).ToString
				Dim strMonth As String = Month(datDate).ToString
				Dim strDay As String = Day(datDate).ToString

				strDate = strMonth & "/" & strDay & "/" & strYear
			End If

			Return strDate

		End Function

		' returns a boolean value whether the tab is an admin tab
		Public Function IsAdminTab(ByVal intTabId As Integer, ByVal intParentId As Integer) As Boolean

			' Obtain PortalSettings from Current Context
			Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings

			Return (intTabId = _portalSettings.AdminTabId) Or _
			  (intParentId = _portalSettings.AdminTabId) Or _
			  (intTabId = _portalSettings.SuperTabId) Or _
			  (intParentId = _portalSettings.SuperTabId)

		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Returns whether the tab being displayed is in preview mode
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[Jon Henning]	9/16/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Function IsTabPreview() As Boolean
			Dim blnReturn As Boolean = False
			Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
			If Not HttpContext.Current.Request Is Nothing AndAlso Not HttpContext.Current.Request.Cookies("_Tab_Admin_Preview" & _portalSettings.PortalId.ToString) Is Nothing Then
				blnReturn = Boolean.Parse(HttpContext.Current.Request.Cookies("_Tab_Admin_Preview" & _portalSettings.PortalId.ToString).Value)
			End If
			Return blnReturn
		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Returns whether the currnet tab is in LayoutMode
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[Jon Henning]	9/16/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Function IsLayoutMode() As Boolean
			Dim blnReturn As Boolean = False
			Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
			If (PortalSecurity.IsInRole(_portalSettings.AdministratorRoleName.ToString) = True OrElse PortalSecurity.IsInRoles(_portalSettings.ActiveTab.AdministratorRoles.ToString) = True) AndAlso IsTabPreview() = False Then
				If IsAdminTab(_portalSettings.ActiveTab.TabID, _portalSettings.ActiveTab.ParentId) = False Then
					blnReturn = True
				End If
			End If
			Return blnReturn
		End Function

		' returns a boolean value whether the control is an admin control
		Public Function IsAdminControl() As Boolean

			Return (IsNothing(HttpContext.Current.Request.QueryString("mid")) = False) Or _
			 (IsNothing(HttpContext.Current.Request.QueryString("def")) = False) Or _
			 (IsNothing(HttpContext.Current.Request.QueryString("ctl")) = False)

		End Function

		' Deprecated PreventSQLInjection Function to consolidate Security Filter functions in the PortalSecurity class.
		Public Function PreventSQLInjection(ByVal strSQL As String) As String
			Return (New PortalSecurity).InputFilter(strSQL, PortalSecurity.FilterFlag.NoSQL)
		End Function

		' creates RRS files
		Public Sub CreateRSS(ByVal dr As IDataReader, ByVal TitleField As String, ByVal URLField As String, ByVal CreatedDateField As String, ByVal SyndicateField As String, ByVal DomainName As String, ByVal FileName As String)

			' Obtain PortalSettings from Current Context
			Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings

			' create RSS file
			Dim strRSS As String = ""

			Dim strRelativePath As String = DomainName & Replace(Mid(FileName, InStr(1, FileName, "\Portals")), "\", "/")
			strRelativePath = Left(strRelativePath, InStrRev(strRelativePath, "/"))

			While dr.Read()
				If Convert.ToBoolean(dr(SyndicateField)) Then
					strRSS += "      <item>" & ControlChars.CrLf
					strRSS += "         <title>" & dr(TitleField).ToString & "</title>" & ControlChars.CrLf
					If InStr(1, dr("URL").ToString, "://") = 0 Then
						If IsNumeric(dr("URL").ToString) Then
							strRSS += "         <link>" & DomainName & "/" & glbDefaultPage & "?tabid=" & dr(URLField).ToString & "</link>" & ControlChars.CrLf
						Else
							strRSS += "         <link>" & strRelativePath & dr(URLField).ToString & "</link>" & ControlChars.CrLf
						End If
					Else
						strRSS += "         <link>" & dr(URLField).ToString & "</link>" & ControlChars.CrLf
					End If
					strRSS += "         <description>" & _portalSettings.PortalName & " " & GetMediumDate(dr(CreatedDateField).ToString) & "</description>" & ControlChars.CrLf
					strRSS += "     </item>" & ControlChars.CrLf
				End If
			End While
			dr.Close()

			If strRSS <> "" Then
				strRSS = "<?xml version=""1.0"" encoding=""iso-8859-1""?>" & ControlChars.CrLf & _
				 "<rss version=""0.91"">" & ControlChars.CrLf & _
				 "  <channel>" & ControlChars.CrLf & _
				 "     <title>" & _portalSettings.PortalName & "</title>" & ControlChars.CrLf & _
				 "     <link>" & DomainName & "</link>" & ControlChars.CrLf & _
				 "     <description>" & _portalSettings.PortalName & "</description>" & ControlChars.CrLf & _
				 "     <language>en-us</language>" & ControlChars.CrLf & _
				 "     <copyright>" & _portalSettings.FooterText & "</copyright>" & ControlChars.CrLf & _
				 "     <webMaster>" & _portalSettings.Email & "</webMaster>" & ControlChars.CrLf & _
				 strRSS & _
				 "   </channel>" & ControlChars.CrLf & _
				 "</rss>"

				Dim objStream As StreamWriter
				objStream = File.CreateText(FileName)
				objStream.WriteLine(strRSS)
				objStream.Close()
			Else
				If File.Exists(FileName) Then
					File.Delete(FileName)
				End If
			End If

		End Sub

		' injects the upload directory into raw HTML for src and background tags
		Public Function ManageUploadDirectory(ByVal strHTML As String, ByVal strUploadDirectory As String) As String

			Dim P As Integer

			ManageUploadDirectory = ""

			If strHTML <> "" Then
				P = InStr(1, strHTML.ToLower, "src=""")
				While P <> 0
					ManageUploadDirectory = ManageUploadDirectory & Left(strHTML, P + 4)

					strHTML = Mid(strHTML, P + 5)

					' add uploaddirectory if we are linking internally
					If InStr(1, strHTML, "://") = 0 Then
						strHTML = strUploadDirectory & strHTML
					End If

					P = InStr(1, strHTML.ToLower, "src=""")
				End While
				ManageUploadDirectory = ManageUploadDirectory & strHTML

				strHTML = ManageUploadDirectory
				ManageUploadDirectory = ""

				P = InStr(1, strHTML.ToLower, "background=""")
				While P <> 0
					ManageUploadDirectory = ManageUploadDirectory & Left(strHTML, P + 11)

					strHTML = Mid(strHTML, P + 12)

					' add uploaddirectory if we are linking internally
					If InStr(1, strHTML, "://") = 0 Then
						strHTML = strUploadDirectory & strHTML
					End If

					P = InStr(1, strHTML.ToLower, "background=""")
				End While
			End If

			ManageUploadDirectory = ManageUploadDirectory & strHTML

		End Function

		' returns the database connection string
		Public Function GetDBConnectionString() As String

			Return ConfigurationSettings.AppSettings("SiteSqlServer")

		End Function

		' uses recursion to search the control hierarchy for a specific control based on controlname
		Public Function FindControlRecursive(ByVal objControl As Control, ByVal strControlName As String) As Control
			If objControl.Parent Is Nothing Then
				Return Nothing
			Else
				If Not objControl.Parent.FindControl(strControlName) Is Nothing Then
					Return objControl.Parent.FindControl(strControlName)
				Else
					Return FindControlRecursive(objControl.Parent, strControlName)
				End If
			End If
		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Searches control hierarchy from top down to find a control matching the passed in name
		''' </summary>
		''' <param name="objParent">Root control to begin searching</param>
		''' <param name="strControlName">Name of control to look for</param>
		''' <returns></returns>
		''' <remarks>
		''' This differs from FindControlRecursive in that it looks down the control hierarchy, whereas, the 
		''' FindControlRecursive starts at the passed in control and walks the tree up.  Therefore, this function is 
		''' more a expensive task.
		''' </remarks>
		''' <history>
		''' 	[Jon Henning]	9/17/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Function FindControlRecursiveDown(ByVal objParent As Control, ByVal strControlName As String) As Control
			Dim objCtl As Control
			Dim objChild As Control
			objCtl = objParent.FindControl(strControlName)
			If objCtl Is Nothing Then
				For Each objChild In objParent.Controls
					objCtl = FindControlRecursiveDown(objChild, strControlName)
					If Not objCtl Is Nothing Then Exit For
				Next
			End If
			Return objCtl
		End Function


		'set focus to any control
		Public Sub SetFormFocus(ByVal control As Control)
			If Not control.Page Is Nothing And control.Visible Then
				If control.Page.Request.Browser.JavaScript = True Then

					'JH dnn.js mod
					If DotNetNuke.UI.Utilities.ClientAPI.ClientAPIDisabled = False Then
						DotNetNuke.UI.Utilities.ClientAPI.RegisterClientReference(control.Page, DotNetNuke.UI.Utilities.ClientAPI.ClientNamespaceReferences.dnn)
						UI.Utilities.DNNClientAPI.AddBodyOnloadEventHandler(control.Page, "__dnn_SetInitialFocus('" & control.ClientID & "');")
					Else
						' Create JavaScript 
						Dim sb As New System.Text.StringBuilder
						sb.Append("<SCRIPT LANGUAGE='JavaScript'>")
						sb.Append("<!--")
						sb.Append(ControlChars.Lf)
						sb.Append("function SetInitialFocus() {")
						sb.Append(ControlChars.Lf)
						sb.Append(" document.")

						' Find the Form 
						Dim objParent As control = control.Parent
						While Not TypeOf objParent Is System.Web.UI.HtmlControls.HtmlForm
							objParent = objParent.Parent
						End While
						sb.Append(objParent.ClientID)
						sb.Append("['")
						sb.Append(control.UniqueID)
						sb.Append("'].focus(); }")
						sb.Append("window.onload = SetInitialFocus;")
						sb.Append(ControlChars.Lf)
						sb.Append("// -->")
						sb.Append(ControlChars.Lf)
						sb.Append("</SCRIPT>")

						' Register Client Script 
						control.Page.RegisterClientScriptBlock("InitialFocus", sb.ToString())
					End If
				End If
			End If
		End Sub

		Public Function GetExternalRequest(ByVal Address As String) As HttpWebRequest
			' Obtain PortalSettings from Current Context
			Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings

			' Create the request object
			Dim objRequest As HttpWebRequest = CType(WebRequest.Create(Address), HttpWebRequest)

			' Set a time out to the request ... 10 seconds
			If Not Common.Globals.HostSettings("WebRequestTimeout") Is Nothing Then
				objRequest.Timeout = Integer.Parse(CType(Common.Globals.HostSettings("WebRequestTimeout"), String))
			Else
				objRequest.Timeout = 10000
			End If

			' Attach a User Agent to the request
			objRequest.UserAgent = "DotNetNuke"

			' If there is Proxy info, apply it to the Request
			If CType(Common.Globals.HostSettings("ProxyServer"), String) <> "" Then

				' Create a new Proxy
				Dim Proxy As WebProxy

				' Create a new Network Credentials item
				Dim ProxyCredentials As NetworkCredential

				' Fill Proxy info from host settings
				Proxy = New WebProxy(CType(Common.Globals.HostSettings("ProxyServer"), String), Convert.ToInt32(Common.Globals.HostSettings("ProxyPort")))

				If Not CType(Common.Globals.HostSettings("ProxyUsername"), String) = "" Then
					' Fill the credential info from host settings
					ProxyCredentials = New NetworkCredential(CType(Common.Globals.HostSettings("ProxyUsername"), String), CType(Common.Globals.HostSettings("ProxyPassword"), String))

					'Apply credentials to proxy
					Proxy.Credentials = ProxyCredentials
				End If

				' Apply Proxy to Request
				objRequest.Proxy = Proxy

			End If
			Return objRequest
		End Function

		Public Function GetExternalRequest(ByVal Address As String, ByVal Credentials As NetworkCredential) As HttpWebRequest

			' Obtain PortalSettings from Current Context
			Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings

			' Create the request object
			Dim objRequest As HttpWebRequest = CType(WebRequest.Create(Address), HttpWebRequest)

			' Set a time out to the request ... 10 seconds
			If Not Common.Globals.HostSettings("WebRequestTimeout") Is Nothing Then
				objRequest.Timeout = Integer.Parse(CType(Common.Globals.HostSettings("WebRequestTimeout"), String))
			Else
				objRequest.Timeout = 10000
			End If

			' Attach a User Agent to the request
			objRequest.UserAgent = "DotNetNuke"

			' Attach supplied credentials
			If Not Credentials.UserName Is Nothing Then
				objRequest.Credentials = Credentials
			End If

			' If there is Proxy info, apply it to the Request
			If CType(Common.Globals.HostSettings("ProxyServer"), String) <> "" Then

				' Create a new Proxy
				Dim Proxy As WebProxy

				' Create a new Network Credentials item
				Dim ProxyCredentials As NetworkCredential

				' Fill Proxy info from host settings
				Proxy = New WebProxy(CType(Common.Globals.HostSettings("ProxyServer"), String), Convert.ToInt32(Common.Globals.HostSettings("ProxyPort")))

				If Not CType(Common.Globals.HostSettings("ProxyUsername"), String) = "" Then
					' Fill the credential info from host settings
					ProxyCredentials = New NetworkCredential(CType(Common.Globals.HostSettings("ProxyUsername"), String), CType(Common.Globals.HostSettings("ProxyPassword"), String))

					'Apply credentials to proxy
					Proxy.Credentials = ProxyCredentials
				End If

				' Apply Proxy to Request
				objRequest.Proxy = Proxy

			End If
			Return objRequest
		End Function

		Public Sub DeleteFolderRecursive(ByVal strRoot As String)
			If strRoot <> "" Then
				Dim strFolder As String
				If Directory.Exists(strRoot) Then
					For Each strFolder In Directory.GetDirectories(strRoot)
						DeleteFolderRecursive(strFolder)
					Next
					Dim strFile As String
					For Each strFile In Directory.GetFiles(strRoot)
						Try
							File.SetAttributes(strFile, FileAttributes.Normal)
							File.Delete(strFile)
						Catch
							' error deleting file
						End Try
					Next
					Try
						Directory.Delete(strRoot)
					Catch
						' error deleting folder
					End Try
				End If
			End If
		End Sub

		Public Function CreateValidID(ByVal strID As String) As String

			Dim strBadCharacters As String = " ./-\"

			Dim intIndex As Integer
			For intIndex = 0 To strBadCharacters.Length - 1
				strID = strID.Replace(strBadCharacters.Substring(intIndex, 1), "_")
			Next

			Return strID

		End Function

		Public Overloads Function ApplicationURL() As String

			' Obtain PortalSettings from Current Context
			Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings

			If Not _portalSettings Is Nothing Then
				Return (ApplicationURL(_portalSettings.ActiveTab.TabID))
			Else
				Return (ApplicationURL(-1))
			End If

		End Function

		Public Overloads Function ApplicationURL(ByVal TabID As Integer) As String

			Dim strURL As String = "~/" & glbDefaultPage

			If TabID <> -1 Then
				strURL += "?tabid=" & TabID.ToString
			End If

			Return strURL

		End Function

		<Browsable(False), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)> _
		Public Overloads Function NavigateURL() As String

			Return NavigateURL(Null.NullInteger, Null.NullString)

		End Function

		<Browsable(False), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)> _
		Public Overloads Function NavigateURL(ByVal TabID As Integer) As String

			Return NavigateURL(TabID, Null.NullString)

		End Function

		<Browsable(False), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)> _
		Public Overloads Function NavigateURL(ByVal ControlKey As String) As String

			Return NavigateURL(Null.NullInteger, ControlKey)

		End Function

		<Browsable(False), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)> _
		Public Overloads Function NavigateURL(ByVal TabID As Integer, ByVal ControlKey As String) As String

			Return NavigateURL(TabID, ControlKey, Nothing)

		End Function

		<Browsable(False), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)> _
		Public Overloads Function NavigateURL(ByVal TabID As Integer, ByVal ControlKey As String, ByVal ParamArray AdditionalParameters As String()) As String

			Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings

			Dim strURL As String
			If (TabID = Null.NullInteger) Then
				strURL = ApplicationURL()
			Else
				strURL = ApplicationURL(TabID)
			End If

			If ControlKey <> "" Then
				strURL += "&ctl=" & ControlKey
			End If

			If Not (AdditionalParameters Is Nothing) Then
				For Each parameter As String In AdditionalParameters
					strURL += "&" & parameter
				Next
			End If

			If Not (_portalSettings Is Nothing) Then
				If _portalSettings.ActiveTab.TabID = _portalSettings.SuperTabId Or _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then
					strURL += "&portalid=" & _portalSettings.ActiveTab.PortalID.ToString
				End If
			End If

			If DotNetNuke.Entities.Host.HostSettings.GetHostSetting("UseFriendlyUrls") = "Y" Then
				Return FriendlyUrl(strURL)
			Else
				Return ResolveUrl(strURL)
			End If

		End Function

		Public Function FriendlyUrl(ByVal path As String, ByVal pageName As String) As String

			Return DotNetNuke.Services.Url.FriendlyUrl.FriendlyUrlProvider.Instance().FriendlyUrl(path, pageName)

		End Function

		Public Function FriendlyUrl(ByVal path As String) As String

			Return DotNetNuke.Services.Url.FriendlyUrl.FriendlyUrlProvider.Instance().FriendlyUrl(path)

		End Function

		Public Function ResolveUrl(ByVal url As String) As String

			' String is Empty, just return Url
			If (url.Length = 0) Then
				Return url
			End If

			' String does not contain a ~, so just return Url
			If (url.StartsWith("~") = False) Then
				Return url
			End If

			' There is just the ~ in the Url, return the appPath
			If (url.Length = 1) Then
				Return Common.Globals.ApplicationPath
			End If

			If (url.ToCharArray()(1) = "/" Or url.ToCharArray()(1) = "\") Then

				' Url looks like ~/ or ~\
				If (Common.Globals.ApplicationPath.Length > 1) Then
					Return Common.Globals.ApplicationPath + "/" & url.Substring(2)
				Else
					Return "/" & url.Substring(2)
				End If

			Else

				' Url look like ~something
				If (Common.Globals.ApplicationPath.Length > 1) Then
					Return Common.Globals.ApplicationPath & "/" & url.Substring(1)
				Else
					Return Common.Globals.ApplicationPath & url.Substring(1)
				End If

			End If

		End Function

		Public Function QueryStringEncode(ByVal QueryString As String) As String
			QueryString = QueryString.Replace("/", "|")
			QueryString = QueryString.Replace("\", "|")
			QueryString = QueryString.Replace(".", "!")
			QueryString = HttpUtility.UrlEncode(QueryString)
			Return QueryString
		End Function

		Public Function QueryStringDecode(ByVal QueryString As String) As String
			QueryString = HttpUtility.UrlDecode(QueryString)
			QueryString = QueryString.Replace("|", "/")
			QueryString = QueryString.Replace("!", ".")
			Return QueryString
		End Function

		Public Function DateToString(ByVal DateValue As DateTime) As String
			Try
				If Not Null.IsNull(DateValue) Then
					Return DateValue.ToString("s")
				Else
					Return Null.NullString
				End If
			Catch ex As Exception

			End Try
		End Function

		Public Function GetHashValue(ByVal HashObject As Object, ByVal DefaultValue As String) As String
			If Not HashObject Is Nothing Then
				If Convert.ToString(HashObject) <> "" Then
					Return Convert.ToString(HashObject)
				Else
					Return DefaultValue
				End If
			Else
				Return DefaultValue
			End If
		End Function

		Public Function LinkClick(ByVal Link As String, ByVal TabID As Integer, ByVal ModuleID As Integer) As String
			Return LinkClick(Link, TabID, ModuleID, True)
		End Function

		Public Function LinkClick(ByVal Link As String, ByVal TabID As Integer, ByVal ModuleID As Integer, ByVal TrackClicks As Boolean) As String

			Dim strLink As String = Link

			If TrackClicks Then
				strLink = Common.Globals.ApplicationPath & "/LinkClick.aspx?link=" & HttpUtility.UrlEncode(strLink)

				' tabid is required to identify the portal where the click originated
				strLink += "&tabid=" & TabID.ToString

				' moduleid is used to identify the module where the url is stored
				If ModuleID <> -1 Then
					strLink += "&mid=" & ModuleID.ToString
				End If
			Else
				strLink = LinkClickURL(strLink)
			End If

			Return strLink

		End Function

		Public Function LinkClickURL(ByVal Link As String) As String
			Dim strLink As String = Link

			Select Case GetURLType(strLink)
				Case "T"
					strLink = Common.Globals.ApplicationPath & "/" & glbDefaultPage & "?tabid=" & Link
				Case "F"
					Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
					strLink = _portalSettings.HomeDirectory & Link
			End Select

			Return strLink
		End Function

		Public Function GetURLType(ByVal URL As String) As String
			If URL.IndexOf("://") = -1 And URL.StartsWith("~") = False And URL.StartsWith("\\") = False And URL.StartsWith("/") = False Then
				If IsNumeric(URL) Then
					Return "T"					  ' internal tab ( ie. 23 = tabid )
				Else
					Return "F"					  ' internal file ( ie. folder/file.ext )
				End If
			Else
				Return "U"				' external url ( eg. http://www.domain.com )
			End If
		End Function

		Public Function GetRoleName(ByVal RoleID As Integer) As String

			If Convert.ToString(RoleID) = glbRoleAllUsers Then
				Return "All Users"
			ElseIf Convert.ToString(RoleID) = glbRoleUnauthUser Then
				Return "Unauthenticated Users"
			End If

			Dim htRoles As Hashtable
			If Not Common.Globals.PerformanceSetting = Common.Globals.PerformanceSettings.NoCaching Then
				htRoles = CType(DataCache.GetCache("GetRoles"), Hashtable)
			End If

			If htRoles Is Nothing Then
				Dim objRoleController As New RoleController
				Dim arrRoles As ArrayList
				arrRoles = objRoleController.GetRoles()
				htRoles = New Hashtable
				Dim i As Integer
				For i = 0 To arrRoles.Count - 1
					Dim objRole As RoleInfo
					objRole = CType(arrRoles(i), RoleInfo)
					htRoles.Add(objRole.RoleID, objRole.RoleName)
				Next
				If Not Common.Globals.PerformanceSetting = Common.Globals.PerformanceSettings.NoCaching Then
					DataCache.SetCache("GetRoles", htRoles)
				End If
			End If
			Return CType(htRoles(RoleID), String)
		End Function

		Public Function XMLEncode(ByVal HTML As String) As String
			Return "<![CDATA[" & HTML & "]]>"
		End Function

		Public Function GetContent(ByVal Content As String, ByVal ContentType As String) As XmlNode
			Dim xmlDoc As New XmlDocument
			xmlDoc.LoadXml(Content)
			If ContentType = "" Then
				Return xmlDoc.DocumentElement
			Else
				Return xmlDoc.SelectSingleNode(ContentType)
			End If
		End Function

		Public Function GenerateTabPath(ByVal ParentId As Integer, ByVal TabName As String) As String
			Dim strTabPath As String = ""
			Dim objTabs As New TabController
			Dim objTab As TabInfo
			objTab = objTabs.GetTab(ParentId)
			Do While Not objTab Is Nothing
				strTabPath = "//" & objTab.TabName & strTabPath
				If Null.IsNull(objTab.ParentId) Then
					objTab = Nothing
				Else
					objTab = objTabs.GetTab(objTab.ParentId)
				End If
			Loop
			strTabPath = strTabPath & "//" & TabName
			Return strTabPath

		End Function
	End Module

End Namespace
