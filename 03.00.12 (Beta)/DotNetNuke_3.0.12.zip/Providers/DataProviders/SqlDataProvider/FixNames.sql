/**********************************************************************/
/* FixNames.sql                                                       */
/*                                                                    */
/* Fixes the Object Names                           */
/**********************************************************************/

/*************************************************************/
/* aspnet Updates											 */
/*************************************************************/

SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO

/*************************************************************/
/* Table Updates											 */
/*************************************************************/
--Remove all the Constraints, we don't know their exact names but we do know how the name starts
DECLARE @name varchar(64)

--Remove Foreign Keys
SET @name = (SELECT name from sysobjects WHERE name Like 'FK__aspnet_Me__Appli%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Membership] DROP CONSTRAINT ' + @name)
SET @name = (SELECT name from sysobjects WHERE name Like 'FK__aspnet_Me__UserI%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Membership] DROP CONSTRAINT ' + @name)
SET @name = (SELECT name from sysobjects WHERE name Like 'FK__aspnet_Pr__UserI%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Profile] DROP CONSTRAINT ' + @name)
SET @name = (SELECT name from sysobjects WHERE name Like 'FK__aspnet_Ro__Appli%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Roles] DROP CONSTRAINT ' + @name)
SET @name = (SELECT name from sysobjects WHERE name Like 'FK__aspnet_Us__RoleI%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_UsersInRoles] DROP CONSTRAINT ' + @name)
SET @name = (SELECT name from sysobjects WHERE name Like 'FK__aspnet_Us__UserI%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_UsersInRoles] DROP CONSTRAINT ' + @name)
SET @name = (SELECT name from sysobjects WHERE name Like 'FK__aspnet_Us__Appli%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Users] DROP CONSTRAINT ' + @name)
SET @name = (SELECT name from sysobjects WHERE name Like 'FK__aspnet_Ro__Appli%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Roles] DROP CONSTRAINT ' + @name)
SET @name = (SELECT name from sysobjects WHERE name Like 'FK__aspnet_Us__Appli%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Users] DROP CONSTRAINT ' + @name)

--Remove Default Constraints
SET @name = (SELECT name from sysobjects WHERE name Like 'DF__aspnet_Me__Passw%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Membership] DROP CONSTRAINT ' + @name)
SET @name = (SELECT name from sysobjects WHERE name Like 'DF__aspnet_Pr__LastU%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Profile] DROP CONSTRAINT ' + @name)
SET @name = (SELECT name from sysobjects WHERE name Like 'DF__aspnet_Ap__Appli%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Applications] DROP CONSTRAINT ' + @name)
SET @name = (SELECT name from sysobjects WHERE name Like 'DF__aspnet_Ro__RoleI%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Roles] DROP CONSTRAINT ' + @name)
SET @name = (SELECT name from sysobjects WHERE name Like 'DF__aspnet_Us__UserI%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Users] DROP CONSTRAINT ' + @name)
SET @name = (SELECT name from sysobjects WHERE name Like 'DF__aspnet_Us__Mobil%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Users] DROP CONSTRAINT ' + @name)
SET @name = (SELECT name from sysobjects WHERE name Like 'DF__aspnet_Us__IsAno%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Users] DROP CONSTRAINT ' + @name)

--Remove Unique Constraints
SET @name = (SELECT TOP 1 name from sysobjects WHERE name Like 'UQ__aspnet_Applicati%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Applications] DROP CONSTRAINT ' + @name)
SET @name = (SELECT TOP 1 name from sysobjects WHERE name Like 'UQ__aspnet_Applicati%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Applications] DROP CONSTRAINT ' + @name)

--Remove Primary Keys
SET @name = (SELECT TOP 1 name from sysobjects WHERE name Like 'PK__aspnet_Users%' ORDER BY name)
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Users] DROP CONSTRAINT ' + @name)
SET @name = (SELECT name from sysobjects WHERE name Like 'PK__aspnet_Membershi%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Membership] DROP CONSTRAINT ' + @name)
SET @name = (SELECT name from sysobjects WHERE name Like 'PK__aspnet_Profile%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Profile] DROP CONSTRAINT ' + @name)
SET @name = (SELECT name from sysobjects WHERE name Like 'PK__aspnet_Roles%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Roles] DROP CONSTRAINT ' + @name)
SET @name = (SELECT name from sysobjects WHERE name Like 'PK__aspnet_UsersInRo%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_UsersInRoles] DROP CONSTRAINT ' + @name)
SET @name = (SELECT name from sysobjects WHERE name Like 'PK__aspnet_Applicati%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_Applications] DROP CONSTRAINT ' + @name)
SET @name = (SELECT name from sysobjects WHERE name Like 'PK__aspnet_SchemaVer%')
IF Not @name Is Null
	EXEC ('ALTER TABLE [dbo].[aspnet_SchemaVersions] DROP CONSTRAINT ' + @name)

--End removal of Constraints
GO

-- Add primary Key Constraints
ALTER TABLE [dbo].[aspnet_Profile] ADD CONSTRAINT [PK__aspnet_Profile] PRIMARY KEY CLUSTERED  ([UserId])
ALTER TABLE [dbo].[aspnet_Applications] ADD CONSTRAINT [PK__aspnet_Applicatitions] PRIMARY KEY NONCLUSTERED  ([ApplicationId])
ALTER TABLE [dbo].[aspnet_Membership] ADD CONSTRAINT [PK__aspnet_Membership] PRIMARY KEY NONCLUSTERED  ([UserId])
ALTER TABLE [dbo].[aspnet_SchemaVersions] ADD CONSTRAINT [PK__aspnet_SchemaVersions] PRIMARY KEY CLUSTERED  ([Feature], [CompatibleSchemaVersion])
ALTER TABLE [dbo].[aspnet_UsersInRoles] ADD CONSTRAINT [PK__aspnet_UsersInRoles] PRIMARY KEY CLUSTERED  ([UserId], [RoleId])
ALTER TABLE [dbo].[aspnet_Roles] ADD CONSTRAINT [PK__aspnet_Roles] PRIMARY KEY NONCLUSTERED  ([RoleId])
ALTER TABLE [dbo].[aspnet_Users] ADD CONSTRAINT [PK__aspnet_Users] PRIMARY KEY NONCLUSTERED  ([UserId])

-- Add Unique Constraints
ALTER TABLE [dbo].[aspnet_Applications] ADD CONSTRAINT [UQ__aspnet_Applicatitions_ApplicationName] UNIQUE NONCLUSTERED  ([ApplicationName])
ALTER TABLE [dbo].[aspnet_Applications] ADD CONSTRAINT [UQ__aspnet_Applicatitions_LoweredApplicationName] UNIQUE NONCLUSTERED  ([LoweredApplicationName])

-- Add Default Constraints
ALTER TABLE [dbo].[aspnet_Membership] ADD CONSTRAINT [DF__aspnet_Membership_PasswordFormat] DEFAULT (0) FOR [PasswordFormat]
ALTER TABLE [dbo].[aspnet_Applications] ADD CONSTRAINT [DF__aspnet_Applications_ApplicationId] DEFAULT (newid()) FOR [ApplicationId]
ALTER TABLE [dbo].[aspnet_Roles] ADD CONSTRAINT [DF__aspnet_Roles_RoleId] DEFAULT (newid()) FOR [RoleId]
ALTER TABLE [dbo].[aspnet_Users] ADD CONSTRAINT [DF__aspnet_Users_UserId] DEFAULT (newid()) FOR [UserId]
ALTER TABLE [dbo].[aspnet_Users] ADD CONSTRAINT [DF__aspnet_Users_MobileAlias] DEFAULT (null) FOR [MobileAlias]
ALTER TABLE [dbo].[aspnet_Users] ADD CONSTRAINT [DF__aspnet_Users_IsAnonymous] DEFAULT (0) FOR [IsAnonymous]

-- Add Foreign Keys
ALTER TABLE [dbo].[aspnet_Membership] ADD
	CONSTRAINT [FK__aspnet_Membership_Applications] FOREIGN KEY ([ApplicationId]) REFERENCES [dbo].[aspnet_Applications] ([ApplicationId]),
	CONSTRAINT [FK__aspnet_Membership_Users] FOREIGN KEY ([UserId]) REFERENCES [dbo].[aspnet_Users] ([UserId])
ALTER TABLE [dbo].[aspnet_Profile] ADD CONSTRAINT [FK__aspnet_Profile_Users] FOREIGN KEY ([UserId]) REFERENCES [dbo].[aspnet_Users] ([UserId])
ALTER TABLE [dbo].[aspnet_Roles] ADD CONSTRAINT [FK__aspnet_Roles_Applications] FOREIGN KEY ([ApplicationId]) REFERENCES [dbo].[aspnet_Applications] ([ApplicationId])
ALTER TABLE [dbo].[aspnet_UsersInRoles] ADD
	CONSTRAINT [FK__aspnet_UsersInRoles_Roles] FOREIGN KEY ([RoleId]) REFERENCES [dbo].[aspnet_Roles] ([RoleId]),
	CONSTRAINT [FK__aspnet_UsersInRoles_Users] FOREIGN KEY ([UserId]) REFERENCES [dbo].[aspnet_Users] ([UserId])
ALTER TABLE [dbo].[aspnet_Applications] ALTER COLUMN [ApplicationId] [uniqueidentifier] NOT NULL
ALTER TABLE [dbo].[aspnet_Users] ADD CONSTRAINT [FK__aspnet_Users_Applications] FOREIGN KEY ([ApplicationId]) REFERENCES [dbo].[aspnet_Applications] ([ApplicationId])

GO

/************************************************************/
/*****              SqlDataProvider                     *****/
/************************************************************/