'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports DotNetNuke.Services.Search
Imports System
Imports System.Configuration
Imports System.Data
Imports System.XML

Namespace DotNetNuke.Modules.Events


    ''' -----------------------------------------------------------------------------
    ''' Namespace:  DotNetNuke.Modules.Events
    ''' Project:    DotNetNuke
    ''' Class:      EventController
    ''' -----------------------------------------------------------------------------
    ''' <summary>
  ''' The EventController Class represents the Events Business Layer
  ''' Methods in this class call methods in the Data Layer
  ''' </summary>
  ''' <returns></returns>
  ''' <remarks>
  ''' </remarks>
  ''' <history>
  ''' 	[cnurse]	9/22/2004	Moved Events to a separate Project
  ''' </history>
  ''' -----------------------------------------------------------------------------
    Public Class EventController
        Implements Entities.Modules.ISearchable
        Implements Entities.Modules.IPortable

#Region "Public Methods"

        Public Sub AddEvent(ByVal objEvent As EventInfo)

            DataProvider.Instance().AddEvent(objEvent.ModuleId, objEvent.Description, objEvent.DateTime, objEvent.Title, objEvent.ExpireDate, objEvent.CreatedByUser, objEvent.Every, objEvent.Period, objEvent.IconFile, objEvent.AltText)

        End Sub

        Public Sub DeleteEvent(ByVal ItemID As Integer)

            DataProvider.Instance().DeleteEvent(ItemID)

        End Sub

        Public Function GetEvent(ByVal ItemId As Integer, ByVal ModuleId As Integer) As EventInfo

            Return CType(CBO.FillObject(DataProvider.Instance().GetEvent(ItemId, ModuleId), GetType(EventInfo)), EventInfo)

        End Function


        Public Function GetEvents(ByVal ModuleId As Integer, ByVal StartDate As Date, ByVal EndDate As Date) As ArrayList

            If (Not Common.Utilities.Null.IsNull(StartDate)) And (Not Common.Utilities.Null.IsNull(EndDate)) Then

                Return CBO.FillCollection(DataProvider.Instance().GetEventsByDate(ModuleId, StartDate, EndDate), GetType(EventInfo))
            Else
                Return CBO.FillCollection(DataProvider.Instance().GetEvents(ModuleId), GetType(EventInfo))
            End If

        End Function

        Public Sub UpdateEvent(ByVal objEvent As EventInfo)

            DataProvider.Instance().UpdateEvent(objEvent.ItemId, objEvent.Description, objEvent.DateTime, objEvent.Title, objEvent.ExpireDate, objEvent.CreatedByUser, objEvent.Every, objEvent.Period, objEvent.IconFile, objEvent.AltText)

        End Sub

#End Region

#Region "Optional Interfaces"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetSearchItems implements the ISearchable Interface
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModInfo">The ModuleInfo for the module to be Indexed</param>
        ''' <history>
        '''		[cnurse]	11/17/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems

            Dim SearchItemCollection As New SearchItemInfoCollection

            Dim Events As ArrayList = GetEvents(ModInfo.ModuleID, Convert.ToDateTime(Common.Utilities.Null.NullDate), Convert.ToDateTime(Common.Utilities.Null.NullDate))

            Dim objEvents As Object
            For Each objEvents In Events
                Dim SearchItem As SearchItemInfo
                With CType(objEvents, EventInfo)
                    Dim UserId As Integer = Null.NullInteger
                    If IsNumeric(.CreatedByUser) Then
                        UserId = Integer.Parse(.CreatedByUser)
                    End If

                    Dim strContent As String = System.Web.HttpUtility.HtmlDecode(.Title & " " & .Description)
                    Dim strDescription As String = HtmlUtils.Shorten(HtmlUtils.Clean(System.Web.HttpUtility.HtmlDecode(.Description), False), 100, "...")

                    SearchItem = New SearchItemInfo(ModInfo.ModuleTitle & " - " & .Title, strDescription, UserId, .CreatedDate, ModInfo.ModuleID, .ItemId.ToString, strContent, "ItemId=" & .ItemId.ToString)
                    SearchItemCollection.Add(SearchItem)
                End With
            Next

            Return SearchItemCollection

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ExportModule implements the IPortable ExportModule Interface
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModuleID">The Id of the module to be exported</param>
        ''' <history>
        '''		[cnurse]	11/17/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
            Dim strXML As String = ""

            Dim arrEvents As ArrayList = GetEvents(ModuleID, Convert.ToDateTime(Common.Utilities.Null.NullDate), Convert.ToDateTime(Common.Utilities.Null.NullDate))
            If arrEvents.Count <> 0 Then
                strXML += "<events>"
                Dim objEvent As EventInfo
                For Each objEvent In arrEvents
                    strXML += "<event>"
                    strXML += "<description>" & XMLEncode(objEvent.Description) & "</description>"
                    strXML += "<datetime>" & XMLEncode(objEvent.DateTime.ToString) & "</datetime>"
                    strXML += "<title>" & XMLEncode(objEvent.Title) & "</title>"
                    strXML += "<icon>" & XMLEncode(objEvent.IconFile) & "</icon>"
                    strXML += "<occursevery>" & XMLEncode(objEvent.Every.ToString) & "</occursevery>"
                    strXML += "<alttext>" & XMLEncode(objEvent.AltText) & "</alttext>"
                    strXML += "<expires>" & XMLEncode(objEvent.ExpireDate.ToString) & "</expires>"
                    strXML += "<maxWidth>" & XMLEncode(objEvent.MaxWidth.ToString) & "</maxWidth>"
                    strXML += "<period>" & XMLEncode(objEvent.Period) & "</period>"
                    strXML += "</event>"
                Next
                strXML += "</events>"
            End If

            Return strXML

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ImportModule implements the IPortable ImportModule Interface
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModuleID">The Id of the module to be imported</param>
        ''' <history>
        '''		[cnurse]	11/17/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserId As Integer) Implements Entities.Modules.IPortable.ImportModule
            Dim xmlEvent As XmlNode
            Dim xmlEvents As XmlNode = GetContent(Content, "events")
            For Each xmlEvent In xmlEvents.SelectNodes("event")
                Dim objEvent As New EventInfo
                objEvent.ModuleId = ModuleID
                objEvent.Description = xmlEvent.Item("description").InnerText
                objEvent.DateTime = Date.Parse(xmlEvent.Item("datetime").InnerText)
                objEvent.Title = xmlEvent.Item("title").InnerText
                objEvent.IconFile = ImportUrl(ModuleID, xmlEvent.Item("icon").InnerText)
                objEvent.Every = Integer.Parse(xmlEvent.Item("occursevery").InnerText)
                objEvent.AltText = xmlEvent.Item("alttext").InnerText
                objEvent.ExpireDate = Date.Parse(xmlEvent.Item("expires").InnerText)
                objEvent.MaxWidth = Integer.Parse(xmlEvent.Item("maxWidth").InnerText)
                objEvent.Period = xmlEvent.Item("period").InnerText
                objEvent.CreatedByUser = UserId.ToString
                AddEvent(objEvent)
            Next

        End Sub

#End Region

    End Class

End Namespace