'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.Services.Search
Imports System
Imports System.Configuration
Imports System.Data

Imports DotNetNuke


Namespace DotNetNuke.Modules.Discussions


    ''' -----------------------------------------------------------------------------
    ''' Namespace:  DotNetNuke.Modules.Discussions
    ''' Project:    DotNetNuke
    ''' Class:      DiscussionController
    ''' -----------------------------------------------------------------------------
    ''' <summary>
  ''' The DiscussionController Class represents the Disscussions Business Layer
  ''' Methods in this class call methods in the Data Layer
  ''' </summary>
  ''' <returns></returns>
  ''' <remarks>
  ''' </remarks>
  ''' <history>
  ''' 	[cnurse]	9/21/2004	Moved Disscussions to a separate Project
  ''' </history>
  ''' -----------------------------------------------------------------------------
    Public Class DiscussionController
        Implements Entities.Modules.ISearchable

#Region "Public Methods"

        Public Sub AddMessage(ByVal objDiscussion As DiscussionInfo)

            objDiscussion.DisplayOrder = ""
            Dim dr As IDataReader = DataProvider.Instance().GetMessageByParentId(objDiscussion.ParentID)
            If dr.Read Then
                If Not IsDBNull(dr("DisplayOrder")) Then
                    objDiscussion.DisplayOrder = Convert.ToString(dr("DisplayOrder"))
                End If
            End If
            dr.Close()

            Dim objSecurity As New Security.PortalSecurity
            'objSecurity.InputFilter removed, this is handled in the BLL
            DataProvider.Instance().AddMessage(objDiscussion.Title, objDiscussion.Body, objDiscussion.DisplayOrder & Now.ToString("s"), objDiscussion.CreatedByUser, objDiscussion.ModuleID)

        End Sub

        Public Sub DeleteMessage(ByVal ItemId As Integer, ByVal ModuleId As Integer)

            Dim dr As IDataReader = DataProvider.Instance().GetMessage(ItemId, ModuleId)
            If dr.Read Then
                Dim Start As Integer = Len(dr("DisplayOrder")) - 18
                DataProvider.Instance().DeleteMessage(ModuleId, Start, Mid(Convert.ToString(dr("DisplayOrder")), Start, 19))
            End If
            dr.Close()

        End Sub

        Public Function GetMessage(ByVal ItemId As Integer, ByVal ModuleId As Integer) As DiscussionInfo

            Return CType(CBO.FillObject(DataProvider.Instance().GetMessage(ItemId, ModuleId), GetType(DiscussionInfo)), DiscussionInfo)

        End Function

        Public Function GetThreadMessages(ByVal Parent As String) As ArrayList

            Return CBO.FillCollection(DataProvider.Instance().GetThreadMessages(Parent), GetType(DiscussionInfo))

        End Function

        Public Function GetTopLevelMessages(ByVal ModuleId As Integer) As ArrayList

            Return CBO.FillCollection(DataProvider.Instance().GetTopLevelMessages(ModuleId), GetType(DiscussionInfo))

        End Function

        Public Sub UpdateMessage(ByVal objDiscussion As DiscussionInfo)

            Dim objSecurity As New Security.PortalSecurity
            'objSecurity.InputFilter removed, this is handled in the BLL
            DataProvider.Instance().UpdateMessage(objDiscussion.ItemID, objDiscussion.Title, objDiscussion.Body, objDiscussion.CreatedByUser)

        End Sub

#End Region

#Region "Optional Interfaces"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetSearchItems implements the ISearchable Interface
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModInfo">The ModuleInfo for the module to be Indexed</param>
        ''' <history>
        '''		[cnurse]	11/17/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            Dim SearchItemCollection As New SearchItemInfoCollection

            Dim TopLevelMessages As ArrayList = GetTopLevelMessages(ModInfo.ModuleID)

            Dim objTopLevelMessage As Object
            For Each objTopLevelMessage In TopLevelMessages
                Dim SearchItem As SearchItemInfo
                With CType(objTopLevelMessage, DiscussionInfo)
                    Dim UserId As Integer = Null.NullInteger
                    If IsNumeric(.CreatedByUser) Then
                        UserId = Integer.Parse(.CreatedByUser)
                    End If

                    Dim strContent As String = System.Web.HttpUtility.HtmlDecode(.Title & " " & .Body)
                    Dim strDescription As String = HtmlUtils.Shorten(HtmlUtils.Clean(System.Web.HttpUtility.HtmlDecode(.Body), False), 100, "...")

                    SearchItem = New SearchItemInfo(ModInfo.ModuleTitle & " - " & .Title, strDescription, UserId, .CreatedDate, ModInfo.ModuleID, .ItemID.ToString, strContent, "ItemId=" & .ItemID.ToString)
                    SearchItemCollection.Add(SearchItem)
                End With
            Next

            Return SearchItemCollection
        End Function


#End Region

    End Class

End Namespace
