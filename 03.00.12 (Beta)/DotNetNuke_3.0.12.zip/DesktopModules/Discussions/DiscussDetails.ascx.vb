'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports DotNetNuke
Imports System.Web.UI.WebControls

Namespace DotNetNuke.Modules.Discussions

  ''' -----------------------------------------------------------------------------
  ''' <summary>
	''' The DiscussDetails PortalModuleBase is used to manage the discussions
	''' </summary>
	''' <returns></returns>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[cnurse]	9/21/2004	Moved Discussions to a separate Project
	''' 	[cnurse]	9/21/2004	Updated to reflect design changes for Help, 508 support
    '''                       and localisation
    '''     [cnurse]    12/15/2004  converted to use TextEditor
	''' </history>
	''' -----------------------------------------------------------------------------
	Public MustInherit Class DiscussDetails
		Inherits Entities.Modules.PortalModuleBase

#Region "Controls"

		'New Message
		Protected plTitleField As UI.UserControls.LabelControl
		Protected WithEvents TitleField As System.Web.UI.WebControls.TextBox
		Protected WithEvents valTitleField As System.Web.UI.WebControls.RequiredFieldValidator
		Protected plBodyField As UI.UserControls.LabelControl
        Protected WithEvents teBodyField As UI.UserControls.TextEditor
        Protected WithEvents valBodyField As System.Web.UI.WebControls.RequiredFieldValidator

        Protected WithEvents cmdSubmit As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
		Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton

		Protected WithEvents EditPanel As System.Web.UI.WebControls.Panel
		Protected WithEvents Subject As System.Web.UI.WebControls.Label
		Protected WithEvents CreatedByUser As System.Web.UI.WebControls.Label
		Protected WithEvents CreatedDate As System.Web.UI.WebControls.Label
		Protected WithEvents Body As System.Web.UI.WebControls.Label
		Protected WithEvents cmdCancel2 As System.Web.UI.WebControls.LinkButton
		Protected WithEvents cmdEdit As System.Web.UI.WebControls.LinkButton
		Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
		Protected WithEvents cmdReply As System.Web.UI.WebControls.LinkButton
		Protected WithEvents tblOriginalMessage As System.Web.UI.HtmlControls.HtmlTable
		Protected WithEvents rowOriginalMessage As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents lblSubject As System.Web.UI.WebControls.Label
        Protected WithEvents lblAuthor As System.Web.UI.WebControls.Label
        Protected WithEvents lblDate As System.Web.UI.WebControls.Label
        Protected WithEvents lblBody As System.Web.UI.WebControls.Label

#End Region

#Region "Private Members"

		Private itemId As Integer
        Protected WithEvents BodyField As System.Web.UI.WebControls.TextBox
        Private itemIndex As Integer

#End Region

#Region "Private Methods"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' ReTitle formats the subject title correctly
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <param name="title">The title to format</param>
		''' <returns>The correctly formatted subject heading</returns>
		''' <history>
		''' 	[cnurse]	9/21/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Function ReTitle(ByVal title As String) As String
			Try
				If title.Length > 0 And title.IndexOf("Re: ", 0) = -1 Then
					title = "Re: " & title
				End If

				Return title
			Catch exc As Exception		  'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Function

#End Region

#Region "Event Handlers"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Page_Load runs when the control is loaded
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/21/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try
                If Not (Request.QueryString("ItemIndex") Is Nothing) Then
                    itemIndex = Int32.Parse(Request.QueryString("ItemIndex"))
                Else
                    itemIndex = Convert.ToInt32(Common.Utilities.Null.NullInteger)
                End If

                If Not (Request.QueryString("ItemId") Is Nothing) Then
                    itemId = Int32.Parse(Request.QueryString("ItemId"))
                Else
                    itemId = Convert.ToInt32(Common.Utilities.Null.NullInteger)
                End If

                ' Populate message contents if this is the first visit to the page
                If Page.IsPostBack = False Then

                    If Not Security.PortalSecurity.IsInRoles(Me.ModuleConfiguration.AuthorizedEditRoles) Then
                        cmdEdit.Visible = False
                        cmdDelete.Visible = False
                    Else
                        cmdDelete.Attributes.Add("onClick", "javascript:return confirm('" & Localization.GetString("DeleteItem") & "');")
                    End If

                    If Not Common.Utilities.Null.IsNull(itemId) Then
                        ' Obtain the selected item from the Discussion table
                        Dim objDiscussionController As New DiscussionController
                        Dim objDiscussionMessageInfo As DiscussionInfo = objDiscussionController.GetMessage(itemId, ModuleId)

                        ' Load row from database
                        If Not objDiscussionMessageInfo Is Nothing Then
                            Dim objSecurity As New Security.PortalSecurity
                            Subject.Text = objDiscussionMessageInfo.Title
                            Body.Text = Server.HtmlDecode(CType(objDiscussionMessageInfo.Body, String))
                            CreatedByUser.Text = objDiscussionMessageInfo.CreatedByUser
                            CreatedDate.Text = String.Format("{0:d}", objDiscussionMessageInfo.CreatedDate)
                            TitleField.Text = objDiscussionMessageInfo.Title
                            teBodyField.Text = objDiscussionMessageInfo.Body
                        Else       ' security violation attempt to access item not related to this Module
                            Response.Redirect(NavigateURL(), True)
                        End If
                    Else
                        EditPanel.Visible = True
                        tblOriginalMessage.Visible = False
                    End If

                End If

                If Security.PortalSecurity.HasEditPermissions(ModuleConfiguration.ModulePermissions) = False Then

                    If Common.Utilities.Null.IsNull(itemId) Then
                        Response.Redirect(NavigateURL(), True)
                    Else
                        cmdReply.Visible = False
                    End If

                End If
            Catch exc As Exception    'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdCancel_Click runs when the Cancel Button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/21/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click, cmdCancel2.Click
			Try
				If (Common.Utilities.Null.IsNull(itemIndex)) Then
					Response.Redirect(NavigateURL(), True)
				Else
                    Response.Redirect(NavigateURL(TabId, "", "ItemIndex=" & Convert.ToString(itemIndex)), True)
				End If
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdDelete_Click runs when the Delete Button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/21/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
			Try
				' Create new discussion database component
				Dim objDiscussionController As New DiscussionController
				objDiscussionController.DeleteMessage(itemId, ModuleId)

				If (Common.Utilities.Null.IsNull(itemIndex)) Then
					Response.Redirect(NavigateURL(), True)
				Else
                    Response.Redirect(NavigateURL(TabId, "", "ItemIndex=" & Convert.ToString(itemIndex)), True)
				End If
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdEdit_Click runs when the Edit Button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/21/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
			Try
                EditPanel.Visible = True
                teBodyField.Text = Body.Text
                cmdSubmit.Visible = False
                cmdUpdate.Visible = True
				rowOriginalMessage.Visible = True
				cmdReply.Visible = False
				cmdCancel2.Visible = False
				cmdEdit.Visible = False
				cmdDelete.Visible = False
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdReply_Click runs when the Reply Button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/21/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdReply_Click(ByVal Sender As Object, ByVal e As EventArgs) Handles cmdReply.Click
			Try
                TitleField.Text = ReTitle(TitleField.Text)
                teBodyField.Text = ""
                EditPanel.Visible = True
                cmdSubmit.Visible = True
                cmdUpdate.Visible = False
				rowOriginalMessage.Visible = True
				cmdReply.Visible = False
				cmdCancel2.Visible = False
				cmdEdit.Visible = False
				cmdDelete.Visible = False
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdUpdate_Click runs when the Update Button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/21/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                ' Only Update if the Entered Data is Valid
                If Page.IsValid = True Then
                    Dim objDiscussion As New DiscussionInfo
                    Dim objSecurity As New Security.PortalSecurity

                    objDiscussion = CType(CBO.InitializeObject(objDiscussion, GetType(DiscussionInfo)), DiscussionInfo)

                    objDiscussion.ItemID = itemId
                    objDiscussion.ModuleID = ModuleId
                    objDiscussion.Title = objSecurity.InputFilter(TitleField.Text, Security.PortalSecurity.FilterFlag.NoMarkup Or Security.PortalSecurity.FilterFlag.MultiLine)
                    objDiscussion.Body = objSecurity.InputFilter(teBodyField.Text, Security.PortalSecurity.FilterFlag.NoMarkup Or Security.PortalSecurity.FilterFlag.MultiLine)
                    objDiscussion.CreatedByUser = UserInfo.UserID.ToString

                    ' Create new discussion database component
                    Dim objDiscussionController As New DiscussionController
                    objDiscussionController.UpdateMessage(objDiscussion)

                    If itemIndex <> -1 Then
                        Response.Redirect(NavigateURL(), True)
                    Else
                        Response.Redirect(NavigateURL(TabId, "", "ItemIndex=" & itemIndex), True)
                    End If
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
		End Sub

        Private Sub cmdSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSubmit.Click
            Try
                If Page.IsValid = True Then
                    Dim objDiscussion As New DiscussionInfo
                    Dim objSecurity As New Security.PortalSecurity

                    objDiscussion = CType(CBO.InitializeObject(objDiscussion, GetType(DiscussionInfo)), DiscussionInfo)

                    objDiscussion.ItemID = itemId
                    objDiscussion.ModuleID = ModuleId
                    'Issue #99 Modified to correctly update input text using Security.PortalSecurity helper functions
                    objDiscussion.Title = objSecurity.InputFilter(TitleField.Text, Security.PortalSecurity.FilterFlag.NoMarkup Or Security.PortalSecurity.FilterFlag.MultiLine)
                    objDiscussion.Body = objSecurity.InputFilter(teBodyField.Text, Security.PortalSecurity.FilterFlag.NoMarkup Or Security.PortalSecurity.FilterFlag.MultiLine)
                    objDiscussion.CreatedByUser = UserInfo.UserID.ToString
                    If Not Common.Utilities.Null.IsNull(itemId) Then
                        objDiscussion.ParentID = itemId
                    End If

                    ' Create new discussion database component
                    Dim objDiscussionController As New DiscussionController
                    objDiscussionController.AddMessage(objDiscussion)

                    If itemIndex <> -1 Then
                        Response.Redirect(NavigateURL(), True)
                    Else
                        Response.Redirect(NavigateURL(TabId, "", "ItemIndex=" & itemIndex), True)
                    End If
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

    End Class

End Namespace
