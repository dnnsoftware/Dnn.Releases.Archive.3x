'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports ICSharpCode.SharpZipLib.Zip
Imports System.IO
Imports System.Text
Imports DotNetNuke.Entities.Modules

Namespace DotNetNuke.Modules.Admin.ResourceInstaller
	Public Class PaDnnInstaller_V3
		Inherits PaDnnInstallerBase

		Public Sub New(ByVal InstallerInfo As PaInstallInfo)
			MyBase.New(InstallerInfo)
		End Sub


		Protected Overrides Function GetDesktopModuleSettings(ByVal objDesktopModule As DesktopModuleInfo, ByVal Folder As PaFolder) As Entities.Modules.DesktopModuleInfo

            ' call the V2 implementation to load the values
            objDesktopModule = MyBase.GetDesktopModuleSettings(objDesktopModule, Folder)

            ' V3 .dnn file format adds the optional businesscontrollerclass node to the folder node element
            objDesktopModule.BusinessControllerClass = Folder.BusinessControllerClass

			Return objDesktopModule
		End Function

		Protected Overrides Function UpgradeModule(ByVal ModuleInfo As Entities.Modules.DesktopModuleInfo) As String
			Dim Results As String
			If ModuleInfo.BusinessControllerClass <> "" Then
				Try
					Dim objObject As Object = Framework.Reflection.CreateObject(ModuleInfo.BusinessControllerClass, ModuleInfo.BusinessControllerClass)

					If TypeOf objObject Is IUpgradeable Then
						For Each Version As String In UpgradeVersions
							Results &= CType(objObject, IUpgradeable).UpgradeModule(Version)
						Next
					End If
				Catch ex As Exception
					LogException(ex)
				End Try
			End If
			Return Results
		End Function
	End Class
End Namespace
