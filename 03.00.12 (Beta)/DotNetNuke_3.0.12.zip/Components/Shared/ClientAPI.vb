'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.UI

Namespace DotNetNuke.UI.Utilities

	''' -----------------------------------------------------------------------------
	''' Project	 : DotNetNuke
	''' Class	 : ClientAPI
	''' 
	''' -----------------------------------------------------------------------------
	''' <summary>
	''' Library responsible for interacting with DNN Client API.
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[Jon Henning]	8/3/2004	Created
	''' </history>
	''' -----------------------------------------------------------------------------
	Public Class DNNClientAPI

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Adds client side body.onload event handler 
		''' </summary>
		''' <param name="objPage">Current page rendering content</param>
		''' <param name="strJSFunction">Javascript function name to execute</param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[Jon Henning]	8/3/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Shared Sub AddBodyOnloadEventHandler(ByVal objPage As Page, ByVal strJSFunction As String)
			If strJSFunction.EndsWith(";") = False Then strJSFunction &= ";"
			If DotNetNuke.UI.Utilities.ClientAPI.GetClientVariable(objPage, "__dnn_pageload").IndexOf(strJSFunction) = -1 Then DotNetNuke.UI.Utilities.ClientAPI.RegisterClientVariable(objPage, "__dnn_pageload", strJSFunction, False)
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Allows any module to have drag and drop functionality enabled
		''' </summary>
		''' <param name="objTitle">Title element that responds to the click and dragged</param>
		''' <param name="objContainer"></param>
		''' <remarks>
		''' This sub also will send down information to notify the client of the panes that have been defined in the current skin.
		''' </remarks>
		''' <history>
		''' 	[Jon Henning]	8/9/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Shared Sub EnableContainerDragAndDrop(ByVal objTitle As Control, ByVal objContainer As Control, ByVal ModuleID As Integer)
			If DotNetNuke.UI.Utilities.ClientAPI.ClientAPIDisabled() = False AndAlso DotNetNuke.UI.Utilities.ClientAPI.BrowserSupportsFunctionality(DotNetNuke.UI.Utilities.ClientAPI.ClientFunctionality.Positioning) Then
				DNNClientAPI.AddBodyOnloadEventHandler(objTitle.Page, "__dnn_enableDragDrop()")
				DotNetNuke.UI.Utilities.ClientAPI.RegisterClientReference(objTitle.Page, DotNetNuke.UI.Utilities.ClientAPI.ClientNamespaceReferences.dnn_dom_positioning)
				DotNetNuke.UI.Utilities.ClientAPI.RegisterClientVariable(objTitle.Page, "__dnn_dragDrop", objContainer.ClientID & " " & objTitle.ClientID & " " & ModuleID.ToString & ";", False)

				Dim strPanes As String = ""
				Dim strPaneNames As String = ""
				Dim objPortalSettings As DotNetNuke.Entities.Portals.PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), DotNetNuke.Entities.Portals.PortalSettings)
				Dim strPane As String
				Dim objCtl As Control
				For Each strPane In objPortalSettings.ActiveTab.Panes
					objCtl = DotNetNuke.Common.Globals.FindControlRecursive(objContainer.Parent, strPane)
					If Not objCtl Is Nothing Then strPanes &= objCtl.ClientID & ";"
					strPaneNames &= strPane & ";"
				Next
				DotNetNuke.UI.Utilities.ClientAPI.RegisterClientVariable(objTitle.Page, "__dnn_Panes", strPanes, True)
				DotNetNuke.UI.Utilities.ClientAPI.RegisterClientVariable(objTitle.Page, "__dnn_PaneNames", strPaneNames, True)
			End If
		End Sub

	End Class
End Namespace
