'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Text.RegularExpressions
Imports System.DirectoryServices

Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Services.Exceptions
Imports DotNetNuke.Security.Authentication.ADSI.Configuration

Namespace DotNetNuke.Security.Authentication.ADSI

    Public Class Utilities

        Sub New()
        End Sub

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Overloads Shared Function GetRootDomain(ByVal ADSIPath As ADSI.Path) As ADSI.Domain
            Try
                Dim adsiConfig As ADSI.Configuration = ADSI.Configuration.GetConfig()

                Dim rootDomainFullPath As String = AddADSIPath(adsiConfig.RootDomainPath, ADSIPath)
                Dim rootDomainEntry As ADSI.Domain = ADSI.Domain.GetDomain(rootDomainFullPath, adsiConfig.UserName, adsiConfig.Password, adsiConfig.AuthenticationType)
                Return rootDomainEntry
            Catch exc As System.Runtime.InteropServices.COMException
                LogException(exc)
                Return Nothing
            End Try

        End Function

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Overloads Shared Function GetRootDomain() As ADSI.Domain
            Try
                Dim adsiConfig As ADSI.Configuration = ADSI.Configuration.GetConfig()

                Dim rootDomainFullPath As String = AddADSIPath(adsiConfig.RootDomainPath)
                Dim rootDomainEntry As ADSI.Domain = ADSI.Domain.GetDomain(rootDomainFullPath, adsiConfig.UserName, adsiConfig.Password, adsiConfig.AuthenticationType)
                Return rootDomainEntry
            Catch exc As System.Runtime.InteropServices.COMException
                LogException(exc)
                Return Nothing
            End Try

        End Function

        ''' -------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt]	08/01/2004	Created
        ''' </history>
        ''' -------------------------------------------------------------------
        Public Shared Function GetDomainByBIOSName(ByVal Name As String) As ADSI.Domain
            Dim adsiConfig As ADSI.Configuration = Authentication.ADSI.Configuration.GetConfig()

            ' Only access CrossRefCollection if LDAP is accessible
            If Not adsiConfig.RefCollection Is Nothing AndAlso adsiConfig.RefCollection.Count > 0 Then
                Dim refObject As ADSI.CrossReferenceCollection.CrossReference = adsiConfig.RefCollection.ItemByNetBIOS(Name)
                Dim path As String = AddADSIPath(refObject.DomainPath)
                Dim domain As ADSI.Domain = ADSI.Domain.GetDomain(path, adsiConfig.UserName, adsiConfig.Password, adsiConfig.AuthenticationType)

                Return domain
            Else
                Return Nothing
            End If

        End Function

		Public Overloads Shared Function GetRootEntry() As DirectoryEntry
			Return GetRootEntry(ADSI.Path.GC)
		End Function

		Public Overloads Shared Function GetRootEntry(ByVal ADSIPath As ADSI.Path) As DirectoryEntry
			Try
				Dim adsiConfig As ADSI.Configuration = Authentication.ADSI.Configuration.GetConfig()
				Dim entry As DirectoryEntry
				If Not adsiConfig Is Nothing Then
					Dim rootDomainFullPath As String = AddADSIPath(adsiConfig.RootDomainPath, ADSIPath)
					If Not rootDomainFullPath Is Nothing Then
						entry = GetDirectoryEntry(rootDomainFullPath)
					End If
				End If
				If Not entry Is Nothing AndAlso entry.Name.Length > 0 Then
					Return entry
				Else
					Return Nothing
				End If
			Catch exc As System.Runtime.InteropServices.COMException
				LogException(exc)
				Return Nothing
			End Try

		End Function

		''' -------------------------------------------------------------------
		''' <summary>
		'''     Depends on how User/Password specified, 2 different method to obtain directory entry
		''' </summary>
		''' <remarks>
		'''     Admin might not enter User/Password to access AD in web.config
		''' </remarks>
		''' <history>
		'''     [tamttt]	08/01/2004	Created
		''' </history>
		''' -------------------------------------------------------------------
		Public Shared Function GetDirectoryEntry(ByVal Path As String) As DirectoryEntry
			Dim adsiConfig As ADSI.Configuration = ADSI.Configuration.GetConfig()
			Dim returnEntry As DirectoryEntry

			If (adsiConfig.UserName.Length > 0) AndAlso (adsiConfig.Password.Length > 0) Then
				returnEntry = New DirectoryEntry(Path, adsiConfig.UserName, adsiConfig.Password, AuthenticationTypes.Delegation)
			Else
				returnEntry = New DirectoryEntry(Path)
			End If

			Return returnEntry

		End Function

		'''-------------------------------------------------------------------
		'''<summary>
		'''    Obtain the path to access top level domain entry in Windows Active Directory
		'''</summary>
		'''<remarks>For better performance and avoid error, Global Catalog is preferer accessing method
		'''</remarks>
		'''<history>
		'''    [tamttt]	08/01/2004	Created
		'''</history>
		'''-------------------------------------------------------------------
		Public Shared Function GetRootForestPath(Optional ByVal ADSIPath As ADSI.Path = ADSI.Path.GC) As String
			Try
				Dim strADSIPath As String = ADSIPath.ToString & "://"
				Dim ADsRoot As New DirectoryEntry(strADSIPath & "rootDSE")
				Dim strRootDomain As String = strADSIPath & CType(ADsRoot.Properties(ADSI_ROOTDOMAINNAMIMGCONTEXT).Value, String)

				Return strRootDomain
			Catch ex As System.Runtime.InteropServices.COMException
				LogException(ex)
				Return Nothing
			End Try
		End Function

		''' -------------------------------------------------------------------
		''' <summary>
		'''     Obtain location of the domain contains this entry, 
		''' </summary>
		''' <remarks>
		'''     Return string is in canonical format (ttt.com.vn)
		''' </remarks>
		''' <history>
		'''     [tamttt]	08/01/2004	Created
		''' </history>
		''' -------------------------------------------------------------------
		Public Shared Function GetEntryLocation(ByVal Entry As DirectoryEntry) As String
			Dim strReturn As String = ""
			If Not Entry Is Nothing Then
				Dim entryPath As String = CheckNullString(Entry.Path)

				If entryPath.Length > 0 Then
					strReturn = Right(entryPath, entryPath.Length - entryPath.IndexOf("DC="))
					strReturn = ConvertToCanonical(strReturn, False)
				End If
			End If

			Return strReturn
		End Function

		''' -------------------------------------------------------------------
		''' <summary>
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''     [tamttt]	08/01/2004	Created
		''' </history>
		''' -------------------------------------------------------------------
		Public Shared Function GetGroupEntryByName(ByVal GroupName As String) As DirectoryEntry
			Dim RootDomain As ADSI.Domain = GetRootDomain()
			Dim objSearch As New Authentication.ADSI.Search(RootDomain)

			objSearch.AddFilter(ADSI_CLASS, ADSI.CompareOperator.Is, Authentication.ObjectClass.group.ToString)
			objSearch.AddFilter(ADSI_ACCOUNTNAME, ADSI.CompareOperator.Is, GroupName)

			Dim groupEntry As DirectoryEntry = objSearch.GetEntry

			If Not groupEntry Is Nothing Then
				Return groupEntry
			Else
				Return Nothing
			End If

		End Function

		''' -------------------------------------------------------------------
		''' <summary>
		''' </summary>
		''' <remarks>
		'''     in multiple domains network that search result return more than one group with the same name (i.e Administrators)
		''' </remarks>
		''' <history>
		'''     [tamttt]	08/01/2004	Created
		''' </history>
		''' -------------------------------------------------------------------
		Public Shared Function GetGroupEntriesByName(ByVal GroupName As String) As ArrayList
			Dim RootDomain As ADSI.Domain = GetRootDomain()
			Dim objSearch As New Authentication.ADSI.Search(RootDomain)

			objSearch.AddFilter(ADSI_CLASS, ADSI.CompareOperator.Is, Authentication.ObjectClass.group.ToString)
			objSearch.AddFilter(ADSI_ACCOUNTNAME, ADSI.CompareOperator.Is, GroupName)

			Dim groupEntries As ArrayList = objSearch.GetEntries

			If Not groupEntries Is Nothing Then
				Return groupEntries
			Else
				Return Nothing
			End If

		End Function

		''' -------------------------------------------------------------------
		''' <summary>
		'''     Obtain user from Windows Active Directory using simple Username format
		''' </summary>
		''' <remarks>
		'''     Reserved for simple network which have single domain and logon username in simple format
		''' </remarks>
		''' <history>
		'''     [tamttt]	08/01/2004	Created
		''' </history>
		''' -------------------------------------------------------------------
		Public Shared Function GetUser0(ByVal Name As String) As DirectoryEntry
			' Create search object then assign required params to get user entry in Active Directory
			Dim objSearch As New ADSI.Search(GetRootDomain)
			Dim userEntry As DirectoryEntry

			With objSearch
				.AddFilter(ADSI_CLASS, ADSI.CompareOperator.Is, Authentication.ObjectClass.person.ToString)
				.AddFilter(ADSI_ACCOUNTNAME, ADSI.CompareOperator.Is, Name)
				userEntry = .GetEntry()
			End With

			Return userEntry

		End Function

		''' -------------------------------------------------------------------
		''' <summary>
		'''     Obtain user from Windows Active Directory using LogonName format - NETBIOSNAME\USERNAME
		''' </summary>
		''' <remarks>
		'''     -In multiple domains network, search result might return more than one user with the same name
		'''     -Additional steps to check by domain name to get correct user
		''' </remarks>
		''' <history>
		'''     [tamttt]	08/01/2004	Created
		''' </history>
		''' -------------------------------------------------------------------
		Public Shared Function GetUserEntryByName(ByVal Name As String) As DirectoryEntry
			' Create search object then assign required params to get user entry in Active Directory
			Dim objSearch As New ADSI.Search(GetRootDomain)
			Dim userEntries As ArrayList
			Dim userEntry As DirectoryEntry
			Dim userDomain As ADSI.Domain

			With objSearch
				.AddFilter(ADSI_CLASS, ADSI.CompareOperator.Is, Authentication.ObjectClass.person.ToString)
				.AddFilter(ADSI_ACCOUNTNAME, ADSI.CompareOperator.Is, TrimUserDomainName(Name))

				userEntries = .GetEntries
				Select Case userEntries.Count
					Case 0
						' Found no entry, return nothing
						Return Nothing
					Case 1
						' Find only one entry, return it
						Return CType(userEntries.Item(0), DirectoryEntry)
					Case Else
						' Find more than one entry, so we have to check to obtain correct user
						' Get user domain
						userDomain = GetDomainByBIOSName(GetUserDomainName(Name))
						If Not userDomain Is Nothing Then
							For Each userEntry In userEntries
								Dim entryPath As String = userEntry.Path
								Dim entryLocation As String = Right(entryPath, entryPath.Length - entryPath.IndexOf("DC="))
								If entryLocation.ToLower = userDomain.DistinguishedName.ToLower Then
									Return userEntry
								End If
							Next
						Else
							' If an error occurs while accessing LDAP (i.e double-hop issue), we return the first entry
							' This method not very accurately, however it would be OK for ALMOST network
							Return CType(userEntries.Item(0), DirectoryEntry)
						End If

				End Select

			End With

			Return Nothing
		End Function

		''' -------------------------------------------------------------------
		''' <summary>
		'''     Obtain user from Windows Active Directory using LogonName format - NETBIOSNAME\USERNAME
		''' </summary>
		''' <remarks>
		'''     -In multiple domains network, search result might return more than one user with the same name
		'''     -Additional steps to check by domain name to get correct user
		''' </remarks>
		''' <history>
		'''     [tamttt]	08/01/2004	Created
		''' </history>
		''' -------------------------------------------------------------------
		Public Shared Function GetUserEntryByCName0(ByVal CName As String, ByVal RootDomain As ADSI.Domain) As DirectoryEntry
			' Create search object then assign required params to get user entry in Active Directory
			Dim objSearch As New ADSI.Search(RootDomain)
			Dim userEntries As ArrayList
			Dim userEntry As DirectoryEntry
			Dim userDomain As ADSI.Domain

			With objSearch
				.AddFilter(ADSI_CLASS, ADSI.CompareOperator.Is, Authentication.ObjectClass.person.ToString)
				.AddFilter(ADSI_CNAME, ADSI.CompareOperator.Is, TrimUserDomainName(CName))

				userEntries = .GetEntries
				Select Case userEntries.Count
					Case 0
						' Found no entry, return nothing
						Return Nothing
					Case 1
						' Find only one entry, return it
						Return CType(userEntries.Item(0), DirectoryEntry)
					Case Else
						' Find more than one entry, so we have to check to obtain correct user
						' Get user domain
						userDomain = GetDomainByBIOSName(GetUserDomainName(CName))
						If Not userDomain Is Nothing Then
							For Each userEntry In userEntries
								Dim entryPath As String = userEntry.Path
								Dim entryLocation As String = Right(entryPath, entryPath.Length - entryPath.IndexOf("DC="))
								If entryLocation.ToLower = userDomain.DistinguishedName.ToLower Then
									Return userEntry
								End If
							Next
						Else
							' If an error occurs while accessing LDAP (i.e double-hop issue), we return the first entry
							' This method not very accurately, however it would be OK for ALMOST network
							Return CType(userEntries.Item(0), DirectoryEntry)
						End If

				End Select

			End With
			Return Nothing
		End Function

		''' -------------------------------------------------------------------
		''' <summary>
		'''     Obtain user from Windows Active Directory using UPN format - USERNAME@DOMAIN
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''     [tamttt]	08/01/2004	Created
		''' </history>
		''' -------------------------------------------------------------------
		Public Shared Function GetUserByUPN0(ByVal Name As String, ByVal RootDomain As ADSI.Domain) As DirectoryEntry
			' Create search object then assign required params to get user entry in Active Directory
			Dim objSearch As New ADSI.Search(RootDomain)
			Dim userEntry As DirectoryEntry

			' UPN is unique in entire Windows network
			With objSearch
				.AddFilter(ADSI_CLASS, ADSI.CompareOperator.Is, Authentication.ObjectClass.person.ToString)
				.AddFilter(ADSI_UPN, ADSI.CompareOperator.Is, Name)
				userEntry = .GetEntry()
			End With

			Return userEntry

		End Function

		''' -------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <remarks>
		''' This function's reserved for simple network which have single domain and logon username in simple format
		''' </remarks>
		''' <history>
		'''     [tamttt]	08/01/2004	Created
		''' </history>
		''' -------------------------------------------------------------------
		Public Shared Function CanonicalToNetBIOS(ByVal CanonicalName As String) As String
			Dim config As Authentication.ADSI.Configuration = Authentication.ADSI.Configuration.GetConfig()

			' Only access CrossRefCollection if LDAP is accessible
			If Not config.RefCollection Is Nothing AndAlso config.RefCollection.Count > 0 Then
				Dim refObject As ADSI.CrossReferenceCollection.CrossReference = config.RefCollection.Item(CanonicalName)
				Return refObject.mNetBIOSName
			Else
				Return ""
			End If
		End Function

		''' -------------------------------------------------------------------
		''' <summary>
		'''    Convert input string USERNAME@DOMAIN into NETBIOSNAME\USERNAME
		''' </summary>
		''' <remarks>
		'''    - We could do it only if LDAP is accessible to obtain NetBIOSName
		'''    - If LDAP is unaccessible, return original user name (UPN format)
		''' </remarks>
		''' <history>
		'''     [tamttt]	08/01/2004	Created
		''' </history>
		''' -------------------------------------------------------------------
		Public Shared Function UPNToLogonName0(ByVal UserPrincipalName As String) As String
			Dim config As Authentication.ADSI.Configuration = Authentication.ADSI.Configuration.GetConfig()
			Dim userName As String = UserPrincipalName

			If config.LDAPAccesible Then
				Dim userDomain As String = Right(UserPrincipalName, UserPrincipalName.Length - (UserPrincipalName.IndexOf("@") + 1))
				Dim userNetBIOS As String = CanonicalToNetBIOS(userDomain)
				If Not userNetBIOS.Length = 0 Then
					userName = userNetBIOS & "\" & TrimUserDomainName(UserPrincipalName)
				End If
			End If

			Return userName

		End Function

		''' -------------------------------------------------------------------
		''' <summary>
		''' Get domain name (NETBIOS) from user logon name
		''' </summary>
		''' <remarks>
		''' Input string must be LogonName format (NETBIOSNAME\USERNAME)
		''' </remarks>
		''' <history>
		'''     [tamttt]	08/01/2004	Created
		''' </history>
		''' -------------------------------------------------------------------
		Public Shared Function GetUserDomainName(ByVal UserName As String) As String
			Dim strReturn As String = ""
			If UserName.IndexOf("\") > 0 Then
				strReturn = Left(UserName, (UserName.IndexOf("\")))
			End If
			Return strReturn
		End Function

		''' -------------------------------------------------------------------
		''' <summary>
		''' Trim user logon string to get simple user name
		''' </summary>
		''' <remarks>
		''' Accept 3 different formats :
		''' - LogonName format (NETBIOSNAME\USERNAME)
		''' - UPN format (USERNAME@DOMAINNAME)
		''' - Simple format (USERNAME only)
		''' </remarks>
		''' <history>
		'''     [tamttt]	08/01/2004	Created
		''' </history>
		''' -------------------------------------------------------------------
		Public Shared Function TrimUserDomainName(ByVal UserName As String) As String
			Dim strReturn As String
			If UserName.IndexOf("\") > -1 Then
				strReturn = Right(UserName, UserName.Length - (UserName.IndexOf("\") + 1))
			ElseIf UserName.IndexOf("@") > -1 Then
				strReturn = Left(UserName, UserName.IndexOf("@"))
			Else
				strReturn = UserName
			End If

			Return strReturn
		End Function

		''' -------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''     [tamttt]	08/01/2004	Created
		''' </history>
		''' -------------------------------------------------------------------
		Public Shared Function AddADSIPath(ByVal Path As String, Optional ByVal ADSIPath As ADSI.Path = ADSI.Path.GC) As String
			If Path.IndexOf("://") <> -1 Then
				'Clean existing ADs path first
				Path = Right(Path, Path.Length - (Path.IndexOf("://") + 3))
			End If
			Return ADSIPath.ToString & "://" & Path
		End Function

		''' -------------------------------------------------------------------
		''' <summary>
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''     [tamttt]	08/01/2004	Created
		''' </history>
		''' -------------------------------------------------------------------
		Public Shared Function ValidateDomainPath(ByVal Path As String, Optional ByVal ADSIPath As ADSI.Path = ADSI.Path.GC) As String
			' If root domain is not specified in site settings, we start from top root forest
			If Path.Length = 0 Then
				Return GetRootForestPath()
			ElseIf (Path.IndexOf("DC=") <> -1) And (Path.IndexOf("://") <> -1) Then
				Return Path
			ElseIf (Path.IndexOf(".") <> -1) Then
				' "ttt.com.vn" format,  it's possible for "LDAP://ttt.com.vn" format to access Authentication, however GC:// gives better performance
				Return ConvertToDistinguished(Path)
			Else
				' Invalid path, so we get root path from Active Directory
				Return GetRootForestPath()
			End If
			'End If
		End Function

		''' -------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''     [tamttt]	08/01/2004	Created
		''' </history>
		''' -------------------------------------------------------------------
		Public Shared Function ConvertToDistinguished(ByVal Canonical As String, Optional ByVal ADSIPath As ADSI.Path = ADSI.Path.GC) As String
			Dim strDistinguished As String

			' Clean up ADSI.Path to make sure we get a proper path
			If Canonical.IndexOf("://") <> -1 Then
				strDistinguished = Right(Canonical, Canonical.Length - (Canonical.IndexOf("://") + 3))
			Else
				strDistinguished = Canonical
			End If

			strDistinguished = Replace(strDistinguished, ".", ",DC=")
			strDistinguished = "DC=" & strDistinguished

			If Canonical.IndexOf("://") <> -1 Then
				strDistinguished = AddADSIPath(strDistinguished, ADSIPath)
			End If

			Return strDistinguished

		End Function

		''' -------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''     [tamttt]	08/01/2004	Created
		''' </history>
		''' -------------------------------------------------------------------
		Public Shared Function ConvertToCanonical(ByVal Distinguished As String, ByVal IncludeADSIPath As Boolean) As String
			Dim strCanonical As String = Distinguished

			If Not IncludeADSIPath AndAlso Distinguished.IndexOf("://") <> -1 Then
				strCanonical = Right(Distinguished, Distinguished.Length - (Distinguished.IndexOf("://") + 3))
			End If

			strCanonical = Replace(strCanonical, "DC=", "")
			strCanonical = Replace(strCanonical, "dc=", "")
			strCanonical = Replace(strCanonical, "CN=", "")
			strCanonical = Replace(strCanonical, "cn=", "")
			strCanonical = Replace(strCanonical, ",", ".")

			Return strCanonical

		End Function

		''' -------------------------------------------------------------------
		''' <summary>
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''     [tamttt]	08/01/2004	Created
		''' </history>
		''' -------------------------------------------------------------------
		Public Shared Function CheckNullString(ByVal value As Object) As String
			If value Is Nothing Then
				Return ""
			Else
				Return value.ToString
			End If
		End Function

		''' -------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''     [tamttt]	08/01/2004	Created
		''' </history>
		''' -------------------------------------------------------------------
		Public Shared Function GetRandomPassword() As String
			Dim rd As New System.Random
			Return Convert.ToString(rd.Next)
		End Function

		' See http://www.aspalliance.com/bbilbro/viewarticle.aspx?paged_article_id=4
		Public Shared Function ReplaceCaseInsensitive(ByVal text As String, ByVal oldValue As String, ByVal newValue As String) As String
			oldValue = GetCaseInsensitiveSearch(oldValue)

			Return Regex.Replace([text], oldValue, newValue)

		End Function		  'ReplaceCaseInsensitive

		Shared Function GetCaseInsensitiveSearch(ByVal search As String) As String
			Dim result As String = String.Empty

			Dim index As Integer

			For index = 0 To search.Length - 1
				Dim character As Char = search.Chars(index)
				Dim characterLower As Char = Char.ToLower(character)
				Dim characterUpper As Char = Char.ToUpper(character)

				If characterUpper = characterLower Then
					result = result + character
				Else
					result = result + "[" + characterLower + characterUpper + "]"
				End If

			Next index
			Return result
		End Function		  'GetCaseInsensitiveSearch

	End Class

End Namespace
