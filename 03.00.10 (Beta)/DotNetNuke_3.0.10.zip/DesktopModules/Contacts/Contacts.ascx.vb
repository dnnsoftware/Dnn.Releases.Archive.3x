'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports DotNetNuke
Imports System.Web.UI.WebControls

Namespace DotNetNuke.Modules.Contacts

  ''' -----------------------------------------------------------------------------
  ''' <summary>
  ''' The Contacts Class provides the UI for displaying the Contacts
  ''' </summary>
  ''' <returns></returns>
  ''' <remarks>
  ''' </remarks>
  ''' <history>
  ''' 	[cnurse]	9/20/2004	Moved Contacts to a separate Project
  ''' </history>
  ''' -----------------------------------------------------------------------------
  Public MustInherit Class Contacts
		Inherits Entities.Modules.PortalModuleBase
        Implements Entities.Modules.IActionable
        Implements Entities.Modules.IPortable
        Implements Entities.Modules.ISearchable

#Region "Controls"

    Protected WithEvents grdContacts As System.Web.UI.WebControls.DataGrid

#End Region

#Region "Public Methods"

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' DisplayEmail formats an email address correctly
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <param name="Email">The email address to format</param>
    ''' <returns>The formatted email address</returns>
    ''' <history>
    ''' 	[cnurse]	9/21/2004	Moved Contacts to a separate Project
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Function DisplayEmail(ByVal Email As String) As String
      Try
        DisplayEmail = FormatEmail(Email)
      Catch exc As Exception 'Module failed to load
        ProcessModuleLoadException(Me, exc)
      End Try
    End Function

#End Region

#Region "Event Handlers"

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' Page_Load runs when the control is loaded
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	9/21/2004	Moved Contacts to a separate Project
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      Try
        Dim objContacts As New ContactController

        'Localize Grid
        Localization.LocalizeDataGrid(grdContacts, Me.LocalResourceFile)

        grdContacts.DataSource = objContacts.GetContacts(ModuleId)
        grdContacts.DataBind()
      Catch exc As Exception 'Module failed to load
        ProcessModuleLoadException(Me, exc)
      End Try
    End Sub

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' grdContacts_ItemCreated runs when an item in the Contacts grid is created
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	9/21/2004	Moved Contacts to a separate Project
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Sub grdContacts_ItemCreated(ByVal sender As Object, ByVal e As DataGridItemEventArgs) Handles grdContacts.ItemCreated
      Try
        If e.Item.ItemType = ListItemType.Header Then
          e.Item.Cells(1).Attributes.Add("Scope", "col")
          e.Item.Cells(2).Attributes.Add("Scope", "col")
          e.Item.Cells(3).Attributes.Add("Scope", "col")
          e.Item.Cells(4).Attributes.Add("Scope", "col")
          e.Item.Cells(5).Attributes.Add("Scope", "col")
        End If
      Catch exc As Exception 'Module failed to load
        ProcessModuleLoadException(Me, exc)
      End Try
    End Sub

#End Region

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
      'CODEGEN: This method call is required by the Web Form Designer
      'Do not modify it using the code editor.
      InitializeComponent()

    End Sub

#End Region

#Region "Optional Interfaces"

        Public ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
            Get
                Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
                Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.AddContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", EditURL(), False, Security.SecurityAccessLevel.Edit, True, False)
                Return Actions
            End Get
        End Property

        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Function

        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserId As Integer) Implements Entities.Modules.IPortable.ImportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Sub

        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
        End Function

#End Region

    End Class

End Namespace
