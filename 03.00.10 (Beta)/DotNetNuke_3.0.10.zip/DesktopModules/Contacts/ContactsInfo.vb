'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data

Imports DotNetNuke


Namespace DotNetNuke.Modules.Contacts

  ''' -----------------------------------------------------------------------------
  ''' <summary>
  ''' The ContactInfo Class provides the Contacts Business Object
  ''' </summary>
  ''' <returns></returns>
  ''' <remarks>
  ''' </remarks>
  ''' <history>
  ''' 	[cnurse]	9/20/2004	Moved Contacts to a separate Project
  ''' </history>
  ''' -----------------------------------------------------------------------------
  Public Class ContactInfo

#Region "Private Members"

    Private _ItemId As Integer
    Private _ModuleId As Integer
    Private _CreatedByUser As String
    Private _CreatedDate As Date
    Private _Name As String
    Private _Role As String
    Private _Email As String
    Private _Contact1 As String
    Private _Contact2 As String

#End Region

#Region "Constructors"

    Public Sub New()
    End Sub

#End Region

#Region "Properties"

    Public Property ItemId() As Integer
      Get
        Return _ItemId
      End Get
      Set(ByVal Value As Integer)
        _ItemId = Value
      End Set
    End Property

    Public Property ModuleId() As Integer
      Get
        Return _ModuleId
      End Get
      Set(ByVal Value As Integer)
        _ModuleId = Value
      End Set
    End Property

    Public Property CreatedByUser() As String
      Get
        Return _CreatedByUser
      End Get
      Set(ByVal Value As String)
        _CreatedByUser = Value
      End Set
    End Property

    Public Property CreatedDate() As Date
      Get
        Return _CreatedDate
      End Get
      Set(ByVal Value As Date)
        _CreatedDate = Value
      End Set
    End Property

    Public Property Name() As String
      Get
        Return _Name
      End Get
      Set(ByVal Value As String)
        _Name = Value
      End Set
    End Property

    Public Property Role() As String
      Get
        Return _Role
      End Get
      Set(ByVal Value As String)
        _Role = Value
      End Set
    End Property

    Public Property Email() As String
      Get
        Return _Email
      End Get
      Set(ByVal Value As String)
        _Email = Value
      End Set
    End Property

    Public Property Contact1() As String
      Get
        Return _Contact1
      End Get
      Set(ByVal Value As String)
        _Contact1 = Value
      End Set
    End Property

    Public Property Contact2() As String
      Get
        Return _Contact2
      End Get
      Set(ByVal Value As String)
        _Contact2 = Value
      End Set
    End Property

#End Region

  End Class

End Namespace
