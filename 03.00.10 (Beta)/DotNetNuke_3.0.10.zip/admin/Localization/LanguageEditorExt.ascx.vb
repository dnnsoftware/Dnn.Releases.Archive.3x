'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO
Imports System.Xml
Imports DotNetNuke.UI.WebControls
Imports DotNetNuke

Namespace DotNetNuke.Services.Localization

	''' -----------------------------------------------------------------------------
	''' <summary>
    ''' Manages translations for Resource files
	''' </summary>
	''' <returns></returns>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[vmasanas]	10/04/2004  Created
	''' </history>
	''' -----------------------------------------------------------------------------
    Public MustInherit Class LanguageEditorExt
		Inherits DotNetNuke.Entities.Modules.PortalModuleBase

#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents Label1 As System.Web.UI.WebControls.Label
        Protected WithEvents lblName As System.Web.UI.WebControls.Label
        Protected WithEvents Label3 As System.Web.UI.WebControls.Label
        Protected WithEvents lblDefault As System.Web.UI.WebControls.Label
		Protected WithEvents teContent As UI.UserControls.TextEditor
#End Region

#Region "Private Members"
        Private name As String
        Private resfile As String
        Private locale As String
#End Region

#Region "Event Handlers"
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Loads resource file and default data
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[vmasanas]	07/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Dim node As XmlNode
            Dim resDoc As New XmlDocument
            Dim defDoc As New XmlDocument

            Try
                name = Request.QueryString("name")
                resfile = QueryStringDecode(Request.QueryString("resourcefile"))
                locale = Request.QueryString("locale")

                If Not Page.IsPostBack Then
                    lblName.Text = name

                    resDoc.Load(ResourceFile(resfile, locale))
                    node = resDoc.SelectSingleNode("//root/data[@name='" + name + "']/value")
                    teContent.Text = node.InnerXml

                    defDoc.Load(ResourceFile(resfile, Services.Localization.Localization.SystemLocale, True))
                    node = defDoc.SelectSingleNode("//root/data[@name='" + name + "']/value")
                    lblDefault.Text = Server.HtmlDecode(node.InnerXml)
				End If
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Returns to language editor control
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[vmasanas]	04/10/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Try
                If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                    Response.Redirect(EditUrl("locale", locale, "Language", "resourcefile=" & QueryStringEncode(resfile)), True)
                Else
                    Response.Redirect(NavigateURL(TabId, "", "locale=" & locale, "resourcefile=" & QueryStringEncode(resfile)), True)
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Saves the translation to the resource file
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[vmasanas]	07/10/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click
			Dim node As XmlNode
			Dim resDoc As New XmlDocument

			Try
				If teContent.Text = "" Then
					UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("RequiredField.ErrorMessage", Me.LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
				Else
					resDoc.Load(ResourceFile(resfile, locale))
					node = resDoc.SelectSingleNode("//root/data[@name='" + name + "']/value")
                    node.InnerXml = teContent.Text

					Try
                        File.SetAttributes(ResourceFile(resfile, locale), FileAttributes.Normal)
                        resDoc.Save(ResourceFile(resfile, locale))
                        If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                            Response.Redirect(EditUrl("locale", locale, "Language", "resourcefile=" & QueryStringEncode(resfile)), True)
                        Else
                            Response.Redirect(NavigateURL(TabId, "", "locale=" & locale, "resourcefile=" & QueryStringEncode(resfile)), True)
                        End If
                    Catch
                        UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("Save.ErrorMessage", Me.LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    End Try
				End If
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub
#End Region

#Region "Private Methods"
		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Returns the resource file name for a given resource and language
		''' </summary>
		''' <param name="filename">Resource File</param>
		''' <param name="language">Language</param>
        ''' <param name="forceHost">When true will return the general resource file name, not portal specific</param>
        ''' <returns>Localized File Name</returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[vmasanas]	04/10/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
        Private Function ResourceFile(ByVal filename As String, ByVal language As String, ByVal forceHost As Boolean) As String
            Dim resourcefilename As String = Server.MapPath("~/" + filename)
            If Not filename.EndsWith(".resx") Then
                resourcefilename &= ".resx"
            End If

            If language <> Services.Localization.Localization.SystemLocale Then
                resourcefilename = resourcefilename.Substring(0, resourcefilename.Length - 5) + "." + language + ".resx"
            End If

            ' if accessing from Admin menu -> edit custom portal locale
            If PortalSettings.ActiveTab.ParentId = PortalSettings.AdminTabId And Not forceHost Then
                resourcefilename = resourcefilename.Substring(0, resourcefilename.Length - 5) + ".Portal-" + PortalSettings.PortalId.ToString + ".resx"
            End If

            Return resourcefilename

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Returns the resource file name for a given resource and language
        ''' </summary>
        ''' <param name="filename">Resource File</param>
        ''' <param name="language">Language</param>
        ''' <returns>Localized File Name</returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[vmasanas]	04/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function ResourceFile(ByVal filename As String, ByVal language As String) As String

            Return ResourceFile(filename, language, False)

        End Function

#End Region

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		'NOTE: The following placeholder declaration is required by the Web Form Designer.
		'Do not delete or move it.
		Private designerPlaceholderDeclaration As System.Object

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

	End Class

End Namespace
