'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO
Imports System.Xml
Imports DotNetNuke.UI.WebControls
Imports DotNetNuke

Namespace DotNetNuke.Services.Localization

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' Manages translations for Resource files
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[vmasanas]	10/04/2004  Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public MustInherit Class LanguageEditor
        Inherits DotNetNuke.Entities.Modules.PortalModuleBase


#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents dgEditor As System.Web.UI.WebControls.DataGrid
        Protected WithEvents cboLocales As System.Web.UI.WebControls.DropDownList
        Protected WithEvents lblMissing As System.Web.UI.WebControls.Label
        Protected WithEvents cmdAddMissing As System.Web.UI.WebControls.LinkButton
        Protected WithEvents pnlMissing As System.Web.UI.WebControls.Panel
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
        Protected WithEvents DNNTree As DotNetNuke.UI.WebControls.DnnTree
        Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
        Protected WithEvents lblSelected As System.Web.UI.WebControls.Label
        Protected WithEvents lblResourceFile As System.Web.UI.WebControls.Label
        Protected WithEvents lblConfirm As System.Web.UI.WebControls.Label
        Protected WithEvents cmdYes As System.Web.UI.WebControls.LinkButton
        Protected WithEvents pnlConfirm As System.Web.UI.WebControls.Panel
        Protected WithEvents chkHighlight As System.Web.UI.WebControls.CheckBox
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Loads suported locales and shows default values
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[vmasanas]	04/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Dim idx, idx2 As Integer

            Try
                ' accessing from admin menu (custom portal locale) or from host menu (host locales)
                adminMode = (PortalSettings.ActiveTab.ParentId = PortalSettings.AdminTabId)

                If Not Page.IsPostBack Then
                    cmdCancel.Visible = Not adminMode

                    ' configure tree
                    DNNTree.SystemImagesPath = ResolveUrl("~/images/")
                    DNNTree.ImageList.Add(ResolveUrl("~/images/folder.gif"))
                    DNNTree.ImageList.Add(ResolveUrl("~/images/file.gif"))
                    DNNTree.IndentWidth = 10
                    DNNTree.CollapsedNodeImage = ResolveUrl("~/images/max.gif")
                    DNNTree.ExpandedNodeImage = ResolveUrl("~/images/min.gif")

                    'Local resources
                    idx = DNNTree.TreeNodes.Add("Local Resources")
                    DNNTree.TreeNodes(idx).Key = "Local Resources"
                    DNNTree.TreeNodes(idx).ToolTip = "Local Resources"
                    DNNTree.TreeNodes(idx).ImageIndex = eImageType.Folder
                    DNNTree.TreeNodes(idx).ClickAction = eClickAction.Expand

                    'admin
                    idx2 = DNNTree.TreeNodes(idx).TreeNodes.Add("Admin")
                    DNNTree.TreeNodes(idx).TreeNodes(idx2).Key = "Admin"
                    DNNTree.TreeNodes(idx).TreeNodes(idx2).ToolTip = "Admin"
                    DNNTree.TreeNodes(idx).TreeNodes(idx2).ImageIndex = eImageType.Folder
                    DNNTree.TreeNodes(idx).TreeNodes(idx2).ClickAction = eClickAction.Expand
                    PopulateTree(DNNTree.TreeNodes(idx).TreeNodes(idx2).TreeNodes, Server.MapPath("~\admin"))
                    'controls
                    idx2 = DNNTree.TreeNodes(idx).TreeNodes.Add("Controls")
                    DNNTree.TreeNodes(idx).TreeNodes(idx2).Key = "Controls"
                    DNNTree.TreeNodes(idx).TreeNodes(idx2).ToolTip = "Controls"
                    DNNTree.TreeNodes(idx).TreeNodes(idx2).ImageIndex = eImageType.Folder
                    DNNTree.TreeNodes(idx).TreeNodes(idx2).ClickAction = eClickAction.Expand
                    PopulateTree(DNNTree.TreeNodes(idx).TreeNodes(idx2).TreeNodes, Server.MapPath("~\controls"))
                    'desktopmodules
                    idx2 = DNNTree.TreeNodes(idx).TreeNodes.Add("DesktopModules")
                    DNNTree.TreeNodes(idx).TreeNodes(idx2).Key = "DesktopModules"
                    DNNTree.TreeNodes(idx).TreeNodes(idx2).ToolTip = "DesktopModules"
                    DNNTree.TreeNodes(idx).TreeNodes(idx2).ImageIndex = eImageType.Folder
                    DNNTree.TreeNodes(idx).TreeNodes(idx2).ClickAction = eClickAction.Expand
                    PopulateTree(DNNTree.TreeNodes(idx).TreeNodes(idx2).TreeNodes, Server.MapPath("~\desktopmodules"))

                    ' add application resources
                    idx = DNNTree.TreeNodes.Add("Global Resources")
                    DNNTree.TreeNodes(idx).Key = "Global Resources"
                    DNNTree.TreeNodes(idx).ToolTip = "Global Resources"
                    DNNTree.TreeNodes(idx).ImageIndex = eImageType.Folder
                    DNNTree.TreeNodes(idx).ClickAction = eClickAction.Expand
                    idx2 = DNNTree.TreeNodes(idx).TreeNodes.Add(Path.GetFileNameWithoutExtension(Localization.GlobalResourceFile))
                    DNNTree.TreeNodes(idx).TreeNodes(idx2).Key = Server.MapPath(Localization.GlobalResourceFile)
                    DNNTree.TreeNodes(idx).TreeNodes(idx2).ToolTip = DNNTree.TreeNodes(idx).TreeNodes(idx2).Text
                    DNNTree.TreeNodes(idx).TreeNodes(idx2).ImageIndex = eImageType.Page
                    idx2 = DNNTree.TreeNodes(idx).TreeNodes.Add(Path.GetFileNameWithoutExtension(Localization.SharedResourceFile))
                    DNNTree.TreeNodes(idx).TreeNodes(idx2).Key = Server.MapPath(Localization.SharedResourceFile)
                    DNNTree.TreeNodes(idx).TreeNodes(idx2).ToolTip = DNNTree.TreeNodes(idx).TreeNodes(idx2).Text
                    DNNTree.TreeNodes(idx).TreeNodes(idx2).ImageIndex = eImageType.Page

                    BindList()
                    ' If returning from full editor, use params
                    ' else load system global resource file by default
                    If Request.QueryString("locale") <> "" Then
                        cboLocales.SelectedValue = Request.QueryString("locale").ToString
                    Else
                        cboLocales.SelectedValue = Services.Localization.Localization.SystemLocale
                    End If
                    If Request.QueryString("resourcefile") <> "" Then
                        SelectedResourceFile = Server.MapPath("~/" + QueryStringDecode(Request.QueryString("resourcefile")))
                    Else
                        SelectedResourceFile = Server.MapPath(Localization.GlobalResourceFile)
                    End If
                    DNNTree.SelectNodeByKey(SelectedResourceFile)

                    If adminMode And Not File.Exists(ResourceFile(SelectedResourceFile, cboLocales.SelectedValue)) Then
                        ' require confirmation
                        ShowConfirm(True)
                    Else
                        ShowConfirm(False)
                        BindGrid()
                    End If
                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Loads localized file
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' If a localized file does not exist for the selected language it is created using default values
        ''' </remarks>
        ''' <history>
        ''' 	[vmasanas]	04/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cboLocales_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboLocales.SelectedIndexChanged
            Try
                Try
                    If adminMode And Not File.Exists(ResourceFile(SelectedResourceFile, cboLocales.SelectedValue)) Then
                        ' require confirmation
                        ShowConfirm(True)
                    Else
                        ShowConfirm(False)
                        If Not File.Exists(ResourceFile(SelectedResourceFile, cboLocales.SelectedValue)) Then
                            File.Copy(SelectedResourceFile, ResourceFile(SelectedResourceFile, cboLocales.SelectedValue))
                        End If
                        BindGrid()
                    End If
                Catch
                    UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("Save.ErrorMessage", Me.LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                End Try

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Updates all values from the datagrid
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[vmasanas]	04/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click
            Dim di As DataGridItem
            Dim node, parent As XmlNode
            Dim resDoc As New XmlDocument

            Try
                resDoc.Load(ResourceFile(SelectedResourceFile, cboLocales.SelectedValue))
                For Each di In dgEditor.Items
                    If (di.ItemType = ListItemType.Item Or di.ItemType = ListItemType.AlternatingItem) Then
                        Dim ctl1 As TextBox = CType(di.Cells(0).FindControl("txtValue"), TextBox)
                        node = resDoc.SelectSingleNode("//root/data[@name='" + di.Cells(1).Text + "']/value")
                        node.InnerXml = Server.HtmlEncode(ctl1.Text)
                    End If
                Next
                Try
                    File.SetAttributes(ResourceFile(SelectedResourceFile, cboLocales.SelectedValue), FileAttributes.Normal)
                    resDoc.Save(ResourceFile(SelectedResourceFile, cboLocales.SelectedValue))
                    BindGrid()
                Catch
                    UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("Save.ErrorMessage", Me.LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                End Try

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Deletes the localized file for a given locale
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' System Default file cannot be deleted
        ''' </remarks>
        ''' <history>
        ''' 	[vmasanas]	04/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
            Try
                If cboLocales.SelectedValue = Services.Localization.Localization.SystemLocale And Not adminMode Then
                    UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("Delete.ErrorMessage", Me.LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                Else
                    Try
                        File.Delete(ResourceFile(SelectedResourceFile, cboLocales.SelectedValue))
                        cboLocales.SelectedValue = Services.Localization.Localization.SystemLocale
                        If adminMode And Not File.Exists(ResourceFile(SelectedResourceFile, cboLocales.SelectedValue)) Then
                            ' require confirmation
                            ShowConfirm(True)
                        Else
                            ShowConfirm(False)
                            BindGrid()
                        End If
                    Catch
                        UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("Save.ErrorMessage", Me.LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    End Try
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Returns to main control
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[vmasanas]	04/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL())
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Adds missing nodes from the System Default file to the Resource file 
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[VMasanas]	05/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdAddMissing_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAddMissing.Click
            Dim node, parent As XmlNode
            Dim resDoc As New XmlDocument
            Dim defDoc As New XmlDocument

            Try
                resDoc.Load(ResourceFile(SelectedResourceFile, cboLocales.SelectedValue))
                defDoc.Load(SelectedResourceFile)

                For Each node In defDoc.SelectNodes("//root/data")
                    If resDoc.SelectSingleNode("//root/data[@name='" + node.Attributes("name").Value + "']") Is Nothing Then
                        resDoc.SelectSingleNode("//root").AppendChild(resDoc.ImportNode(node, True))
                    End If
                Next
                Try
                    resDoc.Save(ResourceFile(SelectedResourceFile, cboLocales.SelectedValue))
                    BindGrid()
                Catch
                    UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("Save.ErrorMessage", Me.LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                End Try

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Open the selected resource file in editor or expand/collapse node if is folder
        ''' </summary>
        ''' <param name="source"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[vmasanas]	07/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub DNNTree_NodeClick(ByVal source As Object, ByVal e As DotNetNuke.UI.WebControls.DNNTreeNodeClickEventArgs) Handles DNNTree.NodeClick
            If e.Node.ImageIndex = eImageType.Page Then
                SelectedResourceFile = e.Node.Key
                Try
                    If adminMode And Not File.Exists(ResourceFile(SelectedResourceFile, cboLocales.SelectedValue)) Then
                        ' require confirmation
                        ShowConfirm(True)
                    Else
                        ShowConfirm(False)
                        If Not File.Exists(ResourceFile(SelectedResourceFile, cboLocales.SelectedValue)) Then
                            File.Copy(SelectedResourceFile, ResourceFile(SelectedResourceFile, cboLocales.SelectedValue))
                        End If
                        BindGrid()
                    End If
                Catch
                    UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("Save.ErrorMessage", Me.LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                End Try
            ElseIf e.Node.IsExpanded Then
                e.Node.Collapse()
            Else
                e.Node.Expand()
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates portal custom locale
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Vicen�]	11/10/2004	Created
        '''  	[Vicen�]	01/19/2004	Portal specific resource file should be initialized 
        '''                             from the same language resource file if available
        '''  </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdYes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdYes.Click
            Try
                Dim translatedResource As String = ResourceFile(SelectedResourceFile, cboLocales.SelectedValue, True)

                If Not File.Exists(ResourceFile(SelectedResourceFile, cboLocales.SelectedValue)) Then
                    If File.Exists(translatedResource) Then
                        File.Copy(translatedResource, ResourceFile(SelectedResourceFile, cboLocales.SelectedValue))
                    Else
                        File.Copy(SelectedResourceFile, ResourceFile(SelectedResourceFile, cboLocales.SelectedValue))
                    End If
                    ShowConfirm(False)
                    BindGrid()
                End If
            Catch
                UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("Save.ErrorMessage", Me.LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Adds a warning message before leaving the page to edit in full editor so the user can save changes
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[vmasanas]	20/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub dgEditor_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles dgEditor.ItemCreated
            If e.Item.ItemType = ListItemType.AlternatingItem Or e.Item.ItemType = ListItemType.Item Then
                Dim c As HyperLink
                c = CType(e.Item.FindControl("lnkEdit"), HyperLink)
                If Not c Is Nothing Then
                    c.Attributes.Add("onClick", "javascript:return confirm('" & Services.Localization.Localization.GetString("SaveWarning", Me.LocalResourceFile) & "');")
                End If
            End If
        End Sub

        Private Sub chkHighlight_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkHighlight.CheckedChanged
            BindGrid()
        End Sub

#End Region

#Region "Protected Methods"
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Return default Value
        ''' </summary>
        ''' <param name="name"></param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[VMasanas]	11/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Function FormatText(ByVal name As String) As String
            Dim node As XmlNode

            node = defaultXML.SelectSingleNode("//root/data[@name='" + name + "']")
            If Not node Is Nothing Then
                Return node.SelectSingleNode("value").InnerXml
            Else
                Return ""
            End If

        End Function

        Protected Function FormatStyle(ByVal name As String, ByVal current As String) As String
            Dim node As XmlNode

            If chkHighlight.Checked Then
                node = defaultXML.SelectSingleNode("//root/data[@name='" + name + "']")
                If Not node Is Nothing Then
                    If node.SelectSingleNode("value").InnerXml = current And cboLocales.SelectedValue <> Localization.SystemLocale Then
                        Return "Pending"
                    End If
                End If
            End If
            Return ""

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Returns height of textbox based on number of chars
        ''' </summary>
        ''' <param name="a"></param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[VMasanas]	23/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Function FormatHeight(ByVal a As String) As Unit
            If a.Length < 30 Then
                Return New Unit("30")
            Else
                Return New Unit("100")
            End If
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Builds the url for the lang. html editor control
        ''' </summary>
        ''' <param name="name"></param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[vmasanas]	07/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Function OpenFullEditor(ByVal name As String) As String
            Dim file As String
            file = SelectedResourceFile.Replace(Server.MapPath(Common.Globals.ApplicationPath + "/"), "")
            Return EditUrl("name", name, "fulleditor", "locale=" & cboLocales.SelectedValue, "resourcefile=" & QueryStringEncode(file))
        End Function
#End Region

#Region "Private Methods"
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Shows or hides Confirm panel
        ''' </summary>
        ''' <param name="show"></param>
        ''' <remarks>
        ''' When confirm panel is visible, update, delete and datagrid are hidden
        ''' </remarks>
        ''' <history>
        ''' 	[Vicen�]	11/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ShowConfirm(ByVal show As Boolean)
            pnlConfirm.Visible = show
            cmdUpdate.Visible = Not show
            cmdDelete.Visible = Not show
            dgEditor.Visible = Not show
            chkHighlight.Visible = Not show
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Loads Local Resource files in the tree
        ''' </summary>
        ''' <param name="Nodes">Node collection where to add new nodes</param>
        ''' <param name="_path">Folder to search for</param>
        ''' <returns>true is a Local Resource file is found in the given path</returns>
        ''' <remarks>
        ''' The Node collection will only contain en-US resources
        ''' Only folders with Resource files will be included in the tree
        ''' </remarks>
        ''' <history>
        ''' 	[vmasanas]	07/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function PopulateTree(ByVal Nodes As TreeNodeCollection, ByVal _path As String) As Boolean
            Dim folders As String() = Directory.GetDirectories(_path)
            Dim folder As String
            Dim found As Boolean = False
            Dim nodeIndex As Integer
            Dim objFile As IO.FileInfo
            Dim objFolder As DirectoryInfo
            Dim node, leaf As TreeNode

            For Each folder In folders
                objFolder = New System.IO.DirectoryInfo(folder)
                node = New TreeNode(objFolder.Name)
                node.Key = objFolder.FullName
                node.ToolTip = objFolder.Name
                node.ImageIndex = eImageType.Folder
                node.ClickAction = eClickAction.Expand
                Nodes.Add(node)

                If objFolder.Name = Services.Localization.Localization.LocalResourceDirectory Then
                    ' found local resource folder, add resources
                    For Each objFile In objFolder.GetFiles("*.ascx.resx")
                        leaf = New TreeNode(Path.GetFileNameWithoutExtension(objFile.Name))
                        leaf.Key = objFile.FullName
                        leaf.ToolTip = objFile.Name
                        leaf.ImageIndex = eImageType.Page
                        node.TreeNodes.Add(leaf)
                    Next
                    found = True
                Else
                    'recurse
                    If PopulateTree(node.TreeNodes, folder) Then
                        ' found resources
                        found = True
                    Else
                        ' not found, remove node
                        Nodes.Remove(node)
                    End If
                End If
            Next

            Return found
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Loads suported locales
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[vmasanas]	04/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub BindList()
            Dim ds As New DataSet
            Dim dv As DataView
            Dim i As Integer
            Dim localeKey As String
            Dim localeName As String


            ds.ReadXml(Server.MapPath(Localization.SupportedLocalesFile))
            dv = ds.Tables(0).DefaultView
            dv.Sort = "name ASC"

            cboLocales.Items.Clear()
            For i = 0 To dv.Count - 1
                localeKey = Convert.ToString(dv(i)("key"))
                localeName = Convert.ToString(dv(i)("name")) + " (" + localeKey + ")"
                cboLocales.Items.Add(New ListItem(localeName, localeKey))
            Next
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Loads Resource information
        ''' </summary>
        ''' <remarks>
        ''' If Localized file contains entries not found in the System Default they will be deleted.
        ''' If System Default contains entries not found in the Localized file user will be asked to add them.
        ''' </remarks>
        ''' <history>
        ''' 	[vmasanas]	04/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub BindGrid()
            Dim resDoc As New XmlDocument
            Dim node As XmlNode

            defaultXML = New XmlDocument
            defaultXML.Load(SelectedResourceFile)

            resDoc.Load(ResourceFile(SelectedResourceFile, cboLocales.SelectedValue))

            pnlMissing.Visible = False
            If cboLocales.SelectedValue <> Localization.SystemLocale Then
                ' Check for missing entries in localized file
                For Each node In defaultXML.SelectNodes("//root/data")
                    If resDoc.SelectSingleNode("//root/data[@name='" + node.Attributes("name").Value + "']") Is Nothing Then
                        pnlMissing.Visible = True
                        Exit For
                    End If
                Next
                ' Delete orphan entries in localized file not found in System Default
                If DeleteEntries(resDoc, defaultXML) Then
                    resDoc.Load(ResourceFile(SelectedResourceFile, cboLocales.SelectedValue))
                End If
            End If

            Dim s As New SortedList
            For Each node In resDoc.SelectNodes("//root/data")
                Try
                    s.Add(node.Attributes.ItemOf("name").Value, node.SelectSingleNode("value").InnerXml)
                Catch
                    Skins.Skin.AddModuleMessage(Me, String.Format(Localization.GetString("DuplicateEntry", Me.LocalResourceFile), node.Attributes.ItemOf("name").Value), Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                End Try
            Next
            Dim a As New ArrayList(s)

            dgEditor.DataSource = a
            dgEditor.DataMember = "Resource"
            dgEditor.DataBind()

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Removes nodes in localized file not found in System default
        ''' </summary>
        ''' <param name="resourceFile">Resource file</param>
        ''' <param name="defaultFile">System Default resource file</param>
        ''' <remarks>
        ''' Deletes the nodes in the resource file as saves it
        ''' </remarks>
        ''' <history>
        ''' 	[VMasanas]	05/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function DeleteEntries(ByVal resDoc As XmlDocument, ByVal defDoc As XmlDocument) As Boolean
            Dim node, parent As XmlNode
            Dim needSave As Boolean = False

            For Each node In resDoc.SelectNodes("//root/data")
                If defDoc.SelectSingleNode("//root/data[@name='" + node.Attributes("name").Value + "']") Is Nothing Then
                    parent = node.ParentNode
                    parent.RemoveChild(node)
                    needSave = True
                End If
            Next

            Try
                If needSave Then
                    resDoc.Save(ResourceFile(SelectedResourceFile, cboLocales.SelectedValue))
                End If
            Catch
                UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("Save.ErrorMessage", Me.LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
            End Try

            Return needSave
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Returns the resource file name for a given resource and language
        ''' </summary>
        ''' <param name="filename">Resource File</param>
        ''' <param name="language">Language</param>
        ''' <param name="forceHost">When true will return the general resource file name, not portal specific</param>
        ''' <returns>Localized File Name</returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[vmasanas]	04/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function ResourceFile(ByVal filename As String, ByVal language As String, ByVal forceHost As Boolean) As String
            Dim resourcefilename As String = filename
            If Not filename.EndsWith(".resx") Then
                resourcefilename &= ".resx"
            End If

            If language <> Services.Localization.Localization.SystemLocale Then
                resourcefilename = resourcefilename.Substring(0, resourcefilename.Length - 5) + "." + language + ".resx"
            End If

            ' if accessing from Admin menu -> edit custom portal locale
            If adminMode And Not forceHost Then
                resourcefilename = resourcefilename.Substring(0, resourcefilename.Length - 5) + ".Portal-" + PortalSettings.PortalId.ToString + ".resx"
            End If

            Return resourcefilename

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Returns the resource file name for a given resource and language
        ''' </summary>
        ''' <param name="filename">Resource File</param>
        ''' <param name="language">Language</param>
        ''' <returns>Localized File Name</returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[vmasanas]	04/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function ResourceFile(ByVal filename As String, ByVal language As String) As String

            Return ResourceFile(filename, language, False)

        End Function

#End Region

#Region "Private Members"
        Private adminMode As Boolean
        Private defaultXML As XmlDocument

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Saves / Gets the selected resource file being edited in viewstate
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[vmasanas]	07/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Property SelectedResourceFile() As String
            Get
                Return Viewstate("SelectedResourceFile").ToString
            End Get
            Set(ByVal Value As String)
                viewstate("SelectedResourceFile") = Value
                lblResourceFile.Text = Value.Replace(ApplicationMapPath, "")
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Identifies images in TreeView
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[vmasanas]	07/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Enum eImageType
            Folder = 0
            Page = 1
        End Enum
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
