'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Modules.Actions
Imports DotNetNuke.UI.Skins

Namespace DotNetNuke.UI.Containers

	''' -----------------------------------------------------------------------------
	''' Project	 : DotNetNuke
	''' Class	 : Containers.ActionBase
	''' 
	''' -----------------------------------------------------------------------------
	''' <summary>
	''' ActionBase is the base for the Action objects 
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[cnurse]	10/07/2004	Documented
	''' </history>
	''' -----------------------------------------------------------------------------
    Public MustInherit Class ActionBase

        Inherits UI.Skins.SkinObjectBase

        Protected _menuActions As ModuleActionCollection
        Protected _menuActionRoot As ModuleAction
		Protected _portalModule As Entities.Modules.PortalModuleBase
		Protected _tabPreview As Boolean = False
		Protected _editMode As Boolean = False
		Protected _adminModule As Boolean = False
		Protected _adminControl As Boolean = False
        Protected _moduleConfiguration As ModuleInfo
		Protected _supportsIcons As Boolean = True

		Public Event Action As ActionEventHandler

		Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Init
			_portalModule = Container.GetPortalModuleBase(Me)

            If Not Request.Cookies("_Tab_Admin_Preview" & _portalModule.PortalSettings.PortalId.ToString) Is Nothing Then
                If Not _portalModule.PortalSettings.ActiveTab.IsAdminTab Then
                    _tabPreview = Boolean.Parse(Request.Cookies("_Tab_Admin_Preview" & _portalModule.PortalSettings.PortalId.ToString).Value)
                End If
            End If

            _adminControl = IsAdminControl()

            If Not _portalModule.ModuleConfiguration Is Nothing Then
                _editMode = PortalSecurity.IsInRoles(_portalModule.PortalSettings.AdministratorRoleName) Or PortalSecurity.IsInRoles(_portalModule.PortalSettings.ActiveTab.AdministratorRoles.ToString)
                _adminModule = _portalModule.ModuleConfiguration.IsAdmin
            End If
		End Sub

		Protected Overridable Sub OnAction(ByVal e As ActionEventArgs)
			RaiseEvent Action(Me, e)
		End Sub

		Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try
				_menuActionRoot = New ModuleAction(0, " ", "", "", "action.gif")

				' custom module actions defined in the code behind for each module
				Dim userAction As ModuleAction
				Dim intItem As Integer
				For intItem = 0 To MenuActions.Count - 1
					userAction = MenuActions(intItem)
					If userAction.Icon = "" Then
						userAction.Icon = "edit.gif"
					End If
					_menuActionRoot.Actions.Insert(0, New ModuleAction(GetNextActionID, userAction.Title, userAction.CommandName, userAction.CommandArgument, userAction.Icon, userAction.Url, userAction.ClientScript, userAction.UseActionEvent, userAction.Secure, userAction.Visible, userAction.NewWindow))
				Next intItem

				' help module actions available to content editors and administrators
				If Services.Localization.Localization.GetString(ModuleActionType.HelpText, _portalModule.LocalResourceFile) <> "" Then
                    _menuActionRoot.Actions.Add(GetNextActionID, Services.Localization.Localization.GetString(ModuleActionType.ModuleHelp, Services.Localization.Localization.GlobalResourceFile), ModuleActionType.ModuleHelp, "", "help.gif", NavigateURL(_portalModule.TabId, "Help", "ctlid=" & _portalModule.ModuleConfiguration.ModuleControlId.ToString, "moduleid=" & _portalModule.ModuleId), Secure:=SecurityAccessLevel.Edit, Visible:=True, NewWindow:=False)
				End If
				If Not Null.IsNull(_portalModule.ModuleConfiguration.HelpUrl) Then
					_menuActionRoot.Actions.Add(GetNextActionID, Services.Localization.Localization.GetString(ModuleActionType.OnlineHelp, Services.Localization.Localization.GlobalResourceFile), ModuleActionType.OnlineHelp, "", "help.gif", Services.Localization.Localization.GetHelpUrl(_portalModule.ModuleConfiguration.HelpUrl, _portalModule.PortalSettings), UseActionEvent:=True, Secure:=SecurityAccessLevel.Edit, Visible:=True, NewWindow:=True)
				ElseIf _portalModule.HelpURL <> "" Then
					_menuActionRoot.Actions.Add(GetNextActionID, Services.Localization.Localization.GetString(ModuleActionType.OnlineHelp, Services.Localization.Localization.GlobalResourceFile), ModuleActionType.OnlineHelp, "", "help.gif", Services.Localization.Localization.GetHelpUrl(_portalModule.HelpURL, _portalModule.PortalSettings), UseActionEvent:=True, Secure:=SecurityAccessLevel.Edit, Visible:=True, NewWindow:=True)
				End If

                ' print module action available to everyone
                _menuActionRoot.Actions.Add(GetNextActionID, Services.Localization.Localization.GetString(ModuleActionType.PrintModule, Services.Localization.Localization.GlobalResourceFile), ModuleActionType.PrintModule, "", "print.gif", NavigateURL(_portalModule.TabId, "", "mid=" & _portalModule.ModuleId.ToString, "SkinSrc=" & QueryStringEncode("[G]" & SkinInfo.RootSkin & "/" & glbHostSkinFolder & "/" & "No Skin"), "ContainerSrc=" & QueryStringEncode("[G]" & SkinInfo.RootContainer & "/" & glbHostSkinFolder & "/" & "No Container"), "dnnprintmode=true"), "", False, SecurityAccessLevel.Anonymous, True, True)

				' core module actions only available to administrators 
				If _editMode = True And _adminModule = False And _adminControl = False Then
					' module settings
					_menuActionRoot.Actions.Add(GetNextActionID, "~", "")
					_menuActionRoot.Actions.Add(GetNextActionID, Services.Localization.Localization.GetString(ModuleActionType.ModuleSettings, Services.Localization.Localization.GlobalResourceFile), ModuleActionType.ModuleSettings, "", "settings.gif", NavigateURL(_portalModule.TabId, "Module", "ModuleId=" & _portalModule.ModuleId.ToString), secure:=SecurityAccessLevel.Admin, Visible:=True)
					_menuActionRoot.Actions.Add(GetNextActionID, Services.Localization.Localization.GetString(ModuleActionType.DeleteModule, Services.Localization.Localization.GlobalResourceFile), ModuleActionType.DeleteModule, _portalModule.ModuleConfiguration.ModuleId.ToString, "delete.gif", "", Services.Localization.Localization.GetString("DeleteModule.Confirm"), False, SecurityAccessLevel.Admin, True, False)
					If _portalModule.ModuleConfiguration.CacheTime <> 0 Then
						_menuActionRoot.Actions.Add(GetNextActionID, Services.Localization.Localization.GetString(ModuleActionType.ClearCache, Services.Localization.Localization.GlobalResourceFile), ModuleActionType.ClearCache, _portalModule.ModuleConfiguration.ModuleId.ToString, "restore.gif", secure:=SecurityAccessLevel.Admin, Visible:=True)
					End If

                    ' module movement
					_menuActionRoot.Actions.Add(GetNextActionID, "~", "")
					Dim MoveActionRoot As New ModuleAction(GetNextActionID, Services.Localization.Localization.GetString(ModuleActionType.MoveRoot, Services.Localization.Localization.GlobalResourceFile), "", "", "", "", "", False, SecurityAccessLevel.Admin, _editMode)
					' move module up/down
					If Not _portalModule.ModuleConfiguration Is Nothing Then
						SetMoveMenuVisibility(MoveActionRoot.Actions.Add(GetNextActionID(MoveActionRoot, 1), Services.Localization.Localization.GetString(ModuleActionType.MoveTop, Services.Localization.Localization.GlobalResourceFile), ModuleActionType.MoveTop, _portalModule.ModuleConfiguration.PaneName, Icon:="top.gif", secure:=SecurityAccessLevel.Admin, Visible:=_editMode))
						SetMoveMenuVisibility(MoveActionRoot.Actions.Add(GetNextActionID(MoveActionRoot, 1), Services.Localization.Localization.GetString(ModuleActionType.MoveUp, Services.Localization.Localization.GlobalResourceFile), ModuleActionType.MoveUp, _portalModule.ModuleConfiguration.PaneName, Icon:="up.gif", secure:=SecurityAccessLevel.Admin, Visible:=_editMode))
						SetMoveMenuVisibility(MoveActionRoot.Actions.Add(GetNextActionID(MoveActionRoot, 1), Services.Localization.Localization.GetString(ModuleActionType.MoveDown, Services.Localization.Localization.GlobalResourceFile), ModuleActionType.MoveDown, _portalModule.ModuleConfiguration.PaneName, Icon:="dn.gif", secure:=SecurityAccessLevel.Admin, Visible:=_editMode))
						SetMoveMenuVisibility(MoveActionRoot.Actions.Add(GetNextActionID(MoveActionRoot, 1), Services.Localization.Localization.GetString(ModuleActionType.MoveBottom, Services.Localization.Localization.GlobalResourceFile), ModuleActionType.MoveBottom, _portalModule.ModuleConfiguration.PaneName, Icon:="bottom.gif", secure:=SecurityAccessLevel.Admin, Visible:=_editMode))
					End If
					' move module to pane
                    For intItem = 0 To _portalModule.PortalSettings.ActiveTab.Panes.Count - 1
                        SetMoveMenuVisibility(MoveActionRoot.Actions.Add(GetNextActionID(MoveActionRoot, 2), Services.Localization.Localization.GetString(ModuleActionType.MovePane, Services.Localization.Localization.GlobalResourceFile) & " " & Convert.ToString(_portalModule.PortalSettings.ActiveTab.Panes(intItem)), ModuleActionType.MovePane, Convert.ToString(_portalModule.PortalSettings.ActiveTab.Panes(intItem)), Icon:="move.gif", secure:=SecurityAccessLevel.Admin, Visible:=_editMode))
                    Next intItem
                    Dim ma As ModuleAction
                    For Each ma In MoveActionRoot.Actions
                        If ma.Visible Then
                            _menuActionRoot.Actions.Add(MoveActionRoot)
                            Exit For
                        End If
                    Next
                End If

			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		Public Sub ProcessAction(ByVal ActionID As String)
			If IsNumeric(ActionID) Then
				Dim action As ModuleAction = GetAction(Convert.ToInt32(ActionID))
				Select Case action.CommandName
					Case ModuleActionType.ModuleHelp
						DoAction(action)
					Case ModuleActionType.OnlineHelp
						DoAction(action)
					Case ModuleActionType.ModuleSettings
						DoAction(action)
					Case ModuleActionType.DeleteModule
						Delete(action)
					Case ModuleActionType.PrintModule
						DoAction(action)
					Case ModuleActionType.ClearCache
						ClearCache(action)
					Case ModuleActionType.MovePane
						MoveToPane(action)
					Case ModuleActionType.MoveTop, ModuleActionType.MoveUp, ModuleActionType.MoveDown, ModuleActionType.MoveBottom
						MoveUpDown(action)
					Case Else					  ' custom action
						If action.Url.Length > 0 And action.UseActionEvent = False Then
							DoAction(action)
						Else
                            OnAction(New ActionEventArgs(action, ModuleConfiguration))
						End If
				End Select
			End If
		End Sub

		Private Sub DoAction(ByVal Command As ModuleAction)
			If Command.NewWindow Then
				Response.Write("<script>window.open('" & Command.Url & "','_blank')</script>")
			Else
				Response.Redirect(Command.Url, True)
			End If
		End Sub

		Private Sub MoveToPane(ByVal Command As ModuleAction)

			Dim objModules As New ModuleController

            objModules.UpdateModuleOrder(_portalModule.TabId, _portalModule.ModuleConfiguration.ModuleId, -1, Command.CommandArgument)
			objModules.UpdateTabModuleOrder(_portalModule.TabId)

			' Redirect to the same page to pick up changes
			Response.Redirect(Request.RawUrl, True)

		End Sub

		Private Sub MoveUpDown(ByVal Command As ModuleAction)

			Dim objModules As New ModuleController
			Select Case Command.CommandName
				Case ModuleActionType.MoveTop
                    objModules.UpdateModuleOrder(_portalModule.TabId, _portalModule.ModuleConfiguration.ModuleId, 0, Command.CommandArgument)
				Case ModuleActionType.MoveUp
                    objModules.UpdateModuleOrder(_portalModule.TabId, _portalModule.ModuleConfiguration.ModuleId, _portalModule.ModuleConfiguration.ModuleOrder - 3, Command.CommandArgument)
				Case ModuleActionType.MoveDown
                    objModules.UpdateModuleOrder(_portalModule.TabId, _portalModule.ModuleConfiguration.ModuleId, _portalModule.ModuleConfiguration.ModuleOrder + 3, Command.CommandArgument)
				Case ModuleActionType.MoveBottom
                    objModules.UpdateModuleOrder(_portalModule.TabId, _portalModule.ModuleConfiguration.ModuleId, (_portalModule.ModuleConfiguration.PaneModuleCount * 2) + 1, Command.CommandArgument)
			End Select

			objModules.UpdateTabModuleOrder(_portalModule.TabId)

			' Redirect to the same page to pick up changes
			Response.Redirect(Request.RawUrl, True)

		End Sub

		Private Sub Delete(ByVal Command As ModuleAction)

			Dim objModules As New ModuleController

            Dim objModule As ModuleInfo = objModules.GetModule(Integer.Parse(Command.CommandArgument), _portalModule.TabId)
            If Not objModule Is Nothing Then
                objModules.DeleteTabModule(_portalModule.TabId, Integer.Parse(Command.CommandArgument))

                Dim _UserInfo As UserInfo = UserController.GetCurrentUserInfo
                Dim objEventLog As New Services.Log.EventLog.EventLogController
				objEventLog.AddLog(objModule, PortalSettings, _UserInfo.UserID, "", Services.Log.EventLog.EventLogController.EventLogType.MODULE_SENT_TO_RECYCLE_BIN)
            End If

            ' Redirect to the same page to pick up changes
            Response.Redirect(Request.RawUrl, True)

		End Sub

		Private Sub ClearCache(ByVal Command As ModuleAction)

			DataCache.RemoveCache(_portalModule.CacheKey)

			' Redirect to the same page to pick up changes
			Response.Redirect(Request.RawUrl, True)

		End Sub


		''' -----------------------------------------------------------------------------
		''' <summary></summary>
		''' <returns></returns>
		''' <remarks></remarks>
		''' <history>
		''' 	[Nik Kalyani]	10/15/2004	Replaced Optional parameters with multiple method signatures
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Sub AddAction(ByVal Title As String, ByVal CmdName As String)
			AddAction(Title, CmdName, "", "", "", False, SecurityAccessLevel.Anonymous, False, False)
		End Sub
		Public Sub AddAction(ByVal Title As String, ByVal CmdName As String, ByVal CmdArg As String)
			AddAction(Title, CmdName, CmdArg, "", "", False, SecurityAccessLevel.Anonymous, False, False)
		End Sub
		Public Sub AddAction(ByVal Title As String, ByVal CmdName As String, ByVal CmdArg As String, ByVal Icon As String)
			AddAction(Title, CmdName, CmdArg, Icon, "", False, SecurityAccessLevel.Anonymous, False, False)
		End Sub
		Public Sub AddAction(ByVal Title As String, ByVal CmdName As String, ByVal CmdArg As String, ByVal Icon As String, ByVal Url As String)
			AddAction(Title, CmdName, CmdArg, Icon, Url, False, SecurityAccessLevel.Anonymous, False, False)
		End Sub
		Public Sub AddAction(ByVal Title As String, ByVal CmdName As String, ByVal CmdArg As String, ByVal Icon As String, ByVal Url As String, ByVal UseActionEvent As Boolean)
			AddAction(Title, CmdName, CmdArg, Icon, Url, UseActionEvent, SecurityAccessLevel.Anonymous, False, False)
		End Sub
		Public Sub AddAction(ByVal Title As String, ByVal CmdName As String, ByVal CmdArg As String, ByVal Icon As String, ByVal Url As String, ByVal UseActionEvent As Boolean, ByVal Secure As SecurityAccessLevel)
			AddAction(Title, CmdName, CmdArg, Icon, Url, UseActionEvent, Secure, False, False)
		End Sub
		Public Sub AddAction(ByVal Title As String, ByVal CmdName As String, ByVal CmdArg As String, ByVal Icon As String, ByVal Url As String, ByVal UseActionEvent As Boolean, ByVal Secure As SecurityAccessLevel, ByVal Visible As Boolean)
			AddAction(Title, CmdName, CmdArg, Icon, Url, UseActionEvent, Secure, Visible, False)
		End Sub
		Public Sub AddAction(ByVal Title As String, ByVal CmdName As String, ByVal CmdArg As String, ByVal Icon As String, ByVal Url As String, ByVal UseActionEvent As Boolean, ByVal Secure As SecurityAccessLevel, ByVal Visible As Boolean, ByVal NewWindow As Boolean)
			Dim Action As ModuleAction = MenuActions.Add(GetNextActionID, Title, CmdName, CmdArg, Icon, Url, UseActionEvent, Secure, Visible, NewWindow)
		End Sub
		Protected Function GetNextActionID() As Integer
			Return GetNextActionID(_menuActionRoot, 0)
		End Function

		Protected Function GetNextActionID(ByVal ModAction As ModuleAction, ByVal Level As Integer) As Integer
			Return ModAction.Actions.Count + (ModAction.ID * CType((10 ^ Level), Integer)) + 1
		End Function

		Public Function GetAction(ByVal Index As Integer) As ModuleAction
			Return GetAction(Index, _menuActionRoot)
		End Function

		Public Function GetAction(ByVal Index As Integer, ByVal ParentAction As ModuleAction) As ModuleAction
			Dim retAction As ModuleAction
			If Not ParentAction Is Nothing Then
				Dim modaction As ModuleAction
				For Each modaction In ParentAction.Actions
					If modaction.ID = Index Then
						retAction = modaction
						Exit For
					End If
					If modaction.HasChildren Then
						Dim ChildAction As ModuleAction = GetAction(Index, modaction)
						If Not ChildAction Is Nothing Then
							retAction = ChildAction
							Exit For
						End If
					End If
				Next
			End If
			Return retAction
		End Function

		Private Sub SetMoveMenuVisibility(ByVal Action As ModuleAction)

			Select Case Action.CommandName
				Case ModuleActionType.MoveTop
					Action.Visible = (_portalModule.ModuleConfiguration.ModuleOrder <> 0) And (_portalModule.ModuleConfiguration.PaneModuleIndex > 0) And _editMode
				Case ModuleActionType.MoveUp
					Action.Visible = (_portalModule.ModuleConfiguration.ModuleOrder <> 0) And (_portalModule.ModuleConfiguration.PaneModuleIndex > 0) And _editMode
				Case ModuleActionType.MoveDown
					Action.Visible = (_portalModule.ModuleConfiguration.ModuleOrder <> 0) And (_portalModule.ModuleConfiguration.PaneModuleIndex < (_portalModule.ModuleConfiguration.PaneModuleCount - 1)) And _editMode
				Case ModuleActionType.MoveBottom
					Action.Visible = (_portalModule.ModuleConfiguration.ModuleOrder <> 0) And (_portalModule.ModuleConfiguration.PaneModuleIndex < (_portalModule.ModuleConfiguration.PaneModuleCount - 1)) And _editMode
				Case ModuleActionType.MovePane
					Action.Visible = (LCase(_portalModule.ModuleConfiguration.PaneName) <> LCase(Action.CommandArgument)) And _editMode
			End Select

		End Sub

		Public ReadOnly Property ActionRoot() As ModuleAction
			Get
				Return _menuActionRoot
			End Get
		End Property

		Public ReadOnly Property MenuActions() As ModuleActionCollection
			Get
				If _menuActions Is Nothing Then
					_menuActions = New ModuleActionCollection
				End If
				Return _menuActions
			End Get
		End Property

		Public ReadOnly Property EditMode() As Boolean
			Get
				Return _editMode
			End Get
		End Property

        Public Property ModuleConfiguration() As ModuleInfo
            Get
                Return _moduleConfiguration
            End Get
            Set(ByVal Value As ModuleInfo)
                _moduleConfiguration = Value
            End Set
        End Property

        Public ReadOnly Property SupportsIcons() As Boolean
            Get
                Return _supportsIcons
            End Get
        End Property

    End Class
End Namespace
