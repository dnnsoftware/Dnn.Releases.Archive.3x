'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Modules.Actions

'Legacy Support
Namespace DotNetNuke
	<Obsolete("This class is obsolete.  Please use DotNetNuke.UI.Containers.Container.")> _
	Public Class Container
		Inherits DotNetNuke.UI.Containers.Container
	End Class
End Namespace

Namespace DotNetNuke.UI.Containers

	Public Class Container

		Inherits System.Web.UI.UserControl

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

#End Region

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'
			' CODEGEN: This call is required by the ASP.NET Web Form Designer.
			'
			InitializeComponent()

			' iterate page controls
			Dim ctlControl As Control
			For Each ctlControl In Me.Controls
				' update the image paths ( only used in Portable skins ) 
				If ctlControl.GetType().ToString = "System.Web.UI.HtmlControls.HtmlImage" Then
					Dim strSrc As String = CType(ctlControl, HtmlImage).Src
					If strSrc <> "" Then
						If strSrc.StartsWith("~") = False And strSrc.StartsWith("/") = False And strSrc.IndexOf("://") = -1 And strSrc.IndexOf("\\") = -1 Then
							CType(ctlControl, HtmlImage).Src = Me.TemplateSourceDirectory & "/" & strSrc
						End If
					End If
				End If
				If ctlControl.GetType().ToString = "System.Web.UI.HtmlControls.HtmlTableCell" Then
					Dim strBackground As String = CType(ctlControl, HtmlTableCell).Attributes.Item("background")
					If strBackground <> "" Then
						If strBackground.StartsWith("~") = False And strBackground.StartsWith("/") = False And strBackground.IndexOf("://") = -1 And strBackground.IndexOf("\\") = -1 Then
							CType(ctlControl, HtmlTableCell).Attributes.Item("background") = Me.TemplateSourceDirectory & "/" & strBackground
						End If
					End If
				End If
			Next

		End Sub

		Public Shared Function GetPortalModuleBase(ByVal objControl As UserControl) As Entities.Modules.PortalModuleBase

			Dim objPortalModuleBase As Entities.Modules.PortalModuleBase

			Dim ctlPanel As Panel

            If TypeOf objControl Is UI.Skins.SkinObjectBase Then
                ctlPanel = CType(objControl.Parent.FindControl("ModuleContent"), Panel)
            Else
                ctlPanel = CType(objControl.FindControl("ModuleContent"), Panel)
            End If

            If Not ctlPanel Is Nothing Then
                Try
                    objPortalModuleBase = CType(ctlPanel.Controls(0), PortalModuleBase)
                Catch
                    ' module was not loaded correctly
                End Try
            End If

            If objPortalModuleBase Is Nothing Then
                objPortalModuleBase = New PortalModuleBase
                objPortalModuleBase.ModuleConfiguration = New ModuleInfo
            End If

            Return objPortalModuleBase

		End Function

	End Class

End Namespace