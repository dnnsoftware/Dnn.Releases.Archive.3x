'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data
Imports System.XML
Imports System.io
Imports DotNetNuke.Entities.Tabs
Imports DotNetNuke.Security.Roles
Imports DotNetNuke.UI.Skins
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Modules.Definitions
Imports DotNetNuke.Services.FileSystem
Imports ICSharpCode.SharpZipLib.Zip


Namespace DotNetNuke.Entities.Portals

	Public Enum PortalTemplateModuleAction
		Ignore
		Merge
		Replace
	End Enum


    Public Class PortalController

        Public Shared Function GetCurrentPortalSettings() As PortalSettings
            Return CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates a new portal.
        ''' </summary>
        ''' <param name="PortalName">Name of the portal to be created</param>
        ''' <param name="FirstName">Portal Administrator's first name</param>
        ''' <param name="LastName">Portal Administrator's last name</param>
        ''' <param name="Username">Portal Administrator's username</param>
        ''' <param name="Password">Portal Administrator's password</param>
        ''' <param name="Email">Portal Administrator's email</param>
        ''' <param name="Description>Description for the new portal</param>
        ''' <param name="KeyWords>KeyWords for the new portal</param>
        ''' <param name="TemplatePath">Path where the templates are stored</param>
        ''' <param name="TemplateFile">Template file</param>
        ''' <param name="PortalAlias">Portal Alias String</param>
        ''' <param name="ServerPath">The Path to the root of the Application</param>
        ''' <param name="ChildPath">The Path to the Child Portal Folder</param>
        ''' <param name="IsChildPortal">True if this is a child portal</param>
        ''' <returns>PortalId of the new portal if there are no errors, -1 otherwise.</returns>
        ''' <remarks>
        ''' After the selected portal template is parsed the admin template ("admin.template") will be
        ''' also processed. The admin template should only contain the "Admin" menu since it's the same
        ''' on all portals. The selected portal template can contain a <settings> node to specify portal
        ''' properties and a <roles> node to define the roles that will be created on the portal by default.
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	11/08/2004	created (most of this code was moved from SignUp.ascx.vb)
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function CreatePortal(ByVal PortalName As String, ByVal FirstName As String, ByVal LastName As String, ByVal Username As String, ByVal Password As String, ByVal Email As String, ByVal Description As String, ByVal KeyWords As String, ByVal TemplatePath As String, ByVal TemplateFile As String, ByVal HomeDirectory As String, ByVal PortalAlias As String, ByVal ServerPath As String, ByVal ChildPath As String, ByVal IsChildPortal As Boolean) As Integer

            Dim intPortalId As Integer

            intPortalId = AddPortalInfo(PortalName, FirstName, LastName, Username, Password, Email, HomeDirectory)


            If HomeDirectory = "" Then
                HomeDirectory = "Portals/" + intPortalId.ToString
            End If
            Dim MappedHomeDirectory As String
            Dim objFolderController As New Services.FileSystem.FolderController
            'objFolderController.SetMappedDirectory(Common.Globals.ApplicationPath + "/" + HomeDirectory + "/", HttpContext.Current)
            MappedHomeDirectory = objFolderController.GetMappedDirectory(Common.Globals.ApplicationPath + "/" + HomeDirectory + "/")

            If intPortalId <> -1 Then

                ' add administrator
                Dim AdministratorId As Integer = -1
                Dim objUser As New UserController
                Dim objAdminUser As New UserInfo

                Try
                    objAdminUser.Profile.FirstName = FirstName
                    objAdminUser.Profile.LastName = LastName
                    objAdminUser.PortalID = intPortalId
                    objAdminUser.Membership.Username = Username
                    objAdminUser.Membership.Password = Password
                    objAdminUser.Membership.Email = Email
                    objAdminUser.Membership.Approved = True
                    AdministratorId = objUser.AddUser(objAdminUser)
                Catch
                    ' error creating admin user account - duplicate username but different password
                End Try

                If AdministratorId > 0 Then

                    ' the upload directory may already exist if this is a new DB working with a previously installed application
                    If Directory.Exists(MappedHomeDirectory) Then
                        DeleteFolderRecursive(MappedHomeDirectory)
                    End If

                    'Set up Child Portal
                    If IsChildPortal Then
                        ' create the subdirectory for the new portal
                        System.IO.Directory.CreateDirectory(ChildPath)

                        ' create the subhost default.aspx file
                        System.IO.File.Copy(Common.Globals.HostMapPath & "subhost.aspx", ChildPath & "\" & glbDefaultPage)
                    End If

                    ' create the upload directory for the new portal
                    System.IO.Directory.CreateDirectory(MappedHomeDirectory)

                    ' copy the default stylesheet to the upload directory
                    System.IO.File.Copy(Common.Globals.HostMapPath & "portal.css", MappedHomeDirectory & "portal.css")

                    ' process zip resource file if present
                    ProcessResourceFile(intPortalId, MappedHomeDirectory, TemplatePath & TemplateFile)

                    ' parse portal template
                    ParseTemplate(intPortalId, TemplatePath, TemplateFile, AdministratorId, PortalTemplateModuleAction.Replace)

                    ' parse admin template
                    ParseTemplate(intPortalId, TemplatePath, "admin.template", AdministratorId, PortalTemplateModuleAction.Replace)

                    ' update portal setup
                    Dim objportal As PortalInfo = GetPortal(intPortalId)

                    ' update portal info
                    objportal.Description = Description
                    objportal.KeyWords = KeyWords
                    UpdatePortalInfo(objportal.PortalID, objportal.PortalName, objportal.LogoFile, objportal.FooterText, _
                     objportal.ExpiryDate, objportal.UserRegistration, objportal.BannerAdvertising, objportal.Currency, objportal.AdministratorId, objportal.HostFee, _
                     objportal.HostSpace, objportal.PaymentProcessor, objportal.ProcessorUserId, objportal.ProcessorPassword, objportal.Description, _
                     objportal.KeyWords, objportal.BackgroundFile, objportal.SiteLogHistory, objportal.SplashTabId, objportal.HomeTabId, objportal.LoginTabId, objportal.UserTabId, _
                     objportal.DefaultLanguage, objportal.TimeZoneOffset, objportal.HomeDirectory)

                    'Update Administrators Locale/TimeZone
                    objAdminUser.Profile.PreferredLocale = objportal.DefaultLanguage
                    objAdminUser.Profile.TimeZone = objportal.TimeZoneOffset
                    objUser.UpdateUser(objAdminUser)

                    'clear portal alias cache
                    DataCache.ClearCoreCache(CoreCacheType.Host, cascade:=True)

                    ' clear roles cache
                    DataCache.RemoveCache("GetRoles")

                    'Create Portal Alias
                    AddPortalAlias(intPortalId, PortalAlias)

                Else    ' clean up
                    DeletePortalInfo(intPortalId)
                End If

            End If

            Return intPortalId

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Updates basic portal information
        ''' </summary>
        ''' <param name="Portal"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	10/13/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub UpdatePortalInfo(ByVal Portal As PortalInfo)

            UpdatePortalInfo(Portal.PortalID, Portal.PortalName, _
             Portal.LogoFile, Portal.FooterText, Portal.ExpiryDate, Portal.UserRegistration, _
             Portal.BannerAdvertising, Portal.Currency, Portal.AdministratorId, _
             Portal.HostFee, Portal.HostSpace, Portal.PaymentProcessor, Portal.ProcessorUserId, _
             Portal.ProcessorPassword, Portal.Description, Portal.KeyWords, _
             Portal.BackgroundFile, Portal.SiteLogHistory, Portal.SplashTabId, Portal.HomeTabId, _
             Portal.LoginTabId, Portal.UserTabId, Portal.DefaultLanguage, Portal.TimeZoneOffset, Portal.HomeDirectory)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Updates basic portal information
        ''' </summary>
        ''' <param name="PortalId"></param>
        ''' <param name="PortalName"></param>
        ''' <param name="LogoFile"></param>
        ''' <param name="FooterText"></param>
        ''' <param name="ExpiryDate"></param>
        ''' <param name="UserRegistration"></param>
        ''' <param name="BannerAdvertising"></param>
        ''' <param name="Currency"></param>
        ''' <param name="AdministratorId"></param>
        ''' <param name="HostFee"></param>
        ''' <param name="HostSpace"></param>
        ''' <param name="PaymentProcessor"></param>
        ''' <param name="ProcessorUserId"></param>
        ''' <param name="ProcessorPassword"></param>
        ''' <param name="Description"></param>
        ''' <param name="KeyWords"></param>
        ''' <param name="BackgroundFile"></param>
        ''' <param name="SiteLogHistory"></param>
        ''' <param name="HomeTabId"></param>
        ''' <param name="LoginTabId"></param>
        ''' <param name="UserTabId"></param>
        ''' <param name="DefaultLanguage"></param>
        ''' <param name="TimeZoneOffset"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub UpdatePortalInfo(ByVal PortalId As Integer, ByVal PortalName As String, ByVal LogoFile As String, ByVal FooterText As String, ByVal ExpiryDate As Date, ByVal UserRegistration As Integer, ByVal BannerAdvertising As Integer, ByVal Currency As String, ByVal AdministratorId As Integer, ByVal HostFee As Double, ByVal HostSpace As Double, ByVal PaymentProcessor As String, ByVal ProcessorUserId As String, ByVal ProcessorPassword As String, ByVal Description As String, ByVal KeyWords As String, ByVal BackgroundFile As String, ByVal SiteLogHistory As Integer, ByVal SplashTabId As Integer, ByVal HomeTabId As Integer, ByVal LoginTabId As Integer, ByVal UserTabId As Integer, ByVal DefaultLanguage As String, ByVal TimeZoneOffset As Integer, ByVal HomeDirectory As String)

            DataProvider.Instance().UpdatePortalInfo(PortalId, PortalName, LogoFile, FooterText, ExpiryDate, UserRegistration, BannerAdvertising, Currency, AdministratorId, HostFee, HostSpace, PaymentProcessor, ProcessorUserId, ProcessorPassword, Description, KeyWords, BackgroundFile, SiteLogHistory, SplashTabId, HomeTabId, LoginTabId, UserTabId, DefaultLanguage, TimeZoneOffset, HomeDirectory)

            ' clear portal settings
            DataCache.ClearCoreCache(CoreCacheType.Portal, PortalId, True)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Deletes a portal permanently
        ''' </summary>
        ''' <param name="PortalId">PortalId of the portal to be deleted</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[VMasanas]	03/09/2004	Created
        ''' 	[VMasanas]	26/10/2004	Remove dependent data (skins, modules)
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub DeletePortalInfo(ByVal PortalId As Integer)
            ' remove skin assignments
            Dim objSkins As New UI.Skins.SkinController
            objSkins.SetSkin(SkinInfo.RootSkin, PortalId, SkinType.Portal, "")
            objSkins.SetSkin(SkinInfo.RootContainer, PortalId, SkinType.Portal, "")
            objSkins.SetSkin(SkinInfo.RootSkin, PortalId, SkinType.Admin, "")
            objSkins.SetSkin(SkinInfo.RootContainer, PortalId, SkinType.Admin, "")

            ' remove portal modules
            Dim objModules As New ModuleController
            Dim objModule As ModuleInfo
            For Each objModule In objModules.GetModules(PortalId)
                objModules.DeleteModule(objModule.ModuleID)
            Next

            DataProvider.Instance().DeletePortalInfo(PortalId)

            ' clear portal alias cache and entire portal
            DataCache.ClearCoreCache(CoreCacheType.Host, cascade:=True)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets information from all portals
        ''' </summary>
        ''' <returns>ArrayList of PortalInfo objects</returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetPortals() As ArrayList

            Return CBO.FillCollection(DataProvider.Instance().GetPortals(), GetType(PortalInfo))

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets information of a portal
        ''' </summary>
        ''' <param name="PortalId">Id of the portal</param>
        ''' <returns>PortalInfo object with portal definition</returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
		Public Function GetPortal(ByVal PortalId As Integer) As PortalInfo

			Return CType(CBO.FillObject(DataProvider.Instance().GetPortal(PortalId), GetType(PortalInfo)), PortalInfo)

		End Function

		Public Sub UpdatePortalExpiry(ByVal PortalId As Integer)

			Dim ExpiryDate As DateTime

			Dim dr As IDataReader = DataProvider.Instance().GetPortal(PortalId)
			If dr.Read Then
				If IsDBNull(dr("ExpiryDate")) Then
					ExpiryDate = Convert.ToDateTime(dr("ExpiryDate"))
				Else
					ExpiryDate = Now()
				End If

				DataProvider.Instance().UpdatePortalInfo(PortalId, Convert.ToString(dr("PortalName")), Convert.ToString(dr("LogoFile")), Convert.ToString(dr("FooterText")), DateAdd(DateInterval.Month, 1, ExpiryDate), Convert.ToInt32(dr("UserRegistration")), Convert.ToInt32(dr("BannerAdvertising")), Convert.ToString(dr("Currency")), Convert.ToInt32(dr("AdministratorId")), Convert.ToDouble(dr("HostFee")), Convert.ToDouble(dr("HostSpace")), Convert.ToString(dr("PaymentProcessor")), Convert.ToString(dr("ProcessorUserId")), Convert.ToString(dr("ProcessorPassword")), Convert.ToString(dr("Description")), Convert.ToString(dr("KeyWords")), Convert.ToString(dr("BackgroundFile")), Convert.ToInt32(dr("SiteLogHistory")), Convert.ToInt32(dr("SplashTabId")), Convert.ToInt32(dr("HomeTabId")), Convert.ToInt32(dr("LoginTabId")), Convert.ToInt32(dr("UserTabId")), Convert.ToString(dr("DefaultLanguage")), Convert.ToInt32(dr("TimeZoneOffset")), Convert.ToString(dr("HomeDirectory")))
			End If
			dr.Close()

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Gets the space used by a portal
		''' </summary>
		''' <param name="PortalId">Id of the portal</param>
		''' <returns>Space used in bytes</returns>
		''' <remarks>
		''' If PortalId is -1 or not  present (defaults to -1) the host space (\Portals\_default\) will be returned.
		''' </remarks>
		''' <history>
		''' 	[VMasanas]	27/08/2004	Changed to return the real space used by a portal looking at the files on disc.
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Function GetPortalSpaceUsed(Optional ByVal PortalId As Integer = -1) As Integer
			Dim path As String

			If PortalId = -1 Then
				path = Common.Globals.HostMapPath()
			Else
				Dim objPortalController As New PortalController
				Dim objPortal As PortalInfo = objPortalController.GetPortal(PortalId)
				path = objPortal.HomeDirectoryMapPath
			End If

			Dim folder As New DirectoryInfo(path)
			Return Convert.ToInt32(GetFolderSize(folder))

		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Gets the total size of a folder
		''' </summary>
		''' <param name="dirInfo">The directory to get the size</param>
		''' <returns>Size of the folder</returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[VMasanas]	18/09/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Function GetFolderSize(ByVal dirInfo As DirectoryInfo) As Long
			Dim size As Long = 0

			For Each file As IO.FileInfo In dirInfo.GetFiles()
				size += file.Length
			Next
			For Each folder As IO.DirectoryInfo In dirInfo.GetDirectories()
				size += GetFolderSize(folder)
			Next

			Return size
		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Processess a template file for the new portal. This method will be called twice: for the portal template and for the admin template
		''' </summary>
		''' <param name="PortalId">PortalId of the new portal</param>
		''' <param name="TemplatePath">Path for the folder where templates are stored</param>
		''' <param name="TemplateFile">Template file to process</param>
		''' <param name="AdministratorId">UserId for the portal administrator. This is used to assign roles to this user</param>
		''' <param name="mergeTabs">Flag to determine whether Module content is merged.</param>
		''' <remarks>
		''' The roles and settings nodes will only be processed on the portal template file.
		''' </remarks>
		''' <history>
		''' 	[VMasanas]	27/08/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Friend Sub ParseTemplate(ByVal PortalId As Integer, ByVal TemplatePath As String, ByVal TemplateFile As String, ByVal AdministratorId As Integer, ByVal mergeTabs As PortalTemplateModuleAction)

			Dim xmlDoc As New XmlDocument
			Dim node As XmlNode
			Dim AdministratorRoleId As Integer = -1
			Dim RegisteredRoleId As Integer = -1
			Dim SubscriberRoleId As Integer = -1
			Dim objrole As New RoleController
			Dim isAdminTemplate As Boolean

			isAdminTemplate = (TemplateFile = "admin.template")

			' open the XML file
			Try
				xmlDoc.Load(TemplatePath & TemplateFile)
			Catch			 ' error
				' 
			End Try

			' settings, roles, folders and files can only be specified in portal templates, will be ignored on the admin template
			If Not isAdminTemplate Then
				' parse portal settings if available
				node = xmlDoc.SelectSingleNode("//portal/settings")
				If Not node Is Nothing Then
					ParsePortalSettings(node, PortalId)
				End If

				' parse roles if available
				node = xmlDoc.SelectSingleNode("//portal/roles")
				If Not node Is Nothing Then
					ParseRoles(node, PortalId, AdministratorId, AdministratorRoleId, RegisteredRoleId, SubscriberRoleId)
				End If

				' create required roles if not already created
				If AdministratorRoleId = -1 Then
					AdministratorRoleId = CreateRole(PortalId, "Administrators", "Portal Administrators", 0, 0, "M", 0, 0, "N", False, False)
				End If
				If RegisteredRoleId = -1 Then
					RegisteredRoleId = CreateRole(PortalId, "Registered Users", "Registered Users", 0, 0, "M", 0, 0, "N", False, True)
				End If
				If SubscriberRoleId = -1 Then
					SubscriberRoleId = CreateRole(PortalId, "Subscribers", "A public role for portal subscriptions", 0, 0, "M", 0, 0, "N", True, True)
				End If

				objrole.AddUserRole(PortalId, AdministratorId, AdministratorRoleId, Null.NullDate)
				objrole.AddUserRole(PortalId, AdministratorId, RegisteredRoleId, Null.NullDate)
				objrole.AddUserRole(PortalId, AdministratorId, SubscriberRoleId, Null.NullDate)

				' update portal setup
				Dim objportal As PortalInfo
				objportal = GetPortal(PortalId)
				DataProvider.Instance().UpdatePortalSetup(PortalId, AdministratorId, AdministratorRoleId, RegisteredRoleId, objportal.SplashTabId, objportal.HomeTabId, objportal.LoginTabId, objportal.UserTabId, objportal.AdminTabId)

				' parse portal folders
				node = xmlDoc.SelectSingleNode("//portal/folders")
				If Not node Is Nothing Then
					ParseFolders(node, PortalId)
                End If

                'Remove Exising Tabs if doing a "Replace"
                If mergeTabs = PortalTemplateModuleAction.Replace Then
                    Dim objTabs As New TabController
                    Dim arrTabs As ArrayList = objTabs.GetTabs(PortalId)
                    Dim objTab As TabInfo
                    For Each objTab In arrTabs
                        If Not objTab.IsAdminTab Then
                            'soft delete Tab
                            objTab.TabName = objTab.TabName & "_old"
                            objTab.IsDeleted = True
                            objTabs.UpdateTab(objTab)
                            'Delete all Modules
                            Dim objModules As New ModuleController
                            Dim arrModules As ArrayList = objModules.GetPortalTabModules(objTab.PortalID, objTab.TabID)
                            Dim objModule As ModuleInfo
                            For Each objModule In arrModules
                                objModules.DeleteTabModule(objModule.TabID, objModule.ModuleID)
                            Next
                        End If
                    Next
                End If
            End If

            ' parse portal tabs
            node = xmlDoc.SelectSingleNode("//portal/tabs")
            If Not node Is Nothing Then
                ParseTabs(node, PortalId, isAdminTemplate, mergeTabs)
            End If

		End Sub


#Region "Private Methods"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Creates a new portal alias
		''' </summary>
		''' <param name="PortalId">Id of the portal</param>
		''' <param name="PortalAlias">Portal Alias to be created</param>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''     [cnurse]    01/11/2005  created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub AddPortalAlias(ByVal PortalId As Integer, ByVal PortalAlias As String)

			Dim objPortalAliasController As New PortalAliasController
			Dim objPortalAliasInfo As New PortalAliasInfo
			objPortalAliasInfo.PortalID = PortalId
			objPortalAliasInfo.HTTPAlias = PortalAlias
			objPortalAliasController.AddPortalAlias(objPortalAliasInfo)

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Creates a new portal based on the portal template provided.
		''' </summary>
		''' <param name="PortalName">Name of the portal to be created</param>
		''' <param name="FirstName">Portal Administrator's first name</param>
		''' <param name="LastName">Portal Administrator's last name</param>
		''' <param name="Username">Portal Administrator's username</param>
		''' <param name="Password">Portal Administrator's password</param>
		''' <param name="Email">Portal Administrator's email</param>
		''' <returns>PortalId of the new portal if there are no errors, -1 otherwise.</returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[VMasanas]	03/09/2004	Modified to support new template format.
		'''                             Portal template file should be processed before admin.template
		'''     [cnurse]    01/11/2005  Template parsing moved to CreatePortal
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Function AddPortalInfo(ByVal PortalName As String, ByVal FirstName As String, ByVal LastName As String, ByVal Username As String, ByVal Password As String, ByVal Email As String, ByVal HomeDirectory As String) As Integer

			' add portal
			Dim PortalId As Integer = -1
			Try
				' Use host settings as default values for these parameters
				' This can be overwritten on the portal template
				Dim datExpiryDate As Date
				If Convert.ToString(Common.Globals.HostSettings("DemoPeriod")) <> "" Then
					datExpiryDate = Convert.ToDateTime(GetMediumDate(DateAdd(DateInterval.Day, Int32.Parse(Convert.ToString(Common.Globals.HostSettings("DemoPeriod"))), Now()).ToString))
				Else
					datExpiryDate = Null.NullDate
				End If

				Dim dblHostFee As Double = 0
				If Convert.ToString(Common.Globals.HostSettings("HostFee")) <> "" Then
					dblHostFee = Convert.ToDouble(Common.Globals.HostSettings("HostFee"))
				End If

				Dim dblHostSpace As Double = 0
				If Convert.ToString(Common.Globals.HostSettings("HostSpace")) <> "" Then
					dblHostSpace = Convert.ToDouble(Common.Globals.HostSettings("HostSpace"))
				End If

				Dim intSiteLogHistory As Integer = -1
				If Convert.ToString(Common.Globals.HostSettings("SiteLogHistory")) <> "" Then
					intSiteLogHistory = Convert.ToInt32(Common.Globals.HostSettings("SiteLogHistory"))
				End If

				Dim strCurrency As String = Convert.ToString(Common.Globals.HostSettings("HostCurrency"))
				If strCurrency = "" Then
					strCurrency = "USD"
				End If
				PortalId = DataProvider.Instance().AddPortalInfo(PortalName, strCurrency, FirstName, LastName, Username, Password, Email, datExpiryDate, dblHostFee, dblHostSpace, intSiteLogHistory, HomeDirectory)

			Catch
				' error creating portal
			End Try

			Return PortalId

		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Processes the resource file for the template file selected
		''' </summary>
		''' <param name="PortalId">PortalId of the new portal</param>
		''' <param name="portalPath">New portal's folder</param>
		''' <param name="TemplateFile">Selected template file</param>
		''' <remarks>
		''' The resource file is a zip file with the same name as the selected template file and with
		''' an extension of .resources (to unable this file being downloaded).
		''' For example: for template file "portal.template" a resource file "portal.template.resources" can be defined.
		''' </remarks>
		''' <history>
		''' 	[VMasanas]	10/09/2004	Created
		'''     [cnurse]    11/08/2004  Moved from SignUp to PortalController
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub ProcessResourceFile(ByVal PortalId As Integer, ByVal portalPath As String, ByVal TemplateFile As String)
			Dim resourceFile, LocalFileName, RelativeDir, FileNamePath As String
			Dim saveCurrentDirectory As String
			Dim objZipEntry As ZipEntry
			Dim objZipInputStream As ZipInputStream

			resourceFile = TemplateFile & ".resources"

			Try
				objZipInputStream = New ZipInputStream(New FileStream(resourceFile, FileMode.Open, FileAccess.Read))
				objZipEntry = objZipInputStream.GetNextEntry
			Catch exc As Exception
				' error opening file
			End Try

			While Not objZipEntry Is Nothing
				' This gets the Zipped FileName (including the path)
				LocalFileName = objZipEntry.Name

				' This creates the necessary directories if they don't 
				' already exist.
				RelativeDir = Path.GetDirectoryName(objZipEntry.Name)
				If (RelativeDir <> String.Empty) AndAlso (Not Directory.Exists(Path.Combine(portalPath, RelativeDir))) Then
					Directory.CreateDirectory(Path.Combine(portalPath, RelativeDir))
				End If

				' This block creates the file using buffered reads from the zipfile
				If (Not objZipEntry.IsDirectory) AndAlso (LocalFileName <> "") Then
					FileNamePath = Path.Combine(portalPath, LocalFileName).Replace("/", "\")

					Try
						' delete the file if it already exists
						If File.Exists(FileNamePath) Then
							File.SetAttributes(FileNamePath, FileAttributes.Normal)
							File.Delete(FileNamePath)
						End If

						' create the file
						Dim objFileStream As FileStream = File.Create(FileNamePath)

						Dim intSize As Integer = 2048
						Dim arrData(2048) As Byte

						intSize = objZipInputStream.Read(arrData, 0, arrData.Length)
						While intSize > 0
							objFileStream.Write(arrData, 0, intSize)
							intSize = objZipInputStream.Read(arrData, 0, arrData.Length)
						End While

						objFileStream.Close()
					Catch
						' an error occurred saving a file in the resource file
					End Try

				End If

				objZipEntry = objZipInputStream.GetNextEntry
			End While
			If Not objZipInputStream Is Nothing Then
				objZipInputStream.Close()
			End If

		End Sub

		Private Function ImportFile(ByVal PortalId As Integer, ByVal url As String) As String

			Dim strUrl As String = url

			If GetURLType(url) = TabType.File Then
				Dim objFileController As New FileController
				Dim fileId As Integer = objFileController.ConvertFilePathToFileId(url, PortalId)
				If fileId >= 0 Then
					strUrl = "FileID=" + fileId.ToString
				End If
			End If

			Return strUrl
		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Processes the settings node
		''' </summary>
		''' <param name="nodeSettings">Template file node for the settings</param>
		''' <param name="PortalId">PortalId of the new portal</param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[VMasanas]	27/08/2004	Created
		''' 	[VMasanas]	15/10/2004	Modified for new skin structure
		'''     [cnurse]    11/21/2004  Modified to use GetNodeValueDate for ExpiryDate
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub ParsePortalSettings(ByVal nodeSettings As XmlNode, ByVal PortalId As Integer)

			Dim objPortal As PortalInfo
			objPortal = GetPortal(PortalId)

			objPortal.LogoFile = ImportFile(PortalId, XmlUtils.GetNodeValue(nodeSettings, "logofile"))
			objPortal.FooterText = XmlUtils.GetNodeValue(nodeSettings, "footertext")
			objPortal.ExpiryDate = XmlUtils.GetNodeValueDate(nodeSettings, "expirydate", Null.NullDate)
			objPortal.UserRegistration = XmlUtils.GetNodeValueInt(nodeSettings, "userregistration")
			objPortal.BannerAdvertising = XmlUtils.GetNodeValueInt(nodeSettings, "banneradvertising")
			If XmlUtils.GetNodeValue(nodeSettings, "currency") <> "" Then
				objPortal.Currency = XmlUtils.GetNodeValue(nodeSettings, "currency")
			End If
			If XmlUtils.GetNodeValue(nodeSettings, "hostfee") <> "" Then
				objPortal.HostFee = XmlUtils.GetNodeValueSingle(nodeSettings, "hostfee")
			End If
			If XmlUtils.GetNodeValue(nodeSettings, "hostspace") <> "" Then
				objPortal.HostSpace = XmlUtils.GetNodeValueInt(nodeSettings, "hostspace")
			End If
			objPortal.BackgroundFile = XmlUtils.GetNodeValue(nodeSettings, "backgroundfile")
			objPortal.PaymentProcessor = XmlUtils.GetNodeValue(nodeSettings, "paymentprocessor")
			If XmlUtils.GetNodeValue(nodeSettings, "siteloghistory") <> "" Then
				objPortal.SiteLogHistory = XmlUtils.GetNodeValueInt(nodeSettings, "siteloghistory")
			End If
			objPortal.DefaultLanguage = XmlUtils.GetNodeValue(nodeSettings, "defaultlanguage", "en-US")
			objPortal.TimeZoneOffset = XmlUtils.GetNodeValueInt(nodeSettings, "timezoneoffset", -8)

			UpdatePortalInfo(objPortal.PortalID, objPortal.PortalName, objPortal.LogoFile, objPortal.FooterText, _
			 objPortal.ExpiryDate, objPortal.UserRegistration, objPortal.BannerAdvertising, objPortal.Currency, objPortal.AdministratorId, objPortal.HostFee, _
			 objPortal.HostSpace, objPortal.PaymentProcessor, objPortal.ProcessorUserId, objPortal.ProcessorPassword, objPortal.Description, _
			 objPortal.KeyWords, objPortal.BackgroundFile, objPortal.SiteLogHistory, objPortal.SplashTabId, objPortal.HomeTabId, objPortal.LoginTabId, objPortal.UserTabId, _
			 objPortal.DefaultLanguage, objPortal.TimeZoneOffset, objPortal.HomeDirectory)

			' set portal skins and containers
			If XmlUtils.GetNodeValue(nodeSettings, "skinsrc", "") <> "" Then
				SkinController.SetSkin(SkinInfo.RootSkin, PortalId, SkinType.Portal, XmlUtils.GetNodeValue(nodeSettings, "skinsrc", ""))
			End If
			If XmlUtils.GetNodeValue(nodeSettings, "skinsrcadmin", "") <> "" Then
				SkinController.SetSkin(SkinInfo.RootSkin, PortalId, SkinType.Admin, XmlUtils.GetNodeValue(nodeSettings, "skinsrcadmin", ""))
			End If
			If XmlUtils.GetNodeValue(nodeSettings, "containersrc", "") <> "" Then
				SkinController.SetSkin(SkinInfo.RootContainer, PortalId, SkinType.Portal, XmlUtils.GetNodeValue(nodeSettings, "containersrc", ""))
			End If
			If XmlUtils.GetNodeValue(nodeSettings, "containersrcadmin", "") <> "" Then
				SkinController.SetSkin(SkinInfo.RootContainer, PortalId, SkinType.Admin, XmlUtils.GetNodeValue(nodeSettings, "containersrcadmin", ""))
			End If

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Processes all Files from the template
		''' </summary>
		''' <param name="nodeFiles">Template file node for the Files</param>
		''' <param name="PortalId">PortalId of the new portal</param>
		''' <history>
		''' 	[cnurse]	11/09/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub ParseFiles(ByVal nodeFiles As XmlNodeList, ByVal PortalId As Integer, ByVal folderPath As String)

			Dim node As XmlNode
			Dim FileId As Integer
			Dim objController As New FileController
			Dim objInfo As DotNetNuke.Services.FileSystem.FileInfo
			Dim fileName As String

			For Each node In nodeFiles
				fileName = XmlUtils.GetNodeValue(node, "filename")

				'First check if the file exists
				objInfo = objController.GetFile(fileName, PortalId, folderPath)

				If objInfo Is Nothing Then
					objInfo = New DotNetNuke.Services.FileSystem.FileInfo
					objInfo.PortalId = PortalId
					objInfo.FileName = fileName
					objInfo.Extension = XmlUtils.GetNodeValue(node, "extension")
					objInfo.Size = XmlUtils.GetNodeValueInt(node, "size")
					objInfo.Width = XmlUtils.GetNodeValueInt(node, "width")
					objInfo.Height = XmlUtils.GetNodeValueInt(node, "height")
					objInfo.ContentType = XmlUtils.GetNodeValue(node, "contenttype")

					'Save new File 
					FileId = objController.AddFile(objInfo, folderPath)
				Else
					'Get Id from File
					FileId = objInfo.FileId
				End If
			Next

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Processes all Folders from the template
		''' </summary>
		''' <param name="nodeFolders">Template file node for the Folders</param>
		''' <param name="PortalId">PortalId of the new portal</param>
		''' <history>
		''' 	[cnurse]	11/09/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub ParseFolders(ByVal nodeFolders As XmlNode, ByVal PortalId As Integer)

			Dim node As XmlNode
			Dim FolderId As Integer
			Dim objController As New FolderController
			Dim objInfo As FolderInfo
			Dim folderPath As String

			For Each node In nodeFolders.SelectNodes("//folder")
				folderPath = XmlUtils.GetNodeValue(node, "folderpath")

				'First check if the folder exists
				objInfo = objController.GetFolder(PortalId, folderPath)

				If objInfo Is Nothing Then
					'Save new folder 
					FolderId = objController.AddFolder(PortalId, folderPath)
				Else
					'Get Id from Folder
					FolderId = objInfo.FolderID
				End If

				Dim nodeFolderPermissions As XmlNodeList = node.SelectNodes("folderpermissions/permission")
				ParseFolderPermissions(nodeFolderPermissions, PortalId, FolderId, folderPath)

				Dim nodeFiles As XmlNodeList = node.SelectNodes("files/file")
				If folderPath <> "" Then
					folderPath += "/"
				End If
				ParseFiles(nodeFiles, PortalId, folderPath)
			Next

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Parses folder permissions
		''' </summary>
		''' <param name="nodeFolderPermissions">Node for folder permissions</param>
		''' <param name="PortalID">PortalId of new portal</param>
		''' <param name="FolderId">FolderId of folder being processed</param>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	11/09/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub ParseFolderPermissions(ByVal nodeFolderPermissions As XmlNodeList, ByVal PortalID As Integer, ByVal FolderId As Integer, ByVal folderPath As String)
			Dim objFolderPermissions As New Security.Permissions.FolderPermissionCollection
			Dim objPermissionController As New Security.Permissions.PermissionController
			Dim objPermission As Security.Permissions.PermissionInfo
			Dim objFolderPermission As Security.Permissions.FolderPermissionInfo
			Dim objFolderPermissionController As New Security.Permissions.FolderPermissionController
			Dim objRoleController As New RoleController
			Dim objRole As RoleInfo
			Dim RoleID As Integer
			Dim PermissionID As Integer
			Dim PermissionKey, PermissionCode As String
			Dim RoleName As String
			Dim AllowAccess As Boolean
			Dim arrPermissions As ArrayList
			Dim i As Integer
			Dim xmlFolderPermission As XmlNode

			For Each xmlFolderPermission In nodeFolderPermissions
				PermissionKey = XmlUtils.GetNodeValue(xmlFolderPermission, "permissionkey")
				PermissionCode = XmlUtils.GetNodeValue(xmlFolderPermission, "permissioncode")
				RoleName = XmlUtils.GetNodeValue(xmlFolderPermission, "rolename")
				AllowAccess = XmlUtils.GetNodeValueBoolean(xmlFolderPermission, "allowaccess")
				arrPermissions = objPermissionController.GetPermissionByCodeAndKey(PermissionCode, PermissionKey)

				For i = 0 To arrPermissions.Count - 1
					objPermission = CType(arrPermissions(i), Security.Permissions.PermissionInfo)
					PermissionID = objPermission.PermissionID
				Next
				RoleID = Integer.MinValue
				Select Case RoleName
					Case glbRoleAllUsersName
						RoleID = Convert.ToInt32(glbRoleAllUsers)
					Case Common.Globals.glbRoleUnauthUserName
						RoleID = Convert.ToInt32(glbRoleUnauthUser)
					Case Else
						objRole = objRoleController.GetRoleByName(PortalID, RoleName)
						If Not objRole Is Nothing Then
							RoleID = objRole.RoleID
						End If
				End Select

				' if role was found add, otherwise ignore
				If RoleID <> Integer.MinValue Then
					If AllowAccess Then
						FileSystemUtils.SetFolderPermission(PortalID, FolderId, PermissionID, RoleID, folderPath)
					End If
				End If
			Next

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Processes all Roles from the template
		''' </summary>
		''' <param name="nodeRoles">Template file node for the Roles</param>
		''' <param name="PortalId">PortalId of the new portal</param>
		''' <param name="AdministratorId">New portal's Administrator</param>
		''' <param name="AdministratorRole">Used to return to caller the id of the Administrators Role if found</param>
		''' <param name="RegisteredRole">Used to return to caller the id of the Registered Users Role if found</param>
		''' <param name="SubscriberRole">Used to return to caller the id of the Subscribers Role if found</param>
		''' <remarks>
		''' There must be one role for the Administrators function. Only the first node with this mark will be used as the Administrators Role.
		''' There must be one role for the Registered Users function. Only the first node with this mark will be used as the Registered Users Role.
		''' There must be one role for the Subscribers function. Only the first node with this mark will be used as the Subscribers Role.
		''' If these two minimum roles are not found on the template they will be created with default values.
		''' 
		''' The administrator user will be added to the following roles: Administrators, Registered Users and any role specified with autoassignment=true
		''' </remarks>
		''' <history>
		''' 	[VMasanas]	26/08/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub ParseRoles(ByVal nodeRoles As XmlNode, ByVal PortalId As Integer, ByVal AdministratorId As Integer, ByRef AdministratorRole As Integer, ByRef RegisteredRole As Integer, ByRef SubscriberRole As Integer)

			Dim node As XmlNode
			Dim foundAdminRole As Boolean = False
			Dim foundRegisteredRole As Boolean = False
			Dim foundSubscriberRole As Boolean = False
			Dim RoleId As Integer

			For Each node In nodeRoles.SelectNodes("//role")
				RoleId = ParseRole(node, PortalId)

				' check if this is the admin role (only first found is selected as admin)
				If Not foundAdminRole AndAlso XmlUtils.GetNodeValue(node, "roletype", "") = "adminrole" Then
					foundAdminRole = True
					AdministratorRole = RoleId
				End If

				' check if this is the registered role (only first found is selected as registered)
				If Not foundRegisteredRole AndAlso XmlUtils.GetNodeValue(node, "roletype", "") = "registeredrole" Then
					foundRegisteredRole = True
					RegisteredRole = RoleId
				End If

				' check if this is the subscriber role (only first found is selected as subscriber)
				If Not foundSubscriberRole AndAlso XmlUtils.GetNodeValue(node, "roletype", "") = "subscriberrole" Then
					foundSubscriberRole = True
					SubscriberRole = RoleId
				End If
			Next

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Processes a node for a Role and creates a new Role based on the information gathered from the node
		''' </summary>
		''' <param name="nodeRole">Template file node for the role</param>
		''' <param name="portalid">PortalId of the new portal</param>
		''' <returns>RoleId of the created role</returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[VMasanas]	26/08/2004	Created
		'''		[cnurse]	15/10/2004	Modified to allow for merging template
		'''								with existing pages
		'''     [cnurse]    12/07/2004  modified to use new CreateRole method, which takes care of
		'''                             checking if role exists
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Function ParseRole(ByVal nodeRole As XmlNode, ByVal PortalId As Integer) As Integer

			Dim RoleName As String = XmlUtils.GetNodeValue(nodeRole, "rolename")
			Dim Description As String = XmlUtils.GetNodeValue(nodeRole, "description")
			Dim ServiceFee As Single = XmlUtils.GetNodeValueSingle(nodeRole, "servicefee")
			Dim BillingPeriod As Integer = XmlUtils.GetNodeValueInt(nodeRole, "billingperiod")
			Dim BillingFrequency As String = XmlUtils.GetNodeValue(nodeRole, "billingfrequency", "M")
			Dim TrialFee As Single = XmlUtils.GetNodeValueSingle(nodeRole, "trialfee")
			Dim TrialPeriod As Integer = XmlUtils.GetNodeValueInt(nodeRole, "trialperiod")
			Dim TrialFrequency As String = XmlUtils.GetNodeValue(nodeRole, "trialfrequency", "N")
			Dim IsPublic As Boolean = XmlUtils.GetNodeValueBoolean(nodeRole, "ispublic")
			Dim AutoAssignment As Boolean = XmlUtils.GetNodeValueBoolean(nodeRole, "autoassignment")

			'Call Create Role
			Return CreateRole(PortalId, RoleName, Description, ServiceFee, BillingPeriod, BillingFrequency, TrialFee, TrialPeriod, TrialFrequency, IsPublic, AutoAssignment)

		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Processes all tabs from the template
		''' </summary>
		''' <param name="nodeTabs">Template file node for the tabs</param>
		''' <param name="PortalId">PortalId of the new portal</param>
		''' <param name="IsAdminTemplate">True when processing admin template, false when processing portal template</param>
		''' <param name="mergeTabs">Flag to determine whether Module content is merged.</param>
		''' <remarks>
		''' When a special tab is found (HomeTab, UserTab, LoginTab, AdminTab) portal information will be updated.
		''' </remarks>
		''' <history>
		''' 	[VMasanas]	26/08/2004	Removed code to allow multiple tabs with same name.
		''' 	[VMasanas]	15/10/2004	Modified for new skin structure
		'''		[cnurse]	15/10/2004	Modified to allow for merging template
		'''								with existing pages
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub ParseTabs(ByVal nodeTabs As XmlNode, ByVal PortalId As Integer, ByVal IsAdminTemplate As Boolean, ByVal mergeTabs As PortalTemplateModuleAction)

			Dim nodeTab As XmlNode
			'used to control if modules are true modules or instances
			'will hold module ID from template / new module ID so new instances can reference right moduleid
			'only first one from the template will be create as a true module, 
			'others will be moduleinstances (tabmodules)
			Dim hModules As New Hashtable

			For Each nodeTab In nodeTabs.SelectNodes("//tab")
				ParseTab(nodeTab, PortalId, IsAdminTemplate, mergeTabs, hModules)
			Next
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Processes a single tab from the template
		''' </summary>
		''' <param name="nodeTabs">Template file node for the tabs</param>
		''' <param name="PortalId">PortalId of the new portal</param>
		''' <param name="IsAdminTemplate">True when processing admin template, false when processing portal template</param>
		''' <param name="mergeTabs">Flag to determine whether Module content is merged.</param>
		''' <param name="hModules">Used to control if modules are true modules or instances</param>
		''' <remarks>
		''' When a special tab is found (HomeTab, UserTab, LoginTab, AdminTab) portal information will be updated.
		''' </remarks>
		''' <history>
		''' 	[VMasanas]	26/08/2004	Removed code to allow multiple tabs with same name.
		''' 	[VMasanas]	15/10/2004	Modified for new skin structure
		'''		[cnurse]	15/10/2004	Modified to allow for merging template
		'''								with existing pages
		'''     [cnurse]    11/21/2204  modified to use GetNodeValueDate for Start and End Dates
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Function ParseTab(ByVal nodeTab As XmlNode, ByVal PortalId As Integer, ByVal IsAdminTemplate As Boolean, ByVal mergeTabs As PortalTemplateModuleAction, ByVal hModules As Hashtable) As Integer

			Dim objTab As TabInfo
			Dim objTabs As New TabController
			Dim strName As String = XmlUtils.GetNodeValue(nodeTab, "name")
			Dim intTabId As Integer
			Dim objportal As PortalInfo
			Dim tabExists As Boolean = True

            'supporting object to build the tab hierarchy
			Dim tabName As String
            Dim hTabs As New Hashtable

			objportal = GetPortal(PortalId)

			If strName <> "" Then

				'First get the tab
                objTab = objTabs.GetTabByName(strName, PortalId)

                If objTab Is Nothing Then

                    tabExists = False

                    objTab = New TabInfo
                    intTabId = Null.NullInteger

                    objTab.TabID = intTabId
                    objTab.PortalID = PortalId
                    objTab.TabName = XmlUtils.GetNodeValue(nodeTab, "name")
                    objTab.Title = XmlUtils.GetNodeValue(nodeTab, "title")
                    objTab.Description = XmlUtils.GetNodeValue(nodeTab, "description")
                    objTab.KeyWords = XmlUtils.GetNodeValue(nodeTab, "keywords")
                    objTab.IsVisible = XmlUtils.GetNodeValueBoolean(nodeTab, "visible", True)
                    objTab.DisableLink = XmlUtils.GetNodeValueBoolean(nodeTab, "disabled")
                    objTab.IconFile = ImportFile(PortalId, XmlUtils.GetNodeValue(nodeTab, "iconfile"))
                    objTab.Url = XmlUtils.GetNodeValue(nodeTab, "url")
                    objTab.StartDate = XmlUtils.GetNodeValueDate(nodeTab, "startdate", Null.NullDate)
                    objTab.EndDate = XmlUtils.GetNodeValueDate(nodeTab, "enddate", Null.NullDate)

                    Dim nodeTabPermissions As XmlNodeList = nodeTab.SelectNodes("tabpermissions/permission")
                    objTab.TabPermissions = ParseTabPermissions(nodeTabPermissions, PortalId, objTab.TabID)

                    ' get parent
                    If XmlUtils.GetNodeValue(nodeTab, "parent") <> "" Then
                        If Not hTabs(XmlUtils.GetNodeValue(nodeTab, "parent")) Is Nothing Then
                            ' parent node specifies the path (tab1/tab2/tab3), use saved tabid
                            objTab.ParentId = Convert.ToInt32(hTabs(XmlUtils.GetNodeValue(nodeTab, "parent")))
                            tabName = XmlUtils.GetNodeValue(nodeTab, "parent") + "/" + objTab.TabName
                        Else
                            ' Parent node doesn't spcecify the path, search by name.
                            ' Possible incoherence is tabname not unique
                            Dim objParent As TabInfo = objTabs.GetTabByName(XmlUtils.GetNodeValue(nodeTab, "parent"), PortalId)
                            If Not objParent Is Nothing Then
                                objTab.ParentId = objParent.TabID
                                tabName = objParent.TabName + "/" + objTab.TabName
                            Else
                                ' parent tab not found!
                                objTab.ParentId = Null.NullInteger
                                tabName = objTab.TabName
                            End If
                        End If
                    Else
                        ' save tab as: CurrentTabName
                        tabName = objTab.TabName

                        objTab.ParentId = Null.NullInteger
                    End If

                    ' set tab skin and container
                    If XmlUtils.GetNodeValue(nodeTab, "skinsrc", "") <> "" Then
                        objTab.SkinSrc = XmlUtils.GetNodeValue(nodeTab, "skinsrc", "")
                    End If
                    If XmlUtils.GetNodeValue(nodeTab, "containersrc", "") <> "" Then
                        objTab.ContainerSrc = XmlUtils.GetNodeValue(nodeTab, "containersrc", "")
                    End If

                    ' create tab
                    intTabId = objTabs.AddTab(objTab)
                Else
                    intTabId = objTab.TabID
                    tabName = objTab.TabName
                End If

                hTabs.Add(tabName, intTabId)

                If IsAdminTemplate Then
                    ' when processing the admin template we should identify the Admin tab
                    If objTab.TabName = "Admin" Then
                        objportal.AdminTabId = intTabId
                        DataProvider.Instance().UpdatePortalSetup(PortalId, objportal.AdministratorId, objportal.AdministratorRoleId, objportal.RegisteredRoleId, objportal.SplashTabId, objportal.HomeTabId, objportal.LoginTabId, objportal.UserTabId, objportal.AdminTabId)
                    End If
                Else
                    ' when processing the portal template we can find: hometab, usertab, logintab
                    Select Case XmlUtils.GetNodeValue(nodeTab, "tabtype", "")
                        Case "splashtab"
                            objportal.SplashTabId = intTabId
                            DataProvider.Instance().UpdatePortalSetup(PortalId, objportal.AdministratorId, objportal.AdministratorRoleId, objportal.RegisteredRoleId, objportal.SplashTabId, objportal.HomeTabId, objportal.LoginTabId, objportal.UserTabId, objportal.AdminTabId)
                        Case "hometab"
                            objportal.HomeTabId = intTabId
                            DataProvider.Instance().UpdatePortalSetup(PortalId, objportal.AdministratorId, objportal.AdministratorRoleId, objportal.RegisteredRoleId, objportal.SplashTabId, objportal.HomeTabId, objportal.LoginTabId, objportal.UserTabId, objportal.AdminTabId)
                        Case "logintab"
                            objportal.LoginTabId = intTabId
                            DataProvider.Instance().UpdatePortalSetup(PortalId, objportal.AdministratorId, objportal.AdministratorRoleId, objportal.RegisteredRoleId, objportal.SplashTabId, objportal.HomeTabId, objportal.LoginTabId, objportal.UserTabId, objportal.AdminTabId)
                        Case "usertab"
                            objportal.UserTabId = intTabId
                            DataProvider.Instance().UpdatePortalSetup(PortalId, objportal.AdministratorId, objportal.AdministratorRoleId, objportal.RegisteredRoleId, objportal.SplashTabId, objportal.HomeTabId, objportal.LoginTabId, objportal.UserTabId, objportal.AdminTabId)
                    End Select
                End If

                'If tab does not already exist parse modules
                If Not tabExists Then
                    If Not nodeTab.SelectSingleNode("panes") Is Nothing Then
                        ParsePanes(nodeTab.SelectSingleNode("panes"), PortalId, intTabId, mergeTabs, hModules)
                    End If
                End If
            End If
		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Parses tab permissions
		''' </summary>
		''' <param name="nodeTabPermissions">Node for tab permissions</param>
		''' <param name="PortalID">PortalId of new portal</param>
		''' <param name="TabId">TabId of tab being processed</param>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[Vicen�]	15/10/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Function ParseTabPermissions(ByVal nodeTabPermissions As XmlNodeList, ByVal PortalID As Integer, ByVal TabId As Integer) As Security.Permissions.TabPermissionCollection
			Dim objTabPermissions As New Security.Permissions.TabPermissionCollection
			Dim objPermissionController As New Security.Permissions.PermissionController
			Dim objPermission As Security.Permissions.PermissionInfo
			Dim objTabPermission As Security.Permissions.TabPermissionInfo
			Dim objRoleController As New RoleController
			Dim objRole As RoleInfo
			Dim RoleID As Integer
			Dim PermissionID As Integer
			Dim PermissionKey, PermissionCode As String
			Dim RoleName As String
			Dim AllowAccess As Boolean
			Dim arrPermissions As ArrayList
			Dim i As Integer
			Dim xmlTabPermission As XmlNode

			For Each xmlTabPermission In nodeTabPermissions
				PermissionKey = XmlUtils.GetNodeValue(xmlTabPermission, "permissionkey")
				PermissionCode = XmlUtils.GetNodeValue(xmlTabPermission, "permissioncode")
				RoleName = XmlUtils.GetNodeValue(xmlTabPermission, "rolename")
				AllowAccess = XmlUtils.GetNodeValueBoolean(xmlTabPermission, "allowaccess")
				arrPermissions = objPermissionController.GetPermissionByCodeAndKey(PermissionCode, PermissionKey)

				For i = 0 To arrPermissions.Count - 1
					objPermission = CType(arrPermissions(i), Security.Permissions.PermissionInfo)
					PermissionID = objPermission.PermissionID
				Next
				RoleID = Integer.MinValue
				Select Case RoleName
					Case glbRoleAllUsersName
						RoleID = Convert.ToInt32(glbRoleAllUsers)
					Case Common.Globals.glbRoleUnauthUserName
						RoleID = Convert.ToInt32(glbRoleUnauthUser)
					Case Else
						objRole = objRoleController.GetRoleByName(PortalID, RoleName)
						If Not objRole Is Nothing Then
							RoleID = objRole.RoleID
						End If
				End Select

				' if role was found add, otherwise ignore
				If RoleID <> Integer.MinValue Then
					objTabPermission = New Security.Permissions.TabPermissionInfo
					objTabPermission.TabID = TabId
					objTabPermission.PermissionID = PermissionID
					objTabPermission.RoleID = RoleID
					objTabPermission.AllowAccess = AllowAccess
					objTabPermissions.Add(objTabPermission)
				End If
			Next
			Return objTabPermissions
		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Processes all panes and modules in the template file
		''' </summary>
		''' <param name="nodePanes">Template file node for the panes is current tab</param>
		''' <param name="PortalId">PortalId of the new portal</param>
		''' <param name="TabId">Tab being processed</param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[VMasanas]	03/09/2004	Created
		''' 	[VMasanas]	15/10/2004	Modified for new skin structure
		'''		[cnurse]	15/10/2004	Modified to allow for merging template
		'''								with existing pages
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub ParsePanes(ByVal nodePanes As XmlNode, ByVal PortalId As Integer, ByVal TabId As Integer, ByVal mergeTabs As PortalTemplateModuleAction, ByVal hModules As Hashtable)

			Dim nodePane As XmlNode
			Dim nodeModule As XmlNode
			Dim objDesktopModules As New DesktopModuleController
			Dim objModuleDefinitions As New ModuleDefinitionController
			Dim objModuleDefinition As ModuleDefinitionInfo
			Dim objModules As New ModuleController
			Dim arrModules As ArrayList = objModules.GetPortalTabModules(PortalId, TabId)
			Dim objModule As ModuleInfo
			Dim intModuleId As Integer
			Dim intIndex As Integer
			Dim iModule As Integer
			Dim modTitle As String
			Dim moduleFound As Boolean

			Dim objportal As PortalInfo
			objportal = GetPortal(PortalId)

			'If Mode is Replace remove all the modules already on this Tab
			If mergeTabs = PortalTemplateModuleAction.Replace Then
				For iModule = 0 To arrModules.Count - 1
					objModule = CType(arrModules(iModule), ModuleInfo)
					objModules.DeleteTabModule(TabId, objModule.ModuleID)
				Next
			End If

			' iterate through the panes
			For Each nodePane In nodePanes.ChildNodes

				' iterate through the modules
				If Not nodePane.SelectSingleNode("modules") Is Nothing Then
					For Each nodeModule In nodePane.SelectSingleNode("modules")
						' will be instance or module?
						Dim templateModuleID As Integer = XmlUtils.GetNodeValueInt(nodeModule, "moduleID")
						Dim IsInstance As Boolean = False
						If templateModuleID > 0 Then
							If Not hModules(templateModuleID) Is Nothing Then
								' this module has already been processed -> process as instance
								IsInstance = True
							End If
						End If

						' get module definition
						Dim objDesktopModule As DesktopModuleInfo = objDesktopModules.GetDesktopModuleByName(XmlUtils.GetNodeValue(nodeModule, "definition"))
						If Not objDesktopModule Is Nothing Then
							Dim arrModuleDefinitions As ArrayList = objModuleDefinitions.GetModuleDefinitions(objDesktopModule.DesktopModuleID)
							For intIndex = 0 To arrModuleDefinitions.Count - 1
								objModuleDefinition = CType(arrModuleDefinitions(intIndex), ModuleDefinitionInfo)
								If Not objModuleDefinition Is Nothing Then

									'If Mode is Merge Check if Module exists
									moduleFound = False
									modTitle = XmlUtils.GetNodeValue(nodeModule, "title", objModuleDefinition.FriendlyName)
									If mergeTabs = PortalTemplateModuleAction.Merge Then
										For iModule = 0 To arrModules.Count - 1
											objModule = CType(arrModules(iModule), ModuleInfo)
											If modTitle = objModule.ModuleTitle Then
												moduleFound = True
												Exit For
											End If
										Next
									End If

									If moduleFound = False Then
										'Create New Module
										objModule = New ModuleInfo
										objModule.PortalID = PortalId
										objModule.TabID = TabId
										objModule.ModuleOrder = -1
										objModule.ModuleTitle = modTitle
										objModule.PaneName = XmlUtils.GetNodeValue(nodePane, "name")
										objModule.ModuleDefID = objModuleDefinition.ModuleDefID
										objModule.CacheTime = XmlUtils.GetNodeValueInt(nodeModule, "cachetime")
										objModule.Alignment = XmlUtils.GetNodeValue(nodeModule, "alignment")
										objModule.IconFile = ImportFile(PortalId, XmlUtils.GetNodeValue(nodeModule, "iconfile"))
										objModule.AllTabs = XmlUtils.GetNodeValueBoolean(nodeModule, "alltabs")
										Select Case XmlUtils.GetNodeValue(nodeModule, "visibility")
											Case "Maximized" : objModule.Visibility = VisibilityState.Maximized
											Case "Minimized" : objModule.Visibility = VisibilityState.Minimized
											Case "None" : objModule.Visibility = VisibilityState.None
										End Select
										objModule.Color = XmlUtils.GetNodeValue(nodeModule, "color", "")
										objModule.Border = XmlUtils.GetNodeValue(nodeModule, "border", "")
										objModule.Header = XmlUtils.GetNodeValue(nodeModule, "header", "")
										objModule.Footer = XmlUtils.GetNodeValue(nodeModule, "footer", "")
										objModule.InheritViewPermissions = XmlUtils.GetNodeValueBoolean(nodeModule, "inheritviewpermissions", False)
										objModule.ModulePermissions = New Security.Permissions.ModulePermissionCollection

										objModule.StartDate = XmlUtils.GetNodeValueDate(nodeModule, "startdate", Null.NullDate)
										objModule.EndDate = XmlUtils.GetNodeValueDate(nodeModule, "enddate", Null.NullDate)

										If XmlUtils.GetNodeValue(nodeModule, "containersrc", "") <> "" Then
											objModule.ContainerSrc = XmlUtils.GetNodeValue(nodeModule, "containersrc", "")
										End If
										objModule.DisplayTitle = XmlUtils.GetNodeValueBoolean(nodeModule, "displaytitle", True)
										objModule.DisplayPrint = XmlUtils.GetNodeValueBoolean(nodeModule, "displayprint", True)
										objModule.DisplaySyndicate = XmlUtils.GetNodeValueBoolean(nodeModule, "displaysyndicate", False)

										If Not IsInstance Then
											'Add new module
											intModuleId = objModules.AddModule(objModule)
											If templateModuleID > 0 Then
												hModules.Add(templateModuleID, intModuleId)
											End If
										Else
											'Add instance
											objModule.ModuleID = Convert.ToInt32(hModules(templateModuleID))
											intModuleId = objModules.AddModule(objModule)
										End If

										If XmlUtils.GetNodeValue(nodeModule, "content") <> "" And Not IsInstance Then
											objModule = objModules.GetModule(intModuleId, TabId)
											Dim strVersion As String = nodeModule.SelectSingleNode("content").Attributes.ItemOf("version").Value
											Dim strType As String = nodeModule.SelectSingleNode("content").Attributes.ItemOf("type").Value
											Dim strcontent As String = nodeModule.SelectSingleNode("content").InnerXml
											strcontent = strcontent.Substring(9, strcontent.Length - 12)
											strcontent = HttpContext.Current.Server.HtmlDecode(strcontent)

											If objModule.BusinessControllerClass <> "" Then
												Try
													Dim objObject As Object = Framework.Reflection.CreateObject(objModule.BusinessControllerClass, objModule.BusinessControllerClass)
													If TypeOf objObject Is IPortable Then
														CType(objObject, IPortable).ImportModule(objModule.ModuleID, strcontent, strVersion, objportal.AdministratorId)
													End If
												Catch
													'ignore errors
												End Try
											End If
										End If

										' Process permissions only once
										If Not IsInstance Then
											Dim nodeModulePermissions As XmlNodeList = nodeModule.SelectNodes("modulepermissions/permission")
											ParseModulePermissions(nodeModulePermissions, PortalId, intModuleId)
										End If
									End If
								End If
							Next
						End If
					Next
				End If
			Next
		End Sub

		Private Sub ParseModulePermissions(ByVal nodeModulePermissions As XmlNodeList, ByVal PortalId As Integer, ByVal ModuleID As Integer)
			Dim objRoleController As New RoleController
			Dim objRole As RoleInfo
			Dim objModulePermissions As New Security.Permissions.ModulePermissionCollection
			Dim objModulePermissionController As New Security.Permissions.ModulePermissionController
			Dim objPermissionController As New Security.Permissions.PermissionController
			Dim objPermission As Security.Permissions.PermissionInfo
			Dim objModulePermissionCollection As New Security.Permissions.ModulePermissionCollection
			Dim node As XmlNode
			Dim PermissionID As Integer
			Dim arrPermissions As ArrayList
			Dim i As Integer
			Dim PermissionKey, PermissionCode As String
			Dim RoleName As String
			Dim RoleID As Integer
			Dim AllowAccess As Boolean

			For Each node In nodeModulePermissions
				PermissionKey = XmlUtils.GetNodeValue(node, "permissionkey")
				PermissionCode = XmlUtils.GetNodeValue(node, "permissioncode")
				RoleName = XmlUtils.GetNodeValue(node, "rolename")
				AllowAccess = XmlUtils.GetNodeValueBoolean(node, "allowaccess")

				RoleID = Integer.MinValue
				Select Case RoleName
					Case glbRoleAllUsersName
						RoleID = Convert.ToInt32(glbRoleAllUsers)
					Case Common.Globals.glbRoleUnauthUserName
						RoleID = Convert.ToInt32(glbRoleUnauthUser)
					Case Else
						objRole = objRoleController.GetRoleByName(PortalId, RoleName)
						If Not objRole Is Nothing Then
							RoleID = objRole.RoleID
						End If
				End Select
				If RoleID <> Integer.MinValue Then
					PermissionID = -1
					arrPermissions = objPermissionController.GetPermissionByCodeAndKey(PermissionCode, PermissionKey)

					For i = 0 To arrPermissions.Count - 1
						objPermission = CType(arrPermissions(i), Security.Permissions.PermissionInfo)
						PermissionID = objPermission.PermissionID
					Next

					' if role was found add, otherwise ignore
					If PermissionID <> -1 Then
						Dim objModulePermission As New Security.Permissions.ModulePermissionInfo
						objModulePermission.ModuleID = ModuleID
						objModulePermission.PermissionID = PermissionID
						objModulePermission.RoleID = RoleID
						objModulePermission.AllowAccess = Convert.ToBoolean(XmlUtils.GetNodeValue(node, "allowaccess"))
						objModulePermissionController.AddModulePermission(objModulePermission)
					End If
				End If
			Next

		End Sub

		Private Function CreateRole(ByVal PortalId As Integer, ByVal roleName As String, ByVal description As String, ByVal serviceFee As Single, ByVal billingPeriod As Integer, ByVal billingFrequency As String, ByVal trialFee As Single, ByVal trialPeriod As Integer, ByVal trialFrequency As String, ByVal isPublic As Boolean, ByVal isAuto As Boolean) As Integer

			Dim objRoleInfo As New RoleInfo
			Dim objRoleController As New RoleController
			Dim RoleId As Integer

			'First check if the role exists
			objRoleInfo = objRoleController.GetRoleByName(PortalId, roleName)

			If objRoleInfo Is Nothing Then

				objRoleInfo = New RoleInfo
				objRoleInfo.PortalID = PortalId
				objRoleInfo.RoleName = roleName
				objRoleInfo.Description = description
				objRoleInfo.ServiceFee = CType(IIf(serviceFee < 0, 0, serviceFee), Single)
				objRoleInfo.BillingPeriod = billingPeriod
				objRoleInfo.BillingFrequency = billingFrequency
				objRoleInfo.TrialFee = CType(IIf(trialFee < 0, 0, trialFee), Single)
				objRoleInfo.TrialPeriod = trialPeriod
				objRoleInfo.TrialFrequency = trialFrequency
				objRoleInfo.IsPublic = isPublic
				objRoleInfo.AutoAssignment = isAuto
				RoleId = objRoleController.AddRole(objRoleInfo)
			Else
				RoleId = objRoleInfo.RoleID
			End If

			Return RoleId

		End Function

#End Region

	End Class

End Namespace
