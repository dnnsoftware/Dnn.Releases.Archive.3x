'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data
Imports System.Globalization
Imports System.IO

Namespace DotNetNuke.Services.FileSystem
	''' -----------------------------------------------------------------------------
	''' Project	 : DotNetNuke
	''' Class	 : FileController
	''' 
	''' -----------------------------------------------------------------------------
	''' <summary>
	''' Business Class that provides access to the Database for the functions within the calling classes
	''' Instantiates the instance of the DataProvider and returns the object, if any
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[DYNST]	2/1/2004	Created
	''' </history>
	''' -----------------------------------------------------------------------------
	Public Class FileController

        Public Function GetFiles(ByVal PortalId As Integer, ByVal Folder As String) As IDataReader

            Return DataProvider.Instance().GetFiles(PortalId, Folder)

        End Function

        Public Function GetFilesByFolder(ByVal PortalId As Integer, ByVal Folder As String) As ArrayList

            Return CBO.FillCollection(DataProvider.Instance().GetFiles(PortalId, Folder), GetType(FileInfo))

        End Function

        Public Function GetFile(ByVal FilePath As String, ByVal PortalId As Integer) As FileInfo

            Return GetFile(Path.GetFileName(FilePath), PortalId, FilePath.Replace(Path.GetFileName(FilePath), ""))

        End Function

        Public Function GetFile(ByVal FileName As String, ByVal PortalId As Integer, ByVal Folder As String) As FileInfo

            Return CType(CBO.FillObject(DataProvider.Instance().GetFile(FileName, PortalId, Folder), GetType(FileInfo)), FileInfo)

        End Function

        Public Function GetFileById(ByVal FileId As Integer, ByVal PortalId As Integer) As FileInfo

            Return CType(CBO.FillObject(DataProvider.Instance().GetFileById(FileId, PortalId), GetType(FileInfo)), FileInfo)

        End Function

        Public Sub DeleteFile(ByVal PortalId As Integer, ByVal FileName As String, ByVal folder As String)

            DataProvider.Instance().DeleteFile(PortalId, FileName, folder)

        End Sub

        Public Sub DeleteFiles(ByVal PortalId As Integer)

            DataProvider.Instance().DeleteFiles(PortalId)

        End Sub

        Public Function AddFile(ByVal file As FileInfo, ByVal folder As String) As Integer

            Return AddFile(file.PortalId, file.FileName, file.Extension, file.Size, file.Width, file.Height, file.ContentType, folder)

        End Function

        Public Function AddFile(ByVal PortalId As Integer, ByVal FileName As String, ByVal Extension As String, ByVal Size As Long, ByVal Width As Integer, ByVal Height As Integer, ByVal ContentType As String, ByVal Folder As String) As Integer

            Dim dr As IDataReader = DataProvider.Instance().GetFile(FileName, PortalId, Folder)
            Dim FileId As Integer
            If dr.Read Then
                FileId = Convert.ToInt32(dr("FileId"))
                DataProvider.Instance().UpdateFile(FileId, FileName, Extension, Size, Width, Height, ContentType, Folder)
            Else
                FileId = DataProvider.Instance().AddFile(PortalId, FileName, Extension, Size, Width, Height, ContentType, Folder)
            End If
            dr.Close()

            Return FileId

        End Function

        Public Sub UpdateFile(ByVal PortalId As Integer, ByVal FileName As String, ByVal Extension As String, ByVal Size As Long, ByVal Width As Integer, ByVal Height As Integer, ByVal ContentType As String, ByVal SourceFolder As String, ByVal DestinationFolder As String)

            Dim dr As IDataReader = DataProvider.Instance().GetFile(FileName, PortalId, SourceFolder)
            Dim FileId As Integer
            If dr.Read Then
                FileId = Convert.ToInt32(dr("FileId"))
                DataProvider.Instance().UpdateFile(FileId, FileName, Extension, Size, Width, Height, ContentType, DestinationFolder)
            End If
            dr.Close()

        End Sub

        Public Function ConvertFilePathToFileId(ByVal FilePath As String, ByVal PortalID As Integer) As Integer
            Dim FileName As String = ""
            Dim FolderName As String = ""
            Dim FileId As Integer = -1

            If FilePath <> "" Then
                FileName = FilePath.Substring(FilePath.LastIndexOf("/") + 1)
                FolderName = FilePath.Replace(FileName, "")
            End If

            Dim objFiles As New FileController
            Dim objFile As FileInfo = objFiles.GetFile(FileName, PortalID, FolderName)
            If Not objFile Is Nothing Then
                FileId = objFile.FileId
            End If

            Return FileId
        End Function

    End Class

End Namespace
