'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke.Framework

    Public MustInherit Class Upgrade
        Inherits System.Web.UI.Page

#Region "Event Handlers"

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            'Set Response buffer to False
            Response.Buffer = False
            Response.Write("<html>")
            Response.Write("<head>")
            Response.Write("<title>DotNetNuke - Upgrade.</title>")
            Response.Write("<style>")
            Response.Write("body {font-family:Verdana;font-weight:normal;font-size: .7em;color:black;} ")
            Response.Write("p {font-family:Verdana;font-weight:normal;color:black;margin-top: -5px}")
            Response.Write("b {font-family:Verdana;font-weight:bold;color:black;margin-top: -5px}")
            Response.Write("H1 { font-family:Verdana;font-weight:normal;font-size:18pt;color:red }")
            Response.Write("H2 { font-family:Verdana;font-weight:normal;font-size:14pt;color:maroon }")
            Response.Write("</style>")
            Response.Write("</head>")
            Response.Write("<body bgcolor=white>")
            Response.Write("<h1><u>Performing Upgrade</u></h1>")
            Response.Flush()


            ' get path to script files
            Dim strProviderPath As String = PortalSettings.GetProviderPath()
            If Not strProviderPath.StartsWith("ERROR:") Then
                Dim strDatabaseVersion As String

                ' get current database version
                Dim dr As IDataReader = PortalSettings.GetDatabaseVersion
                If dr.Read Then
                    'Call Upgrade with the current DB Version to upgrade an
                    'existing DNN installation
                    strDatabaseVersion = Format(dr("Major"), "00") & "." & Format(dr("Minor"), "00") & "." & Format(dr("Build"), "00")

                    Response.Write("<h2>Current Database Version: " & strDatabaseVersion & "<h2>")
                    Response.Write("<h2>Current Assembly Version: " & glbAppVersion & "<h2>")
                    Response.Flush()

                    Services.Upgrade.Upgrade.Upgrade(strProviderPath, strDatabaseVersion.Replace(".", ""), True)

                    Response.Write("<h2>Upgrade Complete:<h2>")
                    Response.Write("<br><br><a href='Default.aspx'>Goto Upgraded DotNetNuke site</a>")
                    Response.Flush()
                End If
                dr.Close()
            End If

            Response.Write("</body>")
            Response.Write("</html>")


        End Sub

#End Region


#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class
End Namespace
