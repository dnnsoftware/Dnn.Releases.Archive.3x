'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Diagnostics
Imports System.Xml

Namespace DotNetNuke.UI.WebControls

	Public Class DNNTreeBuilder
		Inherits ControlBuilder

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <param name="tagName"></param>
		''' <param name="attribs"></param>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Overloads Overrides Function GetChildControlType(ByVal tagName As String, ByVal attribs As IDictionary) As Type
			If tagName.ToUpper.EndsWith("TreeNode") Then
				Return GetType(TreeNode)
			End If
			Return Nothing
		End Function

	End Class

	<ControlBuilderAttribute(GetType(DNNTreeBuilder)), _
	Designer(GetType(DotNetNuke.UI.Design.WebControls.DNNTreeDesigner)), _
	DefaultProperty("Nodes"), _
	ToolboxData("<{0}:DNNTree runat=server></{0}:DNNTree>")> _
	Public Class DnnTree
		Inherits WebControl
		Implements IPostBackEventHandler
		Implements IPostBackDataHandler

		Public Delegate Sub DNNTreeEventHandler(ByVal source As Object, ByVal e As DNNTreeEventArgs)
		Public Delegate Sub DNNTreeNodeClickHandler(ByVal source As Object, ByVal e As DNNTreeNodeClickEventArgs)

		Public Event Expand As DNNTreeEventHandler
		Public Event Collapse As DNNTreeEventHandler
		Public Event NodeClick As DNNTreeNodeClickHandler

		Private _root As TreeNode
		Private _images As NodeImageCollection
        Private m_strTreeScriptPath As String
        Private m_strSystemImagesPath As String
		Private m_bForceDownLevel As Boolean


		Public Property ForceDownLevel() As Boolean
			Get
				Return m_bForceDownLevel
			End Get
			Set(ByVal Value As Boolean)
				m_bForceDownLevel = Value
			End Set
		End Property

		Public ReadOnly Property IsDownLevel() As Boolean
			Get
				If ForceDownLevel OrElse DotNetNuke.UI.Utilities.ClientAPI.BrowserSupportsFunctionality(Utilities.ClientAPI.ClientFunctionality.DHTML) = False Then
					Return True
				Else
					Return False
				End If
			End Get
		End Property

		Public Property ClientAPIScriptPath() As String
			Get
				Return DotNetNuke.UI.Utilities.ClientAPI.ScriptPath
			End Get
			Set(ByVal Value As String)
				' Commented out because it was breaking the build.. (SM 26 Oct)
				' DotNetNuke.UI.Utilities.ClientAPI.ScriptPath = Value
			End Set
		End Property

		Public Property TreeScriptPath() As String
			Get
				If Len(m_strTreeScriptPath) = 0 Then
					Return ClientAPIScriptPath
				Else
					Return m_strTreeScriptPath
				End If
			End Get
			Set(ByVal Value As String)
				m_strTreeScriptPath = Value
			End Set
		End Property

        <Description("Directory to find the images for the menu.  Need to have spacer.gif here!"), DefaultValue("images/")> _
        Public Property SystemImagesPath() As String
            Get
                If Len(m_strSystemImagesPath) = 0 Then
                    Return "images/"
                Else
                    Return m_strSystemImagesPath
                End If
            End Get
            Set(ByVal Value As String)
                m_strSystemImagesPath = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Browsable(True), PersistenceMode(PersistenceMode.InnerProperty)> _
        Public ReadOnly Property TreeNodes() As TreeNodeCollection
            Get
                Return Root.TreeNodes
            End Get
        End Property

        Private m_colSelectedNodes As Collection

        <Browsable(False)> _
        Public ReadOnly Property SelectedTreeNodes() As Collection
            Get
                If m_colSelectedNodes Is Nothing Then
                    m_colSelectedNodes = New Collection
                    PopulateSelectedNodes(Me.TreeNodes)
                End If
                Return m_colSelectedNodes
            End Get
        End Property

        Private Sub PopulateSelectedNodes(ByVal objNodes As TreeNodeCollection)
            Dim objNode As TreeNode
            For Each objNode In objNodes
                If objNode.Selected Then m_colSelectedNodes.Add(objNode)
                If objNode.TreeNodes.Count > 0 Then
                    PopulateSelectedNodes(objNode.TreeNodes)
                End If
            Next
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(0), PersistenceMode(PersistenceMode.Attribute)> _
          Public Property IndentWidth() As Integer
            Get
                Dim Indent As Object = ViewState("IndentWidth")
                Return CType(Indent, Integer)
            End Get
            Set(ByVal Value As Integer)
                ViewState("IndentWidth") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(""), PersistenceMode(PersistenceMode.Attribute)> _
          Public Property CollapsedNodeImage() As String
            Get
                Dim _url As Object = ViewState("CollapsedNodeImage")
                Return CType(_url, String)
            End Get
            Set(ByVal Value As String)
                ViewState("CollapsedNodeImage") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(""), PersistenceMode(PersistenceMode.Attribute)> _
          Public Property ExpandedNodeImage() As String
            Get
                Dim _url As Object = ViewState("ExpandedNodeImage")
                Return CType(_url, String)
            End Get
            Set(ByVal Value As String)
                ViewState("ExpandedNodeImage") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(False), PersistenceMode(PersistenceMode.Attribute)> _
          Public Property CheckBoxes() As Boolean
            Get
                Dim _checkBoxes As Object = ViewState("CheckBoxes")
                Return CType(_checkBoxes, Boolean)
            End Get
            Set(ByVal Value As Boolean)
                ViewState("CheckBoxes") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue("")> _
          Public Property Target() As String
            Get
                Dim _target As String = CType(ViewState("Target"), String)
                Return (_target)
            End Get
            Set(ByVal Value As String)
                ViewState("Target") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Browsable(True), PersistenceMode(PersistenceMode.InnerProperty)> _
          Public ReadOnly Property ImageList() As NodeImageCollection
            Get
                If _images Is Nothing Then
                    _images = New NodeImageCollection
                    If IsTrackingViewState Then
                        CType(_images, IStateManager).TrackViewState()
                    End If
                End If
                Return _images
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(""), PersistenceMode(PersistenceMode.Attribute)> _
          Public Property DefaultChildNodeCssClass() As String
            Get
                Dim _defaultChildNodeCssClass As String = CType(ViewState("DefaultChildNodeCssClass"), String)
                Return (_defaultChildNodeCssClass)
            End Get
            Set(ByVal Value As String)
                ViewState("DefaultChildNodeCssClass") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(""), PersistenceMode(PersistenceMode.Attribute)> _
          Public Property DefaultNodeCssClass() As String
            Get
                Dim _defaultNodeCssClass As String = CType(ViewState("DefaultNodeCssClass"), String)
                Return (_defaultNodeCssClass)
            End Get
            Set(ByVal Value As String)
                ViewState("DefaultNodeCssClass") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(""), PersistenceMode(PersistenceMode.Attribute)> _
          Public Property DefaultNodeCssClassOver() As String
            Get
                Dim _defaultNodeCssClassOver As String = CType(ViewState("DefaultNodeCssClassOver"), String)
                Return (_defaultNodeCssClassOver)
            End Get
            Set(ByVal Value As String)
                ViewState("DefaultNodeCssClassOver") = Value
            End Set
        End Property

        <Bindable(True), DefaultValue(""), PersistenceMode(PersistenceMode.Attribute)> _
          Public Property DefaultNodeCssClassSelected() As String
            Get
                Dim _defaultNodeCssClassSelected As String = CType(ViewState("DefaultNodeCssClassSelected"), String)
                Return (_defaultNodeCssClassSelected)
            End Get
            Set(ByVal Value As String)
                ViewState("DefaultNodeCssClassSelected") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private ReadOnly Property Root() As TreeNode
            Get
                If _root Is Nothing Then
                    _root = New TreeNode("TreeRoot")
                    _root.SetDNNTree(Me)
                    _root.SetNodeID(UniqueID)
                    _root.SetLevel(-1)
                    _root.ViewState("IsExpanded") = True
                End If
                Return _root
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private ReadOnly Property TreeWriter() As IDNNTreeWriter
            Get
                If Me.IsDownLevel Then
                    Return New DNNTreeWriter
                Else
                    Return New DNNTreeUpLevelWriter
                End If
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub New()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="eventArgument"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overridable Sub RaisePostBackEvent(ByVal eventArgument As String) Implements IPostBackEventHandler.RaisePostBackEvent
            Dim args() As String = eventArgument.Split(","c)

            Dim Node As TreeNode = Root.FindNode(args(0))

            If Not (Node Is Nothing) Then
                If args.Length > 1 AndAlso args(1) = "Click" Then
                    Node.Click()
                Else
                    If Node.IsExpanded Then
                        Node.Collapse()
                    Else
                        Node.Expand()
                    End If
                End If
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overridable Sub OnExpand(ByVal e As DNNTreeEventArgs)
            RaiseEvent Expand(Me, e)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overridable Sub OnCollapse(ByVal e As DNNTreeEventArgs)
            RaiseEvent Collapse(Me, e)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	10/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overridable Sub OnNodeClick(ByVal e As DNNTreeNodeClickEventArgs)
            RaiseEvent NodeClick(Me, e)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="writer"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overloads Overrides Sub Render(ByVal writer As HtmlTextWriter)
            TreeWriter.RenderTree(writer, Me)
            Dim oCtl As Control
            For Each oCtl In Me.Controls
                oCtl.RenderControl(writer)
            Next
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overloads Overrides Sub OnInit(ByVal e As EventArgs)
            MyBase.OnInit(e)
            ConfigureParsedNodes(Root)
            RegisterClientScript()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overloads Overrides Function SaveViewState() As Object
            Dim _baseState As Object = MyBase.SaveViewState
            Dim _treeState As Object = CType(Root, IStateManager).SaveViewState
            Dim _imagesState As Object = CType(ImageList, IStateManager).SaveViewState
            Dim _newState(3 - 1) As Object
            _newState(0) = _baseState
            _newState(1) = _treeState
            _newState(2) = _imagesState
            Return _newState
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="state"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overloads Overrides Sub LoadViewState(ByVal state As Object)
            If Not (state Is Nothing) Then
                Dim _newState As Object() = CType(state, Object())
                If Not (_newState(0) Is Nothing) Then
                    MyBase.LoadViewState(_newState(0))
                End If
                If Not (_newState(1) Is Nothing) Then
                    CType(Root, IStateManager).LoadViewState(_newState(1))
                End If
                If Not (_newState(2) Is Nothing) Then
                    CType(ImageList, IStateManager).LoadViewState(_newState(2))
                End If
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overloads Overrides Sub TrackViewState()
            MyBase.TrackViewState()
            CType(Root, IStateManager).TrackViewState()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="Node"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ConfigureParsedNodes(ByVal Node As TreeNode)
            Dim TempNode As TreeNode
            For Each TempNode In Node.TreeNodes
                TempNode.SetParent(Node)
                TempNode.SetDNNTree(Me)
                TempNode.SetLevel(Node.Level + 1)
                TempNode.NodeType = eNodeType.designTimeNode
                ConfigureParsedNodes(TempNode)
            Next
        End Sub

        Private Sub DnnTree_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
            Page.RegisterRequiresPostBack(Me)
        End Sub

        Public Function LoadPostData(ByVal postDataKey As String, ByVal postCollection As System.Collections.Specialized.NameValueCollection) As Boolean Implements System.Web.UI.IPostBackDataHandler.LoadPostData
            'We need to process the individual checkboxes
            If Me.CheckBoxes Then SelectNodes(Me.Root, postCollection)

        End Function

        Public Sub RaisePostDataChangedEvent() Implements System.Web.UI.IPostBackDataHandler.RaisePostDataChangedEvent

        End Sub

        Private Sub SelectNodes(ByVal node As TreeNode, ByVal selectedNodes As System.Collections.Specialized.NameValueCollection)
            If selectedNodes(node.ID & ":checkbox") Is Nothing Then
                'We need to perform a check to see if data has changed
                node.Selected = False
            Else
                node.Selected = True
            End If

            For Each childNode As TreeNode In node.TreeNodes
                SelectNodes(childNode, selectedNodes)
            Next
        End Sub

        Public Sub RegisterDNNVariableControl()
            Dim ctlVar As System.Web.UI.HtmlControls.HtmlInputHidden = CType(DotNetNuke.UI.Utilities.Globals.FindControlRecursive(Me.Page, "__dnnVariable"), System.Web.UI.HtmlControls.HtmlInputHidden)
            If ctlVar Is Nothing Then
                ctlVar = New System.Web.UI.HtmlControls.HtmlInputHidden
                ctlVar.ID = "__dnnVariable"
                Me.Controls.Add(ctlVar)
            End If
        End Sub

        Public Sub RegisterClientScript()
            If IsDownLevel = False Then
                RegisterDNNVariableControl()
                DotNetNuke.UI.Utilities.ClientAPI.RegisterClientReference(Me.Page, DotNetNuke.UI.Utilities.ClientAPI.ClientNamespaceReferences.dnn_dom)

                If Not Me.Page.IsClientScriptBlockRegistered("dnntree.js") Then
                    Me.Page.RegisterClientScriptBlock("dnntree.js", "<script src=""" & TreeScriptPath & "dnntree.js""></script>")
                End If
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Finds Node by ID 
        ''' </summary>
        ''' <param name="strID">ID of node</param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Jon Henning]	11/17/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function FindNode(ByVal strID As String) As TreeNode
            If Me.TreeNodes.Count > 0 Then
                Dim objNode As TreeNode
                Dim objFind As TreeNode
                For Each objNode In Me.TreeNodes
                    objFind = objNode.FindNode(strID)
                    If Not objFind Is Nothing Then Exit For
                Next
                Return objFind
            End If
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Finds Node by passed in Key. 
        ''' </summary>
        ''' <param name="strKey">Key of node</param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Jon Henning]	11/17/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function FindNodeByKey(ByVal strKey As String) As TreeNode
            If Me.TreeNodes.Count > 0 Then
                Dim objNode As TreeNode
                Dim objFind As TreeNode
                For Each objNode In Me.TreeNodes
                    'First Check self
                    If objNode.Key = strKey Then
                        Return objNode
                    End If
                    objFind = objNode.FindNodeByKey(strKey)
                    If Not objFind Is Nothing Then Exit For
                Next
                Return objFind
            End If
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Finds Node by passed in ID and selects it.  Additionally it will expand 
        ''' all parent nodes.
        ''' </summary>
        ''' <param name="strID">ID of node</param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Jon Henning]	11/17/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function SelectNode(ByVal strID As String) As TreeNode
            If Me.TreeNodes.Count > 0 Then
                Dim objNode As TreeNode = Me.FindNode(strID)
                If Not objNode Is Nothing Then
                    objNode.Selected = True
                    Dim objParent As TreeNode
                    objParent = objNode

                    While Not objParent Is Nothing
                        objParent.Expand()
                        objParent = objParent.Parent
                    End While
                End If
            End If
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Finds Node by passed in Key and selects it.  Additionally it will expand 
        ''' all parent nodes.
        ''' </summary>
        ''' <param name="strID">Key of node</param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Jon Henning]	11/17/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        ''' 
        Public Function SelectNodeByKey(ByVal strKey As String) As TreeNode
            Dim objNode As TreeNode
            If Me.TreeNodes.Count > 0 Then
                objNode = Me.FindNodeByKey(strKey)
                If Not objNode Is Nothing Then

                    objNode.Selected = True

                    Dim objParent As TreeNode
                    objParent = objNode
                    While Not objParent Is Nothing
                        objParent.Expand()
                        objParent = objParent.Parent
                    End While
                End If
            End If
            Return objNode
        End Function

    End Class
End Namespace
