'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Web.UI
Imports System.ComponentModel

Namespace DotNetNuke.UI.WebControls

	Public Class NodeImage
		Implements IStateManager
		Private _marked As Boolean = False
		Private _state As StateBag

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Sub New()
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <param name="NewImageUrl"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Sub New(ByVal NewImageUrl As String)
			If ImageUrl Is Nothing Then
				Throw New ArgumentNullException
			End If
			CType(Me, IStateManager).TrackViewState()
			ImageUrl = NewImageUrl
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public ReadOnly Property IsTrackingViewState() As Boolean Implements IStateManager.IsTrackingViewState
			Get
				Return _marked
			End Get
		End Property

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Sub TrackViewState() Implements IStateManager.TrackViewState
			_marked = True
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Function SaveViewState() As Object Implements IStateManager.SaveViewState
			' save _state state
			Dim _stateState As Object = Nothing
			If Not (_state Is Nothing) Then
				_stateState = CType(_state, IStateManager).SaveViewState()
			End If
			Return _stateState
		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <param name="state"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Sub LoadViewState(ByVal state As Object) Implements IStateManager.LoadViewState
			If Not (state Is Nothing) Then
				CType(ViewState, IStateManager).LoadViewState(state)
			End If
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		'''     [cnurse]    11/3/2004   Fixed to work under Option Strict On
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Property ImageUrl() As String
			Get
				Dim _imageUrl As String = String.Empty
				If (ViewState("ImageUrl") Is Nothing) = False Then
					_imageUrl = CType(ViewState("ImageUrl"), String)
				End If
				Return _imageUrl
			End Get
			Set(ByVal Value As String)
				ViewState("ImageUrl") = Value
			End Set
		End Property

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Protected ReadOnly Property ViewState() As StateBag
			Get
				If _state Is Nothing Then
					_state = New StateBag(True)
					If IsTrackingViewState Then
						CType(_state, IStateManager).TrackViewState()
					End If
				End If
				Return _state
			End Get
		End Property

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Friend Sub SetDirty()
			If Not _state Is Nothing Then
				Dim key As String
				For Each key In _state.Keys
					_state.SetItemDirty(key, True)
				Next
			End If
		End Sub
	End Class
End Namespace