'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports DotNetNuke
Imports System.Web

Namespace DotNetNuke.Modules.Feedback

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' The Feedback Class provides the UI for displaying the Feedback
	''' </summary>
	''' <returns></returns>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[cnurse]	9/22/2004	Moved Feedback to a separate Project
	''' </history>
	''' -----------------------------------------------------------------------------
	Public MustInherit Class Feedback
		Inherits Entities.Modules.PortalModuleBase

#Region "Controls"

        Protected plEmail As UI.UserControls.LabelControl
		Protected WithEvents txtEmail As System.Web.UI.WebControls.TextBox
		Protected plName As UI.UserControls.LabelControl
		Protected WithEvents txtName As System.Web.UI.WebControls.TextBox
		Protected plSubject As UI.UserControls.LabelControl
		Protected WithEvents txtSubject As System.Web.UI.WebControls.TextBox
		Protected plBody As UI.UserControls.LabelControl
		Protected WithEvents txtBody As System.Web.UI.WebControls.TextBox
        Protected plCopy As UI.UserControls.LabelControl
        Protected WithEvents chkCopy As System.Web.UI.WebControls.CheckBox

		'tasks
		Protected WithEvents cmdSend As System.Web.UI.WebControls.LinkButton
		Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblMessage As System.Web.UI.WebControls.Label

#End Region

#Region "Public Methods"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' GetUser fills the Email/Name fields if a user is logged in
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/22/2004	Moved Feedback to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub GetUser()

			If Request.IsAuthenticated Then

                Dim objUsers As New Entities.Users.UserController

				Dim objUser As Entities.Users.UserInfo = objUsers.GetUser(PortalId, UserInfo.UserID)
				If Not objUser Is Nothing Then
					txtEmail.Text = objUser.Membership.Email.ToString
					txtName.Text = objUser.Profile.FullName.ToString
				End If

			End If

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' InitializeForm sets the form up
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/22/2004	Moved Feedback to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub InitializeForm()
			Try
				txtEmail.Text = ""
				txtName.Text = ""
				txtSubject.Text = ""
                txtBody.Text = ""
                chkCopy.Checked = True

				GetUser()
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

#End Region

#Region "Event Handlers"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Page_Load runs when the control is loaded
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/22/2004	Moved Feedback to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try
                If Not Page.IsPostBack Then
                    InitializeForm()

                    Dim rows As String = CType(Settings("rows"), String)
                    Dim width As String = CType(Settings("width"), String)
                    If rows <> String.Empty Then
                        txtBody.Rows = Integer.Parse(rows)
                    End If
                    If width <> String.Empty Then
                        txtEmail.Width = System.Web.UI.WebControls.Unit.Parse(width)
                        txtName.Width = System.Web.UI.WebControls.Unit.Parse(width)
                        txtSubject.Width = System.Web.UI.WebControls.Unit.Parse(width)
                        txtBody.Width = System.Web.UI.WebControls.Unit.Parse(width)
                    End If

                End If
            Catch exc As Exception    'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdCancel_Click runs when the cancel button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/22/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
			Try

				InitializeForm()
				lblMessage.Text = ""
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdSend_Click runs when the send button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/22/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdSend_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSend.Click
			Try
                Dim strSendTo As String = CType(Settings("sendto"), String)
				If strSendTo = "" Then
                    strSendTo = PortalSettings.Email
				End If

				If txtEmail.Text <> "" Then
                    SendNotification(txtEmail.Text, strSendTo, "", txtSubject.Text, txtBody.Text & vbCrLf & vbCrLf & txtName.Text)
                    If chkCopy.Checked Then
                        SendNotification(txtEmail.Text, txtEmail.Text, "", txtSubject.Text, txtBody.Text & vbCrLf & vbCrLf & txtName.Text)
                    End If
                    lblMessage.Text = Localization.GetString("MessageSent", Me.LocalResourceFile)
                    InitializeForm()
                Else
                    lblMessage.Text = Localization.GetString("EmailAddress", Me.LocalResourceFile)
                End If

            Catch exc As Exception    'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
