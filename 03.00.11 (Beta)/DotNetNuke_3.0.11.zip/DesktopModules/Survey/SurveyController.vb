'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Data
Imports DotNetNuke

Namespace DotNetNuke.Modules.Survey

	Public Class SurveyController
		Implements DotNetNuke.Entities.Modules.IUpgradeable

		Public Function GetSurveys(ByVal ModuleId As Integer) As ArrayList

			Return CBO.FillCollection(DataProvider.Instance().GetSurveys(ModuleId), GetType(SurveyInfo))

		End Function

		Public Function GetSurvey(ByVal SurveyID As Integer, ByVal ModuleId As Integer) As SurveyInfo

			Return CType(CBO.FillObject(DataProvider.Instance().GetSurvey(SurveyID, ModuleId), GetType(SurveyInfo)), SurveyInfo)

		End Function

		Public Sub DeleteSurvey(ByVal SurveyID As Integer)

			DataProvider.Instance().DeleteSurvey(SurveyID)

		End Sub

		Public Function AddSurvey(ByVal objSurvey As SurveyInfo) As Integer

			Return CType(DataProvider.Instance().AddSurvey(objSurvey.ModuleId, objSurvey.Question, objSurvey.ViewOrder, objSurvey.OptionType, objSurvey.CreatedByUser), Integer)

		End Function

		Public Sub UpdateSurvey(ByVal objSurvey As SurveyInfo)

			DataProvider.Instance().UpdateSurvey(objSurvey.SurveyId, objSurvey.Question, objSurvey.ViewOrder, objSurvey.OptionType, objSurvey.CreatedByUser)

		End Sub

		Public Function UpgradeModule(ByVal Version As String) As String Implements Entities.Modules.IUpgradeable.UpgradeModule

			'TODO:  Need to localize this string.  I am not sure where the localized resource should be stored.
			' This is a sample implementation of IUpgradeable.  This interface allows the module developer to run custom
			' logic when a module is installed.
			Return "Custom upgrade code goes here for Version: " & Version

		End Function

	End Class

End Namespace
