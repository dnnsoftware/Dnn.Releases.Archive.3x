'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports System.xml

Imports DotNetNuke.Common


Namespace DotNetNuke.Framework

    Public MustInherit Class Install
        Inherits System.Web.UI.Page

#Region "Private Methods"

        Private Sub InstallApplcation()

            'Start Timer
            Services.Upgrade.Upgrade.StartTimer()

            'Write out Header
            HtmlUtils.WriteHeader(Response, "install")

            ' get path to script files
            Dim strProviderPath As String = PortalSettings.GetProviderPath()
            If Not strProviderPath.StartsWith("ERROR:") Then

                Response.Write("<h2>Version: " & glbAppVersion & "</h2>")
                Response.Flush()

                HtmlUtils.WriteSettings(Response)

                Response.Write("<br><br>")

                Response.Write("<h2><u>Installation Status Report</u></h2>")
                Response.Flush()
                Services.Upgrade.Upgrade.InstallDNN(strProviderPath)

                Response.Write("<h2>Installation Complete:</h2>")
                Response.Write("<br><br><h2><a href='../Default.aspx'>Click Here To Access Your Portal</a></h2>")
                Response.Flush()
            Else
                ' upgrade error
                Response.Write("<h2>Upgrade Error: " & strProviderPath & "</h2>")
                Response.Flush()
            End If

            'Write out Footer
            HtmlUtils.WriteFooter(Response)

            'Run Bypassed AppStart methods

            'log APPLICATION_START event
            Global.LogStart()

            'Start Scheduler
            Global.StartScheduler()


        End Sub

        Private Sub UpgradeApplication()

            'Start Timer
            Services.Upgrade.Upgrade.StartTimer()

            'Write out Header
            HtmlUtils.WriteHeader(Response, "upgrade")

            Response.Write("<h2>Current Assembly Version: " & glbAppVersion & "</h2>")
            Response.Flush()

            ' get path to script files
            Dim strProviderPath As String = PortalSettings.GetProviderPath()
            If Not strProviderPath.StartsWith("ERROR:") Then
                Dim strDatabaseVersion As String

                ' get current database version
                Dim dr As IDataReader = PortalSettings.GetDatabaseVersion
                If dr.Read Then
                    'Call Upgrade with the current DB Version to upgrade an
                    'existing DNN installation
                    strDatabaseVersion = Format(dr("Major"), "00") & "." & Format(dr("Minor"), "00") & "." & Format(dr("Build"), "00")

                    Response.Write("<h2>Current Database Version: " & strDatabaseVersion & "</h2>")
                    Response.Flush()

                    HtmlUtils.WriteSettings(Response)

                    Response.Write("<br><br>")

                    Response.Write("<h2><u>Upgrade Status Report</u></h2>")
                    Response.Flush()
                    Services.Upgrade.Upgrade.UpgradeDNN(strProviderPath, strDatabaseVersion.Replace(".", ""))

                    Response.Write("<h2>Upgrade Complete:</h2>")
                    Response.Write("<br><br><a href='../Default.aspx'>Goto Upgraded DotNetNuke site</a>")
                    Response.Flush()
                End If
                dr.Close()
            Else
                Response.Write("<h2>Upgrade Error: " & strProviderPath & "</h2>")
                Response.Flush()
            End If

            'Write out Footer
            HtmlUtils.WriteFooter(Response)
        End Sub

        Private Sub AddPortal()

            'Start Timer
            Services.Upgrade.Upgrade.StartTimer()

            'Write out Header
            HtmlUtils.WriteHeader(Response, "addPortal")

            Response.Write("<h2><u>Add Portal Status Report</u></h2>")
            Response.Flush()

            ' install new portal(s)
            Dim strNewFile As String = Common.Globals.ApplicationMapPath & "\Install\Portal\Portals.resources"
            If File.Exists(strNewFile) Then
                Dim xmlDoc As New XmlDocument
                Dim node As XmlNode
                Dim nodes As XmlNodeList
                Dim intPortalId As Integer
                xmlDoc.Load(strNewFile)

                ' parse portal(s) if available
                nodes = xmlDoc.SelectNodes("//dotnetnuke/portals/portal")
                For Each node In nodes
                    If Not node Is Nothing Then
                        intPortalId = Services.Upgrade.Upgrade.AddPortal(node, True)
                    End If
                Next

                ' delete the file
                Try
                    File.SetAttributes(strNewFile, FileAttributes.Normal)
                    File.Delete(strNewFile)
                Catch
                    ' error removing the file
                End Try

                Response.Write("<h2>Installation Complete:</h2>")
                Response.Write("<br><br><a href='../Default.aspx'>Goto Upgraded DotNetNuke site</a>")
                Response.Flush()
            End If


            'Write out Footer
            HtmlUtils.WriteFooter(Response)
        End Sub

        Private Sub NoUpgrade()

            'Write out Header
            HtmlUtils.WriteHeader(Response, "none")

            Response.Write("<h2>Current Assembly Version: " & glbAppVersion & "</h2>")
            Response.Flush()

            ' get path to script files
            Dim strProviderPath As String = PortalSettings.GetProviderPath()
            If Not strProviderPath.StartsWith("ERROR:") Then
                Dim strDatabaseVersion As String

                ' get current database version
                Dim dr As IDataReader = PortalSettings.GetDatabaseVersion
                If dr.Read Then
                    'Call Upgrade with the current DB Version to upgrade an
                    'existing DNN installation
                    strDatabaseVersion = Format(dr("Major"), "00") & "." & Format(dr("Minor"), "00") & "." & Format(dr("Build"), "00")

                    Response.Write("<h2>Current Database Version: " & strDatabaseVersion & "</h2>")

                    Response.Write("<br><br><a href='Install.aspx?mode=Install'>Upgrade DotNetNuke</a>")
                    Response.Flush()
                Else
                    Response.Write("<h2>Current Database Version: N/A</h2>")

                    Response.Write("<br><br><a href='Install.aspx?mode=Install'>Install DotNetNuke</a>")
                    Response.Flush()
                End If
                dr.Close()
            Else
                Response.Write("<h2>" & strProviderPath & "</h2>")
                Response.Flush()
            End If

            HtmlUtils.WriteSettings(Response)


            'Write out Footer
            HtmlUtils.WriteFooter(Response)
        End Sub

#End Region

#Region "Event Handlers"

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            Dim mode As String = ""
            If Not (Request.QueryString("mode") Is Nothing) Then
                mode = Request.QueryString("mode")
            End If

            'Disable Client side caching
            Response.Cache.SetCacheability(HttpCacheability.ServerAndNoCache)

            'Check mode is not Nothing
            If mode = "None" Then
                NoUpgrade()
            Else
                Select Case GetUpgradeStatus()
                    Case Globals.UpgradeStatus.Install
                        InstallApplcation()
                    Case Globals.UpgradeStatus.Upgrade
                        UpgradeApplication()
                    Case Globals.UpgradeStatus.None
                        'Check mode
                        If mode = "AddPortal" Then
                            AddPortal()
                        End If
                End Select
            End If

        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class
End Namespace
