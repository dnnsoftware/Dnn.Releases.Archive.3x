'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.IO
Imports System.Web
Imports System.Web.Caching
Imports System.Xml
Imports System.Xml.Serialization
Imports System.Xml.XPath
Imports DotNetNuke
Imports DotNetNuke.Common.Utilities

Namespace DotNetNuke.HttpModules.Config

    <Serializable(), XmlRoot("RewriterConfig")> _
    Public Class RewriterConfiguration

        Private _rules As RewriterRuleCollection

        Public Shared Function GetConfig() As RewriterConfiguration

            If (DataCache.GetCache("RewriterConfig") Is Nothing) Then

                Dim filePath As String = HttpRuntime.AppDomainAppPath & "SiteUrls.config"

                ' Create a new Xml Serializer
                Dim ser As XmlSerializer = New XmlSerializer(GetType(RewriterConfiguration))

                Dim fileReader As FileStream = New FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read)

                ' Open up the file to deserialize
                Dim reader As StreamReader = New StreamReader(fileReader)

                ' Deserialize into RewriterConfiguration
				Dim config As RewriterConfiguration = DirectCast(ser.Deserialize(reader), RewriterConfiguration)

                ' Close the Reader
                reader.Close()

                fileReader.Close()

                If File.Exists(filePath) Then
                    ' Create a dependancy on SiteUrls.config
                    Dim dep As CacheDependency = New CacheDependency(filePath)

                    ' Set back into Cache
                    DataCache.SetCache("RewriterConfig", config, dep)
                Else
                    Return config
                End If

            End If

            Return DirectCast(DataCache.GetCache("RewriterConfig"), RewriterConfiguration)

        End Function

        Public Property Rules() As RewriterRuleCollection
            Get
                Return _rules
            End Get
            Set(ByVal Value As RewriterRuleCollection)
                _rules = Value
            End Set
        End Property

    End Class

End Namespace
