'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.IO
Imports System.Web
Imports System.Text.RegularExpressions
Imports DotNetNuke
Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Common

Namespace DotNetNuke.HttpModules

	Public Class UrlRewriteModule

		Implements IHttpModule

		Public ReadOnly Property ModuleName() As String
			Get
				Return "UrlRewriteModule"
			End Get
		End Property

		Public Sub Init(ByVal application As HttpApplication) Implements IHttpModule.Init

			AddHandler application.BeginRequest, AddressOf Me.OnBeginRequest

		End Sub


		Public Sub OnBeginRequest(ByVal s As Object, ByVal e As EventArgs)

			Dim app As HttpApplication = CType(s, HttpApplication)
            Dim requestedPath As String = app.Request.Path
			Dim Server As HttpServerUtility = app.Server
			Dim Request As HttpRequest = app.Request
            Dim Response As HttpResponse = app.Response

            'First check if we are upgrading/installing
            If Request.Url.LocalPath.EndsWith("Install.aspx") Then
                Exit Sub
            End If

            app.Context.Items.Add("UrlRewrite:OriginalUrl", app.Request.Url.AbsoluteUri)

            Dim rules As Config.RewriterRuleCollection = Config.RewriterConfiguration.GetConfig().Rules

            For i As Integer = 0 To rules.Count - 1
                Dim lookFor As String = "^" & RewriterUtils.ResolveUrl(app.Context.Request.ApplicationPath, rules(i).LookFor) & "$"
                Dim re As Regex = New Regex(lookFor, RegexOptions.IgnoreCase)

                If (re.IsMatch(requestedPath)) Then
                    Dim sendTo As String = RewriterUtils.ResolveUrl(app.Context.Request.ApplicationPath, re.Replace(requestedPath, rules(i).SendTo))
                    Dim sesMatch As Match = re.Match(requestedPath)
                    Dim sesUrlParams As String = sesMatch.Groups(2).Value

                    If (sesUrlParams.Trim().Length > 0) Then
                        sesUrlParams = sesUrlParams.Replace("\", "/")
                        Dim urlParams As String() = sesUrlParams.Split("/"c)

                        For x As Integer = 1 To urlParams.Length - 1
                            If (urlParams(x).Trim().Length > 0 And urlParams(x) <> "Default.aspx") Then
                                sendTo = sendTo & "&" & urlParams(x).Replace(".aspx", "").Trim() & "="
                                If (x < (urlParams.Length - 1)) Then
                                    If (urlParams(x + 1).Trim <> "") Then
                                        sendTo = sendTo & urlParams(x + 1).Replace(".aspx", "")
                                    End If
                                End If
                            End If
                        Next
                    End If

                    RewriterUtils.RewriteUrl(app.Context, sendTo)
                    Exit For
                End If
            Next

            ' URL validation 
            ' check for ".." escape characters commonly used by hackers to traverse the folder tree on the server
            ' the application should always use the exact relative location of the resource it is requesting
            Dim strURL As String = Server.UrlDecode(Request.RawUrl)
            If strURL.IndexOf("..") <> -1 Then
                Throw New HttpException(404, "Not Found")
            End If

            'fix for ASP.NET canonicalization issues http://support.microsoft.com/?kbid=887459
            If (Request.Path.IndexOf(Chr(92)) >= 0 Or System.IO.Path.GetFullPath(Request.PhysicalPath) <> Request.PhysicalPath) Then
                Throw New HttpException(404, "Not Found")
            End If

            Dim TabId As Integer = -1
            Dim PortalId As Integer = -1
            Dim DomainName As String = Nothing
            Dim PortalAlias As String = Nothing

            ' get TabId from querystring ( this is mandatory for maintaining portal context for child portals )
            If Not (Request.QueryString("tabid") Is Nothing) Then
                TabId = Int32.Parse(Request.QueryString("tabid"))
            End If
            ' get PortalId from querystring ( this is used for host menu options as well as child portal navigation )
            If Not (Request.QueryString("portalid") Is Nothing) Then
                PortalId = Int32.Parse(Request.QueryString("portalid"))
            End If

            ' parse the Request URL into a Domain Name token 
            DomainName = GetDomainName(Request)

            Dim objPortalAliasInfo As PortalAliasInfo

            ' alias parameter can be used to switch portals
            If Not (Request.QueryString("alias") Is Nothing) Then
                ' check if the alias is valid
                If Not PortalSettings.GetPortalAliasInfo(Request.QueryString("alias")) Is Nothing Then
                    ' check if the domain name contains the alias
                    If InStr(1, Request.QueryString("alias"), DomainName, CompareMethod.Text) = 0 Then
                        ' redirect to the url defined in the alias
                        Response.Redirect(GetPortalDomainName(Request.QueryString("alias"), Request), True)
                    Else ' the alias is the same as the current domain
                        PortalAlias = Request.QueryString("alias")
                    End If
                End If
            End If

            ' PortalId identifies a portal when set
            If PortalAlias Is Nothing Then
                If PortalId <> -1 Then
                    PortalAlias = PortalSettings.GetPortalByID(PortalId, DomainName)
                End If
            End If

            ' TabId uniquely identifies a Portal
            If PortalAlias Is Nothing Then
                If TabId <> -1 Then
                    ' verify the tab belongs to the portal associated with the domain name
                    PortalAlias = PortalSettings.GetPortalByTab(TabId, DomainName)
                End If
            End If

            ' else use the domain name
            If PortalAlias Is Nothing Then
                PortalAlias = DomainName
                TabId = -1 ' load the default tab 
            End If

            ' get the portal alias
            objPortalAliasInfo = PortalSettings.GetPortalAliasInfo(PortalAlias)

            ' if the portalid is not known
            If PortalId = -1 Then
                ' if the portal alias exists
                If Not objPortalAliasInfo Is Nothing Then
                    ' set the portalid
                    PortalId = objPortalAliasInfo.PortalID
                Else ' the alias does not exist
                    If Convert.ToString(HostSettings("HostPortalId")) <> "" Then
                        ' use the host portal
                        Dim objPortalAliasController As New PortalAliasController
                        Dim arrPortalAliases As ArrayList = objPortalAliasController.GetPortalAliasArrayByPortalID(Integer.Parse(Convert.ToString(HostSettings("HostPortalId"))))

                        If arrPortalAliases.Count > 0 Then
                            'Get the first Alias
                            objPortalAliasInfo = CType(arrPortalAliases(0), PortalAliasInfo)
                            PortalAlias = objPortalAliasInfo.HTTPAlias
                            PortalId = objPortalAliasInfo.PortalID
                            TabId = -1 ' load the default tab

                            'Update the OriginalUrl to reflect the default portal
                            Dim originalUrl As String = app.Request.Url.AbsoluteUri.Replace(DomainName, PortalAlias)
                            app.Context.Items("UrlRewrite:OriginalUrl") = originalUrl

                            ' log the event
                            Dim objEventLog As New Services.Log.EventLog.EventLogController
                            Dim objEventLogInfo As New Services.Log.EventLog.LogInfo
                            objEventLogInfo.AddProperty("Portal Alias Lookup", "General")
                            objEventLogInfo.AddProperty("Warnings", "The Portal Alias " & PortalAlias & " Has Not Been Associated With A Portal. Please Login As Host And Add This HTTP Alias In Site Settings.")
                            objEventLogInfo.LogTypeKey = Services.Log.EventLog.EventLogController.EventLogType.HOST_ALERT.ToString
                            objEventLogInfo.BypassBuffering = True
                            objEventLog.AddLog(objEventLogInfo)

                        End If
                    End If
                End If
            End If

            If PortalId <> -1 Then
                Globals.SetApplicationName(PortalId)

                ' load the PortalSettings into current context
                Dim _portalSettings As PortalSettings = New PortalSettings(TabId, objPortalAliasInfo)
                app.Context.Items.Add("PortalSettings", _portalSettings)
            Else
                ' alias does not exist in database
                Dim objStreamReader As StreamReader
                objStreamReader = File.OpenText(Server.MapPath("~/404.htm"))
                Dim strHTML As String = objStreamReader.ReadToEnd
                objStreamReader.Close()
                strHTML = Replace(strHTML, "[DOMAINNAME]", DomainName)
                Response.Write(strHTML)
                Response.End()
            End If

		End Sub

		Public Sub Dispose() Implements IHttpModule.Dispose
		End Sub

	End Class

End Namespace
