'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data
Imports System.Globalization
Imports DotNetNuke.Entities.Tabs

Namespace DotNetNuke.Entities.Modules


	Public Class ModuleController

		Public Function AddModule(ByVal objModule As ModuleInfo) As Integer

			' add module
			If Null.IsNull(objModule.ModuleID) Then
				objModule.ModuleID = DataProvider.Instance().AddModule(objModule.PortalID, objModule.ModuleDefID, objModule.ModuleTitle, objModule.AllTabs, objModule.Header, objModule.Footer, objModule.StartDate, objModule.EndDate, objModule.InheritViewPermissions, objModule.IsDeleted)

				' set module permissions
				If Not objModule.ModulePermissions Is Nothing Then
					Dim objModulePermissionController As New Security.Permissions.ModulePermissionController
					Dim objModulePermissions As Security.Permissions.ModulePermissionCollection
					objModulePermissions = objModule.ModulePermissions
					Dim objModulePermission As New Security.Permissions.ModulePermissionInfo
					For Each objModulePermission In objModulePermissions
						objModulePermission.ModuleID = objModule.ModuleID
						objModulePermissionController.AddModulePermission(objModulePermission)
					Next
				End If
			End If

            'This will fail if the page already contains this module
            Try
                ' add tabmodule
                DataProvider.Instance().AddTabModule(objModule.TabID, objModule.ModuleID, objModule.ModuleOrder, objModule.PaneName, objModule.CacheTime, objModule.Alignment, objModule.Color, objModule.Border, objModule.IconFile, objModule.Visibility, objModule.ContainerSrc, objModule.DisplayTitle, objModule.DisplayPrint, objModule.DisplaySyndicate)

                ' move module to bottom of pane
                UpdateModuleOrder(objModule.TabID, objModule.ModuleID, -1, objModule.PaneName)
            Catch
                ' module already in the page, ignore error
            End Try

            Return objModule.ModuleID

		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' CopyModule copies a Module from one Tab to another optionally including all the 
		'''	TabModule settings
		''' </summary>
		''' <remarks>
		''' </remarks>
		'''	<param name="moduleId">The Id of the module to copy</param>
		'''	<param name="fromTabId">The Id of the source tab</param>
		'''	<param name="toTabId">The Id of the destination tab</param>
		'''	<param name="toPaneName">The name of the Pane on the destination tab where the module will end up</param>
		'''	<param name="includeSettings">A flag to indicate whether the settings are copied to the new Tab</param>
		''' <history>
		''' 	[cnurse]	10/21/2004	created
		''' </history>
		''' -----------------------------------------------------------------------------
        Public Sub CopyModule(ByVal moduleId As Integer, ByVal fromTabId As Integer, ByVal toTabId As Integer, ByVal toPaneName As String, ByVal includeSettings As Boolean)

            'First Get the Module itself
            Dim objModule As ModuleInfo = GetModule(moduleId, fromTabId)

            'If the Destination Pane Name is not set, assume the same name as the source
            If toPaneName = "" Then
                toPaneName = objModule.PaneName
            End If

            'This will fail if the page already contains this module
            Try
                'Add a copy of the module to the bottom of the Pane for the new Tab
                DataProvider.Instance().AddTabModule(toTabId, moduleId, -1, toPaneName, objModule.CacheTime, objModule.Alignment, objModule.Color, objModule.Border, objModule.IconFile, objModule.Visibility, objModule.ContainerSrc, objModule.DisplayTitle, objModule.DisplayPrint, objModule.DisplaySyndicate)

                'Optionally copy the TabModuleSettings
                If includeSettings Then
                    Dim toModule As ModuleInfo = GetModule(moduleId, toTabId)
                    CopyTabModuleSettings(objModule, toModule)
                End If
            Catch
                ' module already in the page, ignore error
            End Try

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' CopyModule copies a Module from one Tab to a collection of Tabs optionally
        '''	including the TabModule settings
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="moduleId">The Id of the module to copy</param>
        '''	<param name="fromTabId">The Id of the source tab</param>
        '''	<param name="toTabs">An ArrayList of TabItem objects</param>
        '''	<param name="includeSettings">A flag to indicate whether the settings are copied to the new Tab</param>
        ''' <history>
        ''' 	[cnurse]	10/22/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub CopyModule(ByVal moduleId As Integer, ByVal fromTabId As Integer, ByVal toTabs As ArrayList, ByVal includeSettings As Boolean)

            Dim intTab As Integer
            Dim objTab As TabInfo

            'Iterate through collection copying the module to each Tab (except the source)
            For intTab = 0 To toTabs.Count - 1
                objTab = CType(toTabs(intTab), TabInfo)
                If objTab.TabID <> fromTabId Then
                    CopyModule(moduleId, fromTabId, objTab.TabID, "", includeSettings)
                End If
            Next

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' CopyTabModuleSettings copies the TabModuleSettings from one instance to another
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="fromModule">The module to copy from</param>
        '''	<param name="toModule">The module to copy to</param>
        ''' <history>
        ''' 	[cnurse]	01/11/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub CopyTabModuleSettings(ByVal fromModule As ModuleInfo, ByVal toModule As ModuleInfo)

            'Get the TabModuleSettings
            Dim settings As Hashtable = GetTabModuleSettings(fromModule.TabModuleID)

            'Copy each setting to the new TabModule instance
            For Each setting As DictionaryEntry In settings
                UpdateTabModuleSetting(toModule.TabModuleID, CType(setting.Key, String), CType(setting.Value, String))
            Next

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' DeleteAllModules deletes all instaces of a Module (from a collection), optionally excluding the
        '''	current instance, and optionally including deleting the Module itself.
        ''' </summary>
        ''' <remarks>
        '''	Note - the base module is not removed unless both the flags are set, indicating
        '''	to delete all instances AND to delete the Base Module
        ''' </remarks>
        '''	<param name="moduleId">The Id of the module to copy</param>
        '''	<param name="tabId">The Id of the current tab</param>
        '''	<param name="fromTabs">An ArrayList of TabItem objects</param>
        '''	<param name="includeCurrent">A flag to indicate whether to delete from the current tab
        '''		as identified ny tabId</param>
        '''	<param name="deleteBaseModule">A flag to indicate whether to delete the Module itself</param>
        ''' <history>
        ''' 	[cnurse]	10/22/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub DeleteAllModules(ByVal moduleId As Integer, ByVal tabId As Integer, ByVal fromTabs As ArrayList, ByVal includeCurrent As Boolean, ByVal deleteBaseModule As Boolean)

            Dim intTab As Integer
            Dim objTab As TabInfo

            'Iterate through collection deleting the module from each Tab (except the current)
            For intTab = 0 To fromTabs.Count - 1
                objTab = CType(fromTabs(intTab), TabInfo)
                If objTab.TabID <> tabId Or includeCurrent Then
                    DeleteTabModule(objTab.TabID, moduleId)
                End If
            Next

            'Optionally delete the Module
            If includeCurrent And deleteBaseModule Then
                DeleteModule(moduleId)
            End If

        End Sub

        Public Sub DeleteModule(ByVal ModuleId As Integer)

            DataProvider.Instance().DeleteModule(ModuleId)

            'Delete Search Items for this Module
            DataProvider.Instance().DeleteSearchItems(ModuleId)

        End Sub

        Public Sub DeleteTabModule(ByVal TabId As Integer, ByVal ModuleId As Integer)

            ' save moduleinfo
            Dim objModule As ModuleInfo = GetModule(ModuleId, TabId)

            ' delete the module instance for the tab
            DataProvider.Instance().DeleteTabModule(TabId, ModuleId)

            ' reorder all modules on tab
            UpdateTabModuleOrder(TabId)

            ' check if all modules instances have been deleted
            If GetModule(ModuleId, Null.NullInteger).TabID = Null.NullInteger Then
                ' soft delete the module
                objModule.TabID = Null.NullInteger
                objModule.IsDeleted = True
                UpdateModule(objModule)

                'Delete Search Items for this Module
                DataProvider.Instance().DeleteSearchItems(ModuleId)
            End If

        End Sub

        Private Function FillModuleInfo(ByVal dr As IDataReader) As ModuleInfo
            Return FillModuleInfo(dr, True, True)
        End Function

        Private Function FillModuleInfo(ByVal dr As IDataReader, ByVal CheckForOpenDataReader As Boolean) As ModuleInfo
            Return FillModuleInfo(dr, CheckForOpenDataReader, True)
        End Function

        Private Function FillModuleInfo(ByVal dr As IDataReader, ByVal CheckForOpenDataReader As Boolean, ByVal IncludePermissions As Boolean) As ModuleInfo
            Dim objModuleInfo As New ModuleInfo
            Dim objModulePermissionController As New Security.Permissions.ModulePermissionController
            ' read datareader
            Dim Continue As Boolean = True

            If CheckForOpenDataReader Then
                Continue = False
                If dr.Read Then
                    Continue = True
                End If
            End If
            If Continue Then
                Try
                    objModuleInfo.PortalID = Convert.ToInt32(Null.SetNull(dr("PortalID"), objModuleInfo.PortalID))
                Catch
                End Try
                Try
                    objModuleInfo.TabID = Convert.ToInt32(Null.SetNull(dr("TabID"), objModuleInfo.TabID))
                Catch
                End Try
                Try
                    objModuleInfo.TabModuleID = Convert.ToInt32(Null.SetNull(dr("TabModuleID"), objModuleInfo.TabModuleID))
                Catch
                End Try
                Try
                    objModuleInfo.ModuleID = Convert.ToInt32(Null.SetNull(dr("ModuleID"), objModuleInfo.ModuleID))
                Catch
                End Try
                Try
                    objModuleInfo.ModuleDefID = Convert.ToInt32(Null.SetNull(dr("ModuleDefID"), objModuleInfo.ModuleDefID))
                Catch
                End Try
                Try
                    objModuleInfo.ModuleOrder = Convert.ToInt32(Null.SetNull(dr("ModuleOrder"), objModuleInfo.ModuleOrder))
                Catch
                End Try
                Try
                    objModuleInfo.PaneName = Convert.ToString(Null.SetNull(dr("PaneName"), objModuleInfo.PaneName))
                Catch
                End Try
                Try
                    objModuleInfo.ModuleTitle = Convert.ToString(Null.SetNull(dr("ModuleTitle"), objModuleInfo.ModuleTitle))
                Catch
                End Try
                Try
                    objModuleInfo.CacheTime = Convert.ToInt32(Null.SetNull(dr("CacheTime"), objModuleInfo.CacheTime))
                Catch
                End Try
                Try
                    objModuleInfo.Alignment = Convert.ToString(Null.SetNull(dr("Alignment"), objModuleInfo.Alignment))
                Catch
                End Try
                Try
                    objModuleInfo.Color = Convert.ToString(Null.SetNull(dr("Color"), objModuleInfo.Color))
                Catch
                End Try
                Try
                    objModuleInfo.Border = Convert.ToString(Null.SetNull(dr("Border"), objModuleInfo.Border))
                Catch
                End Try
                Try
                    objModuleInfo.IconFile = Convert.ToString(Null.SetNull(dr("IconFile"), objModuleInfo.IconFile))
                Catch
                End Try
                Try
                    objModuleInfo.AllTabs = Convert.ToBoolean(Null.SetNull(dr("AllTabs"), objModuleInfo.AllTabs))
                Catch
                End Try
                Try
                    Dim intVisibility As Integer
                    Select Case Convert.ToInt32(Null.SetNull(dr("Visibility"), intVisibility))
                        Case 0, Null.NullInteger : objModuleInfo.Visibility = VisibilityState.Maximized
                        Case 1 : objModuleInfo.Visibility = VisibilityState.Minimized
                        Case 2 : objModuleInfo.Visibility = VisibilityState.None
                    End Select
                Catch
                End Try
                Try
                    objModuleInfo.IsDeleted = Convert.ToBoolean(Null.SetNull(dr("IsDeleted"), objModuleInfo.IsDeleted))
                Catch
                End Try
                Try
                    objModuleInfo.Header = Convert.ToString(Null.SetNull(dr("Header"), objModuleInfo.Header))
                Catch
                End Try
                Try
                    objModuleInfo.Footer = Convert.ToString(Null.SetNull(dr("Footer"), objModuleInfo.Footer))
                Catch
                End Try
                Try
                    objModuleInfo.StartDate = Convert.ToDateTime(Null.SetNull(dr("StartDate"), objModuleInfo.StartDate))
                Catch
                End Try
                Try
                    objModuleInfo.EndDate = Convert.ToDateTime(Null.SetNull(dr("EndDate"), objModuleInfo.EndDate))
                Catch
                End Try
                Try
                    objModuleInfo.ContainerSrc = Convert.ToString(Null.SetNull(dr("ContainerSrc"), objModuleInfo.ContainerSrc))
                Catch
                End Try
                Try
                    objModuleInfo.DisplayTitle = Convert.ToBoolean(Null.SetNull(dr("DisplayTitle"), objModuleInfo.DisplayTitle))
                Catch
                End Try
                Try
                    objModuleInfo.DisplayPrint = Convert.ToBoolean(Null.SetNull(dr("DisplayPrint"), objModuleInfo.DisplayPrint))
                Catch
                End Try
                Try
                    objModuleInfo.DisplaySyndicate = Convert.ToBoolean(Null.SetNull(dr("DisplaySyndicate"), objModuleInfo.DisplaySyndicate))
                Catch
                End Try
                Try
                    objModuleInfo.InheritViewPermissions = Convert.ToBoolean(Null.SetNull(dr("InheritViewPermissions"), objModuleInfo.InheritViewPermissions))
                Catch
                End Try
                Try
                    objModuleInfo.DesktopModuleID = Convert.ToInt32(Null.SetNull(dr("DesktopModuleID"), objModuleInfo.DesktopModuleID))
                Catch
                End Try
                Try
                    objModuleInfo.FriendlyName = Convert.ToString(Null.SetNull(dr("FriendlyName"), objModuleInfo.FriendlyName))
                Catch
                End Try
                Try
                    objModuleInfo.Description = Convert.ToString(Null.SetNull(dr("Description"), objModuleInfo.Description))
                Catch
                End Try
                Try
                    objModuleInfo.Version = Convert.ToString(Null.SetNull(dr("Version"), objModuleInfo.Version))
                Catch
                End Try
                Try
                    objModuleInfo.IsPremium = Convert.ToBoolean(Null.SetNull(dr("IsPremium"), objModuleInfo.IsPremium))
                Catch
                End Try
                Try
                    objModuleInfo.IsAdmin = Convert.ToBoolean(Null.SetNull(dr("IsAdmin"), objModuleInfo.IsAdmin))
                Catch
                End Try
                Try
                    objModuleInfo.BusinessControllerClass = Convert.ToString(Null.SetNull(dr("BusinessControllerClass"), objModuleInfo.BusinessControllerClass))
                Catch
                End Try
                Try
                    objModuleInfo.ModuleControlId = Convert.ToInt32(Null.SetNull(dr("ModuleControlId"), objModuleInfo.ModuleControlId))
                Catch
                End Try
                Try
                    objModuleInfo.ControlSrc = Convert.ToString(Null.SetNull(dr("ControlSrc"), objModuleInfo.ControlSrc))
                Catch
                End Try
                Try
                    Dim intControlType As Integer
                    Select Case Convert.ToInt32(Null.SetNull(dr("ControlType"), intControlType))
                        Case -3 : objModuleInfo.ControlType = SecurityAccessLevel.ControlPanel
                        Case -2 : objModuleInfo.ControlType = SecurityAccessLevel.SkinObject
                        Case -1, Null.NullInteger : objModuleInfo.ControlType = SecurityAccessLevel.Anonymous
                        Case 0 : objModuleInfo.ControlType = SecurityAccessLevel.View
                        Case 1 : objModuleInfo.ControlType = SecurityAccessLevel.Edit
                        Case 2 : objModuleInfo.ControlType = SecurityAccessLevel.Admin
                        Case 3 : objModuleInfo.ControlType = SecurityAccessLevel.Host
                    End Select
                Catch
                End Try
                Try
                    objModuleInfo.ControlTitle = Convert.ToString(Null.SetNull(dr("ControlTitle"), objModuleInfo.ControlTitle))
                Catch
                End Try
                Try
                    objModuleInfo.HelpUrl = Convert.ToString(Null.SetNull(dr("HelpUrl"), objModuleInfo.HelpUrl))
                Catch
                End Try

                If IncludePermissions Then
                    If Not objModuleInfo Is Nothing Then
                        'Get the Module permissions first (then we can parse the collection to determine the View/Edit Roles)
                        Try
                            objModuleInfo.ModulePermissions = objModulePermissionController.GetModulePermissionsCollectionByModuleID(objModuleInfo.ModuleID)
                        Catch
                        End Try
                        Try
                            objModuleInfo.AuthorizedEditRoles = objModulePermissionController.GetModulePermissionsByModuleID(objModuleInfo, "EDIT")
                            If objModuleInfo.AuthorizedEditRoles = ";" Then
                                ' this code is here for legacy support - the AuthorizedEditRoles were stored as a concatenated list of roleids prior to DNN 3.0
                                Try
                                    objModuleInfo.AuthorizedEditRoles = Convert.ToString(Null.SetNull(dr("AuthorizedEditRoles"), objModuleInfo.AuthorizedEditRoles))
                                Catch
                                    ' the AuthorizedEditRoles field was removed from the Tabs table in 3.0
                                End Try
                            End If
                        Catch
                        End Try
                        Try
                            If objModuleInfo.InheritViewPermissions Then
                                Dim objTabPermissionController As New Security.Permissions.TabPermissionController
                                Dim arrTabPermissions As ArrayList = objTabPermissionController.GetTabPermissionsByPortal(objModuleInfo.PortalID)
                                objModuleInfo.AuthorizedViewRoles = objTabPermissionController.GetTabPermissionsByTabID(arrTabPermissions, objModuleInfo.TabID, "VIEW")
                            Else
                                objModuleInfo.AuthorizedViewRoles = objModulePermissionController.GetModulePermissionsByModuleID(objModuleInfo, "VIEW")
                            End If
                            If objModuleInfo.AuthorizedViewRoles = ";" Then
                                ' this code is here for legacy support - the AuthorizedViewRoles were stored as a concatenated list of roleids prior to DNN 3.0
                                Try
                                    objModuleInfo.AuthorizedViewRoles = Convert.ToString(Null.SetNull(dr("AuthorizedViewRoles"), objModuleInfo.AuthorizedViewRoles))
                                Catch
                                    ' the AuthorizedViewRoles field was removed from the Tabs table in 3.0
                                End Try
                            End If
                        Catch
                        End Try
                    End If
                End If
            Else
                objModuleInfo = Nothing
            End If
            Return objModuleInfo
        End Function

        Friend Function FillModuleInfoCollection(ByVal dr As IDataReader) As ArrayList

            Return FillModuleInfoCollection(dr, True)
        End Function

        Friend Function FillModuleInfoCollection(ByVal dr As IDataReader, ByVal IncludePermissions As Boolean) As ArrayList
            Try
                Dim arr As New ArrayList
                Dim obj As ModuleInfo
                While dr.Read
                    ' fill business object
                    obj = FillModuleInfo(dr, False, IncludePermissions)
                    ' add to collection
                    arr.Add(obj)
                End While
                Return arr
            Catch exc As Exception
                LogException(exc)
            Finally
                ' close datareader
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try
        End Function

        Public Function GetAllModules() As ArrayList

            Return FillModuleInfoCollection(DataProvider.Instance().GetAllModules())

        End Function

        Public Function GetModule(ByVal ModuleId As Integer, ByVal TabId As Integer) As ModuleInfo

            Dim dr As IDataReader
            Try
                dr = DataProvider.Instance().GetModule(ModuleId, TabId)
                Return FillModuleInfo(dr)
            Finally
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try

        End Function

        Public Function GetModules(ByVal PortalID As Integer) As ArrayList

            Return FillModuleInfoCollection(DataProvider.Instance().GetModules(PortalID))

        End Function

        Public Function GetModules(ByVal PortalID As Integer, ByVal IncludePermissions As Boolean) As ArrayList

            Return FillModuleInfoCollection(DataProvider.Instance().GetModules(PortalID), IncludePermissions)

        End Function

        Public Function GetAllTabsModules(ByVal PortalID As Integer, ByVal AllTabs As Boolean) As ArrayList

            Return FillModuleInfoCollection(DataProvider.Instance().GetAllTabsModules(PortalID, AllTabs))

        End Function

        Public Function GetModuleSettings(ByVal ModuleId As Integer) As Hashtable

            Dim objModuleSettings As New Hashtable

            Dim dr As IDataReader = DataProvider.Instance().GetModuleSettings(ModuleId)

            While dr.Read()

                If Not dr.IsDBNull(1) Then
                    objModuleSettings(dr.GetString(0)) = dr.GetString(1)
                Else
                    objModuleSettings(dr.GetString(0)) = ""
                End If

            End While

            dr.Close()

            Return objModuleSettings

        End Function

        Public Function GetPortalTabModules(ByVal PortalId As Integer, ByVal TabId As Integer) As ArrayList

            Return FillModuleInfoCollection(DataProvider.Instance().GetPortalTabModules(PortalId, TabId))

        End Function

        Public Function GetModuleByDefinition(ByVal PortalId As Integer, ByVal FriendlyName As String) As ModuleInfo

            Dim dr As IDataReader
            Try
                dr = DataProvider.Instance().GetModuleByDefinition(PortalId, FriendlyName)
                Return FillModuleInfo(dr)
            Finally
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try

        End Function

        Public Function GetTabModuleSettings(ByVal TabModuleId As Integer) As Hashtable

            Dim objTabModuleSettings As New Hashtable

            Dim dr As IDataReader = DataProvider.Instance().GetTabModuleSettings(TabModuleId)

            While dr.Read()

                If Not dr.IsDBNull(1) Then
                    objTabModuleSettings(dr.GetString(0)) = dr.GetString(1)
                Else
                    objTabModuleSettings(dr.GetString(0)) = ""
                End If

            End While

            dr.Close()

            Return objTabModuleSettings

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' MoveModule moes a Module from one Tab to another including all the 
        '''	TabModule settings
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="moduleId">The Id of the module to move</param>
        '''	<param name="fromTabId">The Id of the source tab</param>
        '''	<param name="toTabId">The Id of the destination tab</param>
        '''	<param name="toPaneName">The name of the Pane on the destination tab where the module will end up</param>
        ''' <history>
        ''' 	[cnurse]	10/21/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub MoveModule(ByVal moduleId As Integer, ByVal fromTabId As Integer, ByVal toTabId As Integer, ByVal toPaneName As String)

            'First copy the Module to the new Tab (including the TabModuleSettings)
            CopyModule(moduleId, fromTabId, toTabId, toPaneName, True)

            'Next Remove the Module from the source tab
            DeleteTabModule(fromTabId, moduleId)

        End Sub

        Public Sub UpdateModule(ByVal objModule As ModuleInfo)

            ' update module
            DataProvider.Instance().UpdateModule(objModule.ModuleID, objModule.ModuleTitle, objModule.AllTabs, objModule.Header, objModule.Footer, objModule.StartDate, objModule.EndDate, objModule.InheritViewPermissions, objModule.IsDeleted)

            ' update module permissions
            Dim objModulePermissionController As New Security.Permissions.ModulePermissionController
            Dim objCurrentModulePermissions As Security.Permissions.ModulePermissionCollection
            objCurrentModulePermissions = objModulePermissionController.GetModulePermissionsCollectionByModuleID(objModule.ModuleID)
            If Not objCurrentModulePermissions.CompareTo(objModule.ModulePermissions) Then
                objModulePermissionController.DeleteModulePermissionsByModuleID(objModule.ModuleID)
                Dim objModulePermission As Security.Permissions.ModulePermissionInfo
                For Each objModulePermission In objModule.ModulePermissions
                    objModulePermission.ModuleID = objModule.ModuleID
                    If objModule.InheritViewPermissions And objModulePermission.PermissionKey = "VIEW" Then
                        objModulePermissionController.DeleteModulePermission(objModulePermission.ModulePermissionID)
                    Else
                        If objModulePermission.AllowAccess Then
                            objModulePermissionController.AddModulePermission(objModulePermission)
                        End If
                    End If
                Next
            End If

            If Not Null.IsNull(objModule.TabID) Then

                ' update tabmodule
                DataProvider.Instance().UpdateTabModule(objModule.TabID, objModule.ModuleID, objModule.ModuleOrder, objModule.PaneName, objModule.CacheTime, objModule.Alignment, objModule.Color, objModule.Border, objModule.IconFile, objModule.Visibility, objModule.ContainerSrc, objModule.DisplayTitle, objModule.DisplayPrint, objModule.DisplaySyndicate)

                ' update module order in pane
                UpdateModuleOrder(objModule.TabID, objModule.ModuleID, objModule.ModuleOrder, objModule.PaneName)

                ' set the default module
                If objModule.IsDefaultModule Then
                    PortalSettings.UpdatePortalSetting(objModule.PortalID, "defaultmoduleid", objModule.ModuleID.ToString)
                    PortalSettings.UpdatePortalSetting(objModule.PortalID, "defaulttabid", objModule.TabID.ToString)
                End If

                ' apply settings to all desktop modules in portal
                If objModule.AllModules Then
                    Dim arrModules As ArrayList
                    Dim objTargetModule As ModuleInfo
                    Dim objTabs As New TabController
                    Dim arrTabs As ArrayList = objTabs.GetTabs(objModule.PortalID)
                    Dim objTab As TabInfo
                    For Each objTab In arrTabs
                        If Not objTab.IsAdminTab Then
                            arrModules = GetPortalTabModules(objTab.PortalID, objTab.TabID)
                            For Each objTargetModule In arrModules
                                DataProvider.Instance().UpdateTabModule(objTargetModule.TabID, objTargetModule.ModuleID, objTargetModule.ModuleOrder, objTargetModule.PaneName, objModule.CacheTime, objModule.Alignment, objModule.Color, objModule.Border, objModule.IconFile, objModule.Visibility, objModule.ContainerSrc, objModule.DisplayTitle, objModule.DisplayPrint, objModule.DisplaySyndicate)
                            Next
                        End If
                    Next
                End If
            End If

        End Sub

        Public Sub UpdateModuleOrder(ByVal TabId As Integer, ByVal ModuleId As Integer, ByVal ModuleOrder As Integer, ByVal PaneName As String)

            Dim objModule As ModuleInfo = GetModule(ModuleId, TabId)
            If Not objModule Is Nothing Then
                ' adding a module to a new pane - places the module at the bottom of the pane 
                If ModuleOrder = -1 Then
                    Dim dr As IDataReader = DataProvider.Instance().GetTabModuleOrder(TabId, PaneName)
                    While dr.Read
                        ModuleOrder = Convert.ToInt32(dr("ModuleOrder"))
                    End While
                    dr.Close()
                    ModuleOrder += 2
                End If

                DataProvider.Instance().UpdateModuleOrder(TabId, ModuleId, ModuleOrder, PaneName)

                ' clear cache
                If objModule.AllTabs = False Then
                    DataCache.ClearCoreCache(CoreCacheType.Tab, TabId)
                Else
                    Dim objTabs As New TabController
                    Dim objTab As TabInfo = objTabs.GetTab(TabId)
                    If Not objTab Is Nothing Then
                        DataCache.ClearCoreCache(CoreCacheType.Portal, objTab.PortalID, True)
                    End If
                End If
            End If

        End Sub

        Public Sub UpdateModuleSetting(ByVal ModuleId As Integer, ByVal SettingName As String, ByVal SettingValue As String)

            Dim dr As IDataReader = DataProvider.Instance().GetModuleSetting(ModuleId, SettingName)

            If dr.Read Then
                DataProvider.Instance().UpdateModuleSetting(ModuleId, SettingName, SettingValue)
            Else
                DataProvider.Instance().AddModuleSetting(ModuleId, SettingName, SettingValue)
            End If
            dr.Close()

        End Sub

        Public Sub UpdateTabModuleOrder(ByVal TabId As Integer)

            Dim ModuleCounter As Integer
            Dim dr As IDataReader = DataProvider.Instance().GetTabPanes(TabId)
            While dr.Read
                ModuleCounter = 0
                Dim dr2 As IDataReader = DataProvider.Instance().GetTabModuleOrder(TabId, Convert.ToString(dr("PaneName")))
                While dr2.Read
                    ModuleCounter += 1
                    DataProvider.Instance().UpdateModuleOrder(TabId, Convert.ToInt32(dr2("ModuleID")), (ModuleCounter * 2) - 1, Convert.ToString(dr("PaneName")))
                End While
                dr2.Close()
            End While
            dr.Close()

            ' clear tab cache
            DataCache.ClearCoreCache(CoreCacheType.Tab, TabId)

        End Sub

        Public Sub UpdateTabModuleSetting(ByVal TabModuleId As Integer, ByVal SettingName As String, ByVal SettingValue As String)

            Dim dr As IDataReader = DataProvider.Instance().GetTabModuleSetting(TabModuleId, SettingName)

            If dr.Read Then
                DataProvider.Instance().UpdateTabModuleSetting(TabModuleId, SettingName, SettingValue)
            Else
                DataProvider.Instance().AddTabModuleSetting(TabModuleId, SettingName, SettingValue)
            End If
            dr.Close()

        End Sub

    End Class


End Namespace
