'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.DirectoryServices
Imports DotNetNuke.Services.Exceptions
Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Security.Authentication.ADSI.Configuration
Imports DotNetNuke.Security.Authentication.ADSI.Utilities

Namespace DotNetNuke.Security.Authentication

    Public Class ADSIProvider
        Inherits AuthenticationProvider

        Private _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
        Private _adsiConfig As ADSI.Configuration = ADSI.Configuration.GetConfig()

        Public Sub New()
        End Sub 'New

        Public Overloads Overrides Function GetUser(ByVal LoggedOnUserName As String, ByVal LoggedOnPassword As String) As Authentication.UserInfo
            Dim objAuthUser As Authentication.UserInfo

            If Not _adsiConfig.ADSINetwork Then
                Return Nothing
            End If

            Try
                Dim entry As DirectoryEntry = GetUserEntryByName(LoggedOnUserName)

                'Check authenticated
                If Not IsAuthenticated(entry.Path, LoggedOnUserName, LoggedOnPassword) Then
                    Return Nothing
                End If

                ' Return authenticated if no error 
                objAuthUser = New Authentication.UserInfo

                Dim location As String = GetEntryLocation(entry)
                If location.Length = 0 Then
                    location = _adsiConfig.ConfigDomainPath
                End If

                With objAuthUser
                    .PortalID = _portalSettings.PortalId
                    .GUID = entry.NativeGuid
                    .Username = LoggedOnUserName
                    .Location = location
                    .PrincipalName = TrimUserDomainName(LoggedOnUserName) & "@" & location
                    .Username = LoggedOnUserName
                    .Membership.Password = LoggedOnPassword
                End With

                FillUserInfo(entry, objAuthUser)

                Return objAuthUser

            Catch exc As Exception
                LogException(exc)
                Return Nothing
            End Try
        End Function

        Public Overloads Overrides Function GetUser(ByVal LoggedOnUserName As String) As Authentication.UserInfo
            'Dim adsiConfig As Authentication.ADSI.Configuration = Authentication.ADSI.Configuration.GetConfig(_portalSettings.PortalId)
            Dim objAuthUser As Authentication.UserInfo
            Try
                If _adsiConfig.ADSINetwork Then
                    Dim entry As DirectoryEntry

                    entry = GetUserEntryByName(LoggedOnUserName)

                    If Not entry Is Nothing Then
                        objAuthUser = New Authentication.UserInfo

                        Dim location As String = GetEntryLocation(entry)
                        If location.Length = 0 Then
                            location = _adsiConfig.ConfigDomainPath
                        End If

                        With objAuthUser
                            .PortalID = _portalSettings.PortalId
                            .GUID = entry.NativeGuid
                            .Location = location
                            .Username = LoggedOnUserName
                            .PrincipalName = TrimUserDomainName(LoggedOnUserName) & "@" & location
                            .Username = LoggedOnUserName
                            .Membership.Password = GetRandomPassword()
                        End With

                        FillUserInfo(entry, objAuthUser)

                    Else
                        objAuthUser = GetSimplyUser(LoggedOnUserName)
                    End If

                Else ' could not find it in AD, so populate user object with minumum info
                    objAuthUser = GetSimplyUser(LoggedOnUserName)
                End If

                Return objAuthUser

            Catch exc As System.Runtime.InteropServices.COMException
                LogException(exc)
                Return Nothing
            End Try
        End Function

        Public Overloads Overrides Function GetGroups() As ArrayList
            'Dim adsiConfig As Authentication.ADSI.Configuration = Authentication.ADSI.Configuration.GetConfig(_portalSettings.PortalId)
            ' Normally number of roles in DNN less than groups in Authentication,
            ' so start from DNN roles to get better performance
            Try
                ' Obtain search object
                'Dim rootDomain As DirectoryEntry = GetRootDomain()
                'Dim objSearch As New ADSI.Search(rootDomain)

                Dim colGroup As New ArrayList
                Dim objRoleController As New DotNetNuke.Security.Roles.RoleController
                Dim lstRoles As ArrayList = objRoleController.GetPortalRoles(_portalSettings.PortalId)
                Dim objRole As DotNetNuke.Security.Roles.RoleInfo

                For Each objRole In lstRoles
                    ' Auto assignment roles have been added by DNN, so don't need to get them
                    If Not objRole.AutoAssignment Then

                        ' It's possible in multiple domains network that search result return more than one group with the same name (i.e Administrators)
                        ' We better check them all
                        Dim entry As DirectoryEntry
                        For Each entry In GetGroupEntriesByName(objRole.RoleName)
                            Dim group As New Authentication.GroupInfo

                            With group
                                .PortalID = objRole.PortalID
                                .RoleID = objRole.RoleID
                                .GUID = entry.NativeGuid
                                .Location = GetEntryLocation(entry)
                                .RoleName = objRole.RoleName
                                .Description = objRole.Description
                                .ServiceFee = objRole.ServiceFee
                                .BillingFrequency = objRole.BillingFrequency
                                .TrialPeriod = objRole.TrialPeriod
                                .TrialFrequency = objRole.TrialFrequency
                                .BillingPeriod = objRole.BillingPeriod
                                .TrialFee = objRole.TrialFee
                                .IsPublic = objRole.IsPublic
                                .AutoAssignment = objRole.AutoAssignment
                            End With
                            ' Populate member with distingushed name                            
                            PopulateMembership(group, entry)

                            colGroup.Add(group)
                        Next
                    End If
                Next

                Return colGroup

            Catch exc As System.Runtime.InteropServices.COMException
                LogException(exc)
                Return Nothing
            End Try
        End Function

        Public Overrides Function GetAuthenticationTypes() As System.Array
            Return [Enum].GetValues(GetType(AuthenticationTypes))
        End Function

        Public Overrides Function IsAuthenticationMember(ByVal AuthenticationGroup As Authentication.GroupInfo, ByVal AuthenticationUser As Authentication.UserInfo) As Boolean
            If Not AuthenticationGroup.IsPopulated Then
                PopulateMembership(AuthenticationGroup)
            End If

            Return AuthenticationGroup.AuthenticationMember.Contains(AuthenticationUser.DistinguishedName)
        End Function

        ''Obtain group objects from ADSI, to be used in custom module for importing role into DNN
        'Public Overloads Overrides Function GetGroups(ByVal Filter As String) As ArrayList
        '    Return SearchGroups("", Filter)
        'End Function

        'Public Overrides Sub AddRoleMembership(ByVal Role As DotNetNuke.Security.Roles.RoleInfo, ByVal UserDistinguishedName As String)
        '    Dim adsiConfig As Authentication.ADSI.Configuration = Authentication.ADSI.Configuration.GetConfig(_portalSettings.PortalId)
        '    Dim strDomain As String = Right(UserDistinguishedName, UserDistinguishedName.Length - UserDistinguishedName.IndexOf("DC="))
        '    Dim strUserName As String = UserDistinguishedName.Substring(3, UserDistinguishedName.IndexOf(",") - 3)
        '    Try
        '        Dim objCrossReference As ADSI.CrossReferenceCollection.CrossReference = _adsiConfig.RefCollection.Item(ConvertToCanonical(strDomain, False))
        '        If (Not objCrossReference.NetBIOSName Is Nothing) AndAlso (objCrossReference.NetBIOSName.Length > 0) Then
        '            strUserName = objCrossReference.NetBIOSName & "\" & strUserName
        '        End If

        '        ' Get DNN UserInfo from database
        '        Dim objUserController As New DotNetNuke.Entities.Users.UserController
        '        Dim objRoleController As New DotNetNuke.Security.Roles.RoleController
        '        Dim objUserInfo As DotNetNuke.Entities.Users.UserInfo = objUserController.GetUserByUsername(_portalSettings.PortalId, strUserName)
        '        ' Add user role
        '        If Not objUserInfo Is Nothing Then
        '            objRoleController.AddUserRole(_portalSettings.PortalId, objUserInfo.UserID, Role.RoleID, DateTime.MaxValue)
        '        End If
        '    Catch Exc As System.Runtime.InteropServices.COMException
        '        LogException(Exc)
        '    End Try

        'End Sub

        'Public Overrides Sub AddGroupMembership(ByVal Role As DotNetNuke.Security.Roles.RoleInfo, ByVal User As DotNetNuke.Entities.Users.UserInfo)
        '    Dim adsiConfig As Authentication.ADSI.Configuration = Authentication.ADSI.Configuration.GetConfig(_portalSettings.PortalId)
        '    Try
        '        Dim authGroup As Authentication.GroupInfo = GetGroup(Role.RoleName)
        '        Dim authUser As Authentication.UserInfo = GetUser(User.Username)

        '        If (Not authUser Is Nothing) Then
        '            ' Create new group, if not exists in AD
        '            If authGroup Is Nothing Then
        '                authGroup = CreateGroup(Role)
        '            End If

        '            If (Not authGroup Is Nothing) AndAlso (Not IsAuthenticationMember(authGroup, authUser)) Then
        '                'Get object in ADSI
        '                'Dim rootDomain As ADSI.Domain = _adsiConfig.RootDomain(ADSIPath.LDAP)
        '                Dim rootDomain As ADSI.Domain = _adsiConfig.RootDomain()
        '                Dim userEntry As DirectoryEntry = GetUserEntryByLoggedOnName(User.Username, rootDomain)
        '                Dim tempGroupEntry As DirectoryEntry '= GetGroupEntryByName(Role.RoleName, rootDomain)

        '                ' With a new group, it might not be available due to replication
        '                ' Return to avoid error or
        '                Do Until (Not tempGroupEntry Is Nothing)
        '                    tempGroupEntry = GetGroupEntryByName(Role.RoleName, rootDomain)
        '                Loop
        '                'If tempGroupEntry Is Nothing Then
        '                '    Return
        '                'End If
        '                Dim groupEntry As DirectoryEntry = GetLDAPEntry(tempGroupEntry, _adsiConfig)
        '                If (Not groupEntry Is Nothing) AndAlso (Not userEntry Is Nothing) Then
        '                    Dim strDisName As String = CheckNullString(userEntry.Properties(ADSI_DISTINGUISHEDNAME).Value)
        '                    groupEntry.Properties(ADSI_MEMBER).Add(strDisName)
        '                    groupEntry.CommitChanges()
        '                End If

        '            End If
        '        End If

        '    Catch Exc As System.Runtime.InteropServices.COMException
        '        LogException(Exc)
        '    End Try
        'End Sub

        'Public Overrides Sub RemoveGroupMembership(ByVal Role As DotNetNuke.Security.Roles.RoleInfo, ByVal User As DotNetNuke.Entities.Users.UserInfo)
        '    Dim adsiConfig As Authentication.ADSI.Configuration = Authentication.ADSI.Configuration.GetConfig(_portalSettings.PortalId)
        '    Try
        '        Dim authGroup As Authentication.GroupInfo = GetGroup(Role.RoleName)
        '        Dim authUser As Authentication.UserInfo = GetUser(User.Username)

        '        If (Not authGroup Is Nothing) AndAlso (Not authUser Is Nothing) Then
        '            If IsAuthenticationMember(authGroup, authUser) Then
        '                'Get object in ADSI
        '                'Dim rootDomain As ADSI.Domain = _adsiConfig.RootDomain(ADSIPath.LDAP)
        '                Dim rootDomain As ADSI.Domain = _adsiConfig.RootDomain()
        '                Dim userEntry As DirectoryEntry = GetUserEntryByLoggedOnName(User.Username, rootDomain)
        '                Dim tempGroupEntry As DirectoryEntry = GetGroupEntryByName(Role.RoleName, rootDomain)
        '                Dim groupEntry As DirectoryEntry = GetLDAPEntry(tempGroupEntry, _adsiConfig)

        '                If (Not groupEntry Is Nothing) AndAlso (Not userEntry Is Nothing) Then
        '                    Dim strDisName As String = CheckNullString(userEntry.Properties(ADSI_DISTINGUISHEDNAME).Value)
        '                    groupEntry.Properties(ADSI_MEMBER).Remove(strDisName)
        '                    groupEntry.CommitChanges()
        '                End If

        '            End If
        '        End If

        '    Catch Exc As System.Runtime.InteropServices.COMException
        '        LogException(Exc)
        '    End Try
        'End Sub

        Public Overrides Function GetNetworkStatus() As String
            Dim sb As New System.Text.StringBuilder
            ' Refresh settings cache first
            ADSI.Configuration.ResetConfig()
            _adsiConfig = ADSI.Configuration.GetConfig

            sb.Append("<b>[Global Catalog Status]</b>" & "<br>")
            Try
                If _adsiConfig.ADSINetwork Then
                    sb.Append("OK<br>")
                Else
                    sb.Append("FAIL<br>")
                End If
            Catch ex As System.Runtime.InteropServices.COMException
                sb.Append("FAIL<br>")
                sb.Append(ex.Message & "<br>")
            End Try

            sb.Append("<b>[Root Domain Status]</b><br>")
            Try
                If Not GetRootEntry() Is Nothing Then
                    sb.Append("OK<br>")
                Else
                    sb.Append("FAIL<br>")
                End If
            Catch ex As System.Runtime.InteropServices.COMException
                sb.Append("FAIL<br>")
                sb.Append(ex.Message & "<br>")
            End Try

            sb.Append("<b>[LDAP Status]</b><br>")
            Try
                If _adsiConfig.LDAPAccesible Then
                    sb.Append("OK<br>")
                Else
                    sb.Append("FAIL<br>")
                End If
            Catch ex As System.Runtime.InteropServices.COMException
                sb.Append("FAIL<br>")
                sb.Append(ex.Message & "<br>")
            End Try

            sb.Append("<b>[Network Domains Status]</b><br>")
            Try
                If Not _adsiConfig.RefCollection Is Nothing AndAlso _adsiConfig.RefCollection.Count > 0 Then
                    sb.Append(_adsiConfig.RefCollection.Count.ToString)
                    sb.Append(" Domain(s):<br>")
                    Dim crossRef As ADSI.CrossReferenceCollection.CrossReference
                    For Each crossRef In _adsiConfig.RefCollection
                        sb.Append(crossRef.CanonicalName)
                        sb.Append(" (")
                        sb.Append(crossRef.NetBIOSName)
                        sb.Append(")<br>")
                    Next

                    If _adsiConfig.RefCollection.ProcesssLog.Length > 0 Then
                        sb.Append(_adsiConfig.RefCollection.ProcesssLog & "<br>")
                    End If

                Else
                    sb.Append("[LDAP Error Message]<br>")
                End If
            Catch ex As System.Runtime.InteropServices.COMException
                sb.Append("[LDAP Error Message]<br>")
                sb.Append(ex.Message & "<br>")
            End Try

            If _adsiConfig.ProcessLog.Length > 0 Then
                sb.Append(_adsiConfig.ProcessLog & "<br>")
            End If

            Return sb.ToString

        End Function

#Region "Private Methods"

        Private Function GetSimplyUser(ByVal UserName As String) As Authentication.UserInfo
            Dim objAuthUser As New Authentication.UserInfo

            With objAuthUser
                .PortalID = _portalSettings.PortalId
                .GUID = ""
                .Username = UserName
                .FirstName = TrimUserDomainName(UserName)
                .LastName = GetUserDomainName(UserName)
                .IsSuperUser = False
                .Location = _adsiConfig.ConfigDomainPath
                .PrincipalName = TrimUserDomainName(UserName) & "@" & .Location
                .DistinguishedName = ConvertToDistinguished(UserName)

                Dim strEmail As String = _adsiConfig.DefaultEmailDomain
                If Not strEmail.Length = 0 Then
                    If strEmail.IndexOf("@") = -1 Then
                        strEmail = "@" & strEmail
                    End If
                    strEmail = .FirstName & strEmail
                Else
                    strEmail = .FirstName & "@" & .LastName & ".com" ' confusing?
                End If
                ' Membership properties
                .Username = UserName
                .Email = strEmail
                .Membership.Approved = True
                .Membership.LastLoginDate = Date.Today()
                .Membership.Password = GetRandomPassword() 'Membership.GeneratePassword(6)
                .AuthenticationExists = False
            End With

            Return objAuthUser

        End Function

        Private Overloads Sub PopulateMembership(ByVal GroupInfo As Authentication.GroupInfo)
            'Dim adsiConfig As Authentication.ADSI.Configuration = Authentication.ADSI.Configuration.GetConfig(GroupInfo.PortalID)
            Dim rootDomain As ADSI.Domain = GetRootDomain(ADSI.Path.GC)
            Dim groupEntry As DirectoryEntry = GetGroupEntryByName(GroupInfo.RoleName)

            PopulateMembership(GroupInfo, groupEntry)

        End Sub

        Private Overloads Sub PopulateMembership(ByVal GroupInfo As Authentication.GroupInfo, ByVal GroupEntry As DirectoryEntry)
            If Not GroupInfo.IsPopulated Then
                ' Populate membership with distinguished name
                For Each strMember As String In GroupEntry.Properties(ADSI_MEMBER)
                    'Store DistinguishedName, this method is more accurated
                    GroupInfo.AuthenticationMember.Add(strMember)
                Next
                GroupInfo.IsPopulated = True
            End If
        End Sub

        Private Function IsAuthenticated(ByVal Path As String, ByVal UserName As String, ByVal Password As String) As Boolean
            Try
                Dim userEntry As New DirectoryEntry(Path, UserName, Password, AuthenticationTypes.Signing)
                ' Bind to the native AdsObject to force authentication.
                Dim obj As Object = userEntry.NativeObject

            Catch exc As System.Runtime.InteropServices.COMException
                LogException(exc)
                Return False
            End Try

            Return True

        End Function

        Private Sub FillUserInfo(ByVal UserEntry As DirectoryEntry, ByVal UserInfo As Authentication.UserInfo)

            With UserInfo
                .IsSuperUser = False
                .Username = UserInfo.Username
                .Membership.Approved = True
                .Membership.LastLoginDate = Date.Today()
                .Email = CheckNullString(UserEntry.Properties(ADSI_EMAIL).Value)
                .CName = CheckNullString(UserEntry.Properties(ADSI_CNAME).Value.ToString)
                .DistinguishedName = CheckNullString(UserEntry.Properties(ADSI_DISTINGUISHEDNAME).Value.ToString)
                .sAMAccountName = CheckNullString(UserEntry.Properties(ADSI_ACCOUNTNAME).Value.ToString)
                .Profile.FirstName = CheckNullString(UserEntry.Properties(ADSI_FIRSTNAME).Value)
                .Profile.LastName = CheckNullString(UserEntry.Properties(ADSI_LASTNAME).Value)
                .Profile.Street = CheckNullString(UserEntry.Properties(ADSI_STREET).Value)
                .Profile.City = CheckNullString(UserEntry.Properties(ADSI_CITY).Value)
                .Profile.Region = CheckNullString(UserEntry.Properties(ADSI_REGION).Value)
                .Profile.PostalCode = CheckNullString(UserEntry.Properties(ADSI_POSTALCODE).Value)
                .Profile.Country = CheckNullString(UserEntry.Properties(ADSI_COUNTRY).Value)
                .Profile.Telephone = CheckNullString(UserEntry.Properties(ADSI_TELEPHONE).Value)
                .Profile.Fax = CheckNullString(UserEntry.Properties(ADSI_FAX).Value)
                .Profile.Cell = CheckNullString(UserEntry.Properties(ADSI_CELL).Value)
                .Profile.Website = CheckNullString(UserEntry.Properties(ADSI_WEBSITE).Value)
                .AuthenticationExists = True
                ' obtain firstname from username if admin has not enter enough user info
                If .Profile.FirstName.Length = 0 Then
                    .Profile.FirstName = TrimUserDomainName(UserInfo.Username)
                End If
            End With
        End Sub

#End Region

    End Class
End Namespace