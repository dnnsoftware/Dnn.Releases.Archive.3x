'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.IO
Imports DotNetNuke.Services.Vendors

Namespace DotNetNuke.Common.Utilities

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' The LinkClick Page processes links
	''' </summary>
	''' <returns></returns>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' </history>
	''' -----------------------------------------------------------------------------
    Public MustInherit Class LinkClick

        Inherits Framework.PageBase

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded.
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                ' URL clickthrough
                If Not Request.QueryString("link") Is Nothing Then
                    Dim strLink As String = Request.QueryString("link").ToString

                    ' get ModuleId
                    Dim ModuleId As Integer = -1
                    If Not IsNothing(Request.QueryString("mid")) Then
                        ModuleId = Int32.Parse(Request.QueryString("mid"))
                    End If

                    ' get UserId
                    Dim UserId As Integer = -1
                    Dim objUserInfo As UserInfo = UserController.GetCurrentUserInfo
                    If Request.IsAuthenticated Then
                        UserId = objUserInfo.UserID
                    End If

                    ' update clicks
                    Dim objUrls As New UrlController
                    objUrls.UpdateUrlTracking(PortalSettings.PortalId, strLink, ModuleId, UserId)

                    ' format links
                    strLink = Common.Globals.LinkClickURL(strLink)

                    ' link to internal file
                    If Not Request.QueryString("contenttype") Is Nothing Then
                        ' verify file extension for request
                        Dim strExtension As String = Replace(Path.GetExtension(Request.QueryString("link").ToString()), ".", "")
                        If InStr(1, "," & Common.Globals.HostSettings("FileExtensions").ToString.ToUpper, "," & strExtension.ToUpper) <> 0 Then
                            ' force download dialog
                            Response.AppendHeader("content-disposition", "attachment; filename=" + Request.QueryString("link").ToString)
                            Response.ContentType = Request.QueryString("contenttype").ToString
                            Response.WriteFile(strLink)
                            Response.End()
                        End If
                    Else       ' redirect
                        Response.Redirect(strLink, True)
                    End If
                End If

                ' banner clickthrough
                If (Not Request.QueryString("vendorid") Is Nothing) And (Not Request.QueryString("bannerid") Is Nothing) Then
                    Dim intVendorId As Integer = Integer.Parse(Request.QueryString("vendorid"))
                    Dim intBannerId As Integer = Integer.Parse(Request.QueryString("bannerid"))

                    Dim strURL As String = "~/" & glbDefaultPage

                    Dim objBanners As New BannerController
                    Dim objBanner As BannerInfo = objBanners.GetBanner(intBannerId, intVendorId)
                    If Not objBanner Is Nothing Then
                        If Not Null.IsNull(objBanner.URL) Then
                            strURL = AddHTTP(objBanner.URL)
                        Else
                            Dim objVendors As New VendorController
                            Dim objVendor As VendorInfo = objVendors.GetVendor(objBanner.VendorId, PortalSettings.PortalId)
                            If Not objVendor Is Nothing Then
                                If objVendor.Website <> "" Then
                                    strURL = AddHTTP(objVendor.Website)
                                End If
                            End If
                        End If
                    Else
                        If Not Request.UrlReferrer Is Nothing Then
                            strURL = Request.UrlReferrer.ToString
                        End If
                    End If

                    objBanners.UpdateBannerClickThrough(intBannerId, intVendorId)

                    Response.Redirect(strURL, True)
                End If

            Catch exc As Exception    'Page failed to load
                ProcessPageLoadException(exc)
            End Try
        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
