'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.HtmlControls
Imports System.Web.UI.WebControls

''' -----------------------------------------------------------------------------
''' Project	 : DotNetNuke
''' Class	 : ClientAPI
''' 
''' -----------------------------------------------------------------------------
''' <summary>
''' Library responsible for interacting with DNN Client API.
''' </summary>
''' <remarks>
''' </remarks>
''' <history>
''' 	[Jon Henning]	8/3/2004	Created
''' </history>
''' -----------------------------------------------------------------------------
Namespace DotNetNuke.UI.Utilities
	Public Class ClientAPI

		''' -----------------------------------------------------------------------------
		''' <summary>Character used for delimiting name from value</summary>
		''' -----------------------------------------------------------------------------
		Public Const COLUMN_DELIMITER As Char = Chr(18)
		''' -----------------------------------------------------------------------------
		''' <summary>Character used for delimiting name/value pairs</summary>
		''' -----------------------------------------------------------------------------
		Public Const ROW_DELIMITER As Char = Chr(17)

		''' -----------------------------------------------------------------------------
		''' <summary>Character used for delimiting name from value</summary>
		''' -----------------------------------------------------------------------------
		Public Const CUSTOM_COLUMN_DELIMITER As Char = Chr(16)
		''' -----------------------------------------------------------------------------
		''' <summary>Character used for delimiting name/value pairs</summary>
		''' -----------------------------------------------------------------------------
		Public Const CUSTOM_ROW_DELIMITER As Char = Chr(15)

		''' -----------------------------------------------------------------------------
		''' <summary>Private variable holding location of client side js files.  Shared by entire application.</summary>
		''' -----------------------------------------------------------------------------
		Private Shared m_sScriptPath As String

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Enumerates each namespace with a seperate js file
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[Jon Henning]	8/3/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Enum ClientNamespaceReferences As Integer
			''' -----------------------------------------------------------------------------
			''' <summary></summary>
			''' -----------------------------------------------------------------------------
			dnn
			dnn_dom
			dnn_dom_positioning
			dnn_xml
		End Enum

		Public Enum ClientFunctionality As Integer
			DHTML = CInt(2 ^ 0)
			XML = CInt(2 ^ 1)
			XSLT = CInt(2 ^ 2)
			Positioning = CInt(2 ^ 3)			'what we would call adaquate positioning support
		End Enum

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Finds __dnnVariable control on page, if not found it attempts to add its own.
		''' </summary>
		''' <param name="objPage">Current page rendering content</param>
		''' <value></value>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[Jon Henning]	8/3/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Shared ReadOnly Property ClientVariableControl(ByVal objPage As Page) As HtmlInputHidden
			Get
				Dim ctlVar As HtmlInputHidden = CType(DotNetNuke.UI.Utilities.Globals.FindControlRecursive(objPage, "__dnnVariable"), HtmlInputHidden)
				If ctlVar Is Nothing Then
					Dim ctlParent As Control				   'error prone...  should put placeholder in page
					ctlParent = objPage.Controls(0)

					ctlVar = New HtmlInputHidden
					ctlVar.ID = "__dnnVariable"
					ctlParent.Controls.Add(ctlVar)
				End If
				Return ctlVar
			End Get
		End Property

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Parses DNN Variable control contents and returns out the delimited name/value pair
		''' </summary>
		''' <param name="objPage">Current page rendering content</param>
		''' <param name="strVar">Name to retrieve</param>
		''' <returns>Delimited name/value pair string</returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[Jon Henning]	8/3/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Shared Function GetClientVariableNameValuePair(ByVal objPage As Page, ByVal strVar As String) As String
			Dim ctlVar As HtmlInputHidden = ClientVariableControl(objPage)
			Dim intIndex As Integer = ctlVar.Value.IndexOf(ROW_DELIMITER & strVar & COLUMN_DELIMITER) + 1
			If intIndex > 0 Then
				Dim intEndIndex As Integer = ctlVar.Value.IndexOf(ROW_DELIMITER, intIndex)
				If intEndIndex > -1 Then
					Return ctlVar.Value.Substring(intIndex, intEndIndex - intIndex)
				Else
					Return ctlVar.Value.Substring(intIndex)
				End If
			End If
			Return ""
		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Retrieves DNN Client Variable value
		''' </summary>
		''' <param name="objPage">Current page rendering content</param>
		''' <param name="strVar">Variable name to retrieve value for</param>
		''' <returns>Value of variable</returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[Jon Henning]	8/3/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Shared Function GetClientVariable(ByVal objPage As Page, ByVal strVar As String) As String
			Dim strPair As String = GetClientVariableNameValuePair(objPage, strVar)
			If strPair.IndexOf(COLUMN_DELIMITER) > -1 Then
				Return strPair.Split(COLUMN_DELIMITER)(1)
			Else
				Return ""
			End If
		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Retrieves DNN Client Variable value
		''' </summary>
		''' <param name="objPage">Current page rendering content</param>
		''' <param name="strVar">Variable name to retrieve value for</param>
		''' <param name="strDefaultValue">Default value if variable not found</param>
		''' <returns>Value of variable</returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[Jon Henning]	8/3/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Shared Function GetClientVariable(ByVal objPage As Page, ByVal strVar As String, ByVal strDefaultValue As String) As String
			Dim strPair As String = GetClientVariableNameValuePair(objPage, strVar)
			If strPair.IndexOf(COLUMN_DELIMITER) > -1 Then
				Return strPair.Split(COLUMN_DELIMITER)(1)
			Else
				Return strDefaultValue
			End If
		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Registers a client side variable (name/value) pair
		''' </summary>
		''' <param name="objPage">Current page rendering content</param>
		''' <param name="strVar">Variable name</param>
		''' <param name="strValue">Value</param>
		''' <param name="blnOverwrite">Determins if a replace or append is applied when variable already exists</param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[Jon Henning]	8/3/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Shared Sub RegisterClientVariable(ByVal objPage As Page, ByVal strVar As String, ByVal strValue As String, ByVal blnOverwrite As Boolean)
			'only add once
			Dim ctlVar As HtmlInputHidden = ClientVariableControl(objPage)
			Dim strPair As String = GetClientVariableNameValuePair(objPage, strVar)
			If strPair.Length > 0 Then
				If blnOverwrite Then
					ctlVar.Value = ctlVar.Value.Replace(ROW_DELIMITER & strPair, ROW_DELIMITER & strVar & COLUMN_DELIMITER & strValue)
				Else
					'appending value
					Dim strOrig As String = GetClientVariable(objPage, strVar)
					ctlVar.Value = ctlVar.Value.Replace(ROW_DELIMITER & strPair, ROW_DELIMITER & strVar & COLUMN_DELIMITER & strOrig & strValue)
				End If
			Else
				ctlVar.Value &= ROW_DELIMITER & strVar & COLUMN_DELIMITER & strValue
			End If
			System.Diagnostics.Debug.WriteLine(GetClientVariableNameValuePair(objPage, strVar))
			System.Diagnostics.Debug.WriteLine(GetClientVariable(objPage, strVar))
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Responsible for registering client side js libraries and its dependecies.
		''' </summary>
		''' <param name="objPage">Current page rendering content</param>
		''' <param name="eRef">Enumerator of library to reference</param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[Jon Henning]	8/3/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Shared Sub RegisterClientReference(ByVal objPage As Page, ByVal eRef As ClientNamespaceReferences)
			Select Case eRef
				Case ClientNamespaceReferences.dnn
					If Not objPage.IsClientScriptBlockRegistered("dnn.js") Then
						objPage.RegisterClientScriptBlock("dnn.js", "<script src=""" & ClientAPI.ScriptPath & "dnn.js""></script>")
					End If
				Case ClientNamespaceReferences.dnn_dom
					If Not objPage.IsClientScriptBlockRegistered("dnn.js") Then
						objPage.RegisterClientScriptBlock("dnn.js", "<script src=""" & ClientAPI.ScriptPath & "dnn.js""></script>")
					End If
				Case ClientNamespaceReferences.dnn_dom_positioning
					If Not objPage.IsClientScriptBlockRegistered("dnn.js") Then
						objPage.RegisterClientScriptBlock("dnn.js", "<script src=""" & ClientAPI.ScriptPath & "dnn.js""></script>")
					End If
					If Not objPage.IsClientScriptBlockRegistered("dnn.positioning.js") Then
						objPage.RegisterClientScriptBlock("dnn.positioning.js", "<script src=""" & ClientAPI.ScriptPath & "dnn.dom.positioning.js""></script>")
					End If
				Case ClientNamespaceReferences.dnn_xml
					If Not objPage.IsClientScriptBlockRegistered("dnn.js") Then
						objPage.RegisterClientScriptBlock("dnn.js", "<script src=""" & ClientAPI.ScriptPath & "dnn.js""></script>")
					End If
					If Not objPage.IsClientScriptBlockRegistered("dnn.xml.js") Then
						objPage.RegisterClientScriptBlock("dnn.xml.js", "<script src=""" & ClientAPI.ScriptPath & "dnn.xml.js""></script>")
					End If
			End Select
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Determines of browser currently requesting page adaquately supports passed un client-side functionality
		''' </summary>
		''' <param name="eFunctionality">Desired Functionality</param>
		''' <returns>True when browser supports it</returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[Jon Henning]	8/3/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Shared Function BrowserSupportsFunctionality(ByVal eFunctionality As ClientFunctionality) As Boolean
			Dim objRequest As HttpRequest = System.Web.HttpContext.Current.Request

			Dim iFunc As Integer

			If ClientAPIDisabled() = True Then Return False

			Dim objXML As System.Xml.XmlDocument = GetClientAPICapsDOM()

			Dim blnSupports As Boolean = False
			Dim strBrowser As String = objRequest.Browser.Browser
			Dim dblVersion As Double = CDbl(objRequest.Browser.MajorVersion + objRequest.Browser.MinorVersion)
			Dim strFunc As String = System.Enum.GetName(eFunctionality.GetType, eFunctionality)

			blnSupports = CapsMatchFound(objXML.SelectSingleNode("/capabilities/functionality[@nm='" & strFunc & "']/supports"), objRequest.UserAgent, strBrowser, dblVersion)
			If CapsMatchFound(objXML.SelectSingleNode("/capabilities/functionality[@nm='" & strFunc & "']/excludes"), objRequest.UserAgent, strBrowser, dblVersion) Then
				blnSupports = False
			End If
			Return blnSupports

		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Retrieves XML Document representing the featuresets that each browser handles
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[Jon Henning]	8/20/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Shared Function GetClientAPICapsDOM() As System.Xml.XmlDocument
			Dim strFileName As String
			Dim objXML As System.Xml.XmlDocument = New System.Xml.XmlDocument
			Const CLIENTAPI_CACHE_KEY As String = "ClientAPICaps"

			If DataCache.GetCache(CLIENTAPI_CACHE_KEY) Is Nothing Then
				Try
					strFileName = System.Web.HttpContext.Current.Server.MapPath(ScriptPath & "/ClientAPICaps.config")
				Catch ex As Exception
					'ignore error - worried about people with reverse proxies and such...
				End Try

				If Not strFileName Is Nothing AndAlso System.IO.File.Exists(strFileName) Then
					objXML.Load(strFileName)
					'--- set file dependency cache ---'
					DataCache.SetCache(CLIENTAPI_CACHE_KEY, objXML, New System.Web.Caching.CacheDependency(strFileName))
				End If

				'If objXML.ChildNodes.Count = 0 Then
				'    'load default document from embedded resource
				'    Dim objReader As System.IO.StreamReader = New System.IO.StreamReader(GetType(ClientAPI).Assembly.GetManifestResourceStream(GetType(ClientAPI), "ClientAPICaps.config"))
				'    objXML.Load(objReader)

				'    Try
				'        objXML.Save(strFileName)
				'        DotNetNuke.DataCache.SetCache(CLIENTAPI_CACHE_KEY, objXML, New System.Web.Caching.CacheDependency(strFileName))
				'    Catch ex As Exception
				'        'ignore error - permissions... just cache with no dependency
				'        DotNetNuke.DataCache.SetCache(CLIENTAPI_CACHE_KEY, objXML)
				'    End Try
				'End If
			Else
				objXML = CType(DataCache.GetCache(CLIENTAPI_CACHE_KEY), System.Xml.XmlDocument)
			End If

			Return objXML

		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Looks for a browser match (name supplied by .NET Framework) and processes 
		''' matches where UserAgent contains specified text
		''' </summary>
		''' <param name="objNode"></param>
		''' <param name="strAgent"></param>
		''' <param name="strBrowser"></param>
		''' <param name="dblVersion"></param>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[Jon Henning]	8/20/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Shared Function CapsMatchFound(ByVal objNode As System.Xml.XmlNode, ByVal strAgent As String, ByVal strBrowser As String, ByVal dblVersion As Double) As Boolean
			If Not objNode Is Nothing Then
				If CDec(GetSafeXMLAttr(objNode.SelectSingleNode("browser[@nm='" & strBrowser & "']"), "minversion", "999")) <= dblVersion Then
					Return True
				End If

				Dim objContains As System.Xml.XmlNodeList = objNode.SelectNodes("browser[@contains]")
				Dim objContain As System.Xml.XmlNode
				For Each objContain In objContains
					If strAgent.ToLower().IndexOf(GetSafeXMLAttr(objContain, "contains", Chr(0)).ToLower()) > -1 Then
						Return True
					End If
				Next
			End If
			Return False
		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' A Safe way of accessing XML Attributes - clean way to handle nodes and attributes
		''' that are set to nothing.  When not found a "nice" default value is returned.
		''' </summary>
		''' <param name="objNode"></param>
		''' <param name="strAttr"></param>
		''' <param name="strDef"></param>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[Jon Henning]	8/20/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Shared Function GetSafeXMLAttr(ByVal objNode As System.Xml.XmlNode, ByVal strAttr As String, ByVal strDef As String) As String
			If Not objNode Is Nothing Then
				Dim objAttr As System.Xml.XmlNode = objNode.Attributes.GetNamedItem(strAttr)
				If Not objAttr Is Nothing Then Return objAttr.Value
			End If
			Return strDef
		End Function


		Public Shared Function ClientAPIDisabled() As Boolean
			Return System.Configuration.ConfigurationSettings.AppSettings("ClientAPI") = "0"
		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Path where js files are placed
		''' </summary>
		''' <value></value>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[Jon Henning]	8/19/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Shared Property ScriptPath() As String
			Get
				If Len(m_sScriptPath) > 0 Then
					Return m_sScriptPath
				ElseIf Not System.Web.HttpContext.Current Is Nothing Then
					If System.Web.HttpContext.Current.Request.ApplicationPath.EndsWith("/") Then
						Return System.Web.HttpContext.Current.Request.ApplicationPath & "js/"
					Else
						Return System.Web.HttpContext.Current.Request.ApplicationPath & "/js/"
					End If
				End If
			End Get
			Set(ByVal Value As String)
				m_sScriptPath = Value
			End Set
		End Property

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Allows a listener to be associated to a client side post back
		''' </summary>
		''' <param name="objParent">The current control on the page or the page itself.  Depending on where the page is in its lifecycle it may not be possible to add a control directly to the page object, therefore we will use the current control being rendered to append the postback control.</param>
		''' <param name="strEventName">Name of the event to sync.  If a page contains more than a single client side event only the events associated with the passed in name will be raised.</param>
		''' <param name="objDelegate">Server side AddressOf the function to handle the event</param>
		''' <param name="blnMultipleHandlers">Boolean flag to determine if multiple event handlers can be associated to an event.</param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[Jon Henning]	9/15/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Shared Sub RegisterPostBackEventHandler(ByVal objParent As Control, ByVal strEventName As String, ByVal objDelegate As ClientAPIPostBackControl.PostBackEvent, ByVal blnMultipleHandlers As Boolean)
			Const CLIENTAPI_POSTBACKCTL_ID As String = "ClientAPIPostBackCtl"
			Dim objCtl As Control = Globals.FindControlRecursive(objParent.Page, CLIENTAPI_POSTBACKCTL_ID)			'DotNetNuke.Globals.FindControlRecursive(objParent, CLIENTAPI_POSTBACKCTL_ID)
			If objCtl Is Nothing Then
				objCtl = New ClientAPIPostBackControl(objParent.Page, strEventName, objDelegate)
				objCtl.ID = CLIENTAPI_POSTBACKCTL_ID
				objParent.Controls.Add(objCtl)
				ClientAPI.RegisterClientVariable(objParent.Page, "__dnn_postBack", objParent.Page.GetPostBackClientEvent(objCtl, "[DATA]"), True)
			ElseIf blnMultipleHandlers Then
				CType(objCtl, ClientAPIPostBackControl).AddEventHandler(strEventName, objDelegate)
			End If
		End Sub

		Public Shared Sub RegisterKeyCapture(ByVal objControl As Control, ByVal objPostbackControl As Control, ByVal intKeyAscii As Integer)
			'ClientAPI.RegisterClientVariable(objControl.Page, "__dnn_keyCapture", objControl.ClientID & CUSTOM_COLUMN_DELIMITER & objPostbackControl.Page.GetPostBackClientEvent(objPostbackControl, "") & CUSTOM_COLUMN_DELIMITER & KeyAscii & CUSTOM_ROW_DELIMITER, False)
			Globals.SetAttribute(objControl, "onkeydown", GetKeyDownHandler(intKeyAscii, objPostbackControl.Page.GetPostBackClientEvent(objPostbackControl, "")))
		End Sub

		Public Shared Sub RegisterKeyCapture(ByVal objControl As Control, ByVal strJavascript As String, ByVal intKeyAscii As Integer)
			Globals.SetAttribute(objControl, "onkeydown", GetKeyDownHandler(intKeyAscii, strJavascript))
		End Sub

		Public Shared Function GetKeyDownHandler(ByVal intKeyAscii As Integer, ByVal strJavascript As String) As String
			Return "return __dnn_KeyDown('" & intKeyAscii & "', '" & strJavascript.Replace("'", "%27") & "', event);"
		End Function

	End Class

End Namespace