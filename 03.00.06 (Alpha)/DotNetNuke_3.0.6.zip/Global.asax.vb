'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.Security
Imports System.Security.Principal
Imports System.Threading
Imports System.Web.Security
Imports System.IO
Imports Microsoft.ScalableHosting.Security
Imports DotNetNuke.Security.Roles

Namespace DotNetNuke.Common
	''' -----------------------------------------------------------------------------
	''' Project	 : DotNetNuke
	''' Class	 : Global
	''' 
	''' -----------------------------------------------------------------------------
	''' <summary>
	''' 
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[sun1]	1/18/2004	Created
	''' </history>
	''' -----------------------------------------------------------------------------
	Public Class Global
		Inherits System.Web.HttpApplication


		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Application_AuthenticateRequest  Event
		'''
		''' If the client is authenticated with the application, then determine
		''' which security roles he/she belongs to and replace the "User" intrinsic
		''' with a custom IPrincipal security object that permits "User.IsInRole"
		''' role checks within the application
		'''
		''' Roles are cached in the browser in an in-memory encrypted cookie.  If the
		''' cookie doesn't exist yet for this session, create it.
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks>
		''' - Obtain PortalSettings from Current Context
		''' ' check if user has switched portals
		''' '   expire cookies if portal has changed
		''' '   check if user is valid for new portal
		''' '       log user out
		''' '       Redirect browser back to home page
		''' 
		''' ' get UserId based on authentication method ( from web.config )
		''' '   authenticate user and set last login ( this is necessary for users who have a permanent Auth cookie set ) 
		''' '       Log User Off from Cookie Authentication System
		''' '       expire cookies
		'''     Else ' valid Auth cookie
		''' '       create cookies if they do not exist yet for this session.
		''' '           keep cookies in sync
		'''             create a cookie authentication ticket ( version, user name, issue time, expires every hour, don't persist cookie, roles )
		'''             encrypt the ticket
		'''             send roles cookie to client
		'''             get roles from UserRoles table
		'''             create a string to persist the roles
		'''         ELSE get roles from roles cookie
		'''             convert the string representation of the role data into a string array
		''' add our own custom principal to the request containing the roles in the auth ticket
		''' </remarks>
		''' <history>
		''' 	[sun1]	1/18/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Application_AuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)

			' Obtain PortalSettings from Current Context
			Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
			Dim OriginalApplicationName As String = Common.Globals.GetApplicationName

			If Request.IsAuthenticated = True And Not _portalSettings Is Nothing Then
				Dim objMembershipUser As MembershipUser = Membership.GetUser(True)
				If objMembershipUser Is Nothing Then
					'could be a SuperUser, try super user application name
					Globals.SetApplicationName(Common.Globals.glbSuperUserAppName)
					objMembershipUser = Membership.GetUser
					Globals.SetApplicationName(OriginalApplicationName)
				End If
				If Not Request.Cookies("portalaliasid") Is Nothing Then
					Dim PortalCookie As FormsAuthenticationTicket = FormsAuthentication.Decrypt(Context.Request.Cookies("portalaliasid").Value)

					' check if user has switched portals
					If _portalSettings.PortalId <> Int32.Parse(PortalCookie.UserData) Then

						' expire cookies if portal has changed
						Response.Cookies("portalaliasid").Value = Nothing
						Response.Cookies("portalaliasid").Path = "/"
						Response.Cookies("portalaliasid").Expires = DateTime.Now.AddYears(-30)

						Response.Cookies("portalroles").Value = Nothing
						Response.Cookies("portalroles").Path = "/"
						Response.Cookies("portalroles").Expires = DateTime.Now.AddYears(-30)

						' check if user is valid for new portal
						Dim objUsers As New UserController
						Dim objUser As UserInfo = objUsers.GetUserByUsername(_portalSettings.PortalId, Context.User.Identity.Name)
						If objUser Is Nothing Then
							' log user out
							Dim objPortalSecurity As New PortalSecurity
							objPortalSecurity.SignOut()
							' Redirect browser back to home page
							Response.Redirect(Request.RawUrl, True)
							Exit Sub
						End If

					End If
				End If


				Dim arrPortalRoles() As String
				Dim objRoleController As New RoleController
				Dim objUserController As New UserController
				Dim Username As String
				Dim intUserId As Integer = -1

				Dim objUserInfo As UserInfo
				Dim UserInfoCacheKey As String = objUserController.GetCacheKey(_portalSettings.PortalId, Context.User.Identity.Name)
				If Common.Globals.PerformanceSetting = Common.Globals.PerformanceSettings.HeavyCaching _
				  AndAlso Not DataCache.GetCache(UserInfoCacheKey) Is Nothing Then
					objUserInfo = CType(DataCache.GetCache(UserInfoCacheKey), UserInfo)
				Else
					objUserInfo = objUserController.GetUserByUsername(_portalSettings.PortalId, Context.User.Identity.Name)
					If Common.Globals.PerformanceSetting = Common.Globals.PerformanceSettings.HeavyCaching Then
						UserInfoCacheKey = objUserController.GetCacheKey(_portalSettings.PortalId, objUserInfo.Username)
						Dim intExpire As Integer = Common.Globals.PerformanceSetting.HeavyCaching
						DataCache.SetCache(UserInfoCacheKey, objUserInfo, TimeSpan.FromMinutes(intExpire))
					End If
				End If


				If Not objUserInfo Is Nothing Then
					intUserId = objUserInfo.UserID
					Username = objUserInfo.Username
				Else
					'The user is authenticated because they have
					'an auth cookie, but it is possible that
					'their cookie contains the userid instead
					'of the username.
					Dim objPortalSecurity As New PortalSecurity
					objPortalSecurity.SignOut()
					Exit Sub
				End If


				' authenticate user and set last login ( this is necessary for users who have a permanent Auth cookie set ) 
				If objMembershipUser Is Nothing Then

					Dim objPortalSecurity As New PortalSecurity
					objPortalSecurity.SignOut()

				Else				' valid Auth cookie

					' create cookies if they do not exist yet for this session.
					If Request.Cookies("portalroles") Is Nothing Then

						' keep cookies in sync
						Dim CurrentDateTime As Date = DateTime.Now

						' create a cookie authentication ticket ( version, user name, issue time, expires every hour, don't persist cookie, roles )
						Dim PortalTicket As New FormsAuthenticationTicket(1, Username, CurrentDateTime, CurrentDateTime.AddHours(1), False, _portalSettings.PortalAlias.PortalAliasID.ToString)
						' encrypt the ticket
						Dim strPortalAliasID As String = FormsAuthentication.Encrypt(PortalTicket)
						' send portal cookie to client
						Response.Cookies("portalaliasid").Value = strPortalAliasID
						Response.Cookies("portalaliasid").Path = "/"
						Response.Cookies("portalaliasid").Expires = CurrentDateTime.AddMinutes(1)

						' get roles from UserRoles table
						arrPortalRoles = objRoleController.GetPortalRolesByUser(intUserId, _portalSettings.PortalId)

						' create a string to persist the roles
						Dim strPortalRoles As String = Join(arrPortalRoles, New Char() {";"c})

						' create a cookie authentication ticket ( version, user name, issue time, expires every hour, don't persist cookie, roles )
						Dim RolesTicket As New FormsAuthenticationTicket(1, objUserInfo.Username, CurrentDateTime, CurrentDateTime.AddHours(1), False, strPortalRoles)
						' encrypt the ticket
						Dim strRoles As String = FormsAuthentication.Encrypt(RolesTicket)
						' send roles cookie to client
						Response.Cookies("portalroles").Value = strRoles
						Response.Cookies("portalroles").Path = "/"
						Response.Cookies("portalroles").Expires = CurrentDateTime.AddMinutes(1)

					End If

					If Not Request.Cookies("portalroles") Is Nothing Then
						' get roles from roles cookie
						If Request.Cookies("portalroles").Value <> "" Then
							Dim RoleTicket As FormsAuthenticationTicket = FormsAuthentication.Decrypt(Context.Request.Cookies("portalroles").Value)

							' convert the string representation of the role data into a string array
							Context.Items.Add("UserRoles", ";" + RoleTicket.UserData + ";")
						Else
							Context.Items.Add("UserRoles", "")
						End If
						Context.Items.Add("UserInfo", objUserInfo)
					End If
				End If
			End If


			If CType(HttpContext.Current.Items("UserInfo"), UserInfo) Is Nothing Then
				Context.Items.Add("UserInfo", New UserInfo)
			End If


		End Sub

		Private Sub Application_AuthorizeRequest(ByVal sender As Object, ByVal e As System.EventArgs)
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Application_BeginRequest Event
		'''
		''' The Application_BeginRequest method is an ASP.NET event that executes 
		''' on each web request into the portal application.  The below method
		''' obtains the current TabId from the querystring of the 
		''' request -- and then obtains the configuration necessary to process
		''' and render the request.
		'''
		''' This portal configuration is stored within the application's "Context"
		''' object -- which is available to all pages, controls and components
		''' during the processing of a single request.
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks>
		''' - get TabId from querystring
		''' - parse the Request URL into a Domain Name token 
		''' - alias parameter can be used to switch portals
		''' - TabId uniquely identifies a Portal
		''' - else use the domainname
		''' - if portalalias is nothing then load the default tab
		''' - validate the alias
		''' - if Portal Alias Exists then load the PortalSettings into current context
		''' - Else portal Alias does not exist in database
		''' </remarks>
		''' <history>
		''' 	[sun1]	1/18/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Application_BeginRequest(ByVal sender As Object, ByVal e As EventArgs)
			'fix for ASP.NET canonicalization issues http://support.microsoft.com/?kbid=887459)
			If (Request.Path.IndexOf(Chr(92)) >= 0 Or System.IO.Path.GetFullPath(Request.PhysicalPath) <> Request.PhysicalPath) Then
				Throw New HttpException(404, "Not Found")
			End If
		End Sub

		Private Sub Application_End(ByVal Sender As Object, ByVal E As EventArgs)

		End Sub

		Private Sub Application_EndRequest(ByVal sender As Object, ByVal e As System.EventArgs)
		End Sub

		Private Sub Application_Error(ByVal sender As Object, ByVal e As EventArgs)
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Application_Start
		'''
		''' Executes on the first web request into the portal application, 
		''' when a new DLL is deployed, or when web.config is modified.
		''' </summary>
		''' <param name="Sender"></param>
		''' <param name="E"></param>
		''' <remarks>
		''' - global variable initialization
		''' - Get the name of the data provider
		''' - get the executing assembly location and cache it
		''' </remarks>
		''' <history>
		''' 	[sun1]		1/18/2004	Created
		'''		[cnurse]	10/29/2004	Removed File System watcher (Medium Trust)
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Application_Start(ByVal Sender As Object, ByVal E As EventArgs)

			' global variable initialization
			ServerName = Server.MachineName

			If HttpContext.Current.Request.ApplicationPath = "/" Then
				ApplicationPath = ""
			Else
				ApplicationPath = HttpContext.Current.Request.ApplicationPath
			End If
			ApplicationMapPath = HttpContext.Current.Server.MapPath(ApplicationPath)

			HostPath = ApplicationPath & "/Portals/_default/"
			HostMapPath = HttpContext.Current.Server.MapPath(HostPath)

			AssemblyPath = HttpContext.Current.Server.MapPath(ApplicationPath & "/bin/dotnetnuke.dll")

		End Sub

	End Class

End Namespace
