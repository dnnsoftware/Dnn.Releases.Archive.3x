'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data
Imports System.IO
Imports System.Runtime.Serialization.Formatters.Binary
Imports System.Collections

Namespace DotNetNuke.Services.Personalization
	Public Class PersonalizationController

		' default implementation relies on HTTPContext
		Public Sub LoadProfile(ByVal objHTTPContext As HttpContext, ByVal UserId As Integer, ByVal PortalId As Integer)

			Dim objPersonalization As New PersonalizationInfo

			objPersonalization.UserId = UserId
			objPersonalization.PortalId = PortalId
			objPersonalization.IsModified = False

			Dim dr As IDataReader = DataProvider.Instance().GetProfile(UserId, PortalId)
			If dr.Read Then
				objPersonalization.Profile = DeserializeHashTableBase64(dr("ProfileData").ToString)
			Else		  ' does not exist
				DataProvider.Instance().AddProfile(UserId, PortalId)
				objPersonalization.Profile = New Hashtable
			End If
			dr.Close()

			objHTTPContext.Items.Add("Personalization", objPersonalization)

		End Sub

		' override allows for manipulation of PersonalizationInfo outside of HTTPContext
		Public Function LoadProfile(ByVal UserId As Integer, ByVal PortalId As Integer) As PersonalizationInfo

			Dim objPersonalization As New PersonalizationInfo

			objPersonalization.UserId = UserId
			objPersonalization.PortalId = PortalId
			objPersonalization.IsModified = False

			Dim dr As IDataReader = DataProvider.Instance().GetProfile(UserId, PortalId)
			If dr.Read Then
				objPersonalization.Profile = DeserializeHashTableBase64(dr("ProfileData").ToString)
			Else		  ' does not exist
				DataProvider.Instance().AddProfile(UserId, PortalId)
				objPersonalization.Profile = New Hashtable
			End If
			dr.Close()

			Return objPersonalization

		End Function

		' default implementation relies on HTTPContext
		Public Sub SaveProfile(ByVal objHTTPContext As HttpContext, ByVal UserId As Integer, ByVal PortalId As Integer)
			Dim objPersonalization As PersonalizationInfo = CType(objHTTPContext.Items("Personalization"), PersonalizationInfo)
			SaveProfile(objPersonalization, UserId, PortalId)
		End Sub

		' override allows for manipulation of PersonalizationInfo outside of HTTPContext
		Public Sub SaveProfile(ByVal objPersonalization As PersonalizationInfo, ByVal UserId As Integer, ByVal PortalId As Integer)
			If Not objPersonalization Is Nothing Then
				If objPersonalization.IsModified Then
					Dim ProfileData As String = SerializeHashTableBase64(objPersonalization.Profile)
					DataProvider.Instance().UpdateProfile(UserId, PortalId, ProfileData)
				End If
			End If
		End Sub

		Private Function SerializeHashTableBase64(ByVal Source As Hashtable) As String
			Dim strString As String
			If Source.Count <> 0 Then
				Dim bin As BinaryFormatter = New BinaryFormatter
				Dim mem As MemoryStream = New MemoryStream
				bin.Serialize(mem, Source)
				strString = Convert.ToBase64String(mem.GetBuffer(), 0, Convert.ToInt32(mem.Length))
				mem.Close()
			Else
				strString = ""
			End If
			Return strString
		End Function

		Private Function DeserializeHashTableBase64(ByVal Source As String) As Hashtable
			Dim objHashTable As Hashtable
			If Source <> "" Then
				Dim bits As Byte() = Convert.FromBase64String(Source)
				Dim mem As MemoryStream = New MemoryStream(bits)
				Dim bin As BinaryFormatter = New BinaryFormatter
				objHashTable = CType(bin.Deserialize(mem), Hashtable)
				mem.Close()
			Else
				objHashTable = New Hashtable
			End If
			Return objHashTable
		End Function

	End Class
End Namespace