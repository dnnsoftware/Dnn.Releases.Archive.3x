'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.Text
Imports DotNetNuke

Namespace DotNetNuke.Modules.IFrame

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The IFrame Class provides the UI for displaying the IFrame
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	9/23/2004	Moved IFrame to a separate Project
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public MustInherit Class IFrame
		Inherits Entities.Modules.PortalModuleBase
		Implements Entities.Modules.IActionable

#Region "Controls"

        Protected WithEvents lblIFrame As System.Web.UI.WebControls.Label

#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/23/2004	Moved IFrame to a separate Project
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                If (CType(Settings("src"), String)) <> "" Then
                    Dim FrameText As New StringBuilder
                    FrameText.Append("<iframe frameborder=""")
                    FrameText.Append(CType(Settings("border"), String))
                    FrameText.Append(""" src=""")
                    FrameText.Append(AddHTTP(CType(Settings("src"), String)))
                    FrameText.Append(""" height=""")
                    FrameText.Append(CType(Settings("height"), String))
                    FrameText.Append(""" width=""")
                    FrameText.Append(CType(Settings("width"), String))
                    FrameText.Append(""" title=""")
                    FrameText.Append(CType(Settings("title"), String))
                    FrameText.Append(""" scrolling=""")
                    FrameText.Append(CType(Settings("scrolling"), String))
                    FrameText.Append(""">")
                    FrameText.Append(Localization.GetString("Support", Me.LocalResourceFile))
                    FrameText.Append("</iframe>")
                    lblIFrame.Text = FrameText.ToString
                End If
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region

#Region "Optional Interfaces"

		Public ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
			Get
				Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
                Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.AddContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", EditUrl(), False, Security.SecurityAccessLevel.Edit, True, False)
				Return Actions
			End Get
		End Property

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
