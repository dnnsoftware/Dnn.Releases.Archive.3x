'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.Web
Imports System.Web.UI.WebControls
Imports DotNetNuke

Namespace DotNetNuke.Modules.UserDefinedTable

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The UserDefinedTable Class provides the UI for displaying the UserDefinedTable
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	9/24/2004	Moved UserDefinedTable to a separate Project
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public MustInherit Class UserDefinedTable
		Inherits Entities.Modules.PortalModuleBase
        Implements Entities.Modules.IActionable
        Implements Entities.Modules.ISearchable

#Region "Controls"

        Protected WithEvents grdData As System.Web.UI.WebControls.DataGrid

#End Region

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' BindData fetchs the data from the database and binds it to the grid
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/24/2004	Moved UserDefinedTable to a separate Project
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub BindData()

            Dim objUserDefinedTable As New UserDefinedTableController

            Dim strSortField As String
            Dim strSortOrder As String
            Dim intColumn As Integer

            Dim dr As IDataReader

            If Convert.ToString(ViewState("SortField")) <> "" And Convert.ToString(ViewState("SortOrder")) <> "" Then
                strSortField = Convert.ToString(ViewState("SortField"))
                strSortOrder = Convert.ToString(ViewState("SortOrder"))
            Else
                Dim settings As Hashtable = PortalSettings.GetModuleSettings(ModuleId)
                If CType(settings("sortfield"), String) <> "" Then
                    dr = objUserDefinedTable.GetUserDefinedField(CType(settings("sortfield"), Integer))
                    If dr.Read Then
                        strSortField = dr("FieldTitle").ToString
                    End If
                    dr.Close()
                End If
                If CType(settings("sortorder"), String) <> "" Then
                    strSortOrder = CType(settings("sortorder"), String)
                Else
                    strSortOrder = "ASC"
                End If
            End If

            For intColumn = grdData.Columns.Count - 1 To 1 Step -1
                grdData.Columns.RemoveAt(intColumn)
            Next

            dr = objUserDefinedTable.GetUserDefinedFields(ModuleId)
            While dr.Read
                Dim colField As New BoundColumn
                colField.HeaderText = dr("FieldTitle").ToString
                If dr("FieldTitle").ToString = strSortField Then
                    If strSortOrder = "ASC" Then
                        colField.HeaderText += "<img src=""" & Convert.ToString(IIf(Request.ApplicationPath = "/", "", Request.ApplicationPath)) & "/images/sortascending.gif"" border=""0"" alt=""Sorted By " & strSortField & " In Ascending Order"">"
                    Else
                        colField.HeaderText += "<img src=""" & Convert.ToString(IIf(Request.ApplicationPath = "/", "", Request.ApplicationPath)) & "/images/sortdescending.gif"" border=""0"" alt=""Sorted By " & strSortField & " In Descending Order"">"
                    End If
                End If
                colField.DataField = dr("FieldTitle").ToString
                colField.Visible = Convert.ToBoolean(dr("Visible"))
                colField.SortExpression = dr("FieldTitle").ToString & "|ASC"
                Select Case dr("FieldType").ToString
                    Case "DateTime"
                        colField.DataFormatString = "{0:MMM dd yyyy}"
                    Case "Int32"
                        colField.DataFormatString = "{0:#,###,##0}"
                        colField.HeaderStyle.HorizontalAlign = HorizontalAlign.Right
                        colField.ItemStyle.HorizontalAlign = HorizontalAlign.Right
                    Case "Decimal"
                        colField.DataFormatString = "{0:#,###,##0.00}"
                        colField.HeaderStyle.HorizontalAlign = HorizontalAlign.Right
                        colField.ItemStyle.HorizontalAlign = HorizontalAlign.Right
                End Select
                grdData.Columns.Add(colField)
            End While
            dr.Close()

            Dim ds As DataSet

            ds = objUserDefinedTable.GetUserDefinedRows(ModuleId)

            Dim strFieldValue As String
            Dim intRow As Integer
            If Not ds Is Nothing Then
                For intRow = 0 To ds.Tables(0).Rows.Count - 1
                    'strFieldValue = ds.Tables(0).Rows(intRow).Item("FieldValue").ToString
                    'If strFieldValue.IndexOf("://") <> -1 Then
                    '    ds.Tables(0).Rows(intRow).Item("FieldValue") = "<a href=""" & strFieldValue & """>" & strFieldValue & "</a>"
                    'End If
                    'If strFieldValue.IndexOf("@") <> -1 Then
                    '    ds.Tables(0).Rows(intRow).Item("FieldValue") = "<a href=""mailto:" & strFieldValue & """>" & strFieldValue & "</a>"
                    'End If
                Next intRow
            End If


            Dim dv As DataView

            ' create a dataview to process the sort and filter options
            dv = New DataView(ds.Tables(0))

            ' sort data view
            If strSortField <> "" And strSortOrder <> "" Then
                dv.Sort = strSortField & " " & strSortOrder
            End If

            grdData.DataSource = dv
            grdData.DataBind()
        End Sub

#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/24/2004	Moved UserDefinedTable to a separate Project
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                BindData()
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' grdData_Sort runs when the control is loaded
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/24/2004	Moved UserDefinedTable to a separate Project
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub grdData_Sort(ByVal sender As Object, ByVal e As DataGridSortCommandEventArgs)
            Try
                Dim strSort() As String = Split(e.SortExpression, "|")

                If strSort(0) = Convert.ToString(ViewState("SortField")) Then
                    If Convert.ToString(ViewState("SortOrder")) = "ASC" Then
                        ViewState("SortOrder") = "DESC"
                    Else
                        ViewState("SortOrder") = "ASC"
                    End If
                Else
                    ViewState("SortOrder") = strSort(1)
                End If

                ViewState("SortField") = strSort(0)

                BindData()
            Catch exc As Exception 'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region

#Region "Optional Interfaces"

		Public ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
			Get
				Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
                Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.ContentOptions, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.ContentOptions, "", "", EditUrl("Manage UDT"), False, Security.SecurityAccessLevel.Edit, True, False)
				Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.AddContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", EditURL(), False, Security.SecurityAccessLevel.Edit, True, False)
				Return Actions
			End Get
		End Property

        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
        End Function

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

            ' base module properties
            MyBase.HelpURL = "http://www.dotnetnuke.com/" & glbDefaultPage & "?tabid=457"

        End Sub

#End Region

    End Class

End Namespace