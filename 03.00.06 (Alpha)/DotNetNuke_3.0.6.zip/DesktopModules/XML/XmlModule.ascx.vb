'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports System.Xml
Imports System.Net
Imports System.Web
Imports DotNetNuke

Namespace DotNetNuke.Modules.XML

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The XmlModule Class provides the UI for displaying the XML
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	9/23/2004	Moved XML to a separate Project
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public MustInherit Class XmlModule
		Inherits Entities.Modules.PortalModuleBase
		Implements Entities.Modules.IActionable

#Region "Controls"

        Protected WithEvents xmlContent As System.Web.UI.WebControls.Xml

#End Region

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetXMLContent loads the xml content into an Xml Document
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ContentUrl">The url to the xml text</param>
        ''' <returns>An XmlDocument</returns>
        ''' <history>
        ''' 	[cnurse]	9/23/2004	Moved XML to a separate Project
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function GetXMLContent(ByVal ContentUrl As String) As XmlDocument
            'This function reads an Xml document via a Url and returns it as an XmlDocument object

            GetXMLContent = New XmlDocument
            Dim req As WebRequest = WebRequest.Create(ContentUrl)
            Dim result As WebResponse = req.GetResponse()
            Dim ReceiveStream As Stream = result.GetResponseStream()
            Dim objXmlReader As XmlReader = New XmlTextReader(result.GetResponseStream())
            GetXMLContent.Load(objXmlReader)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetXSLContent loads the xsl content into an Xsl Transform
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ContentUrl">The url to the xsl text</param>
        ''' <returns>An XslTransform</returns>
        ''' <history>
        ''' 	[cnurse]	9/23/2004	Moved XML to a separate Project
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function GetXSLContent(ByVal ContentURL As String) As Xsl.XslTransform

            GetXSLContent = New Xsl.XslTransform
            Dim req As WebRequest = WebRequest.Create(ContentURL)
            Dim result As WebResponse = req.GetResponse()
            Dim ReceiveStream As Stream = result.GetResponseStream()
            Dim objXSLTransform As XmlReader = New XmlTextReader(result.GetResponseStream)
            GetXSLContent.Load(objXSLTransform, Nothing, Nothing)

        End Function

#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/23/2004	Moved XML to a separate Project
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim xmlsrc As String = CType(Settings("xmlsrc"), String)
                If xmlsrc <> "" Then
                    If xmlsrc.ToLower.IndexOf("http://") <> -1 Then
                        xmlContent.Document = GetXMLContent(xmlsrc)
                    Else
                        xmlContent.DocumentSource = PortalSettings.HomeDirectory & xmlsrc
                    End If
                End If

                Dim xslsrc As String = CType(Settings("xslsrc"), String)
                If xslsrc <> "" Then
                    If xslsrc.ToLower.IndexOf("http://") <> -1 Then
                        xmlContent.Transform = GetXSLContent(xslsrc)
                    Else
                        xslsrc = PortalSettings.HomeDirectory & xslsrc
                        xmlContent.TransformSource = xslsrc
                    End If
                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region

#Region "Optional Interfaces"

		Public ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
			Get
				Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
				Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.AddContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", EditURL(), False, Security.SecurityAccessLevel.Edit, True, False)
				Return Actions
			End Get
		End Property

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
