'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports System.Xml.Serialization
Imports ICSharpCode.SharpZipLib.Zip
Imports ICSharpCode.SharpZipLib.Checksums
Imports ICSharpCode.SharpZipLib.GZip
Imports DotNetNuke.Modules.Admin.ResourceInstaller

Namespace DotNetNuke.Services.Localization
	Public Class LanguagePack
		Inherits DotNetNuke.Entities.Modules.PortalModuleBase

		Private _ProgressLog As New PaLogger

		Public ReadOnly Property ProgressLog() As PaLogger
			Get
				Return _ProgressLog
			End Get
		End Property

#Region "Controls"
		Protected WithEvents cboLanguage As System.Web.UI.WebControls.DropDownList
		Protected WithEvents cmdCreate As System.Web.UI.WebControls.Button
		Protected pnlLogs As System.Web.UI.WebControls.Panel
		Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
		Protected divLog As System.Web.UI.HtmlControls.HtmlGenericControl
#End Region

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		'NOTE: The following placeholder declaration is required by the Web Form Designer.
		'Do not delete or move it.
		Private designerPlaceholderDeclaration As System.Object

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

#Region "Event Handlers"
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			'Put user code to initialize the page here
			If Not Page.IsPostBack Then
				BindLanguages()
			End If
		End Sub

		Private Sub cmdCreate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCreate.Click
			If cboLanguage.SelectedIndex > -1 Then
				Dim ResPack As New LocaleFilePack
				ResPack.Version = "3.0"

				ProgressLog.StartJob(String.Format(Localization.GetString("LOG.LoadFiles", LocalResourceFile), Localization.GetString("LOG.Global", LocalResourceFile)))				   'Localization.GetString("")
				ResPack.LocalePackCulture.Code = cboLanguage.SelectedItem.Value
				ResPack.LocalePackCulture.Text = cboLanguage.SelectedItem.Text
				GetGlobalResourceFiles(ResPack.Files, ResPack.LocalePackCulture.Code)
				ProgressLog.EndJob(String.Format(Localization.GetString("LOG.LoadFiles", LocalResourceFile), Localization.GetString("LOG.Global", LocalResourceFile)))

				ProgressLog.StartJob(String.Format(Localization.GetString("LOG.LoadFiles", LocalResourceFile), Localization.GetString("LOG.Module", LocalResourceFile)))
				GetResourceFiles(ResPack.Files, Server.MapPath("~/desktopmodules"), Server.MapPath("~/desktopmodules"), ResPack.LocalePackCulture.Code, LocaleType.LocalResource)
				ProgressLog.EndJob(String.Format(Localization.GetString("LOG.LoadFiles", LocalResourceFile), Localization.GetString("LOG.Module", LocalResourceFile)))

				ProgressLog.StartJob(String.Format(Localization.GetString("LOG.LoadFiles", LocalResourceFile), Localization.GetString("LOG.Control", LocalResourceFile)))
				GetResourceFiles(ResPack.Files, Server.MapPath("~/Controls"), Server.MapPath("~/Controls"), ResPack.LocalePackCulture.Code, LocaleType.ControlResource)
				ProgressLog.EndJob(String.Format(Localization.GetString("LOG.LoadFiles", LocalResourceFile), Localization.GetString("LOG.Control", LocalResourceFile)))

				ProgressLog.StartJob(String.Format(Localization.GetString("LOG.LoadFiles", LocalResourceFile), Localization.GetString("LOG.Admin", LocalResourceFile)))
				GetResourceFiles(ResPack.Files, Server.MapPath("~/Admin"), Server.MapPath("~/Admin"), ResPack.LocalePackCulture.Code, LocaleType.AdminResource)
				ProgressLog.EndJob(String.Format(Localization.GetString("LOG.LoadFiles", LocalResourceFile), Localization.GetString("LOG.Admin", LocalResourceFile)))

				ProgressLog.StartJob(Localization.GetString("LOG.ArchiveFiles", LocalResourceFile))
				CreateResourcePack(ResPack)
				ProgressLog.EndJob(Localization.GetString("LOG.ArchiveFiles", LocalResourceFile))

				If ProgressLog.Valid Then
					lblMessage.Text = Localization.GetString("LOG.MESSAGE.Success", LocalResourceFile)
					lblMessage.CssClass = "Head"
				Else
					lblMessage.Text = Localization.GetString("LOG.MESSAGE.Error", LocalResourceFile)
					lblMessage.CssClass = "NormalRed"
				End If
				divLog.Controls.Add(ProgressLog.GetLogsTable)
				pnlLogs.Visible = True
			End If
		End Sub
#End Region

#Region "Private Methods"
		Private Sub BindLanguages()
			Dim locales As LocaleCollection = Localization.GetSupportedLocales()
			cboLanguage.DataSource = New LocaleCollectionWrapper(locales)
			cboLanguage.DataTextField = "Text"
			cboLanguage.DataValueField = "Code"
			cboLanguage.DataBind()
			cboLanguage.Items.Insert(0, New ListItem("English - United States", ""))
		End Sub

		Private Sub GetResourceFiles(ByVal ResFileList As LocaleFileCollection, ByVal BasePath As String, ByVal RootPath As String, ByVal LocaleCode As String, ByVal ResType As LocaleType)
			Dim folders As String() = Directory.GetDirectories(BasePath)
			Dim folder As String
			Dim objFile As FileInfo
			Dim objFolder As DirectoryInfo

			For Each folder In folders
				objFolder = New DirectoryInfo(folder)

				If objFolder.Name = Localization.LocalResourceDirectory Then
					' found local resource folder, add resources
					Dim Files As FileInfo()
					If LocaleCode = "" Then
						' This is the case for en-US which is the default locale
						Files = objFolder.GetFiles("*.ascx.resx")
					Else
						Files = objFolder.GetFiles("*.ascx." & LocaleCode & ".resx")
					End If

					If Files.Length > 0 Then
						'ProgressLog.StartJob(String.Format(Localization.GetString("LOG.LoadFromFolder", LocalResourceFile), objFolder.FullName))
						For Each objFile In Files
							Dim LocaleFile As New LocaleFileInfo
							LocaleFile.LocaleFileName = objFile.Name
							LocaleFile.LocalePath = StripCommonDirectory(RootPath, objFile.DirectoryName)
							LocaleFile.LocaleModule = GetModuleName(LocaleFile.LocalePath)
							LocaleFile.LocalePath = StripModuleName(LocaleFile.LocalePath, LocaleFile.LocaleModule)
							LocaleFile.LocaleFileType = ResType
							LocaleFile.Buffer = GetFileAsByteArray(objFile)

							ResFileList.Add(LocaleFile)
							ProgressLog.AddInfo(String.Format(Localization.GetString("LOG.LoadFileName", LocalResourceFile), objFile.Name))
						Next
						'ProgressLog.EndJob(String.Format(Localization.GetString("LOG.LoadFromFolder", LocalResourceFile), objFolder.FullName))
					End If
				Else
					GetResourceFiles(ResFileList, folder, RootPath, LocaleCode, ResType)
				End If
			Next

		End Sub

		Private Sub GetGlobalResourceFiles(ByVal ResFileList As LocaleFileCollection, ByVal LocaleCode As String)
			Dim objFile As IO.FileInfo
			Dim objFolder As New DirectoryInfo(Server.MapPath(Localization.ApplicationResourceDirectory))

			Dim Files As FileInfo()
			If LocaleCode.Length = 0 Then
				' This is the case for en-US which is the default locale
				Files = objFolder.GetFiles("*.resx")
			Else
				Files = objFolder.GetFiles("*." & LocaleCode & ".resx")
			End If

			For Each objFile In Files
				If (Not objFile.Name.StartsWith("Template")) _
				 AndAlso (LocaleCode.Length > 0 _
				 OrElse (LocaleCode.Length = 0 AndAlso objFile.Name.IndexOf("."c) = objFile.Name.LastIndexOf("."c))) Then

					Dim LocaleFile As New LocaleFileInfo
					LocaleFile.LocaleFileName = objFile.Name
					'Since paths are relative and all global resources exist in a known directory,
					' we don't need a path.
					LocaleFile.LocalePath = Nothing
					LocaleFile.LocaleFileType = LocaleType.GlobalResource
					LocaleFile.Buffer = GetFileAsByteArray(objFile)

					ResFileList.Add(LocaleFile)
					ProgressLog.AddInfo(String.Format(Localization.GetString("LOG.LoadFileName", LocalResourceFile), objFile.Name))
				End If
			Next
		End Sub

		Public Function StripCommonDirectory(ByVal RootPath As String, ByVal FullPath As String) As String
			Dim NewPath As String = FullPath.Replace("/", "\")
			NewPath = NewPath.Replace(RootPath, "")
			NewPath = NewPath.Replace(Localization.LocalResourceDirectory, "")
			NewPath = NewPath.Trim("\"c, "/"c)

			If NewPath.Length = 0 Then
				NewPath = Nothing
			End If
			Return NewPath
		End Function

		Public Function GetModuleName(ByVal FullPath As String) As String
			Dim ModuleName As String = FullPath
			If Not ModuleName Is Nothing Then
				Dim Paths As String() = ModuleName.Split("\"c)
				ModuleName = Paths(0)
			End If
			Return ModuleName
		End Function

		Public Function StripModuleName(ByVal BasePath As String, ByVal ModuleName As String) As String
			Dim NewPath As String
			If BasePath Is Nothing Or ModuleName Is Nothing Then
				Return Nothing
			Else
				NewPath = BasePath.Replace(ModuleName, "").Trim("\"c)
			End If

			If NewPath.Length = 0 Then
				NewPath = Nothing
			End If
			Return NewPath
		End Function

		Private Function GetFileAsByteArray(ByVal FileObject As IO.FileInfo) As Byte()
			Dim Buffer(CType(FileObject.Length - 1, Integer)) As Byte
			Dim strmFile As FileStream
			Try
				strmFile = FileObject.OpenRead()
				strmFile.Read(Buffer, 0, Buffer.Length)
			Catch ex As Exception
				LogException(ex)
				ProgressLog.AddFailure(String.Format(Localization.GetString("Log.ERROR.CreatingByteArray", LocalResourceFile), FileObject.Name, ex))
			Finally
				strmFile.Close()
			End Try
			Return Buffer
		End Function

		Private Function GetLanguagePackManifest(ByVal ResourcePack As LocaleFilePack) As Byte()
			Dim Manifest() As Byte
			Dim ManifestSerializer As New XmlSerializer(GetType(LocaleFilePack))
			Dim ms As New MemoryStream
			Try
				ManifestSerializer.Serialize(ms, ResourcePack)
				ReDim Manifest(CType(ms.Length - 1, Integer))
				ms.Position = 0
				ms.Read(Manifest, 0, CType(ms.Length, Integer))
				ProgressLog.AddInfo(Localization.GetString("LOG.SerializeManifest", LocalResourceFile))
			Catch ex As Exception
				LogException(ex)
				ProgressLog.AddFailure(String.Format(Localization.GetString("LOG.ERROR.ManifestFile", LocalResourceFile), ex))
			Finally
				ms.Close()
			End Try

			Return Manifest
		End Function

		Private Function CreateResourcePack(ByVal ResourcePack As LocaleFilePack) As String
			Dim CompressionLevel As Integer = 9
			Dim BlockSize As Integer = 4096
			Dim ResPackName As String
			Dim ResPackShortName As String
			If ResourcePack.LocalePackCulture.Code.Length = 0 Then
				ResPackShortName = "ResourcePack.default.zip"
			Else
				ResPackShortName = "ResourcePack." & ResourcePack.LocalePackCulture.Code & ".zip"
			End If
			ResPackName = Request.MapPath(Common.Globals.HostPath) & ResPackShortName

			Dim strmZipFile As FileStream
			Try
				ProgressLog.AddInfo(String.Format(Localization.GetString("LOG.CreateArchive", LocalResourceFile), ResPackShortName))
				strmZipFile = File.Create(ResPackName)

				Dim strmZipStream As ZipOutputStream
				Try
					strmZipStream = New ZipOutputStream(strmZipFile)

					Dim myZipEntry As ZipEntry
					myZipEntry = New ZipEntry("Manifest.xml")

					strmZipStream.PutNextEntry(myZipEntry)
					strmZipStream.SetLevel(CompressionLevel)

					Dim FileData As Byte() = GetLanguagePackManifest(ResourcePack)

					strmZipStream.Write(FileData, 0, FileData.Length)
					ProgressLog.AddInfo(String.Format(Localization.GetString("LOG.SavedFile", LocalResourceFile), "Manifest.xml"))

					For Each LocaleFile As LocaleFileInfo In ResourcePack.Files
						myZipEntry = New ZipEntry(GetFullFileName(LocaleFile))
						strmZipStream.PutNextEntry(myZipEntry)
						strmZipStream.Write(LocaleFile.Buffer, 0, LocaleFile.Buffer.Length)
						ProgressLog.AddInfo(String.Format(Localization.GetString("LOG.SavedFile", LocalResourceFile), LocaleFile.LocaleFileName))
					Next
				Catch ex As Exception
					LogException(ex)
					ProgressLog.AddFailure(String.Format(Localization.GetString("LOG.ERROR.SavingFile", LocalResourceFile), ex))
				Finally
					strmZipStream.Finish()
					strmZipStream.Close()
				End Try
			Catch ex As Exception
				LogException(ex)
				ProgressLog.AddFailure(String.Format(Localization.GetString("LOG.ERROR.SavingFile", LocalResourceFile), ex))
			Finally
				strmZipFile.Close()
			End Try

			Return ResPackName
		End Function

		Private Function GetFullFileName(ByVal LocaleFile As LocaleFileInfo) As String
			Dim Result As String = LocaleFile.LocaleFileType.ToString & "\"
			If Not LocaleFile.LocaleModule Is Nothing Then
				Result &= LocaleFile.LocaleModule & "\"
			End If
			If Not LocaleFile.LocalePath Is Nothing Then
				Result &= LocaleFile.LocalePath & "\"
			End If
			Result &= LocaleFile.LocaleFileName
			Return Result
		End Function

#End Region
	End Class
End Namespace