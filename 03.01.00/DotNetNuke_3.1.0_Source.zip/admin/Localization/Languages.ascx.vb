'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO
Imports System.Xml
Imports DotNetNuke
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Modules.Actions
Imports DotNetNuke.Modules.Admin.FileSystem
Imports DotNetNuke.UI.Utilities

Namespace DotNetNuke.Services.Localization

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' Manages the suported locales file
	''' </summary>
	''' <returns></returns>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[vmasanas]	10/04/2004  Created
	''' </history>
	''' -----------------------------------------------------------------------------
	Public MustInherit Class Languages
		Inherits DotNetNuke.Entities.Modules.PortalModuleBase
		Implements Entities.Modules.IActionable


#Region "Controls"
		Protected WithEvents tblBasic As System.Web.UI.HtmlControls.HtmlTable
		Protected WithEvents tblAdd As System.Web.UI.HtmlControls.HtmlTable
		Protected WithEvents cmdAdd As System.Web.UI.WebControls.LinkButton
		Protected WithEvents RegularExpressionValidator1 As System.Web.UI.WebControls.RegularExpressionValidator
		Protected WithEvents RequiredFieldValidator2 As System.Web.UI.WebControls.RequiredFieldValidator
		Protected WithEvents txtKey As System.Web.UI.WebControls.TextBox
		Protected WithEvents RequiredFieldValidator1 As System.Web.UI.WebControls.RequiredFieldValidator
		Protected WithEvents txtName As System.Web.UI.WebControls.TextBox
		Protected WithEvents chkDeleteFiles As System.Web.UI.WebControls.CheckBox
        Protected WithEvents dgLocales As System.Web.UI.WebControls.DataGrid
#End Region

#Region "Event Handlers"
		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Loads defined locales
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[vmasanas]	04/10/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try
				If Not Page.IsPostBack Then
					'Localize Grid
					Localization.LocalizeDataGrid(dgLocales, Me.LocalResourceFile)
                    BindGrid()

                    Dim sl As New SortedList
                    Dim ci As CultureInfo
                    For Each ci In CultureInfo.GetCultures(CultureTypes.AllCultures)
                        sl.Add(ci.EnglishName, ci.Name)
                    Next ci
                End If

            Catch exc As Exception    'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Adds a new locale to the locales xml file
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks>
		''' Only one definition for a given locale key can be defined
		''' </remarks>
		''' <history>
		''' 	[vmasanas]	04/10/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAdd.Click

			Try
				If Page.IsValid Then
					Select Case (New Localization).AddLocale(txtKey.Text, txtName.Text)
						Case "Duplicate.ErrorMessage"
							UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("Duplicate.ErrorMessage", Me.LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
						Case "NewLocale.ErrorMessage"
							UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("NewLocale.ErrorMessage", Me.LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.GreenSuccess)
							BindGrid()
						Case "Save.ErrorMessage"
							UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("Save.ErrorMessage", Me.LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
						Case ""
							txtName.Text = ""
							txtKey.Text = ""
							BindGrid()
					End Select
				End If

			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Removes a given locale from the suported locales file
		''' </summary>
		''' <param name="source"></param>
		''' <param name="e"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[vmasanas]	04/10/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub dgLocales_DeleteCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles dgLocales.DeleteCommand
			Dim key As String
			Dim node As XmlNode
			Dim resDoc As New XmlDocument

			Try
				key = e.Item.Cells(1).Text
				If key = Services.Localization.Localization.SystemLocale Then
					UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("Delete.ErrorMessage", Me.LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
				Else
					resDoc.Load(Server.MapPath(Localization.SupportedLocalesFile))
					node = resDoc.SelectSingleNode("//root/language[@key='" + key + "']")
					node.ParentNode.RemoveChild(node)

					Try
						resDoc.Save(Server.MapPath(Localization.SupportedLocalesFile))
						BindGrid()
						' check if files needs to be deleted.
						If chkDeleteFiles.Checked Then
							DeleteLocalizedFiles(key)
							chkDeleteFiles.Checked = False
						End If
					Catch
						UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("Save.ErrorMessage", Me.LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
					End Try
				End If
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Adds a confirmation message to the delete button
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[vmasanas]	04/10/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub dgLocales_ItemCreated(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles dgLocales.ItemCreated
			Try
				Select Case e.Item.ItemType
					Case ListItemType.Item, ListItemType.AlternatingItem, ListItemType.EditItem
						Dim ctl As LinkButton
						ctl = CType(e.Item.Cells(2).Controls(0), LinkButton)
						ClientAPI.AddButtonConfirm(ctl, Services.Localization.Localization.GetString("DeleteItem"))
						ctl.Text = Services.Localization.Localization.GetString("cmdDelete")
						ctl.CssClass = "CommandButton"
				End Select
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try

		End Sub

#End Region

#Region "Private Methods"
		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Reads XML file and binds to the datagrid
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[vmasanas]	04/10/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub BindGrid()
			Dim ds As New DataSet
			Dim dv As DataView

			ds.ReadXml(Server.MapPath(Localization.SupportedLocalesFile))
			dv = ds.Tables(0).DefaultView
			dv.Sort = "name ASC"

			dgLocales.DataSource = dv
			dgLocales.DataBind()
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Removes all localized files for a given locale
		''' </summary>
		''' <param name="locale">Locale to delete</param>
		''' <remarks>
		''' LocalResources files are only found in \admin, \controls, \DesktopModules
		''' Global and shared resource files are in \Resources
		''' </remarks>
		''' <history>
		''' 	[vmasanas]	04/10/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub DeleteLocalizedFiles(ByVal locale As String)
			Dim fil As String

			' Delete LocalResources from following folders
			DeleteLocalizedFiles(Server.MapPath("~"), locale, True)

			' Delete Global/Shared resources
			For Each fil In Directory.GetFiles(Server.MapPath(Localization.ApplicationResourceDirectory))
				' find the locale substring, ex: .nl-NL.
				If Path.GetFileName(fil).ToLower.IndexOf("." + locale.ToLower + ".") > -1 Then
					Try
						File.Delete(fil)
					Catch
						UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("Save.ErrorMessage", Me.LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
					End Try

				End If
			Next
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Recursively deletes files on a given folder
		''' </summary>
		''' <param name="folder">Initial folder</param>
		''' <param name="locale">Locale files to be deleted</param>
		''' <param name="recurse">Delete recursively or not</param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[vmasanas]	04/10/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub DeleteLocalizedFiles(ByVal folder As String, ByVal locale As String, ByVal recurse As Boolean)
			Dim fol As String
			Dim fil As String
			locale = locale.ToLower

			For Each fol In Directory.GetDirectories(folder)
				If Path.GetFileName(fol) = Services.Localization.Localization.LocalResourceDirectory Then
					' Found LocalResources folder
					For Each fil In Directory.GetFiles(fol)
						' find the locale substring, ex: .nl-NL.
                        If Path.GetFileName(fil).ToLower.IndexOf("." + locale + ".resx") > -1 Then
                            Try
                                File.Delete(fil)
                            Catch
                                UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("Save.ErrorMessage", Me.LocalResourceFile), UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                            End Try

                        End If
                    Next
				Else
					If recurse Then
						'recurse
						DeleteLocalizedFiles(fol, locale, recurse)
					End If
				End If
			Next

		End Sub
#End Region

#Region "Optional Interfaces"
		Public ReadOnly Property ModuleActions() As ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
			Get
				Dim FileManagerModule As ModuleInfo = (New ModuleController).GetModuleByDefinition(Null.NullInteger, "File Manager")
				Dim params(2) As String

				params(0) = "mid=" & FileManagerModule.ModuleID
				params(1) = "ftype=" & UploadType.LanguagePack.ToString
				params(2) = "rtab=" & Me.TabId


				Dim Actions As New ModuleActionCollection
				Actions.Add(GetNextActionID, Services.Localization.Localization.GetString("PackageImport.Action", LocalResourceFile), ModuleActionType.AddContent, "", "", NavigateURL(FileManagerModule.TabID, "Edit", params), False, SecurityAccessLevel.Host, True, False)
				Actions.Add(GetNextActionID, Services.Localization.Localization.GetString("PackageGenerate.Action", LocalResourceFile), ModuleActionType.AddContent, "", "", EditUrl(controlkey:="package"), False, SecurityAccessLevel.Host, True, False)
				Actions.Add(GetNextActionID, Services.Localization.Localization.GetString("Verify.Action", LocalResourceFile), ModuleActionType.AddContent, "", "", EditUrl(controlkey:="verify"), False, SecurityAccessLevel.Host, True, False)
				Actions.Add(GetNextActionID, Services.Localization.Localization.GetString("TimeZones.Action", LocalResourceFile), ModuleActionType.AddContent, "", "", EditUrl(controlkey:="timezone"), False, SecurityAccessLevel.Host, True, False)
				Actions.Add(GetNextActionID, Services.Localization.Localization.GetString("Languages.Action", LocalResourceFile), ModuleActionType.AddContent, "", "", EditUrl(controlkey:="language"), False, SecurityAccessLevel.Host, True, False)
				Return Actions
			End Get
		End Property
#End Region

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		'NOTE: The following placeholder declaration is required by the Web Form Designer.
		'Do not delete or move it.
		Private designerPlaceholderDeclaration As System.Object

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

	End Class

End Namespace
