'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO
Imports System.Xml

Imports DotNetNuke
Imports DotNetNuke.UI.WebControls
Imports DotNetNuke.Services.Localization
Imports DotNetNuke.UI.Utilities

Namespace DotNetNuke.Common.Lists

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' Manages Entry List
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[tamttt] 20/10/2004	Created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public MustInherit Class ListEditor
        Inherits DotNetNuke.Entities.Modules.PortalModuleBase

#Region "Controls"
		Protected WithEvents DNNTree As DotNetNuke.UI.WebControls.DnnTree
        Protected WithEvents lblListParent As System.Web.UI.WebControls.Label
        Protected WithEvents lblListName As System.Web.UI.WebControls.Label
        Protected WithEvents lblEntryCount As System.Web.UI.WebControls.Label
        Protected WithEvents cmdAddEntry As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDeleteList As System.Web.UI.WebControls.LinkButton
        Protected WithEvents grdEntries As System.Web.UI.WebControls.DataGrid
        Protected WithEvents txtParentKey As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtEntryName As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtEntryID As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtEntryText As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtEntryValue As System.Web.UI.WebControls.TextBox
        Protected WithEvents cmdSaveEntry As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents tblTree As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents rowListParent As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents rowEntryGrid As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents rowEntryEdit As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents tblEntryEdit As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents tblDetails As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents tblEntryInfo As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents rowListCommand As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents cmdAddList As System.Web.UI.WebControls.LinkButton
        Protected WithEvents ddlSelectParent As System.Web.UI.WebControls.DropDownList
        Protected WithEvents rowParentKey As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents rowSelectList As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents ddlSelectList As System.Web.UI.WebControls.DropDownList
        Protected WithEvents chkEnableSortOrder As System.Web.UI.WebControls.CheckBox
        Protected WithEvents rowEnableSortOrder As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents rowListDetails As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents rowSelectParent As System.Web.UI.HtmlControls.HtmlTableRow
#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Page load, bind tree and enable controls
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt] 20/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal [sender] As System.Object, ByVal [e] As System.EventArgs) Handles MyBase.Load
            Try

                If Not Page.IsPostBack Then

                    ' configure tree
                    DNNTree.ImageList.Add(ResolveUrl("~/images/folder.gif"))
                    DNNTree.ImageList.Add(ResolveUrl("~/images/file.gif"))
                    DNNTree.IndentWidth = 10
                    DNNTree.CollapsedNodeImage = ResolveUrl("~/images/max.gif")
                    DNNTree.ExpandedNodeImage = ResolveUrl("~/images/min.gif")

                    BindTree()

                    Me.rowListDetails.Visible = False
                    Me.rowEntryGrid.Visible = False
                    Me.rowEntryEdit.Visible = False

                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Populate list entries based on value selected in DNNTree
        ''' </summary>
        ''' <param name="source"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt] 20/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
		Private Sub DNNTree_NodeClick(ByVal [source] As Object, ByVal [e] As DotNetNuke.UI.WebControls.DNNTreeNodeClickEventArgs) Handles DNNTree.NodeClick
			SelectedKey = e.Node.Key
			'SelectedText = e.Node.Text

			InitList()
			BindListInfo()
			BindGrid()

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		'''     Handles events when clicking image button in the grid (Edit/Up/Down)
		''' </summary>
		''' <param name="source"></param>
		''' <param name="e"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''     [tamttt] 20/10/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub grdEntries_ItemCommand(ByVal [source] As Object, ByVal [e] As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdEntries.ItemCommand
			Try
				Dim ctlLists As New ListController
				Dim entryID As Integer = CType(CType(source, DataGrid).DataKeys(e.Item.ItemIndex), Integer)

				Select Case e.CommandName.ToLower
					Case "edit"
						EnableView(False)
						EnableEdit(False)

						Dim entry As ListEntryInfo = ctlLists.GetListEntryInfo(entryID)
						Me.txtEntryID.Text = entryID.ToString
						Me.txtParentKey.Text = entry.ParentKey
						Me.txtEntryName.Text = entry.ListName
						Me.txtEntryValue.Text = entry.Value
						Me.txtEntryText.Text = entry.Text
						Me.txtEntryName.ReadOnly = True
						Me.cmdSaveEntry.CommandName = "Update"

						If Not entry.DefinitionID = -1 Then
							Me.cmdDelete.Visible = True
							ClientAPI.AddButtonConfirm(cmdDelete, Localization.GetString("DeleteItem"))
						Else
							Me.cmdDelete.Visible = False
						End If

					Case "up"
						ctlLists.UpdateListSortOrder(entryID, True)
						InitList()
						BindGrid()
					Case "down"
						ctlLists.UpdateListSortOrder(entryID, False)
						InitList()
						BindGrid()
				End Select

			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		'''     Handles Add New List command
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks>
		'''     Using "CommandName" property of cmdSaveEntry to determine this is a new list
		''' </remarks>
		''' <history>
		'''     [tamttt] 20/10/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdAddList_Click(ByVal [sender] As Object, ByVal [e] As System.EventArgs) Handles cmdAddList.Click
			EnableView(False)
			EnableEdit(True)

			Me.txtParentKey.Text = ""
			Me.txtEntryName.Text = ""
			Me.txtEntryValue.Text = ""
			Me.txtEntryText.Text = ""
			Me.txtEntryName.ReadOnly = False
			Me.cmdSaveEntry.CommandName = "SaveList"


			Dim ctlLists As New ListController
			With ddlSelectList
				.DataSource = ctlLists.GetListInfoCollection()
				.DataTextField = "DisplayName"
				.DataValueField = "Key"
				.DataBind()
				.Items.Insert(0, New ListItem(Localization.GetString("None_Specified"), ""))
			End With

			' Reset dropdownlist
			With ddlSelectParent
				.ClearSelection()
				.Enabled = False
			End With

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		'''     Select a list in dropdownlist
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>        
		''' <history>
		'''     [tamttt] 20/10/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub ddlSelectList_SelectedIndexChanged(ByVal [sender] As Object, ByVal [e] As System.EventArgs) Handles ddlSelectList.SelectedIndexChanged
			Dim ctlLists As New ListController
			Dim selList As String = ddlSelectList.SelectedItem.Value
			Dim listName As String = selList.Substring(selList.IndexOf(":") + 1)
			Dim parentKey As String = selList.Replace(listName, "").TrimEnd(":"c)

			With ddlSelectParent
				.Enabled = True
				.DataSource = ctlLists.GetListEntryInfoCollection(listName, parentKey)
				.DataTextField = "DisplayName"
				.DataValueField = "Key"
				.DataBind()
				.Items.Insert(0, New ListItem(Localization.GetString("None_Specified"), ""))
			End With

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		'''     Handles Add New Entry command
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks>
		'''     Using "CommandName" property of cmdSaveEntry to determine this is a new entry of an existing list
		''' </remarks>
		''' <history>
		'''     [tamttt] 20/10/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdAddEntry_Click(ByVal [sender] As Object, ByVal [e] As System.EventArgs) Handles cmdAddEntry.Click
			Dim listName As String = SelectedKey.Substring(SelectedKey.IndexOf(":") + 1)
			Dim parentKey As String = SelectedKey.Replace(listName, "").TrimEnd(":"c)

			EnableView(False)
			EnableEdit(False)

			Me.txtParentKey.Text = parentKey
			Me.txtEntryName.Text = listName
			Me.txtEntryValue.Text = ""
			Me.txtEntryText.Text = ""
			Me.txtEntryName.ReadOnly = True
			Me.cmdDelete.Visible = False
			Me.cmdSaveEntry.CommandName = "SaveEntry"

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		'''     Handles cmdSaveEntry.Click
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks>
		'''     Using "CommandName" property of cmdSaveEntry to determine action to take (ListUpdate/AddEntry/AddList)
		''' </remarks>
		''' <history>
		'''     [tamttt] 20/10/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdSaveEntry_Click(ByVal [sender] As Object, ByVal [e] As System.EventArgs) Handles cmdSaveEntry.Click
			Dim ctlLists As New ListController
			Dim entry As New ListEntryInfo
			With entry
				.ListName = txtEntryName.Text
				.Value = txtEntryValue.Text
				.Text = txtEntryText.Text
			End With

			Select Case cmdSaveEntry.CommandName.ToLower
				Case "update"
					entry.ParentKey = txtParentKey.Text
					entry.EntryID = Int16.Parse(txtEntryID.Text)

					ctlLists.UpdateListEntry(entry)

					InitList()
					EnableView(True)
					'BindListInfo()
					BindGrid()

				Case "saveentry"
					entry.ParentKey = txtParentKey.Text
					If EnableSortOrder Then
						entry.SortOrder = 1
					Else
						entry.SortOrder = 0
					End If

					ctlLists.AddListEntry(entry)

					InitList()
					BindListInfo()
					BindTree()
					BindGrid()

				Case "savelist"
					Dim strKey As String = ""
					Dim strText As String = ""
					If ddlSelectParent.SelectedIndex <> -1 Then
						strKey = ddlSelectParent.SelectedItem.Value
						strText = ddlSelectParent.SelectedItem.Text
						entry.ParentKey = strKey
						strKey += ":"
						strText += ":"
					End If

					If chkEnableSortOrder.Checked Then
						entry.SortOrder = 1
					Else
						entry.SortOrder = 0
					End If

					ctlLists.AddListEntry(entry)

					strKey += Me.txtEntryName.Text
					strText += Me.txtEntryName.Text

					SelectedKey = strKey
					SelectedText = strText

					BindTree()
					InitList()
					BindListInfo()
					BindGrid()
					'Response.Redirect(NavigateURL(TabId))
			End Select

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		'''     Delete List
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''     [tamttt] 20/10/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdDeleteList_Click(ByVal [sender] As Object, ByVal [e] As System.EventArgs) Handles cmdDeleteList.Click
			Dim listName As String = SelectedKey.Substring(SelectedKey.IndexOf(":") + 1)
			Dim parentKey As String = SelectedKey.Replace(listName, "").TrimEnd(":"c)

			Dim ctlLists As New ListController
			ctlLists.DeleteList(listName, parentKey)

			Response.Redirect(NavigateURL(TabId))
			'BindTree()            

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		'''     Delete List
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks>
		'''     If deleting entry is not the last one in the list, rebinding the grid, otherwise return back to main page (rebinding DNNTree)
		''' </remarks>
		''' <history>
		'''     [tamttt] 20/10/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdDelete_Click(ByVal [sender] As Object, ByVal [e] As System.EventArgs) Handles cmdDelete.Click
			Try
				Dim ctlLists As New ListController
				Dim entryID As Integer = CType(txtEntryID.Text, Integer)

				' If this is the last entry of the list, delete list
				If SelectedList.Count > 1 Then
					ctlLists.DeleteListEntryByID(entryID, True)
					EnableView(True)
					InitList()
					BindListInfo()
					BindTree()
					BindGrid()
				Else
					ctlLists.DeleteListEntryByID(entryID, True)
					BindTree()
					Me.rowListDetails.Visible = False
					Me.rowEntryGrid.Visible = False
					Me.rowEntryEdit.Visible = False
				End If

			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		'''     Cancel
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>       
		''' <history>
		'''     [tamttt] 20/10/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdCancel_Click(ByVal [sender] As Object, ByVal [e] As System.EventArgs) Handles cmdCancel.Click
			Try
				If SelectedKey <> "" Then
					EnableView(True)
					BindGrid()
				Else
					Me.rowListDetails.Visible = False
					Me.rowEntryGrid.Visible = False
					Me.rowEntryEdit.Visible = False
				End If
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub


#End Region

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Loads top level entry list into DNNTree
        ''' </summary>        
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt] 20/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub BindTree()
            Dim idx As Integer
            Dim ctlLists As New ListController
            Dim colLists As ListInfoCollection = ctlLists.GetListInfoCollection
            Dim Lists As ListInfo
            Dim indexLookup As New Hashtable

            DNNTree.TreeNodes.Clear()

            For Each Lists In colLists
                Dim node As New TreeNode(Lists.DisplayName)
                With node
                    .Key = Lists.Key
                    .ToolTip = Lists.EntryCount.ToString & " entries"
                    .ImageIndex = eImageType.Folder
                    '.Target = Lists.DefinitionID.ToString & ":" & Lists.EnableSortOrder.ToString ' borrow this property to store this value
                End With

                If Lists.Level = 0 Then
                    DNNTree.TreeNodes.Add(node)
                Else
                    If Not indexLookup.Item(Lists.ParentList) Is Nothing Then
                        Dim parentNode As TreeNode = CType(indexLookup.Item(Lists.ParentList), TreeNode)
                        parentNode.TreeNodes.Add(node)
                    End If
                End If

                ' Add index key here to find it later, should suggest with Joe to add it to DNNTree
                If indexLookup.Item(Lists.Key) Is Nothing Then
                    indexLookup.Add(Lists.Key, node)
                End If

            Next
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Loads top level entry list
        ''' </summary>
        ''' <param name="ParentKey"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt] 20/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function GetParentNode(ByVal [ParentKey] As String) As TreeNode
            Dim i As Integer
            For i = 0 To DNNTree.TreeNodes.Count - 1
                If DNNTree.TreeNodes(i).Key = ParentKey Then
                    Return DNNTree.TreeNodes(i)
                End If
            Next
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Loads top level entry list
        ''' </summary>
        ''' <param name="ParentKey"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt] 20/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub InitList()
            Dim ctlLists As New ListController
            Dim listName As String = SelectedKey.Substring(SelectedKey.IndexOf(":") + 1)
            Dim parentKey As String = SelectedKey.Replace(listName, "").TrimEnd(":"c)

            selListInfo = ctlLists.GetListInfo(listName, parentKey)
            SelectedText = selListInfo.DisplayName
            EnableSortOrder = selListInfo.EnableSortOrder
            SystemList = selListInfo.SystemList

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Loads top level entry list
        ''' </summary>
        ''' <param name="ParentKey"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt] 20/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub BindListInfo()
            Dim listName As String = SelectedText.Substring(SelectedText.IndexOf(":") + 1)
            Dim parent As String = SelectedText.Replace(listName, "").TrimEnd(":"c)

            Me.lblListParent.Text = parent
            Me.lblListName.Text = listName

            Me.rowListParent.Visible = (selListInfo.Parent.Length > 0)  '(parent.Length > 0)
            If Not SystemList Then
				Me.cmdDeleteList.Visible = True
				ClientAPI.AddButtonConfirm(cmdDeleteList, Localization.GetString("DeleteItem"))
			Else
				Me.cmdDeleteList.Visible = False
			End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Loads top level entry list
        ''' </summary>
        ''' <param name="ParentKey"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt] 20/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub BindGrid()
            Dim listName As String = SelectedKey.Substring(SelectedKey.IndexOf(":") + 1)
            Dim parentKey As String = SelectedKey.Replace(listName, "").TrimEnd(":"c)

            Dim ctlLists As New ListController
            Dim selList As ListEntryInfoCollection = ctlLists.GetListEntryInfoCollection(listName, "", parentKey)

            EnableView(True)

            SelectedList = selList

            grdEntries.DataSource = selList 'selList
            grdEntries.DataBind()

            Me.lblEntryCount.Text = selList.Count.ToString & " entries"

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Switching to view mode, change controls visibility for viewing
        ''' </summary>
        ''' <param name="ViewMode">Boolean value to determine View or Edit mode</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt] 20/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub EnableView(ByVal [ViewMode] As Boolean)
            Me.rowListDetails.Visible = True
            Me.rowEntryGrid.Visible = ViewMode
            Me.rowEntryEdit.Visible = (Not ViewMode)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Switching to edit mode, change controls visibility for editing depends on AddList params
        ''' </summary>
        ''' <param name="AddList">Boolean value to determine Add or Edit mode</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt] 20/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub EnableEdit(ByVal [AddList] As Boolean)
            Me.rowListDetails.Visible = (Not AddList)
            Me.rowSelectList.Visible = AddList
            Me.rowSelectParent.Visible = AddList
            Me.rowEnableSortOrder.Visible = (AddList)
            Me.rowParentKey.Visible = False
            Me.cmdDelete.Visible = False
        End Sub

#End Region

#Region "Private Members"
        Private selListInfo As ListInfo

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Selected list
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt] 20/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Property SelectedList() As ListEntryInfoCollection
            Get
                Return CType(Session("SelectedList"), ListEntryInfoCollection)
            End Get
            Set(ByVal Value As ListEntryInfoCollection)
                Session("SelectedList") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''    Selected parent key
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt] 20/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Property [SelectedParentKey]() As String
            Get
                Return Viewstate("SelectedParentKey").ToString
            End Get
            Set(ByVal [Value] As String)
                viewstate("SelectedParentKey") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Selected key
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt] 20/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Property [SelectedKey]() As String
            Get
                If Not viewstate("SelectedKey") Is Nothing Then
                    Return Viewstate("SelectedKey").ToString
                Else
                    Return ""
                End If
            End Get
            Set(ByVal [Value] As String)
                viewstate("SelectedKey") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Selected text
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        '''     [tamttt] 20/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Property [SelectedText]() As String
            Get
                Return Viewstate("SelectedText").ToString
            End Get
            Set(ByVal [Value] As String)
                viewstate("SelectedText") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Property to determine if this list has custom sort order
        ''' </summary>
        ''' <remarks>
        '''     Up/Down button in datagrid will be visibled based on this property.
        '''     If disable, list will be sorted anphabetically
        ''' </remarks>
        ''' <history>
        '''     [tamttt] 20/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Property EnableSortOrder() As Boolean
            Get
                If Viewstate("EnableSortOrder") Is Nothing Then
                    Viewstate("EnableSortOrder") = False
                End If
                Return CType(Viewstate("EnableSortOrder"), Boolean)
            End Get
            Set(ByVal [Value] As Boolean)
                viewstate("EnableSortOrder") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        '''     Property to determine if this list is system (DNN core)
        ''' </summary>
        ''' <remarks>
        '''     Default entries in system list can not be deleted
        '''     Entries in system list is sorted anphabetically
        ''' </remarks>
        ''' <history>
        '''     [tamttt] 20/10/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Property SystemList() As Boolean
            Get
                If Viewstate("SystemList") Is Nothing Then
                    Viewstate("SystemList") = False
                End If
                Return CType(Viewstate("SystemList"), Boolean)
            End Get
            Set(ByVal Value As Boolean)
                viewstate("SystemList") = Value
            End Set
        End Property

        Private Enum eImageType
            Folder = 0
            Page = 1
        End Enum
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
