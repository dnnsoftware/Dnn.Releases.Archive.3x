'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Xml
Imports System.IO
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Modules.Definitions
Imports DotNetNuke.Entities.Modules.Actions
Imports DotNetNuke.UI.Utilities

Namespace DotNetNuke.Modules.Admin.ModuleDefinitions

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' The EditModuleDefinition PortalModuleBase is used to edit a Module
	''' Definition
	''' </summary>
	''' <returns></returns>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[cnurse]	9/28/2004	Updated to reflect design changes for Help, 508 support
    '''                       and localisation
    '''     [cnurse]    01/13/2005  Added IActionable Implementation for the Private Assembly Package creator
    '''     [cnurse]    04/18/2005  Added support for FolderName, ModuleName and BusinessControllerClass
    '''     [cnurse]    04/21/2005  Added DefaultCacheTime properties for Module Definition
	''' </history>
	''' -----------------------------------------------------------------------------
	Public MustInherit Class EditModuleDefinition

		Inherits DotNetNuke.Entities.Modules.PortalModuleBase
        Implements Entities.Modules.IActionable

#Region "Controls"

		Protected WithEvents tabModule As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents txtModuleName As System.Web.UI.WebControls.TextBox
        Protected WithEvents valModuleName As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtFolderName As System.Web.UI.WebControls.TextBox
        Protected WithEvents valFolderName As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtFriendlyName As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtDescription As System.Web.UI.WebControls.TextBox
		Protected WithEvents txtVersion As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtBusinessClass As System.Web.UI.WebControls.TextBox
        Protected WithEvents chkPremium As System.Web.UI.WebControls.CheckBox
		Protected WithEvents ctlPortals As DotNetNuke.UI.UserControls.DualListControl
		Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
		Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
		Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

		Protected WithEvents tabDefinitions As System.Web.UI.HtmlControls.HtmlTable
		Protected WithEvents cboDefinitions As System.Web.UI.WebControls.DropDownList
		Protected WithEvents cmdDeleteDefinition As System.Web.UI.WebControls.LinkButton
		Protected WithEvents txtDefinition As System.Web.UI.WebControls.TextBox
		Protected WithEvents cmdAddDefinition As System.Web.UI.WebControls.LinkButton

        Protected WithEvents tabCache As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents txtCacheTime As System.Web.UI.WebControls.TextBox
        Protected WithEvents cmdUpdateCacheTime As System.Web.UI.WebControls.LinkButton

		Protected WithEvents tabControls As System.Web.UI.HtmlControls.HtmlTable
		Protected WithEvents grdControls As System.Web.UI.WebControls.DataGrid
		Protected WithEvents cmdAddControl As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblCacheHelp As System.Web.UI.WebControls.Label

#End Region

#Region "Private Members"

		Private DesktopModuleId As Integer

#End Region

#Region "Private Methods"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' LoadDefinitions fetches the control data from the database
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <param name="ModuleDefId">The Module definition Id</param>
		''' <history>
		''' 	[cnurse]	9/28/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub LoadControls(ByVal ModuleDefId As Integer)

            Dim objModuleControls As New ModuleControlController
            Dim arrModuleControls As ArrayList = objModuleControls.GetModuleControls(ModuleDefId)

			If DesktopModuleId = -2 Then
				Dim objModuleControl As ModuleControlInfo
				Dim intIndex As Integer
				For intIndex = arrModuleControls.Count - 1 To 0 Step -1
					objModuleControl = CType(arrModuleControls(intIndex), ModuleControlInfo)
					If objModuleControl.ControlType <> SecurityAccessLevel.SkinObject Then
						arrModuleControls.RemoveAt(intIndex)
					End If
				Next
            End If

            'Localize Grid
            Services.Localization.Localization.LocalizeDataGrid(grdControls, Me.LocalResourceFile)

            grdControls.DataSource = arrModuleControls
            grdControls.DataBind()

            cmdAddControl.Visible = True
            grdControls.Visible = True

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' LoadDefinitions fetches the definitions from the database and updates the controls
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/28/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
        Private Sub LoadDefinitions()

            Dim objModuleDefinitions As New ModuleDefinitionController
            cboDefinitions.DataSource = objModuleDefinitions.GetModuleDefinitions(DesktopModuleId)
            cboDefinitions.DataBind()

            If cboDefinitions.Items.Count <> 0 Then
                cboDefinitions.SelectedIndex = 0
                Dim ModuleDefId As Integer = Integer.Parse(cboDefinitions.SelectedItem.Value)
                LoadCacheProperties(ModuleDefId)
                LoadControls(ModuleDefId)
            Else
                cmdAddControl.Visible = False
                grdControls.Visible = False
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' LoadCacheProperties loads the Module Definitions Default Cache Time properties
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	4/21/2005   created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub LoadCacheProperties(ByVal ModuleDefId As Integer)

            Dim objModuleDefinitionController As New ModuleDefinitionController
            Dim objModuleDefinition As ModuleDefinitionInfo = objModuleDefinitionController.GetModuleDefinition(ModuleDefId)

            txtCacheTime.Text = objModuleDefinition.DefaultCacheTime.ToString

        End Sub

#End Region

#Region "Public Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' FormatURL formats the url correctly (added a key=value onto the Querystring
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="strKeyName">A Key</param>
        ''' <param name="strKeyValue">The Module definition Id</param>
        ''' <returns>A correctly formatted url</returns>
        ''' <history>
        ''' 	[cnurse]	9/28/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation        
        ''' 	[smcculloch]10/11/2004	Updated to use EditUrl overload
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function FormatURL(ByVal strKeyName As String, ByVal strKeyValue As String) As String
            Try

                If DesktopModuleId <> -2 Then
                    FormatURL = EditUrl(strKeyName, strKeyValue, "Control", "desktopmoduleid=" & DesktopModuleId.ToString(), "moduledefid=" & cboDefinitions.SelectedItem.Value)
                Else
                    FormatURL = EditUrl(strKeyName, strKeyValue, "Control", "desktopmoduleid=" & DesktopModuleId.ToString(), "moduledefid=-1")
                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded.
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/28/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        '''     [vmasanas]  31/10/2004  Populate Premium list when we are adding
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim objDesktopModules As New DesktopModuleController

                If Not (Request.QueryString("desktopmoduleid") Is Nothing) Then
                    DesktopModuleId = Int32.Parse(Request.QueryString("desktopmoduleid"))
                Else
                    DesktopModuleId = Null.NullInteger
                End If

                If Page.IsPostBack = False Then
                    ClientAPI.AddButtonConfirm(cmdDelete, Services.Localization.Localization.GetString("DeleteItem"))
                    ClientAPI.AddButtonConfirm(cmdDeleteDefinition, Services.Localization.Localization.GetString("DeleteItem"))

                    If Null.IsNull(DesktopModuleId) Then

                        'Enable ReadOnly Controls for Add Mode only
                        txtModuleName.Enabled = True
                        txtFolderName.Enabled = True
                        txtVersion.Enabled = True
                        txtBusinessClass.Enabled = True

                        cmdDelete.Visible = False
                        tabDefinitions.Visible = False
                        tabCache.Visible = False
                        tabControls.Visible = False

                    Else

                        Dim objDesktopModule As DesktopModuleInfo

                        If DesktopModuleId = -2 Then
                            objDesktopModule = New DesktopModuleInfo
                            objDesktopModule.ModuleName = Services.Localization.Localization.GetString("SkinObjects")
                            objDesktopModule.FolderName = Services.Localization.Localization.GetString("SkinObjects")
                            objDesktopModule.FriendlyName = Services.Localization.Localization.GetString("SkinObjects")
                            objDesktopModule.Description = Services.Localization.Localization.GetString("SkinObjectsDescription")
                            objDesktopModule.IsPremium = False
                            objDesktopModule.Version = ""

                            cmdUpdate.Visible = False
                            cmdDelete.Visible = False
                            tabDefinitions.Visible = False
                            tabCache.Visible = False
                            txtDescription.Enabled = False
                            chkPremium.Enabled = False

                            LoadControls(Null.NullInteger)
                        Else
                            objDesktopModule = objDesktopModules.GetDesktopModule(DesktopModuleId)

                            LoadDefinitions()
                        End If

                        If Not objDesktopModule Is Nothing Then
                            txtModuleName.Text = objDesktopModule.ModuleName
                            txtFolderName.Text = objDesktopModule.FolderName
                            txtFriendlyName.Text = objDesktopModule.FriendlyName
                            txtDescription.Text = objDesktopModule.Description
                            txtVersion.Text = objDesktopModule.Version
                            txtBusinessClass.Text = objDesktopModule.BusinessControllerClass
                            chkPremium.Checked = objDesktopModule.IsPremium
                        End If
                    End If

                    Dim objPortals As New PortalController
                    Dim arrPortals As ArrayList = objPortals.GetPortals
                    Dim arrPortalDesktopModules As ArrayList = objDesktopModules.GetPortalDesktopModules(Null.NullInteger, DesktopModuleId)

                    Dim objPortal As PortalInfo
                    Dim objPortalDesktopModule As PortalDesktopModuleInfo
                    For Each objPortalDesktopModule In arrPortalDesktopModules
                        For Each objPortal In arrPortals
                            If objPortal.PortalID = objPortalDesktopModule.PortalID Then
                                arrPortals.Remove(objPortal)
                                Exit For
                            End If
                        Next
                    Next

                    ctlPortals.Available = arrPortals
                    ctlPortals.Assigned = arrPortalDesktopModules
                    ctlPortals.Visible = chkPremium.Checked

                End If


            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdAddControl_Click runs when the Add Control Button is clicked
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/28/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdAddControl_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAddControl.Click

            Response.Redirect(FormatURL("modulecontrolid", "-1"))

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdAddDefinition_Click runs when the Add Definition Button is clicked
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/28/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdAddDefinition_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAddDefinition.Click

            Dim ModuleDefId As Integer = -1

            If txtDefinition.Text <> "" Then

                Dim objModuleDefinition As New ModuleDefinitionInfo

                objModuleDefinition.DesktopModuleID = DesktopModuleId
                objModuleDefinition.FriendlyName = txtDefinition.Text
                objModuleDefinition.DefaultCacheTime = Integer.Parse(txtCacheTime.Text)

                Dim objModuleDefinitions As New ModuleDefinitionController

                Try
                    ModuleDefId = objModuleDefinitions.AddModuleDefinition(objModuleDefinition)
                Catch
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("AddDefinition.ErrorMessage", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                    Exit Sub
                End Try

                LoadDefinitions()

                If ModuleDefId > -1 Then
                    'Set the Combo
                    cboDefinitions.SelectedIndex = -1
                    cboDefinitions.Items.FindByValue(ModuleDefId.ToString).Selected = True
                    LoadCacheProperties(ModuleDefId)
                    LoadControls(ModuleDefId)
                    'Clear the Text Box
                    txtDefinition.Text = ""
                End If
            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("MissingDefinition.ErrorMessage", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdCancel_Click runs when the Cancel Button is clicked
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/28/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cboDefinitions_SelectedIndexChanged runs when item in the Definitions combo is changed
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/28/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cboDefinitions_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboDefinitions.SelectedIndexChanged

            Dim ModuleDefId As Integer = Integer.Parse(cboDefinitions.SelectedItem.Value)
            LoadCacheProperties(ModuleDefId)
            LoadControls(ModuleDefId)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdDelete_Click runs when the Delete Button is clicked
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/28/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
            Try
                Dim strFileName As String
                Dim arrFiles As String()

                If Not Null.IsNull(DesktopModuleId) Then

                    Dim strRoot As String = Request.MapPath("~/DesktopModules/" & txtFolderName.Text) & "\"
                    Dim dirRoot As New DirectoryInfo(strRoot)
                    If dirRoot.Name <> txtFolderName.Text Then
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("Folder.ErrorMessage", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                        Exit Sub
                    End If

                    ' Check if module directory still exists, if not then simply delete DesktopModule from database
                    ' if we do that all data for the deleted module still exists in the db (the uninstall script will not run)!


                    If Directory.Exists(strRoot) Then

                        ' find dnn manifest file
                        arrFiles = Directory.GetFiles(strRoot, "*.dnn")
                        If arrFiles.Length <> 0 Then
                            If File.Exists(strRoot & Path.GetFileName(arrFiles(0))) Then
                                Dim xmlDoc As New XmlDocument
                                Dim nodeFile As XmlNode

                                ' load the manifest file
                                xmlDoc.Load(strRoot & Path.GetFileName(arrFiles(0)))

                                ' check version
                                Dim nodeModule As XmlNode
                                Select Case xmlDoc.DocumentElement.LocalName.ToLower()
                                    Case "module"
                                        nodeModule = xmlDoc.SelectSingleNode("//module")
                                    Case "dotnetnuke"
                                        ' V2 allows for multiple folders in a single DNN definition - we need to identify the correct node
                                        For Each nodeModule In xmlDoc.SelectNodes("//dotnetnuke/folders/folder")
                                            If nodeModule.SelectSingleNode("name").InnerText.Trim = txtFriendlyName.Text Then
                                                Exit For
                                            End If
                                        Next
                                End Select

                                ' loop through file nodes
                                For Each nodeFile In nodeModule.SelectNodes("files/file")
                                    strFileName = nodeFile.SelectSingleNode("name").InnerText.Trim
                                    ' if Module DLL file
                                    If Path.GetExtension(strFileName) = ".dll" Then
                                        ' remove DLL from /bin
                                        strFileName = Request.MapPath("~/bin/") & strFileName
                                        If File.Exists(strFileName) Then
                                            File.SetAttributes(strFileName, FileAttributes.Normal)
                                            File.Delete(strFileName)
                                        End If
                                    End If
                                Next
                            End If
                        End If

                        ' process uninstall script
                        Dim strProviderType As String = "data"
                        Dim objProviderConfiguration As Framework.Providers.ProviderConfiguration = Framework.Providers.ProviderConfiguration.GetProviderConfiguration(strProviderType)
                        Dim strUninstallScript As String = "Uninstall." & objProviderConfiguration.DefaultProvider
                        If File.Exists(strRoot & strUninstallScript) Then
                            ' read uninstall script
                            Dim objStreamReader As StreamReader
                            objStreamReader = File.OpenText(strRoot & strUninstallScript)
                            Dim strScript As String = objStreamReader.ReadToEnd
                            objStreamReader.Close()

                            ' execute uninstall script
                            PortalSettings.ExecuteScript(strScript)
                        End If

                        ' check for existence of project file ( this indicates a development environment )
                        arrFiles = Directory.GetFiles(strRoot, "*.??proj")
                        If arrFiles.Length = 0 Then
                            ' delete the module folder ( and subfolders )
                            'If Directory.Exists(strRoot) Then
                            '    DeleteFolderRecursive(strRoot)
                            'End If
                        End If

                    End If       'Directory.Exists(strRoot)

                    ' delete the desktopmodule database record
                    Dim objDesktopModules As New DesktopModuleController
                    objDesktopModules.DeleteDesktopModule(DesktopModuleId)

                End If

                Response.Redirect(NavigateURL(), True)

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdDeleteDefinition_Click runs when the Delete Definition Button is clicked
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/28/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdDeleteDefinition_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDeleteDefinition.Click

            Dim objModuleDefinitions As New ModuleDefinitionController

            objModuleDefinitions.DeleteModuleDefinition(Integer.Parse(cboDefinitions.SelectedItem.Value))

            LoadDefinitions()

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdUpdate_Click runs when the Update Button is clicked
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/28/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try

                If Page.IsValid = True Then

                    Dim objDesktopModule As New DesktopModuleInfo

                    objDesktopModule.DesktopModuleID = DesktopModuleId
                    objDesktopModule.ModuleName = txtModuleName.Text
                    objDesktopModule.FolderName = txtFolderName.Text
                    objDesktopModule.FriendlyName = txtFriendlyName.Text
                    If objDesktopModule.FolderName = "" Then
                        objDesktopModule.FolderName = objDesktopModule.ModuleName
                    End If
                    objDesktopModule.Description = txtDescription.Text
                    objDesktopModule.IsPremium = chkPremium.Checked
                    objDesktopModule.IsAdmin = False

                    If txtVersion.Text <> "" Then
                        objDesktopModule.Version = txtVersion.Text
                    Else
                        objDesktopModule.Version = Null.NullString
                    End If

                    Dim objDesktopModules As New DesktopModuleController

                    If Null.IsNull(DesktopModuleId) Then
                        Try
                            objDesktopModule.DesktopModuleID = objDesktopModules.AddDesktopModule(objDesktopModule)
                        Catch
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("AddModule.ErrorMessage", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
                            Exit Sub
                        End Try
                    Else
                        objDesktopModules.UpdateDesktopModule(objDesktopModule)
                    End If

                    ' delete old portal module assignments
                    objDesktopModules.DeletePortalDesktopModules(Null.NullInteger, objDesktopModule.DesktopModuleID)
                    ' add new portal module assignments
                    If objDesktopModule.IsPremium Then
                        Dim objListItem As ListItem
                        For Each objListItem In ctlPortals.Assigned
                            objDesktopModules.AddPortalDesktopModule(Integer.Parse(objListItem.Value), objDesktopModule.DesktopModuleID)
                        Next
                    End If

                    Response.Redirect(EditUrl("desktopmoduleid", objDesktopModule.DesktopModuleID.ToString), True)

                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdUpdateCacheTime_Click runs when the Update Cache Time Button is clicked
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	4/20/2005	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdUpdateCacheTime_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdUpdateCacheTime.Click

            Dim ModuleDefId As Integer = Integer.Parse(cboDefinitions.SelectedItem.Value)
            Dim objModuleDefinitions As New ModuleDefinitionController
            Dim objModuleDefinition As ModuleDefinitionInfo = objModuleDefinitions.GetModuleDefinition(ModuleDefId)

            Try
                objModuleDefinition.DefaultCacheTime = Integer.Parse(txtCacheTime.Text)
                objModuleDefinitions.UpdateModuleDefinition(objModuleDefinition)
            Catch ex As Exception
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Services.Localization.Localization.GetString("UpdateCache.ErrorMessage", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.RedError)
            End Try

        End Sub

        Private Sub chkPremium_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkPremium.CheckedChanged
            ctlPortals.Visible = chkPremium.Checked
        End Sub

#End Region

#Region "Optional Interfaces"
        Public ReadOnly Property ModuleActions() As ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
            Get

                Dim objDesktopModules As New DesktopModuleController
                Dim mid As Integer
                If Not (Request.QueryString("desktopmoduleid") Is Nothing) Then
                    mid = Int32.Parse(Request.QueryString("desktopmoduleid"))
                Else
                    mid = Null.NullInteger
                End If
                Dim objDesktopModule As DesktopModuleInfo = objDesktopModules.GetDesktopModule(mid)
                Dim Actions As New ModuleActionCollection
                If Not objDesktopModule Is Nothing Then
                    If Not objDesktopModule.IsAdmin Then
                        'Create the DirectoryInfo object for the folder
                        Dim folder As New DirectoryInfo(Common.Globals.ApplicationMapPath & "\DesktopModules\" & objDesktopModule.FolderName)
                        If folder.Exists Then
                            'Get the Project File(s) in the folder
                            Dim files As FileInfo() = folder.GetFiles("*.??proj")
                            If files.Length > 0 Then
                                'Add menu item to Actionmenu collectio
                                Actions.Add(GetNextActionID, Services.Localization.Localization.GetString("PrivateAssemblyCreate.Action", LocalResourceFile), ModuleActionType.AddContent, "", "", EditUrl("desktopmoduleid", mid.ToString, "package"), False, SecurityAccessLevel.Host, True, False)
                            End If
                        End If
                    End If
                End If
                Return Actions
            End Get
        End Property
#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
