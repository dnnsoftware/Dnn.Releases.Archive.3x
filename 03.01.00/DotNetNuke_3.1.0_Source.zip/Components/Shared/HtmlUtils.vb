'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Net
Imports DotNetNuke.Data
Imports DotNetNuke.Framework.Providers

Namespace DotNetNuke.Common.Utilities

    ''' -----------------------------------------------------------------------------
    ''' Namespace:  DotNetNuke.Common.Utilities
    ''' Project:    DotNetNuke
    ''' Class:      HtmlUtils
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' HtmlUtils is a Utility class that provides Html Utility methods
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    '''		[cnurse]	11/16/2004	documented
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class HtmlUtils

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Clean removes any HTML Tags, Entities (and optionally any punctuation) from
        ''' a string
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="HTML">The Html to clean</param>
        ''' <param name="RemovePunctuation">A flag indicating whether to remove punctuation</param>
        ''' <returns>The cleaned up string</returns>
        ''' <history>
        '''		[cnurse]	11/16/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function Clean(ByVal HTML As String, ByVal RemovePunctuation As Boolean) As String

            'First remove any HTML entities (&nbsp; &lt; etc)
            HTML = StripEntities(HTML, True)

            'Next remove any HTML Tags ("<....>")
            HTML = StripTags(HTML, True)

            'Finally remove any punctuation
            If RemovePunctuation Then
                HTML = StripPunctuation(HTML, True)
            End If

            Return HTML

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Shorten returns the first (x) characters of a string
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="txt">The text to reduces</param>
        ''' <param name="length">The max number of characters to return</param>
        ''' <param name="suffix">An optional suffic to append to the shortened string</param>
        ''' <returns>The shortened string</returns>
        ''' <history>
        '''		[cnurse]	11/16/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function Shorten(ByVal txt As String, ByVal length As Integer, ByVal suffix As String) As String
            Dim results As String
            If txt.Length > length Then
                results = txt.Substring(0, length) & suffix
            Else
                results = txt
            End If
            Return results
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' StripEntities removes the HTML Entities from the content
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="HTML">The HTML content to clean up</param>
        ''' <param name="RetainSpace">Indicates whether to replace the Entity by a space (true) or nothing (false)</param>
        ''' <returns>The cleaned up string</returns>
        ''' <history>
        '''		[cnurse]	11/16/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function StripEntities(ByVal HTML As String, ByVal RetainSpace As Boolean) As String

            'Set up Replacement String
            Dim RepString As String
            If RetainSpace Then
                RepString = " "
            Else
                RepString = ""
            End If

            'Replace Entities by replacement String and return mofified string
            Return System.Text.RegularExpressions.Regex.Replace(HTML, "&[^;]*;", RepString)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' StripTags removes the HTML Tags from the content
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="HTML">The HTML content to clean up</param>
        ''' <param name="RetainSpace">Indicates whether to replace the Tag by a space (true) or nothing (false)</param>
        ''' <returns>The cleaned up string</returns>
        ''' <history>
        '''		[cnurse]	11/16/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function StripTags(ByVal HTML As String, ByVal RetainSpace As Boolean) As String

            'Set up Replacement String
            Dim RepString As String
            If RetainSpace Then
                RepString = " "
            Else
                RepString = ""
            End If

            'Replace Tags by replacement String and return mofified string
            Return System.Text.RegularExpressions.Regex.Replace(HTML, "<[^>]*>", RepString)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' StripPunctuation removes the Punctuation from the content
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="HTML">The HTML content to clean up</param>
        ''' <param name="RetainSpace">Indicates whether to replace the Punctuation by a space (true) or nothing (false)</param>
        ''' <returns>The cleaned up string</returns>
        ''' <history>
        '''		[cnurse]	11/16/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function StripPunctuation(ByVal HTML As String, ByVal RetainSpace As Boolean) As String

            'Create Regular Expression objects
            Dim punctuationMatch As String = "[~!#\$%\^&*\(\)-+=\{\[\}\]\|;:\x22'<,>\.\?\\\t\r\v\f\n]"
            Dim afterRegEx As New System.Text.RegularExpressions.Regex(punctuationMatch & "\s")
            Dim beforeRegEx As New System.Text.RegularExpressions.Regex("\s" & punctuationMatch)

            'Define return string
            Dim retHTML As String = HTML & " "  'Make sure any punctuation at the end of the String is removed

            'Set up Replacement String
            Dim RepString As String
            If RetainSpace Then
                RepString = " "
            Else
                RepString = ""
            End If

            While beforeRegEx.IsMatch(retHTML)
                'Strip punctuation from beginning of word
                retHTML = beforeRegEx.Replace(retHTML, RepString)
            End While

            While afterRegEx.IsMatch(retHTML)
                'Strip punctuation from end of word
                retHTML = afterRegEx.Replace(retHTML, RepString)
            End While

            ' Return modified string
            Return retHTML
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' StripWhiteSpace removes the WhiteSpace from the content
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="HTML">The HTML content to clean up</param>
        ''' <param name="RetainSpace">Indicates whether to replace the WhiteSpace by a space (true) or nothing (false)</param>
        ''' <returns>The cleaned up string</returns>
        ''' <history>
        '''		[cnurse]	12/13/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function StripWhiteSpace(ByVal HTML As String, ByVal RetainSpace As Boolean) As String

            'Set up Replacement String
            Dim RepString As String
            If RetainSpace Then
                RepString = " "
            Else
                RepString = ""
            End If

            'Replace Tags by replacement String and return mofified string
            Return System.Text.RegularExpressions.Regex.Replace(HTML, "\s+", RepString)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' StripNonWord removes any Non-Word Character from the content
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="HTML">The HTML content to clean up</param>
        ''' <param name="RetainSpace">Indicates whether to replace the Non-Word Character by a space (true) or nothing (false)</param>
        ''' <returns>The cleaned up string</returns>
        ''' <history>
        '''		[cnurse]	1/28/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function StripNonWord(ByVal HTML As String, ByVal RetainSpace As Boolean) As String

            'Set up Replacement String
            Dim RepString As String
            If RetainSpace Then
                RepString = " "
            Else
                RepString = ""
            End If

            'Replace Tags by replacement String and return mofified string
            If HTML Is Nothing Then
                Return HTML
            Else
                Return System.Text.RegularExpressions.Regex.Replace(HTML, "\W*", RepString)
            End If
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' FormatText replaces <br> tags by LineFeed characters
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="HTML">The HTML content to clean up</param>
        ''' <returns>The cleaned up string</returns>
        ''' <history>
        '''		[cnurse]	12/13/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function FormatText(ByVal HTML As String, ByVal RetainSpace As Boolean) As String

            'Match all variants of <br> tag (<br>, <BR>, <br/>, including embedded space
            Dim brMatch As String = "\s*<\s*[bB][rR]\s*/\s*>\s*"

            'Set up Replacement String
            Dim RepString As String
            If RetainSpace Then
                RepString = " "
            Else
                RepString = ""
            End If

            'Replace Tags by replacement String and return mofified string
            Return System.Text.RegularExpressions.Regex.Replace(HTML, brMatch, ControlChars.Lf)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' WriteError outputs an Error Message during Install/Upgrade etc
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="response">The ASP.Net Response object</param>
        ''' <param name="file">The filename where the Error Occurred</param>
        ''' <param name="message">The error message</param>
        ''' <history>
        '''		[cnurse]	02/21/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub WriteError(ByVal response As HttpResponse, ByVal file As String, ByVal message As String)

            response.Write("<h2><u>Error Details</u></h2>")
            response.Write("<table cellspacing=0 cellpadding=0 border=0>")
            response.Write("<tr><td><b>File</b></td><td><b>" & file & "</b></td></tr>")
            response.Write("<tr><td><b>Error</b>&nbsp;&nbsp;</td><td><b>" & message & "</b></td></tr>")
            response.Write("</table>")
            response.Write("<br><br>")
            response.Flush()

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' WriteFeedback outputs a Feedback Line during Install/Upgrade etc
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="response">The ASP.Net Response object</param>
        ''' <param name="message">The feedback message</param>
        ''' <history>
        '''		[cnurse]	02/21/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub WriteFeedback(ByVal response As HttpResponse, ByVal indent As Int32, ByVal message As String)

            'Get the time of the feedback
            Dim timeElapsed As TimeSpan = Upgrade.Upgrade.RunTime

            Dim strMessage As String = timeElapsed.ToString.Substring(0, timeElapsed.ToString.LastIndexOf(".") + 4) & " -"
            For i As Integer = 0 To indent
                strMessage += "&nbsp;"
            Next
            strMessage += message
            HttpContext.Current.Response.Write(strMessage)
            HttpContext.Current.Response.Flush()

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' WriteFooter outputs the Footer during Install/Upgrade etc
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="response">The ASP.Net Response object</param>
        ''' <history>
        '''		[cnurse]	02/21/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub WriteFooter(ByVal response As HttpResponse)

            response.Write("</body>")
            response.Write("</html>")
            response.Flush()

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' WriteHeader outputs the Header during Install/Upgrade etc
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="response">The ASP.Net Response object</param>
        ''' <param name="mode">The mode Install/Upgrade etc</param>
        ''' <history>
        '''		[cnurse]	02/21/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub WriteHeader(ByVal response As HttpResponse, ByVal mode As String)
            'Set Response buffer to False
            response.Buffer = False
            response.Write("<html>")
            response.Write("<head>")
            Select Case mode
                Case "install"
                    response.Write("<title>DotNetNuke - Installation</title>")
                Case "upgrade"
                    response.Write("<title>DotNetNuke - Upgrade</title>")
                Case "addPortal"
                    response.Write("<title>DotNetNuke - Adding Portal(s)</title>")
                Case "installResources"
                    response.Write("<title>DotNetNuke - Installing Resources</title>")
                Case "executeScripts"
                    response.Write("<title>DotNetNuke - Executing Scripts</title>")
                Case "uninstall"
                    response.Write("<title>DotNetNuke - UnInstalling Module</title>")
                Case "none"
                    response.Write("<title>DotNetNuke - Database Not Compatible</title>")
                Case Else
                    response.Write("<title>" & mode & "</title>")
            End Select
            response.Write("<style>")
            response.Write("body {font-family:Verdana;font-weight:normal;font-size: .7em;color:white;} ")
            response.Write("p {font-family:Verdana;font-weight:normal;color:white;margin-top: -5px}")
            response.Write("b {font-family:Verdana;font-weight:bold;color:white;margin-top: -5px}")
            response.Write("H1 { font-family:Verdana;font-weight:normal;font-size:18pt;color:red }")
            response.Write("H2 { font-family:Verdana;font-weight:normal;font-size:14pt;color:red }")
            response.Write("</style>")
            response.Write("</head>")
            response.Write("<body bgcolor=""#000000"" BOTTOMMARGIN=""0"" LEFTMARGIN=""0"" TOPMARGIN=""0"" RIGHTMARGIN=""0"" MARGINWIDTH=""0"" MARGINHEIGHT=""0"">")

            response.Write("<table width=""100%"" cellpadding=""0"" cellspacing=""0"" border=""0"">")
            response.Write("<tr>")
            response.Write("<td width=""100%"" background=""install_left.jpg""></td>")
            response.Write("<td><img src=""install_right.jpg""></td>")
            response.Write("</tr>")
            response.Write("</table>")

            Select Case mode
                Case "install"
                    response.Write("<h1><u>Installing DotNetNuke</u></h1>")
                Case "upgrade"
                    response.Write("<h1><u>Upgrading DotNetNuke</u></h1>")
                Case "addPortal"
                    response.Write("<h1><u>Adding New Portal</u></h1>")
                Case "installResources"
                    response.Write("<h1><u>Installing Resources</u></h1>")
                Case "executeScripts"
                    response.Write("<h1><u>Executing Scripts</u></h1>")
                Case "uninstall"
                    response.Write("<h1><u>UnInstalling Module</u></h1>")
                Case "none"
                    response.Write("<h1><u>Database Not Compatible with current Application version</u></h1>")
                Case Else
                    response.Write("<h1><u>" & mode & "</u></h1>")
            End Select
            response.Flush()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' WriteSettings outputs the Settings during Install/Upgrade etc
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="response">The ASP.Net Response object</param>
        ''' <history>
        '''		[cnurse]	02/21/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub WriteSettings(ByVal response As HttpResponse)

            Dim _providerConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration("data")
            Dim _connectionString As String

            response.Write("<h2><u>Current Settings</u></h2>")
            response.Write("<table cellspacing=0 cellpadding=0 border=0>")
            response.Write("<tr><td><b>Default Provider</b></td><td><b>" & _providerConfiguration.DefaultProvider & "</b></td></tr>")
            If _providerConfiguration.DefaultProvider = "SqlDataProvider" Then
                Dim objProvider As Provider = CType(_providerConfiguration.Providers(_providerConfiguration.DefaultProvider), Provider)

                ' Read the attributes for this provider
                If objProvider.Attributes("connectionStringName") <> "" AndAlso _
                System.Configuration.ConfigurationSettings.AppSettings(objProvider.Attributes("connectionStringName")) <> "" Then
                    _connectionString = System.Configuration.ConfigurationSettings.AppSettings(objProvider.Attributes("connectionStringName"))
                Else
                    _connectionString = objProvider.Attributes("connectionString")
                End If
                _connectionString = _connectionString.Substring(0, _connectionString.LastIndexOf("=") + 1) & "****;"
                response.Write("<tr><td><b>Connection String</b></td><td><b>" & _connectionString & "</b></td></tr>")
            End If
            response.Write("<tr><td><b>.NET Framework Version</b>&nbsp;&nbsp;</td><td><b>" & System.Environment.Version.ToString & "</b></td></tr>")
            response.Write("<tr><td><b>Windows User</b></td><td><b>" & System.Security.Principal.WindowsIdentity.GetCurrent.Name & "</b></td></tr>")
            response.Write("<tr><td><b>Host Name</b></td><td><b>" & Dns.GetHostName() & "</b></td></tr>")

            response.Write("</table>")
            response.Flush()

        End Sub
    End Class
End Namespace