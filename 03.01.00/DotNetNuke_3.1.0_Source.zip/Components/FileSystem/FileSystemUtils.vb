'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports DotNetNuke.Services.FileSystem
Imports DotNetNuke.Services.Localization
Imports DotNetNuke.Security.Permissions
Imports ICSharpCode.SharpZipLib.Checksums
Imports ICSharpCode.SharpZipLib.Zip

Namespace DotNetNuke.Common.Utilities

    Public Class FileSystemUtils

#Region "Private Methods"

        Private Shared Function AddFile(ByVal strSourceFile As String, ByVal PortalId As Integer, ByVal HomeDirectory As String) As String

            UpdateFile(strSourceFile, strSourceFile, PortalId, HomeDirectory, False, True)

        End Function

        Private Shared Function AddFolder(ByVal PortalId As Integer, ByVal AdministratorRoleId As Integer, ByVal relativePath As String) As Integer

            Dim objFolderController As New DotNetNuke.Services.FileSystem.FolderController
            Dim FolderID As Integer = objFolderController.AddFolder(PortalId, relativePath)

            If PortalId <> Null.NullInteger Then
                SetFolderPermissions(PortalId, FolderID, AdministratorRoleId, relativePath)
            End If

            Return FolderID

        End Function

		Private Shared Sub SynchronizeFolder(ByVal PortalId As Integer, ByVal AdministratorRoleId As Integer, ByVal HomeDirectory As String, ByVal physicalPath As String, ByVal relativePath As String)

			Dim folder As String
			Dim fileName As String
			Dim FolderId As Integer

			If directory.Exists(physicalPath) Then
				'Add the folder
				FolderId = AddFolder(PortalId, AdministratorRoleId, relativePath)

				'Get Sub Folders (and synchronize recursively)
				Dim folders As String() = directory.GetDirectories(physicalPath)
				For Each folder In folders
					Dim directory As New DirectoryInfo(folder)
					Dim relPath As String
					If relativePath = "" Then
						relPath = directory.Name
					Else
						relPath = relativePath & "/" & directory.Name
					End If
					SynchronizeFolder(PortalId, AdministratorRoleId, HomeDirectory, folder, relPath)
				Next

				'Get Files in this Folder
				Dim files As String() = directory.GetFiles(physicalPath)
				For Each fileName In files
					'Add the File if it doesn't exist
					AddFile(fileName, PortalId, HomeDirectory)
				Next

			End If

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Updates a File
		''' </summary>
		''' <param name="strSourceFile">The original File Name</param>
		''' <param name="strDestFile">The new File Name</param>
		''' <param name="settings">The Portal Settings for the Portal/Host Account</param>
		''' <param name="isCopy">Flag determines whether file is to be be moved or copied</param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	12/2/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Shared Function UpdateFile(ByVal strSourceFile As String, ByVal strDestFile As String, ByVal PortalId As Integer, ByVal HomeDirectory As String, ByVal isCopy As Boolean, ByVal isNew As Boolean) As String

			Try
				Dim finfo As New System.IO.FileInfo(strSourceFile)
				Dim strFileName As String = System.IO.Path.GetFileName(strDestFile)
				Dim strExtension As String = Path.GetExtension(strFileName).Replace(".", "")
				Dim imgImage As System.Drawing.Image
				Dim imageWidth As Integer
				Dim imageHeight As Integer
				Dim strContentType As String
                Select Case strExtension.ToLower
                    Case "txt" : strContentType = "text/plain"
                    Case "htm", "html" : strContentType = "text/html"
                    Case "rtf" : strContentType = "text/richtext"
                    Case "jpg", "jpeg" : strContentType = "image/jpeg"
                    Case "gif" : strContentType = "image/gif"
                    Case "bmp" : strContentType = "image/bmp"
                    Case "mpg", "mpeg" : strContentType = "video/mpeg"
                    Case "avi" : strContentType = "video/avi"
                    Case "pdf" : strContentType = "application/pdf"
                    Case "doc", "dot" : strContentType = "application/msword"
                    Case "csv", "xls", "xlt" : strContentType = "application/x-msexcel"
                    Case Else : strContentType = "application/octet-stream"
                End Select

                If Convert.ToBoolean(InStr(1, glbImageFileTypes & ",", strExtension.ToLower & ",")) Then
                    Try
                        imgImage = imgImage.FromFile(strSourceFile)
                        imageHeight = imgImage.Height
                        imageWidth = imgImage.Width
                        imgImage.Dispose()
                    Catch
                        ' error loading image file
                        strContentType = "application/octet-stream"
                    End Try
                End If

                Dim SourceFolderName As String = strSourceFile.Replace(strFileName, "")
                SourceFolderName = SourceFolderName.Replace(HomeDirectory, "").Replace("\", "/")

                Dim DestFolderName As String = strDestFile.Replace(strFileName, "")
                DestFolderName = DestFolderName.Replace(HomeDirectory, "").Replace("\", "/")

                Dim objFileController As New DotNetNuke.Services.FileSystem.FileController
                If isCopy Then
                    'Copy file
                    finfo.CopyTo(strDestFile)
                    objFileController.AddFile(PortalId, strFileName, strExtension, finfo.Length, imageWidth, imageHeight, strContentType, DestFolderName)
                ElseIf isNew Then
                    'Add New file entry
                    objFileController.AddFile(PortalId, strFileName, strExtension, finfo.Length, imageWidth, imageHeight, strContentType, SourceFolderName)
                Else
                    'Update existing file
                    objFileController.UpdateFile(PortalId, strFileName, strExtension, finfo.Length, imageWidth, imageHeight, strContentType, SourceFolderName, DestFolderName)
                    finfo.MoveTo(strDestFile)
                End If

            Catch ex As Exception
				Return ex.Message
			End Try
		End Function

#End Region

#Region "Path Manipulation Methods"

        Public Shared Function AddTrailingSlash(ByVal strSource As String) As String
            If Not strSource.EndsWith("\") Then strSource = strSource & "\"
            Return strSource
        End Function

        Public Shared Function RemoveTrailingSlash(ByVal strSource As String) As String
            If strSource = "" Then Return ""
            If Mid(strSource, Len(strSource), 1) = "\" Then
                Return strSource.Substring(0, Len(strSource) - 1)
            Else
                Return strSource
            End If
        End Function

        Public Shared Function StripFolderPath(ByVal strOrigPath As String) As String
            If strOrigPath.IndexOf("\") <> -1 Then
                Return Replace(strOrigPath, "0\", "", 1, 1)
            Else
                Return Replace(strOrigPath, "0", "", 1, 1)
            End If
        End Function

#End Region

#Region "Public Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Adds a Folder
        ''' </summary>
        ''' <param name="settings">Portal Settings for the Portal</param>
        ''' <param name="parentFolder">The Parent Folder Name</param>
        ''' <param name="newFolder">The new Folder Name</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	12/4/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub AddFolder(ByVal _PortalSettings As PortalSettings, ByVal parentFolder As String, ByVal newFolder As String)

            Dim PortalId As Integer
            Dim ParentFolderName As String
            Dim dinfo As New System.IO.DirectoryInfo(parentFolder)
            Dim dinfoNew As System.IO.DirectoryInfo

            If _PortalSettings.ActiveTab.ParentId = _PortalSettings.SuperTabId Then
                PortalId = Null.NullInteger
                ParentFolderName = Common.Globals.HostMapPath
            Else
                PortalId = _PortalSettings.PortalId
                ParentFolderName = _PortalSettings.HomeDirectoryMapPath
            End If

            dinfoNew = New System.IO.DirectoryInfo(parentFolder & newFolder)
            If dinfoNew.Exists Then
                Throw New ArgumentException(Localization.GetString("EXCEPTION_DirectoryExists"))
            End If
            Dim strResult As String = dinfo.CreateSubdirectory(newFolder).FullName

            Dim FolderPath As String = ""
            FolderPath = strResult.Substring(ParentFolderName.Length).Replace("\", "/")

            'Persist in Database
            AddFolder(PortalId, _PortalSettings.AdministratorRoleId, FolderPath)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Copies a File
        ''' </summary>
        ''' <param name="strSourceFile">The original File Name</param>
        ''' <param name="strDestFile">The new File Name</param>
        ''' <param name="settings">The Portal Settings for the Portal/Host Account</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	12/2/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function CopyFile(ByVal strSourceFile As String, ByVal strDestFile As String, ByVal settings As PortalSettings) As String

            Return UpdateFile(strSourceFile, strDestFile, settings.PortalId, settings.HomeDirectoryMapPath, True, False)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Deletes a file
        ''' </summary>
        ''' <param name="strSourceFile">The File to delete</param>
        ''' <param name="settings">The Portal Settings for the Portal/Host Account</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Jon Henning]	11/1/2004	Created
        '''     [cnurse]        12/6/2004   delete file from db
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function DeleteFile(ByVal strSourceFile As String, ByVal settings As PortalSettings) As String
            Try
                Dim strFileName As String = System.IO.Path.GetFileName(strSourceFile)

                Dim RootFolderName As String
                Dim PortalId As Integer
                If settings.ActiveTab.ParentId = settings.SuperTabId Then
                    RootFolderName = Common.Globals.HostMapPath
                    PortalId = Null.NullInteger
                Else
                    RootFolderName = settings.HomeDirectoryMapPath
                    PortalId = settings.PortalId
                End If

                Dim SourceFolderName As String = strSourceFile.Replace(strFileName, "")
                SourceFolderName = SourceFolderName.Replace(RootFolderName, "").Replace("\", "/")

                'Delete file
                System.IO.File.Delete(strSourceFile)

                'Remove file from DataBase
                Dim objFileController As New DotNetNuke.Services.FileSystem.FileController
                objFileController.DeleteFile(PortalId, strFileName, SourceFolderName)

            Catch ex As Exception
                Return ex.Message
            End Try
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Deletes a folder
        ''' </summary>
        ''' <param name="PortalId">The Id of the Portal</param>
        ''' <param name="folder">The Directory Info object to delete</param>
        ''' <param name="folderName">The Name of the folder relative to the Root of the Portal</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	12/4/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub DeleteFolder(ByVal PortalId As Integer, ByVal folder As System.IO.DirectoryInfo, ByVal folderName As String)

            'Delete Folder
            folder.Delete(False)

            'Remove Folder from DataBase
            Dim objFolderController As New DotNetNuke.Services.FileSystem.FolderController
            objFolderController.DeleteFolder(PortalId, folderName.Replace("\", "/"))

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Moved directly from FileManager code, probably should make extension lookup more generic
        ''' </summary>
        ''' <param name="FileLoc">File Location</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Jon Henning]	11/1/2004	Created
        ''' 	[Jon Henning]	1/4/2005	Fixed extension comparison, added content length header - DNN-386
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub DownloadFile(ByVal FileLoc As String)
            Dim objFile As New System.IO.FileInfo(FileLoc)
            Dim objResponse As System.Web.HttpResponse = System.Web.HttpContext.Current.Response
            If objFile.Exists Then
                objResponse.ClearContent()
                objResponse.ClearHeaders()
                objResponse.AppendHeader("content-disposition", "attachment; filename=" + objFile.Name.ToString)
                objResponse.AppendHeader("Content-Length", objFile.Length.ToString())

                Dim strContentType As String
                Select Case objFile.Extension
                    Case ".txt" : strContentType = "text/plain"
                    Case ".htm", ".html" : strContentType = "text/html"
                    Case ".rtf" : strContentType = "text/richtext"
                    Case ".jpg", ".jpeg" : strContentType = "image/jpeg"
                    Case ".gif" : strContentType = "image/gif"
                    Case ".bmp" : strContentType = "image/bmp"
                    Case ".mpg", ".mpeg" : strContentType = "video/mpeg"
                    Case ".avi" : strContentType = "video/avi"
                    Case ".pdf" : strContentType = "application/pdf"
                    Case ".doc", ".dot" : strContentType = "application/msword"
                    Case ".csv", ".xls", ".xlt" : strContentType = "application/vnd.msexcel"
                    Case Else : strContentType = "application/octet-stream"
                End Select
                objResponse.ContentType = strContentType
                'objResponse.WriteFile(objFile.FullName)
                WriteFile(objFile.FullName)

                objResponse.Flush()
                objResponse.Close()
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Writes file to response stream.  Workaround offered by MS for large files
        ''' http://support.microsoft.com/default.aspx?scid=kb;EN-US;812406
        ''' </summary>
        ''' <param name="strFileName">FileName</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Jon Henning]	1/4/2005	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub WriteFile(ByVal strFileName As String)
            Dim objResponse As System.Web.HttpResponse = System.Web.HttpContext.Current.Response
            Dim objStream As System.IO.Stream

            ' Buffer to read 10K bytes in chunk:
            Dim bytBuffer(10000) As Byte

            ' Length of the file:
            Dim intLength As Integer

            ' Total bytes to read:
            Dim lngDataToRead As Long

            Try
                ' Open the file.
                objStream = New System.IO.FileStream(strFileName, System.IO.FileMode.Open, IO.FileAccess.Read, IO.FileShare.Read)

                ' Total bytes to read:
                lngDataToRead = objStream.Length

                objResponse.ContentType = "application/octet-stream"

                ' Read the bytes.
                While lngDataToRead > 0
                    ' Verify that the client is connected.
                    If objResponse.IsClientConnected Then
                        ' Read the data in buffer
                        intLength = objStream.Read(bytBuffer, 0, 10000)

                        ' Write the data to the current output stream.
                        objResponse.OutputStream.Write(bytBuffer, 0, intLength)

                        ' Flush the data to the HTML output.
                        objResponse.Flush()

                        ReDim bytBuffer(10000)       ' Clear the buffer
                        lngDataToRead = lngDataToRead - intLength
                    Else
                        'prevent infinite loop if user disconnects
                        lngDataToRead = -1
                    End If
                End While

            Catch ex As Exception
                ' Trap the error, if any.
                objResponse.Write("Error : " & ex.Message)
            Finally
                If IsNothing(objStream) = False Then
                    ' Close the file.
                    objStream.Close()
                End If
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Roles that have a particualr Permission for a Folder
        ''' </summary>
        ''' <param name="Folder">The Folder</param>
        ''' <param name="PortalId">The Id of the Portal</param>
        ''' <param name="Permission">The Permissions to find</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetRoles(ByVal Folder As String, ByVal PortalId As Integer, ByVal Permission As String) As String

            Dim Roles As New System.Text.StringBuilder
            Dim objFolderPermissionController As New DotNetNuke.Security.Permissions.FolderPermissionController

            Dim objCurrentFolderPermissions As DotNetNuke.Security.Permissions.FolderPermissionCollection
            objCurrentFolderPermissions = objFolderPermissionController.GetFolderPermissionsCollectionByFolderPath(PortalId, Folder)
            Dim objFolderPermission As DotNetNuke.Security.Permissions.FolderPermissionInfo
            For Each objFolderPermission In objCurrentFolderPermissions
                If objFolderPermission.AllowAccess And objFolderPermission.PermissionKey = Permission Then
                    Roles.Append(objFolderPermission.RoleName)
                    Roles.Append(";")
                End If
            Next
            Return Roles.ToString
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Moves (Renames) a File
        ''' </summary>
        ''' <param name="strSourceFile">The original File Name</param>
        ''' <param name="strDestFile">The new File Name</param>
        ''' <param name="settings">The Portal Settings for the Portal/Host Account</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	12/2/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function MoveFile(ByVal strSourceFile As String, ByVal strDestFile As String, ByVal settings As PortalSettings) As String

            Return UpdateFile(strSourceFile, strDestFile, settings.PortalId, settings.HomeDirectoryMapPath, False, False)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Assigns 1 or more attributes to a file
        ''' </summary>
        ''' <param name="FileLoc">File Location</param>
        ''' <param name="FileAttributesOn">Pass in Attributes you wish to switch on (i.e. FileAttributes.Hidden + FileAttributes.ReadOnly)</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Jon Henning]	11/1/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub SetFileAttributes(ByVal FileLoc As String, ByVal FileAttributesOn As Integer)
            System.IO.File.SetAttributes(FileLoc, CType(FileAttributesOn, FileAttributes))
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Sets a Folders Permissions
        ''' </summary>
        ''' <param name="PortalId">The Id of the Portal</param>
        ''' <param name="FolderId">The Id of the Folder</param>
        ''' <param name="AdministratorRoleId">The Id of the Administrator Role</param>
        ''' <param name="relativePath">The folder's Relative Path</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	12/4/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub SetFolderPermissions(ByVal PortalId As Integer, ByVal FolderId As Integer, ByVal AdministratorRoleId As Integer, ByVal relativePath As String)

            'Set Permissions
            Dim objPermissionController As New PermissionController
            Dim Permissions As ArrayList = objPermissionController.GetPermissionsByFolder(PortalId, "")
            Dim objPermssionsInfo As PermissionInfo
            Dim objFolderPermissionController As New DotNetNuke.Security.Permissions.FolderPermissionController
            For Each objPermssionsInfo In Permissions
                SetFolderPermission(PortalId, FolderId, objPermssionsInfo.PermissionID, AdministratorRoleId, relativePath)
            Next

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Sets a Folder Permission
        ''' </summary>
        ''' <param name="PortalId">The Id of the Portal</param>
        ''' <param name="FolderId">The Id of the Folder</param>
        ''' <param name="PermissionId">The Id of the Permission</param>
        ''' <param name="RoleId">The Id of the Role</param>
        ''' <param name="relativePath">The folder's Relative Path</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	01/12/2005	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub SetFolderPermission(ByVal PortalId As Integer, ByVal FolderId As Integer, ByVal PermissionId As Integer, ByVal RoleId As Integer, ByVal relativePath As String)

            Dim objFolderPermissionController As New FolderPermissionController
            Dim objCurrentFolderPermissions As FolderPermissionCollection
            Dim objFolderPermissionInfo As New FolderPermissionInfo
            objCurrentFolderPermissions = objFolderPermissionController.GetFolderPermissionsCollectionByFolderPath(PortalId, relativePath)

            'Iterate current permissions to see if permisison has already been added
            For Each objFolderPermissionInfo In objCurrentFolderPermissions
                If objFolderPermissionInfo.FolderID = FolderId And _
                    objFolderPermissionInfo.PermissionID = PermissionId And _
                    objFolderPermissionInfo.RoleID = RoleId And _
                    objFolderPermissionInfo.AllowAccess = True Then

                    Exit Sub
                End If
            Next

            'Permission not found so Add
            objFolderPermissionInfo = CType(CBO.InitializeObject(objFolderPermissionInfo, GetType(FolderPermissionInfo)), FolderPermissionInfo)
            objFolderPermissionInfo.FolderID = FolderId
            objFolderPermissionInfo.PermissionID = PermissionId
            objFolderPermissionInfo.RoleID = RoleId
            objFolderPermissionInfo.AllowAccess = True
            objFolderPermissionController.AddFolderPermission(objFolderPermissionInfo)
        End Sub

        Public Shared Sub Synchronize(ByVal PortalId As Integer, ByVal AdministratorRoleId As Integer, ByVal HomeDirectory As String)

            Dim PhysicalRoot As String = HomeDirectory
            Dim VirtualRoot As String = ""

            'Call Synchronize Folder that recursively parses the subfolders
            SynchronizeFolder(PortalId, AdministratorRoleId, HomeDirectory, PhysicalRoot, VirtualRoot)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Unzips a File
        ''' </summary>
        ''' <param name="FileLoc">The zip File Name</param>
        ''' <param name="DestFolder">The folder where the file is extracted to</param>
        ''' <param name="settings">The Portal Settings for the Portal/Host Account</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function UnzipFile(ByVal FileLoc As String, ByVal DestFolder As String, ByVal settings As PortalSettings) As String

            Dim strMessage As String = ""
            Dim objPortalController As New PortalController
            Dim objZipEntry As ZipEntry
            Dim strFileName As String
            Dim strExtension As String
            Dim objZipInputStream As ZipInputStream
            Try
                objZipInputStream = New ZipInputStream(File.OpenRead(FileLoc))
            Catch ex As Exception
                Return ex.Message
            End Try

            objZipEntry = objZipInputStream.GetNextEntry
            While Not objZipEntry Is Nothing
                If objZipEntry.IsDirectory Then
                    Try
                        AddFolder(settings, DestFolder, objZipEntry.Name)
                    Catch ex As Exception
                        objZipInputStream.Close()
                        Return ex.Message
                    End Try
                End If
                objZipEntry = objZipInputStream.GetNextEntry
            End While

            objZipInputStream = New ZipInputStream(File.OpenRead(FileLoc))
            objZipEntry = objZipInputStream.GetNextEntry
            While Not objZipEntry Is Nothing
                If Not objZipEntry.IsDirectory Then
                    If ((((objPortalController.GetPortalSpaceUsed(settings.PortalId) + objZipEntry.Size) / 1000000) <= settings.HostSpace) Or settings.HostSpace = 0) Or (settings.ActiveTab.ParentId = settings.SuperTabId) Then
                        strFileName = Path.GetFileName(objZipEntry.Name)

                        If strFileName <> "" Then
                            strExtension = Path.GetExtension(strFileName).Replace(".", "")
                            If InStr(1, "," & settings.HostSettings("FileExtensions").ToString.ToLower, "," & strExtension.ToLower) <> 0 Or settings.ActiveTab.ParentId = settings.SuperTabId Then
                                Try
                                    Dim folderPath As String = System.IO.Path.GetDirectoryName(DestFolder & Replace(objZipEntry.Name, "/", "\"))
                                    Dim Dinfo As New DirectoryInfo(folderPath)
                                    If Not Dinfo.Exists Then
                                        AddFolder(settings, DestFolder, objZipEntry.Name.Substring(0, Replace(objZipEntry.Name, "/", "\").LastIndexOf("\")))
                                    End If
                                    Dim objFileStream As FileStream
                                    Try
                                        objFileStream = File.Create(DestFolder & Replace(objZipEntry.Name, "/", "\"))
                                    Catch ex As Exception
                                        If Not objFileStream Is Nothing Then
                                            objFileStream.Close()
                                        End If
                                        Return ex.Message
                                    End Try

                                    Dim intSize As Integer = 2048
                                    Dim arrData(2048) As Byte

                                    intSize = objZipInputStream.Read(arrData, 0, arrData.Length)
                                    While intSize > 0
                                        objFileStream.Write(arrData, 0, intSize)
                                        intSize = objZipInputStream.Read(arrData, 0, arrData.Length)
                                    End While

                                    objFileStream.Close()
                                    AddFile(DestFolder & Replace(objZipEntry.Name, "/", "\"), settings.PortalId, settings.HomeDirectoryMapPath)

                                Catch ex As Exception
                                    If Not objZipInputStream Is Nothing Then
                                        objZipInputStream.Close()
                                    End If
                                    Return ex.Message
                                End Try
                            Else
                                ' restricted file type
                                strMessage += "<br>" & String.Format(Localization.GetString("RestrictedFileType"), strFileName, Replace(settings.HostSettings("FileExtensions").ToString, ",", ", *."))
                            End If
                        End If
                    Else    ' file too large
                        strMessage += "<br>" & String.Format(Localization.GetString("DiskSpaceExceeded"), strFileName)
                    End If

                End If

                objZipEntry = objZipInputStream.GetNextEntry
            End While

            objZipInputStream.Close()

            Return strMessage

        End Function

        Public Shared Sub SaveFile(ByVal FullFileName As String, ByVal Buffer As Byte())
            If System.IO.File.Exists(FullFileName) Then
                System.IO.File.SetAttributes(FullFileName, FileAttributes.Normal)
            End If
            Dim fs As New FileStream(FullFileName, FileMode.Create, FileAccess.Write)
            fs.Write(Buffer, 0, Buffer.Length)
            fs.Close()
        End Sub

        Public Shared Sub UnzipResources(ByVal zipStream As ZipInputStream, ByVal destPath As String)
            Dim objZipEntry As ZipEntry
            Dim LocalFileName, RelativeDir, FileNamePath As String

            objZipEntry = zipStream.GetNextEntry
            While Not objZipEntry Is Nothing
                ' This gets the Zipped FileName (including the path)
                LocalFileName = objZipEntry.Name

                ' This creates the necessary directories if they don't 
                ' already exist.
                RelativeDir = Path.GetDirectoryName(objZipEntry.Name)
                If (RelativeDir <> String.Empty) AndAlso (Not Directory.Exists(Path.Combine(destPath, RelativeDir))) Then
                    Directory.CreateDirectory(Path.Combine(destPath, RelativeDir))
                End If

                ' This block creates the file using buffered reads from the zipfile
                If (Not objZipEntry.IsDirectory) AndAlso (LocalFileName <> "") Then
                    FileNamePath = Path.Combine(destPath, LocalFileName).Replace("/", "\")

                    Try
                        ' delete the file if it already exists
                        If File.Exists(FileNamePath) Then
                            File.SetAttributes(FileNamePath, FileAttributes.Normal)
                            File.Delete(FileNamePath)
                        End If

                        ' create the file
                        Dim objFileStream As FileStream = File.Create(FileNamePath)

                        Dim intSize As Integer = 2048
                        Dim arrData(2048) As Byte

                        intSize = zipStream.Read(arrData, 0, arrData.Length)
                        While intSize > 0
                            objFileStream.Write(arrData, 0, intSize)
                            intSize = zipStream.Read(arrData, 0, arrData.Length)
                        End While

                        objFileStream.Close()
                    Catch
                        ' an error occurred saving a file in the resource file
                    End Try

                End If

                objZipEntry = zipStream.GetNextEntry
            End While
            If Not zipStream Is Nothing Then
                zipStream.Close()
            End If


        End Sub

        Public Shared Sub AddToZip(ByRef ZipFile As ZipOutputStream, ByVal filePath As String, ByVal fileName As String, ByVal folder As String)
            Dim crc As Crc32 = New Crc32

            'Open File Stream
            Dim fs As FileStream = File.OpenRead(filePath)

            'Read file into byte array buffer
            Dim buffer As Byte()
            ReDim buffer(Convert.ToInt32(fs.Length) - 1)
            fs.Read(buffer, 0, buffer.Length)

            'Create Zip Entry
            Dim entry As ZipEntry = New ZipEntry(folder & fileName)
            entry.DateTime = DateTime.Now
            entry.Size = fs.Length
            fs.Close()
            crc.Reset()
            crc.Update(buffer)
            entry.Crc = crc.Value

            'Compress file and add to Zip file
            ZipFile.PutNextEntry(entry)
            ZipFile.Write(buffer, 0, buffer.Length)

        End Sub

#End Region

    End Class

End Namespace
