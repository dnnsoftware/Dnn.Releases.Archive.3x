'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke.Entities.Users

	Public Class UserProfile
		Private _FirstName As String
		Private _LastName As String
		Private _Street As String
		Private _City As String
		Private _Region As String
		Private _PostalCode As String
		Private _Country As String
		Private _Unit As String
		Private _Telephone As String
		Private _Cell As String
		Private _Fax As String
		Private _Website As String
		Private _IM As String
		Private _TimeZone As Integer
        Private _PreferredLocale As String
        Private _ObjectHydrated As Boolean

        Public Sub New()
        End Sub


        Public Property FirstName() As String
            Get
                Return _FirstName
            End Get
            Set(ByVal Value As String)
                _FirstName = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property LastName() As String
            Get
                Return _LastName
            End Get
            Set(ByVal Value As String)
                _LastName = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public ReadOnly Property FullName() As String
            Get
                Return _FirstName & " " & _LastName
            End Get
        End Property
        Public Property Street() As String
            Get
                Return _Street
            End Get
            Set(ByVal Value As String)
                _Street = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property City() As String
            Get
                Return _City
            End Get
            Set(ByVal Value As String)
                _City = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property Region() As String
            Get
                Return _Region
            End Get
            Set(ByVal Value As String)
                _Region = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property PostalCode() As String
            Get
                Return _PostalCode
            End Get
            Set(ByVal Value As String)
                _PostalCode = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property Country() As String
            Get
                Return _Country
            End Get
            Set(ByVal Value As String)
                _Country = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property Unit() As String
            Get
                Return _Unit
            End Get
            Set(ByVal Value As String)
                _Unit = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property Telephone() As String
            Get
                Return _Telephone
            End Get
            Set(ByVal Value As String)
                _Telephone = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property Cell() As String
            Get
                Return _Cell
            End Get
            Set(ByVal Value As String)
                _Cell = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property Fax() As String
            Get
                Return _Fax
            End Get
            Set(ByVal Value As String)
                _Fax = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property IM() As String
            Get
                Return _IM
            End Get
            Set(ByVal Value As String)
                _IM = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property Website() As String
            Get
                Return _Website
            End Get
            Set(ByVal Value As String)
                _Website = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property TimeZone() As Integer
            Get
                Return _TimeZone
            End Get
            Set(ByVal Value As Integer)
                _TimeZone = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property PreferredLocale() As String
            Get
                Return _PreferredLocale
            End Get
            Set(ByVal Value As String)
                _PreferredLocale = Value
                If Not ObjectHydrated Then
                    ObjectHydrated = True
                End If
            End Set
        End Property
        Public Property ObjectHydrated() As Boolean
            Get
                Return _ObjectHydrated
            End Get
            Set(ByVal Value As Boolean)
                _ObjectHydrated = Value
            End Set
        End Property
    End Class

End Namespace
