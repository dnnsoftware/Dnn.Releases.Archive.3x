'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Drawing
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO
Imports System.Collections
Imports System.Data
Imports DotNetNuke.Security.Roles
Imports DotNetNuke.Services.Localization

Namespace DotNetNuke.Security.Permissions.Controls

    Public Class ModulePermissionsGrid
        Inherits PermissionsGrid

        Private _roles As ArrayList
        Private _Permissions As ArrayList
        Private _ModulePermissions As ModulePermissionCollection
        Private _InheritViewPermissionsFromTab As Boolean = False
        Private _ViewColumnIndex As Integer

        Private _ModuleID As Integer = -1

        Public Property ModuleID() As Integer
            Get
                If _ModuleID <> -1 Then
                    Return _ModuleID
                Else
                    Return Convert.ToInt32(ViewState("ModuleID"))
                End If
            End Get
            Set(ByVal Value As Integer)
                _ModuleID = Value
                ViewState("ModuleID") = Value
            End Set
        End Property

        Public Property InheritViewPermissionsFromTab() As Boolean
            Get
                If Not ViewState("InheritViewPermissionsFromTab") Is Nothing Then
                    Return Convert.ToBoolean(ViewState("InheritViewPermissionsFromTab"))
                Else
                    Return _InheritViewPermissionsFromTab
                End If
            End Get
            Set(ByVal Value As Boolean)
                _InheritViewPermissionsFromTab = Value
                ViewState("InheritViewPermissionsFromTab") = Value
                If Value = True Then
                    Dim i As Integer
                    For i = 0 To Items.Count - 1
                        Dim chk As CheckBox = CType(Me.Items(i).Cells(_ViewColumnIndex).Controls(0), CheckBox)
                        'If chk.ID.tolower.IndexOf("administrators") > 0 Then
                        '    chk.Checked = False
                        'End If
                        chk.Checked = False
                        chk.Enabled = False
                    Next
                Else
                    Dim i As Integer
                    For i = 0 To Items.Count - 1
                        Dim chk As CheckBox = CType(Me.Items(i).Cells(_ViewColumnIndex).Controls(0), CheckBox)
                        Dim Settings As String() = Split(chk.ID, "|")
                        If Integer.Parse(Settings(4)) = PortalController.GetCurrentPortalSettings.AdministratorRoleId Then
                            chk.Checked = True
                        Else
                            chk.Enabled = True
                        End If
                    Next
                End If
            End Set
        End Property

        Public ReadOnly Property Permissions() As Security.Permissions.ModulePermissionCollection
            Get
                Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
                Dim arrModulePermissions As New Security.Permissions.ModulePermissionCollection
                Dim objRoleController As New RoleController

                Dim objModulePermissionController As New Security.Permissions.ModulePermissionController

                Dim objModulePermission As Security.Permissions.ModulePermissionInfo
                Dim dgi As DataGridItem
                For Each dgi In Items
                    Dim i As Integer
                    For i = 1 To dgi.Cells.Count - 1
                        'all except first cell which is role names
                        If dgi.Cells(i).Controls.Count > 0 Then
                            Dim cb As CheckBox = CType(dgi.Cells(i).Controls(0), CheckBox)
                            If cb.Checked Then
                                Dim Settings As String() = Split(cb.ID, "|")

                                If Settings(2) = "" Then
                                    objModulePermission = New Security.Permissions.ModulePermissionInfo
                                    objModulePermission.ModulePermissionID = -1
                                Else
                                    objModulePermission = objModulePermissionController.GetModulePermission(Convert.ToInt32(Settings(2)))
                                End If
                                objModulePermission.PermissionID = Convert.ToInt32(Settings(1))
                                Dim objRoleInfo As Security.Roles.RoleInfo
                                Select Case Settings(3)
                                    Case glbRoleAllUsersName
                                        objRoleInfo = New Security.Roles.RoleInfo
                                        objRoleInfo.RoleID = Convert.ToInt32(glbRoleAllUsers)
                                        objRoleInfo.RoleName = glbRoleAllUsersName
                                        objRoleInfo.PortalID = _portalSettings.PortalId
                                    Case Common.Globals.glbRoleUnauthUserName
                                        objRoleInfo = New Security.Roles.RoleInfo
                                        objRoleInfo.RoleID = Convert.ToInt32(glbRoleUnauthUser)
                                        objRoleInfo.RoleName = glbRoleUnauthUserName
                                        objRoleInfo.PortalID = _portalSettings.PortalId
                                    Case Else
                                        objRoleInfo = objRoleController.GetRoleByName(_portalSettings.PortalId, Settings(3))
                                End Select

                                objModulePermission.RoleID = objRoleInfo.RoleID
                                'If cb.Checked Then
                                objModulePermission.AllowAccess = True
                                'Else
                                'objModulePermission.AllowAccess = False
                                'End If

                                objModulePermission.ModuleID = ModuleID
                                arrModulePermissions.Add(objModulePermission)
                            End If
                        End If
                    Next
                Next
                Return arrModulePermissions
            End Get
        End Property

        Public Overrides Sub GenerateDataGrid()
            If ModuleID = -1 Then
                ModuleID = Convert.ToInt32(viewstate("ModuleID"))
            End If
            SetPermissions()

            Dim textCol As New BoundColumn
            textCol.HeaderText = ""
            textCol.DataField = "Roles"
            Columns.Add(textCol)

            Dim checkCol As Controls.CheckBoxColumn
            Dim i As Integer
            For i = 0 To _Permissions.Count - 1
                Dim objPermission As Security.Permissions.PermissionInfo
                objPermission = CType(_Permissions(i), Security.Permissions.PermissionInfo)
                checkCol = New Controls.CheckBoxColumn
                Dim locName As String = Services.Localization.Localization.GetString(objPermission.PermissionName + ".Permission", Services.Localization.Localization.GlobalResourceFile)
                checkCol.HeaderText = IIf(locName <> "", locName, objPermission.PermissionName).ToString
                checkCol.DataField = objPermission.PermissionName
                Columns.Add(checkCol)
            Next
            DataSource = GetPermissionsDataTable()
            DataBind()
            Me.DynamicColumnAdded = True

        End Sub

        Private Function GetPermissionsDataTable() As DataTable
            Dim dt As New DataTable
            Dim col As DataColumn

            Dim InheritViewPermissions As Boolean = False
            col = New DataColumn("Roles")
            dt.Columns.Add(col)
            Dim i As Integer
            For i = 0 To _Permissions.Count - 1
                Dim objPerm As Security.Permissions.PermissionInfo
                objPerm = CType(_Permissions(i), Security.Permissions.PermissionInfo)
                col = New DataColumn(objPerm.PermissionName)
                If objPerm.PermissionKey = "VIEW" Then
                    _ViewColumnIndex = i + 1
                End If
                dt.Columns.Add(col)
            Next

            Dim row As DataRow
            row = dt.NewRow


            For i = 0 To _roles.Count - 1
                Dim role As RoleInfo = DirectCast(_roles(i), RoleInfo)
                row = dt.NewRow
                row(0) = Localization.LocalizeRole(role.RoleName)

                Dim j As Integer
                For j = 0 To _Permissions.Count - 1
                    Dim objPerm As Security.Permissions.PermissionInfo
                    objPerm = CType(_Permissions(j), Security.Permissions.PermissionInfo)
                    Dim key As String
                    Dim CheckBoxEnabled As String = "Y"
                    Dim objModulePermission As Security.Permissions.ModulePermissionInfo = ModuleHasPermission(objPerm.PermissionID, _ModulePermissions, role.RoleName)
                    If Not objModulePermission Is Nothing Then
                        If role.RoleID = PortalController.GetCurrentPortalSettings.AdministratorRoleId Then
                            CheckBoxEnabled = "N"
                        End If
                        key = "|" + Convert.ToString(objPerm.PermissionID) + "|" + Convert.ToString(objModulePermission.ModulePermissionID) + "|" + role.RoleName + "|" + role.RoleID.ToString + "|" + CheckBoxEnabled
                        If (objModulePermission.AllowAccess Or CheckBoxEnabled = "N") Then
                            row(j + 1) = "True" + key
                        Else
                            row(j + 1) = "False" + key
                        End If
                    Else
                        If role.RoleID = PortalController.GetCurrentPortalSettings.AdministratorRoleId Then
                            CheckBoxEnabled = "N"
                        End If
                        key = "|" + Convert.ToString(objPerm.PermissionID) + "||" + role.RoleName + "|" + role.RoleID.ToString + "|" + CheckBoxEnabled
                        row(j + 1) = "False" + key
                    End If
                Next
                dt.Rows.Add(row)
            Next
            Return dt
        End Function

        Private Function ModuleHasPermission(ByVal PermissionID As Integer, ByVal colModulePermissions As ModulePermissionCollection, ByVal RoleName As String) As Security.Permissions.ModulePermissionInfo
            Dim i As Integer
            For i = 0 To colModulePermissions.Count - 1
                Dim objModulePermission As Security.Permissions.ModulePermissionInfo = colModulePermissions(i)
                If objModulePermission.RoleName = RoleName And PermissionID = objModulePermission.PermissionID Then
                    Return objModulePermission
                End If
            Next
            Return Nothing
        End Function

        Private Sub SetPermissions()
            Dim objRoleController As New RoleController
            _roles = objRoleController.GetPortalRoles(PortalController.GetCurrentPortalSettings.PortalId)

            Dim r As New RoleInfo
            r.RoleID = Integer.Parse(glbRoleUnauthUser)
            r.RoleName = glbRoleUnauthUserName
            _roles.Add(r)
            r = New RoleInfo
            r.RoleID = Integer.Parse(glbRoleAllUsers)
            r.RoleName = glbRoleAllUsersName
            _roles.Add(r)
            _roles.Reverse()
            _roles.Sort(New RoleComparer)

            Dim objModulePermissionController As New Security.Permissions.ModulePermissionController
            _ModulePermissions = objModulePermissionController.GetModulePermissionsCollectionByModuleID(Me.ModuleID)
            Dim objPermissionController As New Security.Permissions.PermissionController
            _Permissions = objPermissionController.GetPermissionsByModuleID(Me.ModuleID)

        End Sub

    End Class


End Namespace