'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Drawing
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO
Imports System.Collections
Imports System.Data
Imports DotNetNuke.Security.Roles
Imports DotNetNuke.Services.Localization

Namespace DotNetNuke.Security.Permissions.Controls

    Public Class TabPermissionsGrid
        Inherits PermissionsGrid

        Private _roles As ArrayList
        Private _Permissions As ArrayList
        Private _TabPermissions As ArrayList

        Private _TabID As Integer = -1

        Public Property TabID() As Integer
            Get
                If _TabID <> -1 Then
                    Return _TabID
                Else
                    Return Convert.ToInt32(ViewState("TabID"))
                End If
            End Get
            Set(ByVal Value As Integer)
                _TabID = Value
                ViewState("TabID") = Value
            End Set
        End Property

        Public ReadOnly Property Permissions() As Security.Permissions.TabPermissionCollection
            Get
                Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
                Dim arrTabPermissions As New Security.Permissions.TabPermissionCollection
                Dim objRoleController As New RoleController

                Dim objTabPermission As Security.Permissions.TabPermissionInfo
                Dim dgi As DataGridItem
                For Each dgi In Items
                    Dim i As Integer
                    For i = 1 To dgi.Cells.Count - 1
                        'all except first cell which is role names
                        If dgi.Cells(i).Controls.Count > 0 Then
                            objTabPermission = New Security.Permissions.TabPermissionInfo
                            Dim cb As CheckBox = CType(dgi.Cells(i).Controls(0), CheckBox)
                            If cb.Checked Then
                                Dim Settings As String() = Split(cb.ID, "|")
                                objTabPermission.PermissionID = Convert.ToInt32(Settings(1))
                                Dim objRoleInfo As RoleInfo
                                Select Case Settings(3)
                                    Case glbRoleAllUsersName
                                        objRoleInfo = New RoleInfo
                                        objRoleInfo.RoleID = Convert.ToInt32(glbRoleAllUsers)
                                        objRoleInfo.RoleName = glbRoleAllUsersName
                                        objRoleInfo.PortalID = _portalSettings.PortalId
                                    Case Common.Globals.glbRoleUnauthUserName
                                        objRoleInfo = New RoleInfo
                                        objRoleInfo.RoleID = Convert.ToInt32(glbRoleUnauthUser)
                                        objRoleInfo.RoleName = glbRoleUnauthUserName
                                        objRoleInfo.PortalID = _portalSettings.PortalId
                                    Case Else
                                        objRoleInfo = objRoleController.GetRoleByName(_portalSettings.PortalId, Settings(3))
                                End Select

                                objTabPermission.RoleID = objRoleInfo.RoleID
                                'If cb.Checked Then
                                objTabPermission.AllowAccess = True
                                'Else
                                'objTabPermission.AllowAccess = False
                                'End If

                                If Settings(2) = "" Then
                                    objTabPermission.TabPermissionID = -1
                                Else
                                    objTabPermission.TabPermissionID = Convert.ToInt32(Settings(2))
                                End If
                                objTabPermission.TabID = TabID
                                arrTabPermissions.Add(objTabPermission)
                            End If
                        End If
                    Next
                Next
                Return arrTabPermissions
            End Get
        End Property

        Public Overrides Sub GenerateDataGrid()
            If TabID = -1 Then
                TabID = Convert.ToInt32(viewstate("TabID"))
            End If
            SetPermissions()

            Dim textCol As New BoundColumn
            textCol.HeaderText = ""
            textCol.DataField = "Roles"
            Columns.Add(textCol)

            Dim checkCol As Controls.CheckBoxColumn
            Dim i As Integer
            For i = 0 To _Permissions.Count - 1
                Dim objPermission As Security.Permissions.PermissionInfo
                objPermission = CType(_Permissions(i), Security.Permissions.PermissionInfo)
                checkCol = New Controls.CheckBoxColumn
                Dim locName As String = Services.Localization.Localization.GetString(objPermission.PermissionName + ".Permission", Services.Localization.Localization.GlobalResourceFile)
                checkCol.HeaderText = IIf(locName <> "", locName, objPermission.PermissionName).ToString
                checkCol.DataField = objPermission.PermissionName
                Columns.Add(checkCol)
            Next
            DataSource = GetPermissionsDataTable()
            DataBind()
            Me.DynamicColumnAdded = True
        End Sub

        Private Function GetPermissionsDataTable() As DataTable
            Dim dt As New DataTable
            Dim col As DataColumn

            col = New DataColumn("Roles")
            dt.Columns.Add(col)
            Dim i As Integer
            For i = 0 To _Permissions.Count - 1
                Dim objPerm As Security.Permissions.PermissionInfo
                objPerm = CType(_Permissions(i), Security.Permissions.PermissionInfo)
                col = New DataColumn(objPerm.PermissionName)
                dt.Columns.Add(col)
            Next

            Dim row As DataRow
            row = dt.NewRow


            For i = 0 To _roles.Count - 1
                Dim role As RoleInfo = DirectCast(_roles(i), RoleInfo)
                row = dt.NewRow
                row(0) = Localization.LocalizeRole(role.RoleName)

                Dim j As Integer
                For j = 0 To _Permissions.Count - 1
                    Dim objPerm As Security.Permissions.PermissionInfo
                    objPerm = CType(_Permissions(j), Security.Permissions.PermissionInfo)
                    Dim key As String
                    Dim CheckBoxEnabled As String = "Y"
                    Dim objTabPermission As Security.Permissions.TabPermissionInfo = TabHasPermission(objPerm.PermissionID, _TabPermissions, role.RoleName)
                    If Not objTabPermission Is Nothing Then
                        If role.RoleID = PortalController.GetCurrentPortalSettings.AdministratorRoleId Then
                            CheckBoxEnabled = "N"
                        End If
                        key = "|" + Convert.ToString(objPerm.PermissionID) + "|" + Convert.ToString(objTabPermission.TabPermissionID) + "|" + role.RoleName + "|" + role.RoleID.ToString + "|" + CheckBoxEnabled
                        If objTabPermission.AllowAccess Or CheckBoxEnabled = "N" Then
                            row(j + 1) = "True" + key
                        Else
                            row(j + 1) = "False" + key
                        End If
                    Else
                        If role.RoleID = PortalController.GetCurrentPortalSettings.AdministratorRoleId Then
                            CheckBoxEnabled = "N"
                        End If
                        key = "|" + Convert.ToString(objPerm.PermissionID) + "||" + role.RoleName + "|" + role.RoleID.ToString + "|" + CheckBoxEnabled
                        row(j + 1) = "False" + key
                    End If
                Next
                dt.Rows.Add(row)
            Next
            Return dt
        End Function

        Private Function TabHasPermission(ByVal PermissionID As Integer, ByVal arrTabPermissions As ArrayList, ByVal RoleName As String) As Security.Permissions.TabPermissionInfo
            Dim i As Integer
            For i = 0 To arrTabPermissions.Count - 1
                Dim objTabPermission As Security.Permissions.TabPermissionInfo = CType(arrTabPermissions(i), Security.Permissions.TabPermissionInfo)
                If objTabPermission.RoleName = RoleName And PermissionID = objTabPermission.PermissionID Then
                    Return objTabPermission
                End If
            Next
            Return Nothing
        End Function

        Private Sub SetPermissions()
            Dim objRoleController As New RoleController
            _roles = objRoleController.GetPortalRoles(PortalController.GetCurrentPortalSettings.PortalId)

            Dim r As New RoleInfo
            r.RoleID = Integer.Parse(glbRoleUnauthUser)
            r.RoleName = glbRoleUnauthUserName
            _roles.Add(r)
            r = New RoleInfo
            r.RoleID = Integer.Parse(glbRoleAllUsers)
            r.RoleName = glbRoleAllUsersName
            _roles.Add(r)
            _roles.Reverse()
            _roles.Sort(New RoleComparer)

            Dim objTabPermissionController As New Security.Permissions.TabPermissionController
            _TabPermissions = objTabPermissionController.GetTabPermissionsByTabID(Me.TabID)
            Dim objPermissionController As New Security.Permissions.PermissionController
            _Permissions = objPermissionController.GetPermissionsByTabID(Me.TabID)

        End Sub

    End Class

End Namespace