'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.Entities.Profile
Imports DotNetNuke.UI.WebControls

Namespace DotNetNuke.Entities.Users

    ''' -----------------------------------------------------------------------------
    ''' Project:    DotNetNuke
    ''' Namespace:  DotNetNuke.Entities.Users
    ''' Class:      UserInfo
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The UserInfo class provides Business Layer model for Users
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    '''     [cnurse]	12/13/2005	documented
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class UserInfo

#Region "Private Members"

        Private _UserID As Integer
        Private _Username As String
        Private _DisplayName As String
        Private _FirstName As String
        Private _LastName As String
        Private _FullName As String
        Private _Email As String
        Private _PortalID As Integer
        Private _IsSuperUser As Boolean
        Private _AffiliateID As Integer
        Private _Membership As UserMembership
        Private _Profile As UserProfile
        Private _Roles As String()

#End Region

#Region "Constructors"

        Public Sub New()

            _UserID = -1
            _PortalID = -1
            _IsSuperUser = False
            _AffiliateID = -1
            _Membership = New UserMembership
            _Profile = New UserProfile

        End Sub

#End Region

#Region "Properties"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the AffiliateId for this user
        ''' </summary>
        ''' <history>
        '''     [cnurse]	02/24/2006	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Browsable(False)> Public Property AffiliateID() As Integer
            Get
                Return _AffiliateID
            End Get
            Set(ByVal Value As Integer)
                _AffiliateID = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the Display Name
        ''' </summary>
        ''' <history>
        '''     [cnurse]	02/24/2006	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <SortOrder(3), Required(True), MaxLength(128)> Public Property DisplayName() As String
            Get
                Return _DisplayName
            End Get
            Set(ByVal Value As String)
                _DisplayName = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the Email Address
        ''' </summary>
        ''' <history>
        '''     [cnurse]	02/27/2006	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <SortOrder(4), MaxLength(256), Required(True), _
        RegularExpressionValidator("[\w\.-]+(\+[\w-]*)?@([\w-]+\.)+[\w-]+")> _
        Public Property Email() As String
            Get
                Return _Email
            End Get
            Set(ByVal Value As String)
                _Email = Value

                'Continue to set the membership Property in case developers have used this
                'in their own code
                Me.Membership.Email = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the First Name
        ''' </summary>
        ''' <history>
        '''     [cnurse]	02/24/2006	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <SortOrder(1), MaxLength(50), Required(True)> Public Property FirstName() As String
            Get
                If _FirstName = "" Then
                    'Try Profile
                    _FirstName = Profile.FirstName
                End If
                Return _FirstName
            End Get
            Set(ByVal Value As String)
                _FirstName = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets whether the User is a SuperUser
        ''' </summary>
        ''' <history>
        '''     [cnurse]	02/24/2006	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Browsable(False)> Public Property IsSuperUser() As Boolean
            Get
                Return _IsSuperUser
            End Get
            Set(ByVal Value As Boolean)
                _IsSuperUser = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the Last Name
        ''' </summary>
        ''' <history>
        '''     [cnurse]	02/24/2006	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <SortOrder(2), MaxLength(50), Required(True)> Public Property LastName() As String
            Get
                If _LastName = "" Then
                    'Try profile
                    _LastName = Profile.LastName
                End If
                Return _LastName
            End Get
            Set(ByVal Value As String)
                _LastName = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the Membership object
        ''' </summary>
        ''' <history>
        '''     [cnurse]	02/24/2006	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Browsable(False)> Public Property Membership() As Entities.Users.UserMembership
            Get
                'implemented progressive hydration
                'this object will be hydrated on demand
                If Not _Membership.ObjectHydrated AndAlso Not Me.Username Is Nothing AndAlso Me.Username.Length > 0 Then
                    _Membership.ObjectHydrated = True
                    UserController.GetUserMembership(Me)
                End If
                Return _Membership
            End Get
            Set(ByVal Value As Entities.Users.UserMembership)
                _Membership = Value
                _Membership.ObjectHydrated = True
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the PortalId
        ''' </summary>
        ''' <history>
        '''     [cnurse]	02/24/2006	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Browsable(False)> Public Property PortalID() As Integer
            Get
                Return _PortalID
            End Get
            Set(ByVal Value As Integer)
                _PortalID = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the Profile Object
        ''' </summary>
        ''' <history>
        '''     [cnurse]	02/24/2006	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Browsable(False)> Public Property Profile() As UserProfile
            Get
                'implemented progressive hydration
                'this object will be hydrated on demand
                If Not _Profile.ObjectHydrated AndAlso Not Me.Username Is Nothing AndAlso Me.Username.Length > 0 Then
                    ProfileController.GetUserProfile(Me)
                    _Profile.ObjectHydrated = True
                End If
                Return _Profile
            End Get
            Set(ByVal Value As UserProfile)
                _Profile = Value
                _Profile.ObjectHydrated = True
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the Roles for this User
        ''' </summary>
        ''' <history>
        '''     [cnurse]	02/24/2006	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Browsable(False)> Public Property Roles() As String()
            Get
                Return _Roles
            End Get
            Set(ByVal Value As String())
                _Roles = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the User Id
        ''' </summary>
        ''' <history>
        '''     [cnurse]	02/24/2006	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Browsable(False)> Public Property UserID() As Integer
            Get
                Return _UserID
            End Get
            Set(ByVal Value As Integer)
                _UserID = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and sets the User Name
        ''' </summary>
        ''' <history>
        '''     [cnurse]	02/24/2006	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <SortOrder(0), IsReadOnly(True), Required(True)> Public Property Username() As String
            Get
                Return _Username
            End Get
            Set(ByVal Value As String)
                _Username = Value

                'Continue to set the membership Property in case developers have used this
                'in their own code
                Me.Membership.Username = Value
            End Set
        End Property

#End Region

#Region "Public Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' IsInRole determines whether the user is in the role passed
        ''' </summary>
        ''' <param name="role">The role to check</param>
        ''' <returns>A Boolean indicating success or failure.</returns>
        ''' <history>
        '''     [cnurse]	12/13/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function IsInRole(ByVal role As String) As Boolean

            If IsSuperUser Or role = glbRoleAllUsersName Then
                Return True
            Else
                If Not Roles Is Nothing Then
                    For Each strRole As String In Roles
                        If strRole = role Then
                            Return True
                        End If
                    Next

                End If
            End If

            Return False

        End Function

#End Region

#Region "Deprecated Members"

        <Browsable(False), Obsolete("This property has been deprecated in favour of Display Name")> _
        Public Property FullName() As String
            Get
                If _FullName = "" Then
                    'Build from component names
                    _FullName = FirstName & " " & LastName
                End If
                Return _FullName
            End Get
            Set(ByVal Value As String)
                _FullName = Value
            End Set
        End Property

#End Region

    End Class

End Namespace
