'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data
Imports DotNetNuke.Framework.Providers

Namespace DotNetNuke.Framework
    ''' -----------------------------------------------------------------------------
    ''' <summary></summary>
    ''' <remarks></remarks>
    ''' <history>
    ''' 	[Nik Kalyani]	10/15/2004	Replaced brackets in parameter names
    ''' </history>
    ''' -----------------------------------------------------------------------------


    Public Class Reflection

        ' overload for creating an object from a Provider configured in web.config
        Public Shared Function CreateObject(ByVal ObjectProviderType As String) As Object
            Return CreateObject(ObjectProviderType, "", "")
        End Function

        ' overload for creating an object from a Provider including NameSpace and AssemblyName ( this allows derived providers to share the same config )
        Public Shared Function CreateObject(ByVal ObjectProviderType As String, ByVal ObjectNamespace As String, ByVal ObjectAssemblyName As String) As Object
            Return CreateObject(ObjectProviderType, "", ObjectNamespace, ObjectAssemblyName)
        End Function

        Public Shared Function CreateObject(ByVal ObjectProviderType As String, ByVal ObjectProviderName As String, ByVal ObjectNamespace As String, ByVal ObjectAssemblyName As String) As Object
            Dim TypeName As String = ""
            ' get the provider configuration based on the type
            Dim objProviderConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration(ObjectProviderType)

            If ObjectNamespace <> "" AndAlso ObjectAssemblyName <> "" Then
                If ObjectProviderName = "" Then
                    ' dynamically create the typename from the constants ( this enables private assemblies to share the same configuration as the base provider ) 
                    TypeName = ObjectNamespace & "." & objProviderConfiguration.DefaultProvider & ", " & ObjectAssemblyName & "." & objProviderConfiguration.DefaultProvider
                Else
                    ' dynamically create the typename from the constants ( this enables private assemblies to share the same configuration as the base provider ) 
                    TypeName = ObjectNamespace & "." & ObjectProviderName & ", " & ObjectAssemblyName & "." & ObjectProviderName
                End If
            Else
                If ObjectProviderName = "" Then
                    ' get the typename of the default DataProvider from web.config
                    TypeName = CType(objProviderConfiguration.Providers(objProviderConfiguration.DefaultProvider), Provider).Type
                Else
                    ' get the typename of the specified ProviderName from web.config 
                    TypeName = CType(objProviderConfiguration.Providers(ObjectProviderName), Provider).Type
                End If
            End If

            Return CreateObject(TypeName, TypeName)

        End Function


        ' dynamically create an object from a TypeName using a CacheKey
        Public Shared Function CreateObject(ByVal TypeName As String, ByVal CacheKey As String) As Object

            If CacheKey = "" Then
                CacheKey = TypeName
            End If

            ' use the cache for performance
            Dim objType As Type = CType(DataCache.GetCache(CacheKey), Type)

            ' is the type in the cache?
            If objType Is Nothing Then
                Try
                    ' use reflection to get the type of the class
                    objType = Type.GetType(TypeName, True)
                    ' insert the type into the cache
                    DataCache.SetCache(CacheKey, objType)
                Catch exc As Exception
                    ' could not load the type
                    LogException(exc)
                End Try
            End If
            ' dynamically create the object
            Return Activator.CreateInstance(objType)
        End Function

        ' dynamically create an object from a TypeName using a CacheKey
        Friend Shared Function CreateObjectNotCached(ByVal ObjectProviderType As String) As Object

            Dim TypeName As String = ""
            Dim objType As Type = Nothing

            ' get the provider configuration based on the type
            Dim objProviderConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration(ObjectProviderType)


            ' get the typename of the Base DataProvider from web.config
            TypeName = CType(objProviderConfiguration.Providers(objProviderConfiguration.DefaultProvider), Provider).Type

            Try
                ' use reflection to get the type of the class
                objType = Type.GetType(TypeName, True)

            Catch exc As Exception

                ' could not load the type
                LogException(exc)

            End Try


            ' dynamically create the object
            Return Activator.CreateInstance(objType)

        End Function
    End Class

End Namespace