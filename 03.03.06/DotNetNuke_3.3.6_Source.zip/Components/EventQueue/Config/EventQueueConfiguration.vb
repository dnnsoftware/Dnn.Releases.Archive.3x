'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.IO
Imports System.Web
Imports System.Web.Caching
Imports System.Xml
Imports System.Xml.Serialization
Imports DotNetNuke
Imports DotNetNuke.Common
Imports System.Text
Imports DotNetNuke.Common.Utilities
Namespace DotNetNuke.Services.EventQueue.Config

    Public Class EventQueueConfiguration

        Private _publishedEvents As PublishedEvents
        Private _eventQueueSubscribers As EventQueueSubscribers
        Public Sub New()
            _publishedEvents = New PublishedEvents
            _eventQueueSubscribers = New EventQueueSubscribers
        End Sub

        Public Shared Function GetConfig() As EventQueueConfiguration

            Dim config As EventQueueConfiguration = CType(DataCache.GetCache("EventQueueConfig"), EventQueueConfiguration)

            If (config Is Nothing) Then

                Dim filePath As String = HostMapPath & "EventQueue\EventQueue.config"
                If File.Exists(filePath) Then
                    config = New EventQueueConfiguration
                    ' Deserialize into EventQueueConfiguration
                    Dim oStreamReader As StreamReader = File.OpenText(filePath)
                    config.Deserialize(oStreamReader.ReadToEnd)
                    oStreamReader.Close()
                Else
                    'make a default config file
                    Dim si As New SubscriberInfo("DNN Core")
                    Dim e As New PublishedEvent
                    e.EventName = "Application_Start"
                    e.Subscribers = si.ID.ToString
                    config = New EventQueueConfiguration
                    config.PublishedEvents = New PublishedEvents
                    config.PublishedEvents.Add(e)
                    config.EventQueueSubscribers = New EventQueueSubscribers
                    config.EventQueueSubscribers.Add(si)
                    Dim oStream As StreamWriter = File.CreateText(filePath)
                    oStream.WriteLine(config.Serialize())
                    oStream.Close()

                End If
                If File.Exists(filePath) Then
                    ' Create a dependency on the config file
                    Dim dep As CacheDependency = New CacheDependency(filePath)

                    ' Set back into Cache
                    DataCache.SetCache("EventQueueConfig", config, dep)
                End If

            End If

            Return config

        End Function
        Public Function Serialize() As String
            Dim configXML As New StringBuilder("<?xml version=""1.0"" encoding=""utf-8""?>")
            configXML.Append(ControlChars.CrLf)
            configXML.Append("<EventQueueConfig>")
            configXML.Append(ControlChars.CrLf)
            configXML.Append(ControlChars.Tab)
            configXML.Append("<PublishedEvents>")
            configXML.Append(ControlChars.CrLf)
            For Each key As String In Me.PublishedEvents.Keys
                configXML.Append(ControlChars.Tab, 2)
                configXML.Append("<Event>")
                configXML.Append(ControlChars.CrLf)
                configXML.Append(ControlChars.Tab, 3)
                configXML.Append("<EventName>")
                configXML.Append(Me.PublishedEvents(key).EventName)
                configXML.Append("</EventName>")
                configXML.Append(ControlChars.CrLf)
                configXML.Append(ControlChars.Tab, 3)
                If Me.PublishedEvents(key).Subscribers.Length > 0 Then
                    configXML.Append("<Subscribers>")
                    configXML.Append(Me.PublishedEvents(key).Subscribers)
                    configXML.Append("</Subscribers>")
                Else
                    configXML.Append("<Subscribers/>")
                End If
                configXML.Append(ControlChars.CrLf)
                configXML.Append(ControlChars.Tab, 2)
                configXML.Append("</Event>")
                configXML.Append(ControlChars.CrLf)

            Next
            configXML.Append(ControlChars.Tab)
            configXML.Append("</PublishedEvents>")
            configXML.Append(ControlChars.CrLf)
            configXML.Append(ControlChars.Tab)
            configXML.Append("<EventQueueSubscribers>")
            configXML.Append(ControlChars.CrLf)

            For Each key As String In Me.EventQueueSubscribers.Keys
                configXML.Append(ControlChars.Tab, 2)
                configXML.Append("<Subscriber>")
                configXML.Append(ControlChars.CrLf)
                configXML.Append(ControlChars.Tab, 3)
                configXML.Append("<ID>")
                configXML.Append(Me.EventQueueSubscribers(key).ID)
                configXML.Append("</ID>")
                configXML.Append(ControlChars.CrLf)
                configXML.Append(ControlChars.Tab, 3)
                If Me.EventQueueSubscribers(key).Name.Length > 0 Then
                    configXML.Append("<Name>")
                    configXML.Append(Me.EventQueueSubscribers(key).Name)
                    configXML.Append("</Name>")
                Else
                    configXML.Append("<Name/>")
                End If
                configXML.Append(ControlChars.CrLf)
                configXML.Append(ControlChars.Tab, 3)
                If Me.EventQueueSubscribers(key).Address.Length > 0 Then
                    configXML.Append("<Address>")
                    configXML.Append(Me.EventQueueSubscribers(key).Address)
                    configXML.Append("</Address>")
                Else
                    configXML.Append("<Address/>")
                End If
                configXML.Append(ControlChars.CrLf)
                configXML.Append(ControlChars.Tab, 3)
                If Me.EventQueueSubscribers(key).Description.Length > 0 Then
                    configXML.Append("<Description>")
                    configXML.Append(Me.EventQueueSubscribers(key).Description)
                    configXML.Append("</Description>")
                Else
                    configXML.Append("<Description/>")
                End If
                configXML.Append(ControlChars.CrLf)
                configXML.Append(ControlChars.Tab, 3)
                If Me.EventQueueSubscribers(key).PrivateKey.Length > 0 Then
                    configXML.Append("<PrivateKey>")
                    configXML.Append(Me.EventQueueSubscribers(key).PrivateKey)
                    configXML.Append("</PrivateKey>")
                Else
                    configXML.Append("<PrivateKey/>")
                End If
                configXML.Append(ControlChars.CrLf)
                configXML.Append(ControlChars.Tab, 2)
                configXML.Append("</Subscriber>")
                configXML.Append(ControlChars.CrLf)
            Next
            configXML.Append(ControlChars.Tab)
            configXML.Append("</EventQueueSubscribers>")
            configXML.Append(ControlChars.CrLf)
            configXML.Append("</EventQueueConfig>")
            Return configXML.ToString()
        End Function

        Public Sub Deserialize(ByVal configXml As String)
            If configXml <> "" Then
                Dim xmlDoc As New XmlDocument
                xmlDoc.LoadXml(configXml)
                For Each xmlItem As XmlElement In xmlDoc.SelectNodes("/EventQueueConfig/PublishedEvents/Event")
                    Dim oPublishedEvent As New PublishedEvent
                    oPublishedEvent.EventName = xmlItem.SelectSingleNode("EventName").InnerText
                    oPublishedEvent.Subscribers = xmlItem.SelectSingleNode("Subscribers").InnerText
                    Me.PublishedEvents.Add(oPublishedEvent)
                Next
                For Each xmlItem As XmlElement In xmlDoc.SelectNodes("/EventQueueConfig/EventQueueSubscribers/Subscriber")
                    Dim oSubscriberInfo As New SubscriberInfo
                    oSubscriberInfo.ID = xmlItem.SelectSingleNode("ID").InnerText
                    oSubscriberInfo.Name = xmlItem.SelectSingleNode("Name").InnerText
                    oSubscriberInfo.Address = xmlItem.SelectSingleNode("Address").InnerText
                    oSubscriberInfo.Description = xmlItem.SelectSingleNode("Description").InnerText
                    oSubscriberInfo.PrivateKey = xmlItem.SelectSingleNode("PrivateKey").InnerText
                    Me.EventQueueSubscribers.Add(oSubscriberInfo)
                Next
            End If


        End Sub
        Public Property PublishedEvents() As PublishedEvents
            Get
                Return _publishedEvents
            End Get
            Set(ByVal Value As PublishedEvents)
                _publishedEvents = Value
            End Set
        End Property
        Public Property EventQueueSubscribers() As EventQueueSubscribers
            Get
                Return _eventQueueSubscribers
            End Get
            Set(ByVal Value As EventQueueSubscribers)
                _eventQueueSubscribers = Value
            End Set
        End Property

    End Class

End Namespace
