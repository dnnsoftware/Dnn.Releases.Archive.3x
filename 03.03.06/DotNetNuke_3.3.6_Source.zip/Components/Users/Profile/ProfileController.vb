'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.Common.Lists
Imports DotNetNuke.Entities.Modules

Namespace DotNetNuke.Entities.Profile

    ''' -----------------------------------------------------------------------------
    ''' Project:    DotNetNuke
    ''' Namespace:  DotNetNuke.Entities.Profile
    ''' Class:      ProfileController
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The ProfileController class provides Business Layer methods for profiles and
    ''' for profile property Definitions
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    '''     [cnurse]	01/31/2006	created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class ProfileController

#Region "Public Constants"

        Public Const PROPERTIES_CACHEKEY As String = "Profile.Property.Definition"

#End Region

#Region "Private Shared Members"

        Private Shared provider As DataProvider = DataProvider.Instance()
        Private Shared profileProvider As DotNetNuke.Security.Profile.ProfileProvider = DotNetNuke.Security.Profile.ProfileProvider.Instance()
        Private Shared _orderCounter As Integer

#End Region

#Region "Private Shared Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Adds a single default property definition
        ''' </summary>
        ''' <param name="PortalId">Id of the Portal</param>
        ''' <param name="category">Category of the Property</param>
        ''' <param name="name">Name of the Property</param>
        ''' <history>
        '''     [cnurse]	02/22/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Sub AddDefaultDefinition(ByVal PortalId As Integer, ByVal category As String, ByVal name As String, ByVal strType As String, ByVal length As Integer, ByVal types As ListEntryInfoCollection)

            Dim typeInfo As ListEntryInfo = types.Item("DataType." + strType)
            If typeInfo Is Nothing Then
                typeInfo = types.Item("DataType.Unknown")
            End If

            Dim propertyDefinition As ProfilePropertyDefinition = New ProfilePropertyDefinition()
            propertyDefinition.DataType = typeInfo.EntryID
            propertyDefinition.DefaultValue = ""
            propertyDefinition.ModuleDefId = Null.NullInteger
            propertyDefinition.PortalId = PortalId
            propertyDefinition.PropertyCategory = category
            propertyDefinition.PropertyName = name
            propertyDefinition.Required = False
            propertyDefinition.Visible = True
            propertyDefinition.Length = length

            _orderCounter += 2

            propertyDefinition.ViewOrder = _orderCounter

            AddPropertyDefinition(propertyDefinition)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Fills a ProfilePropertyDefinitionCollection from a DataReader
        ''' </summary>
        ''' <param name="dr">An IDataReader object</param>
        ''' <returns>The ProfilePropertyDefinitionCollection</returns>
        ''' <history>
        '''     [cnurse]	02/01/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function FillCollection(ByVal dr As IDataReader) As ProfilePropertyDefinitionCollection
            Dim arrDefinitions As ArrayList = CBO.FillCollection(dr, GetType(ProfilePropertyDefinition))
            Dim definitionsCollection As New ProfilePropertyDefinitionCollection
            For Each definition As ProfilePropertyDefinition In arrDefinitions
                'Clear the Is Dirty Flag
                definition.ClearIsDirty()

                'Initialise the Visibility
                Dim setting As Object = UserModuleBase.GetSetting(definition.PortalId, "Profile_DefaultVisibility")
                If Not setting Is Nothing Then
                    definition.Visibility = CType(setting, UserVisibilityMode)
                End If

                'Add to collection
                definitionsCollection.Add(definition)
            Next
            Return definitionsCollection
        End Function

#End Region

#Region "Profile Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Profile Information for the User
        ''' </summary>
        ''' <remarks></remarks>
        ''' <param name="objUser">The user whose Profile information we are retrieving.</param>
        ''' <history>
        ''' 	[cnurse]	12/13/2005	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub GetUserProfile(ByRef objUser As UserInfo)

            profileProvider.GetUserProfile(objUser)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Updates a User's Profile
        ''' </summary>
        ''' <param name="objUser">The use to update</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	02/18/2005	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub UpdateUserProfile(ByVal objUser As UserInfo)

            Dim UserInfoCacheKey As String = UserController.CacheKey(objUser.PortalID, objUser.Username)

            'Update the User Profile
            If objUser.Profile.IsDirty Then
                profileProvider.UpdateUserProfile(objUser)
            End If

            'Remove the UserInfo from the Cache, as it has been modified
            DataCache.RemoveCache(UserInfoCacheKey)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Updates a User's Profile
        ''' </summary>
        ''' <param name="objUser">The use to update</param>
        ''' <param name="profileProperties">The collection of profile properties</param>
        ''' <returns>The updated User</returns>
        ''' <history>
        ''' 	[cnurse]	03/02/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function UpdateUserProfile(ByVal objUser As UserInfo, ByVal profileProperties As ProfilePropertyDefinitionCollection) As UserInfo

            'Iterate through the Definitions
            For Each propertyDefinition As ProfilePropertyDefinition In profileProperties

                Dim propertyName As String = propertyDefinition.PropertyName
                Dim propertyValue As String = propertyDefinition.PropertyValue

                If propertyDefinition.IsDirty Then
                    'Update Profile
                    objUser.Profile.SetProfileProperty(propertyName, propertyValue)
                End If
            Next

            UpdateUserProfile(objUser)

            Return objUser

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Validates the Profile properties for the User (determines if all required properties
        ''' have been set)
        ''' </summary>
        ''' <param name="portalId">The Id of the portal.</param>
        ''' <param name="objProfile">The profile.</param>
        ''' <history>
        ''' 	[cnurse]	03/13/2006	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function ValidateProfile(ByVal portalId As Integer, ByVal objProfile As UserProfile) As Boolean

            Dim isValid As Boolean = True

            For Each propertyDefinition As ProfilePropertyDefinition In objProfile.ProfileProperties

                If propertyDefinition.Required And propertyDefinition.PropertyValue = Null.NullString Then
                    isValid = False
                    Exit For
                End If
            Next

            Return isValid

        End Function

#End Region

#Region "Property Definition Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Adds the default property definitions for a portal
        ''' </summary>
        ''' <param name="PortalId">Id of the Portal</param>
        ''' <history>
        '''     [cnurse]	02/22/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub AddDefaultDefinitions(ByVal PortalId As Integer)

            _orderCounter = 1

            Dim objListController As New ListController
            Dim dataTypes As ListEntryInfoCollection = objListController.GetListEntryInfoCollection("DataType")

            AddDefaultDefinition(PortalId, "Name", "Prefix", "Text", 50, dataTypes)
            AddDefaultDefinition(PortalId, "Name", "FirstName", "Text", 50, dataTypes)
            AddDefaultDefinition(PortalId, "Name", "MiddleName", "Text", 50, dataTypes)
            AddDefaultDefinition(PortalId, "Name", "LastName", "Text", 50, dataTypes)
            AddDefaultDefinition(PortalId, "Name", "Suffix", "Text", 50, dataTypes)
            AddDefaultDefinition(PortalId, "Address", "Unit", "Text", 50, dataTypes)
            AddDefaultDefinition(PortalId, "Address", "Street", "Text", 50, dataTypes)
            AddDefaultDefinition(PortalId, "Address", "City", "Text", 50, dataTypes)
            AddDefaultDefinition(PortalId, "Address", "Region", "Region", 0, dataTypes)
            AddDefaultDefinition(PortalId, "Address", "Country", "Country", 0, dataTypes)
            AddDefaultDefinition(PortalId, "Address", "PostalCode", "Text", 50, dataTypes)
            AddDefaultDefinition(PortalId, "Contact Info", "Telephone", "Text", 50, dataTypes)
            AddDefaultDefinition(PortalId, "Contact Info", "Cell", "Text", 50, dataTypes)
            AddDefaultDefinition(PortalId, "Contact Info", "Fax", "Text", 50, dataTypes)
            AddDefaultDefinition(PortalId, "Contact Info", "Website", "Text", 50, dataTypes)
            AddDefaultDefinition(PortalId, "Contact Info", "IM", "Text", 50, dataTypes)
            AddDefaultDefinition(PortalId, "Preferences", "Biography", "RichText", 0, dataTypes)
            AddDefaultDefinition(PortalId, "Preferences", "TimeZone", "TimeZone", 0, dataTypes)
            AddDefaultDefinition(PortalId, "Preferences", "PreferredLocale", "Locale", 0, dataTypes)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Adds a Property Defintion to the Data Store
        ''' </summary>
        ''' <param name="definition">An ProfilePropertyDefinition object</param>
        ''' <returns>The Id of the definition (or if negative the errorcode of the error)</returns>
        ''' <history>
        '''     [cnurse]	02/01/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function AddPropertyDefinition(ByVal definition As ProfilePropertyDefinition) As Integer
            Return provider.AddPropertyDefinition(definition.PortalId, definition.ModuleDefId, _
                definition.DataType, definition.DefaultValue, _
                definition.PropertyCategory, definition.PropertyName, definition.Required, _
                definition.ValidationExpression, definition.ViewOrder, definition.Visible, definition.Length)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Clears the Profile Definitions Cache
        ''' </summary>
        ''' <param name="PortalId">Id of the Portal</param>
        ''' <history>
        '''     [cnurse]	02/22/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub ClearProfileDefinitionCache(ByVal PortalId As Integer)

            'Clear the Cache and refresh the Properties collection
            Dim strKey As String = PROPERTIES_CACHEKEY & "." & PortalId.ToString
            DataCache.RemoveCache(strKey)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Deletes a Property Defintion from the Data Store
        ''' </summary>
        ''' <param name="definitionId">The id of the ProfilePropertyDefinition object to delete</param>
        ''' <history>
        '''     [cnurse]	02/01/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub DeletePropertyDefinition(ByVal definitionId As Integer)
            provider.DeletePropertyDefinition(definitionId)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Deletes a Property Defintion from the Data Store
        ''' </summary>
        ''' <param name="definition">The ProfilePropertyDefinition object to delete</param>
        ''' <history>
        '''     [cnurse]	02/01/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub DeletePropertyDefinition(ByVal definition As ProfilePropertyDefinition)
            DeletePropertyDefinition(definition.PropertyDefinitionId)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets a Property Defintion from the Data Store by id
        ''' </summary>
        ''' <param name="definitionId">The id of the ProfilePropertyDefinition object to retrieve</param>
        ''' <returns>The ProfilePropertyDefinition object</returns>
        ''' <history>
        '''     [cnurse]	02/01/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetPropertyDefinition(ByVal definitionId As Integer) As ProfilePropertyDefinition
            Return CType(CBO.FillObject(provider.GetPropertyDefinition(definitionId), GetType(ProfilePropertyDefinition)), ProfilePropertyDefinition)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets a Property Defintion from the Data Store by name
        ''' </summary>
        ''' <param name="portalId">The id of the Portal</param>
        ''' <param name="name">The name of the ProfilePropertyDefinition object to retrieve</param>
        ''' <returns>The ProfilePropertyDefinition object</returns>
        ''' <history>
        '''     [cnurse]	02/01/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetPropertyDefinitionByName(ByVal portalId As Integer, ByVal name As String) As ProfilePropertyDefinition
            Return CType(CBO.FillObject(provider.GetPropertyDefinitionByName(portalId, name), GetType(ProfilePropertyDefinition)), ProfilePropertyDefinition)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets a collection of Property Defintions from the Data Store by category
        ''' </summary>
        ''' <param name="portalId">The id of the Portal</param>
        ''' <param name="category">The category of the Property Defintions to retrieve</param>
        ''' <returns>A ProfilePropertyDefinitionCollection object</returns>
        ''' <history>
        '''     [cnurse]	02/01/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetPropertyDefinitionsByCategory(ByVal portalId As Integer, ByVal category As String) As ProfilePropertyDefinitionCollection
            Return FillCollection(provider.GetPropertyDefinitionsByCategory(portalId, category))
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets a collection of Property Defintions from the Data Store by portal
        ''' </summary>
        ''' <param name="portalId">The id of the Portal</param>
        ''' <returns>A ProfilePropertyDefinitionCollection object</returns>
        ''' <history>
        '''     [cnurse]	02/01/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetPropertyDefinitionsByPortal(ByVal portalId As Integer) As ProfilePropertyDefinitionCollection
            Return FillCollection(provider.GetPropertyDefinitionsByPortal(portalId))
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Updates a Property Defintion in the Data Store
        ''' </summary>
        ''' <param name="definition">The ProfilePropertyDefinition object to update</param>
        ''' <history>
        '''     [cnurse]	02/01/2006	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub UpdatePropertyDefinition(ByVal definition As ProfilePropertyDefinition)
            provider.UpdatePropertyDefinition(definition.PropertyDefinitionId, _
                definition.DataType, definition.DefaultValue, definition.PropertyCategory, _
                definition.PropertyName, definition.Required, definition.ValidationExpression, _
                definition.ViewOrder, definition.Visible, definition.Length)
        End Sub

#End Region

    End Class

End Namespace

