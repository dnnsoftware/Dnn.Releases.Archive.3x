'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Drawing
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO
Imports System.Collections
Imports System.Data

Imports DotNetNuke.Security.Roles
Imports DotNetNuke.Services.Localization
Imports DotNetNuke.UI.WebControls

Namespace DotNetNuke.Security.Permissions.Controls

    Public MustInherit Class PermissionsGrid
        Inherits Control
        Implements INamingContainer

        Private pnlPermissions As Panel
        Private lblGroups As Label
        Private WithEvents cboRoleGroups As DropDownList
        Private dgPermissions As DataGrid

#Region "Private Members"

        Private _permissionsDataTable As New DataTable
        Private _roles As ArrayList
        Private m_Permissions As ArrayList
        Private _resourceFile As String

#End Region

#Region "Public Properties"

#Region "DataGrid Properties"

        Public ReadOnly Property AlternatingItemStyle() As TableItemStyle
            Get
                Return dgPermissions.AlternatingItemStyle
            End Get
        End Property

        Public Property AutoGenerateColumns() As Boolean
            Get
                Return dgPermissions.AutoGenerateColumns
            End Get
            Set(ByVal Value As Boolean)
                dgPermissions.AutoGenerateColumns = Value
            End Set
        End Property

        Public Property CellSpacing() As Integer
            Get
                Return dgPermissions.CellSpacing
            End Get
            Set(ByVal Value As Integer)
                dgPermissions.CellSpacing = Value
            End Set
        End Property

        Public ReadOnly Property Columns() As DataGridColumnCollection
            Get
                Return dgPermissions.Columns()
            End Get
        End Property

        Public ReadOnly Property FooterStyle() As TableItemStyle
            Get
                Return dgPermissions.FooterStyle
            End Get
        End Property

        Public Property GridLines() As GridLines
            Get
                Return dgPermissions.GridLines
            End Get
            Set(ByVal Value As GridLines)
                dgPermissions.GridLines = Value
            End Set
        End Property

        Public ReadOnly Property HeaderStyle() As TableItemStyle
            Get
                Return dgPermissions.HeaderStyle
            End Get
        End Property

        Public ReadOnly Property ItemStyle() As TableItemStyle
            Get
                Return dgPermissions.ItemStyle
            End Get
        End Property

        Public ReadOnly Property Items() As DataGridItemCollection
            Get
                Return dgPermissions.Items()
            End Get
        End Property

        Public ReadOnly Property SelectedItemStyle() As TableItemStyle
            Get
                Return dgPermissions.SelectedItemStyle
            End Get
        End Property


#End Region

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Id of the Administrator Role
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/16/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public ReadOnly Property AdministratorRoleId() As Integer
            Get
                Return PortalController.GetCurrentPortalSettings.AdministratorRoleId
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Id of the Registered Users Role
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/16/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public ReadOnly Property RegisteredUsersRoleId() As Integer
            Get
                Return PortalController.GetCurrentPortalSettings.RegisteredRoleId
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and Sets whether as Dynamic Column has been added
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/09/2006  Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Property DynamicColumnAdded() As Boolean
            Get
                If ViewState("ColumnAdded") Is Nothing Then
                    Return False
                Else
                    Return True
                End If
            End Get
            Set(ByVal Value As Boolean)
                ViewState("ColumnAdded") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the underlying Permissions Data Table
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/09/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public ReadOnly Property PermissionsDataTable() As DataTable
            Get
                Return _permissionsDataTable
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Id of the Portal
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/16/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public ReadOnly Property PortalId() As Integer
            Get
                ' Obtain PortalSettings from Current Context
                Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
                Dim intPortalID As Integer

                If _portalSettings.ActiveTab.ParentId = _portalSettings.SuperTabId Then 'if we are in host filemanager then we need to pass a null portal id
                    intPortalID = Null.NullInteger
                Else
                    intPortalID = _portalSettings.PortalId
                End If

                Return intPortalID
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and Sets the collection of Roles to display
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/09/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Property Roles() As ArrayList
            Get
                Return _roles
            End Get
            Set(ByVal Value As ArrayList)
                _roles = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets and Sets the ResourceFile to localize permissions
        ''' </summary>
        ''' <history>
        '''     [vmasanas]    02/24/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Property ResourceFile() As String
            Get
                Return _resourcefile
            End Get
            Set(ByVal Value As String)
                _resourcefile = Value
            End Set
        End Property
#End Region

#Region "Abstract Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Generate the Data Grid
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/09/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public MustOverride Sub GenerateDataGrid()

#End Region

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Bind the Grid to the PermissionsDataTable
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/09/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub BindGrid()

            Me.EnsureChildControls()

            PermissionsDataTable.Columns.Clear()
            PermissionsDataTable.Rows.Clear()

            Dim col As DataColumn

            'Add Roles Column
            col = New DataColumn("RoleId")
            PermissionsDataTable.Columns.Add(col)

            'Add Roles Column
            col = New DataColumn("RoleName")
            PermissionsDataTable.Columns.Add(col)

            Dim i As Integer
            For i = 0 To m_Permissions.Count - 1
                Dim objPerm As Security.Permissions.PermissionInfo
                objPerm = CType(m_Permissions(i), Security.Permissions.PermissionInfo)

                'Add Enabled Column
                col = New DataColumn(objPerm.PermissionName & "_Enabled")
                PermissionsDataTable.Columns.Add(col)

                'Add Permission Column
                col = New DataColumn(objPerm.PermissionName)
                PermissionsDataTable.Columns.Add(col)
            Next

            GetRoles()

            UpDatePermissions()
            Dim row As DataRow
            For i = 0 To Roles.Count - 1
                Dim role As RoleInfo = DirectCast(Roles(i), RoleInfo)
                row = PermissionsDataTable.NewRow
                row("RoleId") = role.RoleID
                row("RoleName") = Localization.LocalizeRole(role.RoleName)

                Dim j As Integer
                For j = 0 To m_Permissions.Count - 1
                    Dim objPerm As Security.Permissions.PermissionInfo
                    objPerm = CType(m_Permissions(j), Security.Permissions.PermissionInfo)

                    row(objPerm.PermissionName & "_Enabled") = GetEnabled(objPerm, role, j + 1)
                    row(objPerm.PermissionName) = GetPermission(objPerm, role, j + 1)
                Next
                PermissionsDataTable.Rows.Add(row)
            Next

            dgPermissions.DataSource = PermissionsDataTable
            dgPermissions.DataBind()

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the roles from the Database and loads them into the Roles property
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/09/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub GetRoles()
            Dim objRoleController As New RoleController
            Dim RoleGroupId As Integer = -2
            If (Not cboRoleGroups Is Nothing) AndAlso (Not cboRoleGroups.SelectedValue Is Nothing) Then
                RoleGroupId = Integer.Parse(cboRoleGroups.SelectedValue)
            End If

            If RoleGroupId > -2 Then
                _roles = objRoleController.GetRolesByGroup(PortalController.GetCurrentPortalSettings.PortalId, RoleGroupId)
            Else
                _roles = objRoleController.GetPortalRoles(PortalController.GetCurrentPortalSettings.PortalId)
            End If

            If RoleGroupId < 0 Then
                Dim r As New RoleInfo
                r.RoleID = Integer.Parse(glbRoleUnauthUser)
                r.RoleName = glbRoleUnauthUserName
                _roles.Add(r)
                r = New RoleInfo
                r.RoleID = Integer.Parse(glbRoleAllUsers)
                r.RoleName = glbRoleAllUsersName
                _roles.Add(r)
            End If
            _roles.Reverse()
            _roles.Sort(New RoleComparer)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Sets up the columns for the Grid
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/09/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub SetUpDataGrid()

            Columns.Clear()

            Dim textCol As New BoundColumn
            textCol.HeaderText = ""
            textCol.DataField = "RoleName"
            Columns.Add(textCol)

            Dim idCol As New BoundColumn
            idCol.HeaderText = ""
            idCol.DataField = "roleid"
            idCol.Visible = False
            Columns.Add(idCol)

            Dim checkCol As TemplateColumn
            Dim i As Integer

            m_Permissions = GetPermissions()
            For i = 0 To m_Permissions.Count - 1
                Dim objPermission As Security.Permissions.PermissionInfo
                objPermission = CType(m_Permissions(i), Security.Permissions.PermissionInfo)

                checkCol = New TemplateColumn
                Dim columnTemplate As New CheckBoxColumnTemplate
                columnTemplate.DataField = objPermission.PermissionName
                columnTemplate.EnabledField = objPermission.PermissionName & "_Enabled"
                checkCol.ItemTemplate = columnTemplate
                Dim locName As String = ""
                If objPermission.ModuleDefID > 0 Then
                    If ResourceFile <> "" Then
                        ' custom permission
                        locName = Services.Localization.Localization.GetString(objPermission.PermissionName + ".Permission", ResourceFile)
                    End If
                Else
                    ' system permission
                    locName = Services.Localization.Localization.GetString(objPermission.PermissionName + ".Permission", Services.Localization.Localization.GlobalResourceFile)
                End If
                checkCol.HeaderText = IIf(locName <> "", locName, objPermission.PermissionName).ToString
                checkCol.ItemStyle.HorizontalAlign = HorizontalAlign.Center
                checkCol.HeaderStyle.Wrap = True
                Columns.Add(checkCol)
            Next

        End Sub

#End Region

#Region "Protected Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Builds the key used to store the "permission" information in the ViewState
        ''' </summary>
        ''' <param name="checked">Is the checkbox checked</param>
        ''' <param name="permissionId">The Id of the permission</param>
        ''' <param name="objectPermissionId">The Id of the object permission</param>
        ''' <param name="roleId">The role id</param>
        ''' <param name="roleName">The role name</param>
        ''' <history>
        '''     [cnurse]    01/09/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Function BuildKey(ByVal checked As Boolean, ByVal permissionId As Integer, ByVal objectPermissionId As Integer, ByVal roleId As Integer, ByVal roleName As String) As String

            Dim key As String

            If checked Then
                key = "True"
            Else
                key = "False"
            End If

            key += "|" + Convert.ToString(permissionId)

            'Add objectPermissionId
            key += "|"
            If objectPermissionId > -1 Then
                key += Convert.ToString(objectPermissionId)
            End If

            key += "|" + roleName
            key += "|" + roleId.ToString

            Return key

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Child Controls
        ''' </summary>
        ''' <history>
        '''     [cnurse]    02/23/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overrides Sub CreateChildControls()

            pnlPermissions = New Panel
            pnlPermissions.CssClass = "DataGrid_Container"

            'Optionally Add Role Group Filter
            Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
            Dim arrGroups As ArrayList = RoleController.GetRoleGroups(_portalSettings.PortalId)
            If arrGroups.Count > 0 Then
                lblGroups = New Label
                lblGroups.Text = Localization.GetString("RoleGroupFilter")
                lblGroups.CssClass = "SubHead"
                pnlPermissions.Controls.Add(lblGroups)

                pnlPermissions.Controls.Add(New LiteralControl("&nbsp;&nbsp;"))

                cboRoleGroups = New DropDownList
                cboRoleGroups.AutoPostBack = True

                cboRoleGroups.Items.Add(New ListItem(Localization.GetString("AllRoles"), "-2"))
                Dim liItem As ListItem = New ListItem(Localization.GetString("GlobalRoles"), "-1")
                liItem.Selected = True
                cboRoleGroups.Items.Add(liItem)
                For Each roleGroup As RoleGroupInfo In arrGroups
                    cboRoleGroups.Items.Add(New ListItem(roleGroup.RoleGroupName, roleGroup.RoleGroupID.ToString))
                Next
                pnlPermissions.Controls.Add(cboRoleGroups)
            End If

            dgPermissions = New DataGrid

            AutoGenerateColumns = False

            CellSpacing = 0
            GridLines = GridLines.None

            FooterStyle.CssClass = "DataGrid_Footer"
            HeaderStyle.CssClass = "DataGrid_Header"
            ItemStyle.CssClass = "DataGrid_Item"
            AlternatingItemStyle.CssClass = "DataGrid_AlternatingItem"

            SetUpDataGrid()

            pnlPermissions.Controls.Add(dgPermissions)

            Me.Controls.Add(pnlPermissions)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Enabled status of the permission
        ''' </summary>
        ''' <param name="objPerm">The permission being loaded</param>
        ''' <param name="role">The role</param>
        ''' <param name="column">The column of the Grid</param>
        ''' <history>
        '''     [cnurse]    01/13/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overridable Function GetEnabled(ByVal objPerm As PermissionInfo, ByVal role As RoleInfo, ByVal column As Integer) As Boolean

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the Value of the permission
        ''' </summary>
        ''' <param name="objPerm">The permission being loaded</param>
        ''' <param name="role">The role</param>
        ''' <param name="column">The column of the Grid</param>
        ''' <history>
        '''     [cnurse]    01/13/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overridable Function GetPermission(ByVal objPerm As PermissionInfo, ByVal role As RoleInfo, ByVal column As Integer) As Boolean

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the permissions from the Database
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/12/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overridable Function GetPermissions() As ArrayList

        End Function

        Protected Overrides Sub OnLoad(ByVal e As System.EventArgs)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Overrides the base OnPreRender method to Bind the Grid to the Permissions
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/09/2006  Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overrides Sub OnPreRender(ByVal e As System.EventArgs)
            BindGrid()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Updates a Permission
        ''' </summary>
        ''' <param name="permission">The permission being updated</param>
        ''' <param name="roleName">The name of the role</param>
        ''' <param name="allowAccess">The value of the permission</param>
        ''' <history>
        '''     [cnurse]    01/12/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Overridable Sub UpdatePermission(ByVal permission As PermissionInfo, ByVal roleId As Integer, ByVal roleName As String, ByVal allowAccess As Boolean)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Updates the permissions
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/09/2006  Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Protected Sub UpdatePermissions()

            Me.EnsureChildControls()

            Dim dgi As DataGridItem
            For Each dgi In Items
                Dim i As Integer
                For i = 2 To dgi.Cells.Count - 1
                    'all except first two cells which is role names and role ids
                    If dgi.Cells(i).Controls.Count > 0 Then
                        Dim cb As CheckBox = CType(dgi.Cells(i).Controls(0), CheckBox)
                        Dim objPermission As PermissionInfo

                        UpdatePermission(CType(m_Permissions(i - 2), PermissionInfo), Integer.Parse(dgi.Cells(1).Text), dgi.Cells(0).Text, cb.Checked)

                    End If
                Next
            Next
        End Sub


#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' RoleGroupsSelectedIndexChanged runs when the Role Group is changed
        ''' </summary>
        ''' <history>
        '''     [cnurse]    01/06/2006  Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub RoleGroupsSelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboRoleGroups.SelectedIndexChanged

            UpDatePermissions()

        End Sub

#End Region

    End Class


End Namespace