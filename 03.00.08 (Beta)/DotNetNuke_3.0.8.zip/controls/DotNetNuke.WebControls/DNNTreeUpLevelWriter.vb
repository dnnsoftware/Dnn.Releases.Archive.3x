'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Web.UI
Imports System.Web.UI.WebControls
Namespace DotNetNuke.UI.WebControls

	Friend Class DNNTreeUpLevelWriter
		Inherits WebControl
		Implements IDNNTreeWriter
		Private _tree As DNNTree

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Sub New()
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <param name="writer"></param>
		''' <param name="tree"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Sub RenderTree(ByVal writer As HtmlTextWriter, ByVal tree As DnnTree) Implements IDNNTreeWriter.RenderTree
			_tree = tree
			RenderControl(writer)
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <param name="writer"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        '''     [cnurse]    11/1/2004   modified to use CssClass property if set
		''' </history>
		''' -----------------------------------------------------------------------------
		Protected Overloads Overrides Sub RenderContents(ByVal writer As HtmlTextWriter)

            If Len(_tree.CssClass) > 0 Then
                writer.AddAttribute(HtmlTextWriterAttribute.Class, _tree.CssClass)
            End If

            writer.AddAttribute(HtmlTextWriterAttribute.Name, _tree.UniqueID)
            writer.AddAttribute(HtmlTextWriterAttribute.Id, _tree.UniqueID.Replace(":", "_"))

            writer.AddAttribute("expimg", _tree.ExpandedNodeImage)
            writer.AddAttribute("colimg", _tree.CollapsedNodeImage)
            writer.AddAttribute("postback", _tree.Page.GetPostBackClientEvent(_tree, "[NodeID],Click"))
            If Len(_tree.DefaultNodeCssClassSelected) > 0 Then
                writer.AddAttribute("selclass", _tree.DefaultNodeCssClassSelected)
            End If

            writer.RenderBeginTag(HtmlTextWriterTag.Div)
            RenderChildren(writer)
            writer.RenderEndTag()
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <param name="writer"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Protected Overloads Overrides Sub RenderChildren(ByVal writer As HtmlTextWriter)
			Dim TempNode As TreeNode
			For Each TempNode In _tree.TreeNodes
				TempNode.Render(writer)
			Next
		End Sub

	End Class
End Namespace
