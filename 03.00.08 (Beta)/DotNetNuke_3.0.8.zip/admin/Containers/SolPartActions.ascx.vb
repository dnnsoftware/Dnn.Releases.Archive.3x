'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports Solpart.WebControls
Imports DotNetNuke.Entities.Modules.Actions

Namespace DotNetNuke.UI.WebControls


    Public MustInherit Class SolPartActions
        Inherits UI.Containers.ActionBase

        Protected WithEvents ctlActions As Solpart.WebControls.SolpartMenu
        Const ItemSpace As String = "&nbsp;&nbsp;"

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim intItem As Integer

                ' style sheet settings
                ctlActions.SeparateCSS = True
                ctlActions.MenuCSS.MenuBar = "ModuleTitle_MenuBar"
                ctlActions.MenuCSS.MenuContainer = "ModuleTitle_MenuContainer"
                ctlActions.MenuCSS.MenuItem = "ModuleTitle_MenuItem"
                ctlActions.MenuCSS.MenuIcon = "ModuleTitle_MenuIcon"
                ctlActions.MenuCSS.SubMenu = "ModuleTitle_SubMenu"
                ctlActions.MenuCSS.MenuBreak = "ModuleTitle_MenuBreak"
                ctlActions.MenuCSS.MenuItemSel = "ModuleTitle_MenuItemSel"
                ctlActions.MenuCSS.MenuArrow = "ModuleTitle_MenuArrow"
                ctlActions.MenuCSS.RootMenuArrow = "ModuleTitle_RootMenuArrow"

                ' generate dynamic menu
				ctlActions.SystemScriptPath = Common.Globals.ApplicationPath & "/Controls/SolpartMenu/"
				ctlActions.SystemImagesPath = Common.Globals.ApplicationPath & "/Images/"
				ctlActions.IconImagesPath = Common.Globals.ApplicationPath & "/Images/"
                ctlActions.ArrowImage = "action_right.gif"

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub ctlActions_MenuClick(ByVal ID As String) Handles ctlActions.MenuClick
            Try
                ProcessAction(ID)
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Public Sub BindMenu()
            Dim RootItemStyle As String = "background-color: Transparent; font-size: 1pt;"

            Dim objItem As System.Xml.XmlNode
            With _menuActionRoot
                ' Is Root Menu visible?
                If .Visible Then
                    ' Add Menu Root
                    objItem = ctlActions.AddMenuItem(Nothing, .ID.ToString, .Title, .Url, .Icon, sItemStyle:=RootItemStyle)
                    AddChildActions(_menuActionRoot, objItem)

                End If
            End With

            'Need to determine if the menu actually has any menu items.
            If ctlActions.MenuItems.Count > 0 And ctlActions.MenuItems(0).Children.Count > 0 And _tabPreview = False Then
                Me.Visible = True
            Else
                Me.Visible = False
            End If
        End Sub

        Private Sub AddChildActions(ByVal Parent As ModuleAction, ByVal ParentItem As System.Xml.XmlNode)
            ' Add Menu Items
            Dim _UserInfo As UserInfo = UserController.GetCurrentUserInfo

            Dim action As ModuleAction
            For Each action In Parent.Actions
                If action.Title = "~" Then
                    ctlActions.AddBreak(ParentItem)
                Else
                    If action.Visible = True And PortalSecurity.HasNecessaryPermission(action.Secure, CType(HttpContext.Current.Items("PortalSettings"), PortalSettings), ModuleConfiguration, _UserInfo.UserID.ToString) Then
                        If (EditMode = True And IsAdminTab(_PortalModule.PortalSettings.ActiveTab.TabID, _PortalModule.PortalSettings.ActiveTab.ParentId) = False And IsAdminControl() = False) Or (action.Secure <> SecurityAccessLevel.Anonymous And action.Secure <> SecurityAccessLevel.View) Then
                            Dim ItemNode As System.Xml.XmlNode
                            If Len(action.ClientScript) > 0 Then
                                Dim ScriptURL As String
                                ItemNode = ctlActions.AddMenuItem(ParentItem, action.ID.ToString, ItemSpace & action.Title, GetClientScriptURL(action), action.Icon, False)
                            Else
                                ItemNode = ctlActions.AddMenuItem(ParentItem, action.ID.ToString, ItemSpace & action.Title, action.Url, action.Icon, bRunatServer:=True)
                            End If
                            If action.HasChildren Then
                                AddChildActions(action, ItemNode)
                            End If
                        End If
                    End If
                End If
            Next
        End Sub

        Private Function GetClientScriptURL(ByVal Action As ModuleAction) As String
            Dim Script As String = Action.ClientScript

            Dim JSPos As Integer = Script.ToLower.IndexOf("javascript:")
            If JSPos > -1 Then
                Script = Script.Substring(JSPos + 11)
            End If

            Dim FormatScript As String = "javascript: if (eval({0})){{{1}}};"
            Script = String.Format(FormatScript, Script, Page.GetPostBackClientEvent(ctlActions, Action.ID.ToString))
            Return Script
        End Function

        Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
            Try
                BindMenu()

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub
    End Class
End Namespace
