'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data
Imports System.Globalization
Imports System.IO
Imports System.Xml

Namespace DotNetNuke.Entities.Modules

	Public Class ModuleControlController

		Public Function GetModuleControl(ByVal ModuleControlId As Integer) As ModuleControlInfo

			Return CType(CBO.FillObject(DataProvider.Instance().GetModuleControl(ModuleControlId), GetType(ModuleControlInfo)), ModuleControlInfo)

		End Function

		Public Function GetModuleControls(ByVal ModuleDefID As Integer) As ArrayList

			Return CBO.FillCollection(DataProvider.Instance().GetModuleControls(ModuleDefID), GetType(ModuleControlInfo))

		End Function

		Public Function GetModuleControlsByKey(ByVal ControlKey As String, ByVal ModuleDefId As Integer) As ArrayList

			Return CBO.FillCollection(DataProvider.Instance().GetModuleControlsByKey(ControlKey, ModuleDefId), GetType(ModuleControlInfo))

		End Function

		Public Function GetModuleControlByKeyAndSrc(ByVal ModuleDefId As Integer, ByVal ControlKey As String, ByVal ControlSrc As String) As ModuleControlInfo

			Return CType(CBO.FillObject(DataProvider.Instance().GetModuleControlByKeyAndSrc(ModuleDefId, ControlKey, ControlSrc), GetType(ModuleControlInfo)), ModuleControlInfo)

		End Function

		Public Sub AddModuleControl(ByVal objModuleControl As ModuleControlInfo)

			DataProvider.Instance().AddModuleControl(objModuleControl.ModuleDefID, objModuleControl.ControlKey, objModuleControl.ControlTitle, objModuleControl.ControlSrc, objModuleControl.IconFile, CType(objModuleControl.ControlType, Integer), objModuleControl.ViewOrder, objModuleControl.HelpURL)

		End Sub

		Public Sub UpdateModuleControl(ByVal objModuleControl As ModuleControlInfo)

			DataProvider.Instance().UpdateModuleControl(objModuleControl.ModuleControlID, objModuleControl.ModuleDefID, objModuleControl.ControlKey, objModuleControl.ControlTitle, objModuleControl.ControlSrc, objModuleControl.IconFile, CType(objModuleControl.ControlType, Integer), objModuleControl.ViewOrder, objModuleControl.HelpURL)

		End Sub

		Public Sub DeleteModuleControl(ByVal ModuleControlId As Integer)

			DataProvider.Instance().DeleteModuleControl(ModuleControlId)

		End Sub

	End Class

End Namespace

