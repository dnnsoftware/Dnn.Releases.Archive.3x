'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System
Imports System.IO
Imports System.Xml
Imports Microsoft.ScalableHosting.Security
Imports DotNetNuke.Security.Roles
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Modules.Definitions
Imports DotNetNuke.Entities.Tabs
Imports DotNetNuke.Entities.Users
Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Entities.Host
Imports DotNetNuke.Framework.Providers
Imports DotNetNuke.UI.Skins

Namespace DotNetNuke.Services.Upgrade

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The Upgrade class provides Shared/Static methods to Upgrade/Install
    '''	a DotNetNuke Application
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	11/6/2004	documented
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class Upgrade

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddAdminPage adds an Admin Tab Page
        ''' </summary>
        '''	<param name="Portal">The Portal</param>
        '''	<param name="TabName">The Name to give this new Tab</param>
        '''	<param name="TabIconFile">The Icon for this new Tab</param>
        '''	<param name="IsVisible">A flag indicating whether the tab is visible</param>
        ''' <history>
        ''' 	[cnurse]	11/11/2004	created 
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Overloads Shared Function AddAdminPage(ByVal Portal As PortalInfo, ByVal TabName As String, ByVal TabIconFile As String, ByVal IsVisible As Boolean) As TabInfo

            Dim objTabController As New TabController
            Dim AdminPage As TabInfo = objTabController.GetTab(Portal.AdminTabId)

            Dim objTabPermissions As New Security.Permissions.TabPermissionCollection
            AddPagePermission(objTabPermissions, "View", Convert.ToInt32(Portal.AdministratorRoleId))


            'Call AddPage with parentTab = AdminPage & RoleId = AdministratorRoleId
            Return AddPage(AdminPage, TabName, TabIconFile, IsVisible, objTabPermissions)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddAdminPages adds an Admin Page and an associated Module to all configured Portals
        ''' </summary>
        '''	<param name="TabName">The Name to give this new Tab</param>
        '''	<param name="TabIconFile">The Icon for this new Tab</param>
        '''	<param name="IsVisible">A flag indicating whether the tab is visible</param>
        '''	<param name="ModuleDefId">The Module Deinition Id for the module to be aded to this tab</param>
        '''	<param name="ModuleTitle">The Module's title</param>
        '''	<param name="ModuleIconFile">The Module's icon</param>
        ''' <history>
        ''' 	[cnurse]	11/16/2004	created 
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Overloads Shared Sub AddAdminPages(ByVal TabName As String, ByVal TabIconFile As String, ByVal IsVisible As Boolean, ByVal ModuleDefId As Integer, ByVal ModuleTitle As String, ByVal ModuleIconFile As String)

            'Call overload with InheritPermisions=True
            AddAdminPages(TabName, TabIconFile, IsVisible, ModuleDefId, ModuleTitle, ModuleIconFile, True)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddAdminPages adds an Admin Page and an associated Module to all configured Portals
        ''' </summary>
        '''	<param name="TabName">The Name to give this new Tab</param>
        '''	<param name="TabIconFile">The Icon for this new Tab</param>
        '''	<param name="IsVisible">A flag indicating whether the tab is visible</param>
        '''	<param name="ModuleDefId">The Module Deinition Id for the module to be aded to this tab</param>
        '''	<param name="ModuleTitle">The Module's title</param>
        '''	<param name="ModuleIconFile">The Module's icon</param>
        '''	<param name="InheritPermissions">Modules Inherit the Pages View Permisions</param>
        ''' <history>
        ''' 	[cnurse]	11/11/2004	created 
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Overloads Shared Sub AddAdminPages(ByVal TabName As String, ByVal TabIconFile As String, ByVal IsVisible As Boolean, ByVal ModuleDefId As Integer, ByVal ModuleTitle As String, ByVal ModuleIconFile As String, ByVal InheritPermissions As Boolean)

            Dim objPortals As New PortalController
            Dim objPortal As PortalInfo
            Dim arrPortals As ArrayList = objPortals.GetPortals
            Dim intPortal As Integer
            Dim newPage As TabInfo

            'Add Page to Admin Menu of all configured Portals
            For intPortal = 0 To arrPortals.Count - 1
                objPortal = CType(arrPortals(intPortal), PortalInfo)

                'Create New Admin Page (or get existing one)
                newPage = AddAdminPage(objPortal, TabName, TabIconFile, IsVisible)

                'Add Module To Page
                AddModuleToPage(newPage, ModuleDefId, ModuleTitle, ModuleIconFile, InheritPermissions)
            Next

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddSearchResults adds a top level Hidden Search Results Page
        ''' </summary>
        '''	<param name="ModuleDefId">The Module Deinition Id for the Search Results Module</param>
        ''' <history>
        ''' 	[cnurse]	11/11/2004	created 
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Sub AddSearchResults(ByVal ModuleDefId As Integer)

            Dim objPortals As New PortalController
            Dim objPortal As PortalInfo
            Dim arrPortals As ArrayList = objPortals.GetPortals
            Dim intPortal As Integer
            Dim newPage As TabInfo

            'Add Page to Admin Menu of all configured Portals
            For intPortal = 0 To arrPortals.Count - 1
                Dim objTabPermissions As New Security.Permissions.TabPermissionCollection

                objPortal = CType(arrPortals(intPortal), PortalInfo)

                AddPagePermission(objTabPermissions, "View", Convert.ToInt32(Common.Globals.glbRoleAllUsers))
                AddPagePermission(objTabPermissions, "View", Convert.ToInt32(objPortal.AdministratorRoleId))
                AddPagePermission(objTabPermissions, "Edit", Convert.ToInt32(objPortal.AdministratorRoleId))

                'Create New Page (or get existing one)
                newPage = AddPage(objPortal.PortalID, Null.NullInteger, "Search Results", "", False, objTabPermissions)

                'Add Module To Page
                AddModuleToPage(newPage, ModuleDefId, "Search Results", "")
            Next

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddHostPage adds a Host Tab Page
        ''' </summary>
        '''	<param name="TabName">The Name to give this new Tab</param>
        '''	<param name="TabIconFile">The Icon for this new Tab</param>
        '''	<param name="IsVisible">A flag indicating whether the tab is visible</param>
        ''' <history>
        ''' 	[cnurse]	11/11/2004	created 
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Overloads Shared Function AddHostPage(ByVal TabName As String, ByVal TabIconFile As String, ByVal IsVisible As Boolean) As TabInfo

            Dim objTabController As New TabController
            Dim HostPage As TabInfo = objTabController.GetTabByName("Host", Null.NullInteger)

            Dim objTabPermissions As New Security.Permissions.TabPermissionCollection
            AddPagePermission(objTabPermissions, "View", Convert.ToInt32(Common.Globals.glbRoleSuperUser))

            'Call AddPage with parentTab = Host & RoleId = SupeUser
            Return AddPage(HostPage, TabName, TabIconFile, IsVisible, objTabPermissions)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddModuleToPage adds a module to a Page
        ''' </summary>
        ''' <remarks>
        ''' This overload assumes ModulePermissions will be inherited
        ''' </remarks>
        '''	<param name="page">The Page to add the Module to</param>
        '''	<param name="ModuleDefId">The Module Deinition Id for the module to be aded to this tab</param>
        '''	<param name="ModuleTitle">The Module's title</param>
        '''	<param name="ModuleIconFile">The Module's icon</param>
        ''' <history>
        ''' 	[cnurse]	11/11/2004	created 
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Sub AddModuleToPage(ByVal page As TabInfo, ByVal ModuleDefId As Integer, ByVal ModuleTitle As String, ByVal ModuleIconFile As String)

            'Call overload with InheritPermisions=True
            AddModuleToPage(page, ModuleDefId, ModuleTitle, ModuleIconFile, True)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddModuleToPage adds a module to a Page
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="page">The Page to add the Module to</param>
        '''	<param name="ModuleDefId">The Module Deinition Id for the module to be aded to this tab</param>
        '''	<param name="ModuleTitle">The Module's title</param>
        '''	<param name="ModuleIconFile">The Module's icon</param>
        '''	<param name="InheritPermissions">Inherit the Pages View Permisions</param>
        ''' <history>
        ''' 	[cnurse]	11/16/2004	created 
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Sub AddModuleToPage(ByVal page As TabInfo, ByVal ModuleDefId As Integer, ByVal ModuleTitle As String, ByVal ModuleIconFile As String, ByVal InheritPermissions As Boolean)
            Dim objModules As New ModuleController
            Dim objModule As New ModuleInfo
            Dim intIndex As Integer
            Dim blnDuplicate As Boolean

            blnDuplicate = False
            Dim arrModules As ArrayList = objModules.GetPortalTabModules(page.PortalID, page.TabID)
            For intIndex = 0 To arrModules.Count - 1
                objModule = CType(arrModules(intIndex), ModuleInfo)
                If objModule.ModuleDefID = ModuleDefId Then
                    blnDuplicate = True
                End If
            Next

            If Not blnDuplicate Then
                objModule = New ModuleInfo
                objModule.ModuleID = Null.NullInteger
                objModule.PortalID = page.PortalID
                objModule.TabID = page.TabID
                objModule.ModuleOrder = -1
                objModule.ModuleTitle = ModuleTitle
                objModule.PaneName = glbDefaultPane
                objModule.ModuleDefID = ModuleDefId
                objModule.CacheTime = 0
                objModule.IconFile = ModuleIconFile
                objModule.AllTabs = False
                objModule.Visibility = VisibilityState.Maximized
                objModule.InheritViewPermissions = InheritPermissions

                Try
                    objModules.AddModule(objModule)
                Catch
                    ' error adding module
                End Try
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddPage adds a Tab Page
        ''' </summary>
        ''' <remarks>
        ''' Adds a Tab to a parentTab
        ''' </remarks>
        '''	<param name="parentTab">The Parent Tab</param>
        '''	<param name="TabName">The Name to give this new Tab</param>
        '''	<param name="TabIconFile">The Icon for this new Tab</param>
        '''	<param name="IsVisible">A flag indicating whether the tab is visible</param>
        '''	<param name="permissions">Page Permissions Collection for this page</param>
        ''' <history>
        ''' 	[cnurse]	11/11/2004	created 
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Overloads Shared Function AddPage(ByVal parentTab As TabInfo, ByVal TabName As String, ByVal TabIconFile As String, ByVal IsVisible As Boolean, ByVal permissions As Security.Permissions.TabPermissionCollection) As TabInfo

            Dim ParentId As Integer = Null.NullInteger
            Dim PortalId As Integer = Null.NullInteger

            If Not parentTab Is Nothing Then
                ParentId = parentTab.TabID
                PortalId = parentTab.PortalID
            End If

            Return AddPage(PortalId, ParentId, TabName, TabIconFile, IsVisible, permissions)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddPage adds a Tab Page
        ''' </summary>
        '''	<param name="PortalId">The Id of the Portal</param>
        '''	<param name="ParentId">The Id of the Parent Tab</param>
        '''	<param name="TabName">The Name to give this new Tab</param>
        '''	<param name="TabIconFile">The Icon for this new Tab</param>
        '''	<param name="IsVisible">A flag indicating whether the tab is visible</param>
        '''	<param name="permissions">Page Permissions Collection for this page</param>
        ''' <history>
        ''' 	[cnurse]	11/11/2004	created 
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Overloads Shared Function AddPage(ByVal PortalId As Integer, ByVal ParentId As Integer, ByVal TabName As String, ByVal TabIconFile As String, ByVal IsVisible As Boolean, ByVal permissions As Security.Permissions.TabPermissionCollection) As TabInfo

            Dim objTabs As New TabController
            Dim objTab As TabInfo

            objTab = objTabs.GetTabByName(TabName, PortalId, ParentId)
            If objTab Is Nothing Then
                objTab = New TabInfo
                objTab.TabID = Null.NullInteger
                objTab.PortalID = PortalId
                objTab.TabName = TabName
                objTab.Title = ""
                objTab.Description = ""
                objTab.KeyWords = ""
                objTab.IsVisible = IsVisible
                objTab.DisableLink = False
                objTab.ParentId = ParentId
                objTab.IconFile = TabIconFile
                objTab.AdministratorRoles = Null.NullString
                objTab.IsDeleted = False
                objTab.TabPermissions = permissions
                objTab.TabID = objTabs.AddTab(objTab)

            End If

            Return objTab


        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddPagePermission adds a TabPermission to a TabPermission Collection
        ''' </summary>
        '''	<param name="permissions">Page Permissions Collection for this page</param>
        '''	<param name="key">The Permission key</param>
        '''	<param name="roleId">The role given the permission</param>
        ''' <history>
        ''' 	[cnurse]	11/11/2004	created 
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Sub AddPagePermission(ByRef permissions As Security.Permissions.TabPermissionCollection, ByVal key As String, ByVal roleId As Integer)


            Dim objPermissionController As New Security.Permissions.PermissionController
            Dim objPermission As Security.Permissions.PermissionInfo = CType(objPermissionController.GetPermissionByCodeAndKey("SYSTEM_TAB", key)(0), Security.Permissions.PermissionInfo)

            Dim objTabPermission As New Security.Permissions.TabPermissionInfo
            objTabPermission.PermissionID = objPermission.PermissionID
            objTabPermission.RoleID = roleId
            objTabPermission.AllowAccess = True
            permissions.Add(objTabPermission)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddModuleDefinition adds a new Core Module Definition to the system
        ''' </summary>
        ''' <remarks>
        '''	This overload asumes the module is an Admin module and not a Premium Module
        ''' </remarks>
        '''	<param name="DesktopModuleName">The Friendly Name of the Module to Add</param>
        '''	<param name="Description">Description of the Module</param>
        '''	<param name="ModuleDefinitionName">The Module Definition Name</param>
        '''	<returns>The Module Definition Id of the new Module</returns>
        ''' <history>
        ''' 	[cnurse]	10/14/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Overloads Shared Function AddModuleDefinition(ByVal DesktopModuleName As String, ByVal Description As String, ByVal ModuleDefinitionName As String) As Integer
            'Call overload with Premium=False and Admin=True
            Return AddModuleDefinition(DesktopModuleName, Description, ModuleDefinitionName, False, True)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddModuleDefinition adds a new Core Module Definition to the system
        ''' </summary>
        ''' <remarks>
        '''	This overload allows the caller to determine whether the module is an Admin module 
        '''	or a Premium Module
        ''' </remarks>
        '''	<param name="DesktopModuleName">The Friendly Name of the Module to Add</param>
        '''	<param name="Description">Description of the Module</param>
        '''	<param name="ModuleDefinitionName">The Module Definition Name</param>
        '''	<param name="Premium">A flag representing whether the module is a Premium module</param>
        '''	<param name="Admin">A flag representing whether the module is an Admin module</param>
        '''	<returns>The Module Definition Id of the new Module</returns>
        ''' <history>
        ''' 	[cnurse]	10/14/2004	documented
        '''     [cnurse]    11/11/2004  removed addition of Module Control (now in AddMOduleControl)
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Overloads Shared Function AddModuleDefinition(ByVal DesktopModuleName As String, ByVal Description As String, ByVal ModuleDefinitionName As String, ByVal Premium As Boolean, ByVal Admin As Boolean) As Integer

            'Call overload with Controller=NulString and HelpUrl=NullString
            Return AddModuleDefinition(DesktopModuleName, Description, ModuleDefinitionName, Premium, Admin, Null.NullString)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddModuleDefinition adds a new Core Module Definition to the system
        ''' </summary>
        ''' <remarks>
        '''	This overload allows the caller to determine whether the module has a controller
        ''' class
        ''' </remarks>
        '''	<param name="DesktopModuleName">The Friendly Name of the Module to Add</param>
        '''	<param name="Description">Description of the Module</param>
        '''	<param name="ModuleDefinitionName">The Module Definition Name</param>
        '''	<param name="Premium">A flag representing whether the module is a Premium module</param>
        '''	<param name="Admin">A flag representing whether the module is an Admin module</param>
        '''	<param name="Controller">The Controller Class string</param>
        '''	<returns>The Module Definition Id of the new Module</returns>
        ''' <history>
        ''' 	[cnurse]	10/14/2004	documented
        '''     [cnurse]    11/11/2004  removed addition of Module Control (now in AddMOduleControl)
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Overloads Shared Function AddModuleDefinition(ByVal DesktopModuleName As String, ByVal Description As String, ByVal ModuleDefinitionName As String, ByVal Premium As Boolean, ByVal Admin As Boolean, ByVal Controller As String) As Integer
            Dim objDesktopModules As New DesktopModuleController

            ' check if desktop module exists
            Dim objDesktopModule As DesktopModuleInfo = objDesktopModules.GetDesktopModuleByName(DesktopModuleName)
            If objDesktopModule Is Nothing Then
                objDesktopModule = New DesktopModuleInfo

                objDesktopModule.DesktopModuleID = Null.NullInteger
                objDesktopModule.FriendlyName = DesktopModuleName
                objDesktopModule.Description = Description
                objDesktopModule.Version = Null.NullString
                objDesktopModule.IsPremium = Premium
                objDesktopModule.IsAdmin = Admin
                objDesktopModule.BusinessControllerClass = Controller

                objDesktopModule.DesktopModuleID = objDesktopModules.AddDesktopModule(objDesktopModule)
            End If

            Dim objModuleDefinitions As New ModuleDefinitionController

            ' check if module definition exists
            Dim objModuleDefinition As ModuleDefinitionInfo = objModuleDefinitions.GetModuleDefinitionByName(objDesktopModule.DesktopModuleID, ModuleDefinitionName)
            If objModuleDefinition Is Nothing Then
                objModuleDefinition = New ModuleDefinitionInfo

                objModuleDefinition.ModuleDefID = Null.NullInteger
                objModuleDefinition.DesktopModuleID = objDesktopModule.DesktopModuleID
                objModuleDefinition.FriendlyName = ModuleDefinitionName

                objModuleDefinition.ModuleDefID = objModuleDefinitions.AddModuleDefinition(objModuleDefinition)
            End If

            Return objModuleDefinition.ModuleDefID

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddModuleControl adds a new Module Control to the system
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="ModuleDefId">The Module Definition Id</param>
        '''	<param name="ControlKey">The key for this control in the Definition</param>
        '''	<param name="ControlTitle">The title of this control</param>
        '''	<param name="ControlSrc">Te source of ths control</param>
        '''	<param name="IconFile">The icon file</param>
        '''	<param name="ControlType">The type of control</param>
        '''	<param name="ViewOrder">The vieworder for this module</param>
        '''	<returns>The Module Definition Id of the new Module</returns>
        ''' <history>
        ''' 	[cnurse]	11/08/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Overloads Shared Sub AddModuleControl(ByVal ModuleDefId As Integer, ByVal ControlKey As String, ByVal ControlTitle As String, ByVal ControlSrc As String, ByVal IconFile As String, ByVal ControlType As SecurityAccessLevel, ByVal ViewOrder As Integer)

            'Call Overload with HelpUrl = Null.NullString
            AddModuleControl(ModuleDefId, ControlKey, ControlTitle, ControlSrc, IconFile, ControlType, ViewOrder, Null.NullString)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddModuleControl adds a new Module Control to the system
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="ModuleDefId">The Module Definition Id</param>
        '''	<param name="ControlKey">The key for this control in the Definition</param>
        '''	<param name="ControlTitle">The title of this control</param>
        '''	<param name="ControlSrc">Te source of ths control</param>
        '''	<param name="IconFile">The icon file</param>
        '''	<param name="ControlType">The type of control</param>
        '''	<param name="ViewOrder">The vieworder for this module</param>
        '''	<param name="HelpURL">The Help Url</param>
        '''	<returns>The Module Definition Id of the new Module</returns>
        ''' <history>
        ''' 	[cnurse]	11/08/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Overloads Shared Sub AddModuleControl(ByVal ModuleDefId As Integer, ByVal ControlKey As String, ByVal ControlTitle As String, ByVal ControlSrc As String, ByVal IconFile As String, ByVal ControlType As SecurityAccessLevel, ByVal ViewOrder As Integer, ByVal HelpURL As String)

            Dim objModuleControls As New ModuleControlController

            ' check if module control exists
            Dim objModuleControl As ModuleControlInfo = objModuleControls.GetModuleControlByKeyAndSrc(ModuleDefId, ControlKey, ControlSrc)
            If objModuleControl Is Nothing Then
                objModuleControl = New ModuleControlInfo

                objModuleControl.ModuleControlID = Null.NullInteger
                objModuleControl.ModuleDefID = ModuleDefId
                objModuleControl.ControlKey = ControlKey
                objModuleControl.ControlTitle = ControlTitle
                objModuleControl.ControlSrc = ControlSrc
                objModuleControl.ControlType = ControlType
                objModuleControl.ViewOrder = ViewOrder
                objModuleControl.IconFile = IconFile
                objModuleControl.HelpURL = HelpURL

                objModuleControls.AddModuleControl(objModuleControl)
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ConvertLegacyUsers converts legacy Users to the new ASP.NET MemberRole Provider (v3.0)
        ''' </summary>
        ''' <remarks>
        '''	Used in Upgrading from v2.1.2 to v3.0.x
        ''' </remarks>
        '''	<param name="dr">DataReader containing the legacy Users</param>
        ''' <history>
        ''' 	[cnurse]	11/6/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function ConvertLegacyUsers(ByVal dr As IDataReader) As ArrayList
            Dim arrUsers As New ArrayList
            Try
                While dr.Read
                    Dim objSuperUserInfo As New UserInfo
                    Try
                        objSuperUserInfo.UserID = Convert.ToInt32(dr("UserID"))
                    Catch
                    End Try
                    Try
                        objSuperUserInfo.PortalID = Convert.ToInt32(dr("PortalID"))
                    Catch
                    End Try
                    Try
                        objSuperUserInfo.IsSuperUser = Convert.ToBoolean(dr("IsSuperUser"))
                    Catch
                    End Try
                    Try
                        objSuperUserInfo.Membership.Username = Convert.ToString(dr("Username"))
                    Catch
                    End Try
                    Try
                        objSuperUserInfo.Membership.Approved = Convert.ToBoolean(dr("Authorized"))
                    Catch
                    End Try
                    Try
                        objSuperUserInfo.Membership.CreatedDate = Convert.ToDateTime(dr("CreatedDate"))
                    Catch
                    End Try
                    Try
                        objSuperUserInfo.Membership.Email = Convert.ToString(dr("Email"))
                    Catch
                    End Try
                    Try
                        objSuperUserInfo.Profile.FirstName = Convert.ToString(dr("FirstName"))
                    Catch
                    End Try
                    Try
                        objSuperUserInfo.Profile.LastName = Convert.ToString(dr("LastName"))
                    Catch
                    End Try
                    Try
                        objSuperUserInfo.Membership.Password = Convert.ToString(dr("Password"))
                    Catch
                    End Try
                    Try
                        objSuperUserInfo.Profile.City = Convert.ToString(dr("City"))
                    Catch
                    End Try
                    Try
                        objSuperUserInfo.Profile.Country = Convert.ToString(dr("Country"))
                    Catch
                    End Try
                    Try
                        objSuperUserInfo.Profile.PostalCode = Convert.ToString(dr("PostalCode"))
                    Catch
                    End Try
                    Try
                        objSuperUserInfo.Profile.Region = Convert.ToString(dr("Region"))
                    Catch
                    End Try
                    Try
                        objSuperUserInfo.Profile.Street = Convert.ToString(dr("Street"))
                    Catch
                    End Try
                    Try
                        objSuperUserInfo.Profile.Telephone = Convert.ToString(dr("Telephone"))
                    Catch
                    End Try
                    Try
                        objSuperUserInfo.Profile.Unit = Convert.ToString(dr("Unit"))
                    Catch
                    End Try

                    arrUsers.Add(objSuperUserInfo)
                End While
                Return arrUsers
            Finally
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' CoreModuleExists determines whether a Core Module exists on the system
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="DesktopModuleName">The Friendly Name of the Module</param>
        '''	<returns>True if the Module exists, otherwise False</returns>
        ''' <history>
        ''' 	[cnurse]	10/14/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function CoreModuleExists(ByVal DesktopModuleName As String) As Boolean

            Dim blnExists As Boolean = False

            Dim objDesktopModules As New DesktopModuleController

            Dim objDesktopModule As DesktopModuleInfo = objDesktopModules.GetDesktopModuleByName(DesktopModuleName)
            If Not objDesktopModule Is Nothing Then
                blnExists = True
            Else
                blnExists = False
            End If

            Return blnExists

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' DeleteFiles - clean up deprecated files and folders
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="strVersion">The Version being Upgraded</param>
        ''' <history>
        ''' 	[swalker]	11/09/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function DeleteFiles(ByVal strVersion As String) As String

            Dim strExceptions As String = ""

            Try
				Dim strListFile As String = DotNetNuke.Common.HostMapPath & strVersion & ".txt"

                If File.Exists(strListFile) Then
                    ' read list file
                    Dim objStreamReader As StreamReader
                    objStreamReader = File.OpenText(strListFile)
                    Dim arrPaths As Array = objStreamReader.ReadToEnd.Split(ControlChars.CrLf.ToCharArray())
                    objStreamReader.Close()

                    ' loop through path list
                    Dim strPath As String

                    For Each strPath In arrPaths
                        If strPath.Trim <> "" Then
                            strPath = HttpContext.Current.Server.MapPath(strPath)
                            If strPath.EndsWith("\") Then
                                ' folder
                                If Directory.Exists(strPath) Then
                                    Try ' delete the folder
                                        DotNetNuke.Common.DeleteFolderRecursive(strPath)
                                    Catch ex As Exception
                                        strExceptions += "Error: " & ex.Message & vbCrLf
                                    End Try
                                End If
                            Else
                                ' file
                                If File.Exists(strPath) Then
                                    Try ' delete the file
                                        File.SetAttributes(strPath, FileAttributes.Normal)
                                        File.Delete(strPath)
                                    Catch ex As Exception
                                        strExceptions += "Error: " & ex.Message & vbCrLf
                                    End Try
                                End If
                            End If
                        End If
                    Next
                End If

            Catch ex As Exception
                strExceptions += "Error: " & ex.Message & vbCrLf
            End Try

            Return strExceptions

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ExecuteScript executes a SQl script file
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="script">The script to Execute</param>
        '''	<param name="version">The script version</param>
        ''' <history>
        ''' 	[cnurse]	11/09/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function ExecuteScript(ByVal script As String, ByVal version As String) As String

            Dim strExceptions As String

            ' Get the name of the data provider
            Dim objProviderConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration("data")

            ' read script file for installation
            Dim strScriptFile As String = script
            Dim objStreamReader As StreamReader
            objStreamReader = File.OpenText(strScriptFile)
            Dim strScript As String = objStreamReader.ReadToEnd
            objStreamReader.Close()

            ' execute SQL installation script
            strExceptions = PortalSettings.ExecuteScript(strScript)

            '' perform version specific application upgrades
            If version <> "" Then
                strExceptions += UpgradeApplication(version)

                ' delete files which are no longer used
                strExceptions += DeleteFiles(version)
            End If

            ' log the results
            Try
                Dim objStream As StreamWriter
                objStream = File.CreateText(strScriptFile.Replace("." & objProviderConfiguration.DefaultProvider, "") & ".log")
                objStream.WriteLine(strExceptions)
                objStream.Close()
            Catch
                ' does not have permission to create the log file
            End Try

            Return strExceptions

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetModuleDefinition gets the Module Definition Id of a module
        ''' </summary>
        '''	<param name="DesktopModuleName">The Friendly Name of the Module to Add</param>
        '''	<param name="ModuleDefinitionName">The Module Definition Name</param>
        '''	<returns>The Module Definition Id of the Module (-1 if no module definition)</returns>
        ''' <history>
        ''' 	[cnurse]	11/16/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function GetModuleDefinition(ByVal DesktopModuleName As String, ByVal ModuleDefinitionName As String) As Integer
            Dim objDesktopModules As New DesktopModuleController

            ' get desktop module 
            Dim objDesktopModule As DesktopModuleInfo = objDesktopModules.GetDesktopModuleByName(DesktopModuleName)
            If objDesktopModule Is Nothing Then
                Return -1
            End If

            Dim objModuleDefinitions As New ModuleDefinitionController

            ' get module definition 
            Dim objModuleDefinition As ModuleDefinitionInfo = objModuleDefinitions.GetModuleDefinitionByName(objDesktopModule.DesktopModuleID, ModuleDefinitionName)
            If objModuleDefinition Is Nothing Then
                Return -1
            End If

            Return objModuleDefinition.ModuleDefID

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' HostTabExists determines whether a tab of a given name exists under the Host tab
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="TabName">The Name of the Tab</param>
        '''	<returns>True if the Tab exists, otherwise False</returns>
        ''' <history>
        ''' 	[cnurse]	11/08/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function HostTabExists(ByVal TabName As String) As Boolean

            Dim blnExists As Boolean = False

            Dim objTabController As New TabController

            Dim objTabInfo As TabInfo = objTabController.GetTabByName(TabName, Null.NullInteger)
            If Not objTabInfo Is Nothing Then
                blnExists = True
            Else
                blnExists = False
            End If

            Return blnExists

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Install manages the Installation of a new DotNetNuke Application
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="strProviderPath">The path to the Data Provider</param>
        ''' <history>
        ''' 	[cnurse]	11/06/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Sub Install(ByVal strProviderPath As String)

            Dim strExceptions As String = ""
            Dim intPortalId As Integer
            Dim xmlDoc As New XmlDocument
            Dim node As XmlNode
			Dim strHostPath As String = Common.Globals.HostMapPath
            Dim strVersion As String
            Dim strScript As String
            Dim strErrorMessage As String

            ' get current App version from constant (Medium Trust)
            Dim strAssemblyVersion As String = glbAppVersion.Replace(".", "")

            ' open the Install Template XML file
            Dim installTemplate As String = System.Configuration.ConfigurationSettings.AppSettings("InstallTemplate")
            Try
                xmlDoc.Load(strHostPath & installTemplate)
            Catch    ' error
                strErrorMessage += "Failed to load Install template.<br><br>"
            End Try

            'Do some simple validation
            Dim nodeSuperUser As XmlNode = xmlDoc.SelectSingleNode("//host/superuser")
            Dim strSuperUserId As String = XmlUtils.GetNodeValue(nodeSuperUser, "username")
            Dim strSuperUserPassword As String = XmlUtils.GetNodeValue(nodeSuperUser, "password")
            If strSuperUserId.Length < 4 Then
                strErrorMessage += "SuperUser username must be at least 4 characters in length.<br><br>"
            End If
            'If strSuperUserId = strSuperUserPassword Then
            '    strErrorMessage += "SuperUser username and pasword cannot be the same.<br><br>"
            'End If

            Dim nodeAdminUser As XmlNode = xmlDoc.SelectSingleNode("//host/portal/administrator")
            Dim strAdminUserId As String = XmlUtils.GetNodeValue(nodeAdminUser, "username")
            Dim strAdminUserPassword As String = XmlUtils.GetNodeValue(nodeAdminUser, "password")
            If strAdminUserId.Length < 4 Then
                strErrorMessage += "Portal Administrator username must be at least 4 characters in length.<br><br>"
            End If
            'If strAdminUserId = strAdminUserPassword Then
            '    strErrorMessage += "Portal Administrator username and pasword cannot be the same.<br><br>"
            'End If

            If strErrorMessage = "" Then
                ' parse host nodes
                node = xmlDoc.SelectSingleNode("//host")
                If Not node Is Nothing Then
                    strVersion = XmlUtils.GetNodeValue(node, "version")
                End If

                'Parse the script nodes
                node = xmlDoc.SelectSingleNode("//host/scripts")
                If Not node Is Nothing Then
                    ' Parse the desktopmodule nodes
                    For Each scriptNode As XmlNode In node.SelectNodes("script")
                        strScript = scriptNode.InnerText
                        strExceptions += ExecuteScript(strProviderPath & strScript, "")
                    Next
                End If
                ' update the version
                Dim arrVersion As Array = strVersion.Split(CType(".", Char))
                Dim intMajor As Integer = CType(arrVersion.GetValue((0)), Integer)
                Dim intMinor As Integer = CType(arrVersion.GetValue((1)), Integer)
                Dim intBuild As Integer = CType(arrVersion.GetValue((2)), Integer)
                PortalSettings.UpdateDatabaseVersion(intMajor, intMinor, intBuild)

                'Call Upgrade with the current DB Version to carry out any incremental upgrades
                Upgrade(strProviderPath, strVersion.Replace(".", ""))

                ' parse Host Settings if available
                node = xmlDoc.SelectSingleNode("//host/settings")
                If Not node Is Nothing Then
                    ParseSettings(node)
                End If

                ' parse SuperUser if Available
                node = xmlDoc.SelectSingleNode("//host/superuser")
                If Not node Is Nothing Then
                    ParseSuperUser(node)
                End If

                ' parse Desktop Modules if available
                node = xmlDoc.SelectSingleNode("//host/desktopmodules")
                If Not node Is Nothing Then
                    ParseDesktopModules(node)
                End If

                ' parse File List if available
                node = xmlDoc.SelectSingleNode("//host/files")
                If Not node Is Nothing Then
                    ParseFiles(node, Null.NullInteger)
                End If

                ' parse portal if available
                node = xmlDoc.SelectSingleNode("//host/portal")
                If Not node Is Nothing Then
                    Dim objPortalController As New PortalController
                    Dim objSecurity As New PortalSecurity
                    Dim strPortalName As String = XmlUtils.GetNodeValue(node, "portalname")
                    Dim adminNode As XmlNode = node.SelectSingleNode("administrator")
                    Dim strFirstName As String = XmlUtils.GetNodeValue(adminNode, "firstname")
                    Dim strLastName As String = XmlUtils.GetNodeValue(adminNode, "lastname")
                    Dim strUserName As String = XmlUtils.GetNodeValue(adminNode, "username")
                    Dim strPassword As String = XmlUtils.GetNodeValue(adminNode, "password")
                    Dim strEmail As String = XmlUtils.GetNodeValue(adminNode, "email")
                    Dim strDescription As String = XmlUtils.GetNodeValue(node, "description")
                    Dim strKeyWords As String = XmlUtils.GetNodeValue(node, "keywords")
                    Dim strTemplate As String = XmlUtils.GetNodeValue(node, "templatefile")
                    Dim strHomeDirectory As String = XmlUtils.GetNodeValue(node, "homedirectory")
                    Dim strPortalAlias As String = GetDomainName(HttpContext.Current.Request)
                    Dim strServerPath As String = GetAbsoluteServerPath(HttpContext.Current.Request)
                    Dim isChild As Boolean = Boolean.Parse(XmlUtils.GetNodeValue(node, "ischild"))

                    intPortalId = objPortalController.CreatePortal(strPortalName, strFirstName, strLastName, strUserName, objSecurity.Encrypt(Convert.ToString(Common.Globals.HostSettings("EncryptionKey")), strPassword), strEmail, strDescription, strKeyWords, strHostPath, strTemplate, strHomeDirectory, strPortalAlias, strServerPath, strServerPath & strPortalAlias, isChild)
                End If
            Else
                ' upgrade error
                Dim objStreamReader As StreamReader
                objStreamReader = File.OpenText(HttpContext.Current.Server.MapPath("~/500.htm"))
                Dim strHTML As String = objStreamReader.ReadToEnd
                objStreamReader.Close()
                strHTML = Replace(strHTML, "[MESSAGE]", strErrorMessage)
                If Not HttpContext.Current Is Nothing Then
                    HttpContext.Current.Response.Write(strHTML)
                    HttpContext.Current.Response.End()
                End If
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ParseDesktopModules parses the Host Template's Desktop Modules node
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="node">The Desktop Modules node</param>
        ''' <history>
        ''' 	[cnurse]	11/08/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Sub ParseDesktopModules(ByVal node As XmlNode)

            Dim desktopModuleNode As XmlNode
            Dim moduleNode As XmlNode
            Dim controlNode As XmlNode
            Dim ModuleDefID As Integer
            Dim controlType As SecurityAccessLevel

            ' Parse the desktopmodule nodes
            For Each desktopModuleNode In node.SelectNodes("desktopmodule")
                Dim strDescription As String = XmlUtils.GetNodeValue(desktopModuleNode, "description")
                Dim strVersion As String = XmlUtils.GetNodeValue(desktopModuleNode, "version")
                Dim strControllerClass As String = XmlUtils.GetNodeValue(desktopModuleNode, "businesscontrollerclass")

                ' Parse the module nodes
                For Each moduleNode In desktopModuleNode.SelectNodes("modules/module")
                    Dim strName As String = XmlUtils.GetNodeValue(moduleNode, "friendlyname")

                    ModuleDefID = AddModuleDefinition(strName, strDescription, strName, False, False, strControllerClass)

                    ' Parse the control nodes
                    For Each controlNode In moduleNode.SelectNodes("controls/control")
                        Dim strKey As String = XmlUtils.GetNodeValue(controlNode, "key")
                        Dim strTitle As String = XmlUtils.GetNodeValue(controlNode, "title")
                        Dim strSrc As String = XmlUtils.GetNodeValue(controlNode, "src")
                        Dim strIcon As String = XmlUtils.GetNodeValue(controlNode, "iconfile")
                        Dim strType As String = XmlUtils.GetNodeValue(controlNode, "type")
                        Select Case XmlUtils.GetNodeValue(controlNode, "type")
                            Case "View"
                                controlType = SecurityAccessLevel.View
                            Case "Edit"
                                controlType = SecurityAccessLevel.Edit
                        End Select
                        Dim strHelpUrl As String = XmlUtils.GetNodeValue(controlNode, "helpurl")

                        'Add Control to System
                        AddModuleControl(ModuleDefID, strKey, strTitle, strSrc, strIcon, controlType, 0, strHelpUrl)
                    Next
                Next
            Next desktopModuleNode


        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ParseFiles parses the Host Template's Files node
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="node">The Files node</param>
        '''	<param name="portalId">The PortalId (-1 for Host Files)</param>
        ''' <history>
        ''' 	[cnurse]	11/08/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Sub ParseFiles(ByVal node As XmlNode, ByVal portalId As Integer)

            Dim fileNode As XmlNode
            Dim objController As New DotNetNuke.Services.FileSystem.FileController

            'Parse the File nodes
            For Each fileNode In node.SelectNodes("file")
                Dim strFileName As String = XmlUtils.GetNodeValue(fileNode, "filename")
                Dim strExtenstion As String = XmlUtils.GetNodeValue(fileNode, "extension")
                Dim fileSize As Long = Long.Parse(XmlUtils.GetNodeValue(fileNode, "size"))
                Dim iWidth As Integer = XmlUtils.GetNodeValueInt(fileNode, "width")
                Dim iHeight As Integer = XmlUtils.GetNodeValueInt(fileNode, "height")
                Dim strType As String = XmlUtils.GetNodeValue(fileNode, "contentType")
                Dim strFolder As String = XmlUtils.GetNodeValue(fileNode, "folder")

                objController.AddFile(portalId, strFileName, strExtenstion, fileSize, iWidth, iHeight, strType, strFolder)

            Next

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ParseSettings parses the Host Template's Settings node
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="node">The settings node</param>
        ''' <history>
        ''' 	[cnurse]	11/08/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Sub ParseSettings(ByVal node As XmlNode)

            Dim settingNode As XmlNode
            Dim objController As New HostSettingsController

            'Parse the Settings nodes
            For Each settingNode In node.ChildNodes
                Dim strSettingName As String = settingNode.Name
                Dim StrSettingValue As String = settingNode.InnerText

                objController.UpdateHostSetting(strSettingName, StrSettingValue)

            Next

            'Refresh the Host Settings
            'Dim objHostSettings As New Entities.Host.HostSettings
            'Common.Globals.HostSettings = objHostSettings.GetHostSettings()

            'Need to clear the cache to pick up new HostSettings from the SQLDataProvider script
            DataCache.RemoveCache("GetHostSettings")


        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ParseSuperUser parses the Host Template's SuperUser node
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="node">The SuperUser node</param>
        ''' <history>
        ''' 	[cnurse]	11/08/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Sub ParseSuperUser(ByVal node As XmlNode)

            Dim settingNode As XmlNode
            Dim objUser As New UserController
            Dim HostId As Integer

            'Parse the SuperUsers nodes
            Dim strFirstName As String = XmlUtils.GetNodeValue(node, "firstname")
            Dim strLastName As String = XmlUtils.GetNodeValue(node, "lastname")
            Dim strUserName As String = XmlUtils.GetNodeValue(node, "username")
            Dim strPassword As String = XmlUtils.GetNodeValue(node, "password")
            Dim strEmail As String = XmlUtils.GetNodeValue(node, "email")

            ' add superuser
            Dim objSuperUserInfo As New UserInfo
            objSuperUserInfo.PortalID = -1
            objSuperUserInfo.Profile.FirstName = strFirstName
            objSuperUserInfo.Profile.LastName = strLastName
            objSuperUserInfo.Membership.Username = strUserName
            objSuperUserInfo.Membership.Password = strPassword
            objSuperUserInfo.Membership.Email = strEmail
            objSuperUserInfo.IsSuperUser = True
            objSuperUserInfo.Membership.Approved = True

            HostId = objUser.AddUser(objSuperUserInfo)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' RemoveCoreModule removes a Core Module from the system
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="DesktopModuleName">The Friendly Name of the Module to Remove</param>
        '''	<param name="ParentTabName">The Name of the parent Tab/Page for this module</param>
        '''	<param name="TabName">The Name to tab that contains the Module</param>
        '''	<param name="TabRemove">A flag to determine whether to remove the Tab if it has no
        ''	other modules</param>
        ''' <history>
        ''' 	[cnurse]	10/14/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Sub RemoveCoreModule(ByVal DesktopModuleName As String, ByVal ParentTabName As String, ByVal TabName As String, ByVal TabRemove As Boolean)

            Dim objTabs As New TabController
            Dim objTab As TabInfo
            Dim objModules As New ModuleController
            Dim objModule As New ModuleInfo
            Dim ParentId As Integer
            Dim intIndex As Integer
            Dim intModuleDefId As Integer
            Dim intDesktopModuleId As Integer

            'Find and remove the Module from the Tab
            Select Case ParentTabName
                Case "Host"
                    'TODO - when we have a need to remove a Host Module
                Case "Admin"
                    Dim objPortals As New PortalController
                    Dim objPortal As PortalInfo

                    Dim arrPortals As ArrayList = objPortals.GetPortals
                    Dim intPortal As Integer

                    'Iterate through the Portals to remove the Module from the Tab
                    For intPortal = 0 To arrPortals.Count - 1
                        objPortal = CType(arrPortals(intPortal), PortalInfo)

                        ParentId = objPortal.AdminTabId
                        objTab = objTabs.GetTabByName(TabName, objPortal.PortalID, ParentId)

                        'Get the Modules on the Tab
                        Dim arrModules As ArrayList = objModules.GetPortalTabModules(objPortal.PortalID, objTab.TabID)
                        Dim intCount As Integer = arrModules.Count

                        'Iterate through Modules to find the one we want
                        For intIndex = 0 To arrModules.Count - 1
                            objModule = DirectCast(arrModules(intIndex), ModuleInfo)
                            If objModule.FriendlyName = DesktopModuleName Then
                                'Delete the Module from the Modules list
                                objModules.DeleteModule(objModule.ModuleID)
                                intModuleDefId = objModule.ModuleDefID
                                intCount -= 1
                            End If
                        Next

                        'If Tab has no modules optionally remove tab
                        If intCount = 0 And TabRemove Then
                            objTabs.DeleteTab(objTab.TabID, objTab.PortalID)
                        End If
                    Next intPortal
            End Select

            'Delete all the Module Controls for this Definition
            Dim objModuleControls As New ModuleControlController
            Dim arrModuleControls As ArrayList = objModuleControls.GetModuleControls(intModuleDefId)
            Dim objModuleControl As ModuleControlInfo
            For intIndex = 0 To arrModuleControls.Count - 1
                objModuleControl = DirectCast(arrModuleControls(intIndex), ModuleControlInfo)
                objModuleControls.DeleteModuleControl(objModuleControl.ModuleControlID)
            Next

            'Get the Module Definition
            Dim objModuleDefinitions As New ModuleDefinitionController
            Dim objModuleDefinition As ModuleDefinitionInfo
            objModuleDefinition = objModuleDefinitions.GetModuleDefinition(intModuleDefId)
            intDesktopModuleId = objModuleDefinition.DesktopModuleID

            'Delete the Module Definition
            objModuleDefinitions.DeleteModuleDefinition(intModuleDefId)

            'Delete the Desktop Module Control
            Dim objDesktopModules As New DesktopModuleController
            objDesktopModules.DeleteDesktopModule(intDesktopModuleId)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' TransferUsersToMembershipProvider transfers legacy users to the
        '''	new ASP.NET MemberRole Architecture
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="PortalID">Id of the Portal</param>
        ''' <history>
        ''' 	[cnurse]	11/6/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Sub TransferUsersToMembershipProvider(ByVal PortalID As Integer)
            Dim arrUsers As ArrayList
            'need to call the cbo here because the new getusers method
            'will not work at this point in the upgrade process
            arrUsers = ConvertLegacyUsers(DataProvider.Instance().GetUsers(PortalID))
            TransferUsersToMembershipProvider(PortalID, arrUsers, False)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' TransferUsersToMembershipProvider transfers legacy users to the
        '''	new ASP.NET MemberRole Architecture
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="PortalID">Id of the Portal</param>
        '''	<param name="arrUsers">An ArrayList of the Users</param>
        '''	<param name="SuperUsers">A flag indicating whether the users are SuperUsers</param>
        ''' <history>
        ''' 	[cnurse]	11/6/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Sub TransferUsersToMembershipProvider(ByVal PortalID As Integer, ByVal arrUsers As ArrayList, ByVal SuperUsers As Boolean)
            Dim objUserCont As New UserController
            Dim objRoles As New Microsoft.ScalableHosting.Security.Roles
            Dim OriginalApplicationName As String = Common.Globals.GetApplicationName
            Try
                If SuperUsers Then
                    Common.Globals.SetApplicationName(Common.Globals.glbSuperUserAppName)
                Else
                    Common.Globals.SetApplicationName(PortalID)
                End If
                Dim dr As IDataReader
                Dim EncryptionKey As String = ""
                dr = DataProvider.Instance().GetHostSetting("EncryptionKey")
                If dr.Read Then
                    EncryptionKey = dr("SettingValue").ToString
                End If
                dr.Close()

                Dim i As Integer
                For i = 0 To arrUsers.Count - 1
                    Dim objUser As UserInfo
                    objUser = CType(arrUsers(i), UserInfo)
                    Dim objStatus As Microsoft.ScalableHosting.Security.MembershipCreateStatus
                    Dim strPassword As String
                    Dim objPortalSecurity As New PortalSecurity
                    strPassword = objPortalSecurity.Decrypt(EncryptionKey, objUser.Membership.Password)
                    If objUser.IsSuperUser Then
                        objUser.Membership.Approved = True
                    End If
                    Dim objMembershipUser As MembershipUser
                    objMembershipUser = Membership.CreateUser(objUser.Membership.Username, strPassword, objUser.Membership.Email, "What is your email address?", objUser.Membership.Email, objUser.Membership.Approved, objStatus)
                    If objStatus <> Microsoft.ScalableHosting.Security.MembershipCreateStatus.Success Then
                        LogException(New Exception(objStatus.ToString))
                    Else
                        Try
                            Dim objProfile As Microsoft.ScalableHosting.Profile.ProfileBase
                            objProfile = Microsoft.ScalableHosting.Profile.ProfileBase.Create(objUser.Membership.Username, True)
                            objProfile("FirstName") = objUser.Profile.FirstName
                            objProfile("LastName") = objUser.Profile.LastName
                            objProfile("Unit") = objUser.Profile.Unit
                            objProfile("Street") = objUser.Profile.Street
                            objProfile("City") = objUser.Profile.City
                            objProfile("Region") = objUser.Profile.Region
                            objProfile("PostalCode") = objUser.Profile.PostalCode
                            objProfile("Country") = objUser.Profile.Country
                            objProfile("Telephone") = objUser.Profile.Telephone
                            objProfile.Save()
                        Catch exc As Exception
                            LogException(exc)
                        End Try

                        Dim objDNNRoles As New RoleController
                        Dim arrUserRoles As String() = objDNNRoles.GetPortalRolesByUser(objUser.UserID, PortalID)
                        If Not arrUserRoles Is Nothing Then
                            Try
                                objRoles.AddUserToRoles(objUser.Membership.Username, arrUserRoles)
                            Catch exc As Exception
                                LogException(exc)
                            End Try
                        End If
                    End If
                Next
            Finally
                Common.Globals.SetApplicationName(OriginalApplicationName)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Upgrade manages the Upgrade of an exisiting DotNetNuke Application
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="strProviderPath">The path to the Data Provider</param>
        '''	<param name="strDatabaseVersion">The current Database Version</param>
        ''' <history>
        ''' 	[cnurse]	11/06/2004	created (Upgrade code extracted from AutoUpgrade)
        '''     [cnurse]    11/10/2004  version specific upgrades extracted to ExecuteScript
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Sub Upgrade(ByVal strProviderPath As String, ByVal strDatabaseVersion As String)

            Dim strExceptions As String

            ' get current App version from constant (Medium Trust)
            Dim strAssemblyVersion As String = glbAppVersion.Replace(".", "")

            ' Get the name of the data provider
            Dim objProviderConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration("data")

            ' get list of script files
            Dim strScriptVersion As String
            Dim arrScriptFiles As New ArrayList
            Dim strFile As String
            Dim arrFiles As String() = Directory.GetFiles(strProviderPath, "*." & objProviderConfiguration.DefaultProvider)
            For Each strFile In arrFiles
                ' script file name must conform to ##.##.##.DefaultProviderName
                If Len(Path.GetFileName(strFile)) = 9 + Len(objProviderConfiguration.DefaultProvider) Then
                    strScriptVersion = Path.GetFileNameWithoutExtension(strFile)
                    ' check if script file is relevant for upgrade
                    If strScriptVersion.Replace(".", "") > strDatabaseVersion And strScriptVersion.Replace(".", "") <= strAssemblyVersion Then
                        arrScriptFiles.Add(strFile)
                    End If
                End If
            Next
            arrScriptFiles.Sort()

            Dim strScriptFile As String
            For Each strScriptFile In arrScriptFiles
                strScriptVersion = Path.GetFileNameWithoutExtension(strScriptFile)

                Dim arrVersion As Array = strScriptVersion.Split(CType(".", Char))
                Dim intMajor As Integer = CType(arrVersion.GetValue((0)), Integer)
                Dim intMinor As Integer = CType(arrVersion.GetValue((1)), Integer)
                Dim intBuild As Integer = CType(arrVersion.GetValue((2)), Integer)

                ' verify script has not already been run
                If Not PortalSettings.FindDatabaseVersion(intMajor, intMinor, intBuild) Then
                    ' upgrade database schema
                    PortalSettings.UpgradeDatabaseSchema(intMajor, intMinor, intBuild)

                    ' execute script file (and version upgrades) for version
                    strExceptions = ExecuteScript(strScriptFile, strScriptVersion)

                    ' update the version
                    PortalSettings.UpdateDatabaseVersion(intMajor, intMinor, intBuild)

                    Dim objEventLog As New Services.Log.EventLog.EventLogController
                    Dim objEventLogInfo As New Services.Log.EventLog.EventLogInfo
                    objEventLogInfo.AddProperty("Upgraded DotNetNuke", "Version: " + intMajor.ToString + "." + intMinor.ToString + "." + intBuild.ToString)
                    If strExceptions.Length > 0 Then
                        objEventLogInfo.AddProperty("Warnings", strExceptions)
                    Else
                        objEventLogInfo.AddProperty("No Warnings", "")
                    End If
                    objEventLogInfo.LogTypeKey = Services.Log.EventLog.EventLogInfo.EventLogType.HOST_ALERT.ToString
                    objEventLogInfo.BypassBuffering = True
                    objEventLog.AddLog(objEventLogInfo)
                End If
            Next

            ' perform general application upgrades
            strExceptions = UpgradeApplication()
            If strExceptions <> "" Then
                Dim objEventLog As New Services.Log.EventLog.EventLogController
                Dim objEventLogInfo As New Services.Log.EventLog.EventLogInfo
                objEventLogInfo.AddProperty("Upgraded DotNetNuke", "General")
                objEventLogInfo.AddProperty("Warnings", strExceptions)
                objEventLogInfo.LogTypeKey = Services.Log.EventLog.EventLogInfo.EventLogType.HOST_ALERT.ToString
                objEventLogInfo.BypassBuffering = True
                objEventLog.AddLog(objEventLogInfo)
            End If

            Dim objPortalController As New PortalController
            Dim arrPortals As ArrayList
            arrPortals = objPortalController.GetPortals()
            Dim j As Integer
            For j = 0 To arrPortals.Count - 1
                Dim objPortal As PortalInfo
                objPortal = CType(arrPortals(j), PortalInfo)
                DataCache.RemoveCache("GetTabPermissionsByPortal" & objPortal.PortalID.ToString)
            Next
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' UpgradeApplication - This overload is used for general application upgrade operations. 
        ''' </summary>
        ''' <remarks>
        '''	Since it is not version specific and is invoked whenever the application is 
        '''	restarted, the operations must be re-executable.
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	11/6/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function UpgradeApplication() As String

            Dim strExceptions As String = ""

            Dim objTabController As New TabController
            Dim HostPage As TabInfo = objTabController.GetTabByName("Host", Null.NullInteger)
            Dim newPage As TabInfo

            Dim ModuleDefID As Integer

            Try
                ' remove the system message module from the admin tab
                ' System Messages are now managed through Localization
                If CoreModuleExists("System Messages") Then
                    RemoveCoreModule("System Messages", "Admin", "Site Settings", False)
                End If

                ' add the log viewer module to the admin tab
                If CoreModuleExists("Log Viewer") = False Then
                    ModuleDefID = AddModuleDefinition("Log Viewer", "Allows you to view log entries for portal events.", "Log Viewer")
                    AddModuleControl(ModuleDefID, "", "", "Admin/Logging/LogViewer.ascx", "", SecurityAccessLevel.Admin, 0)
                    AddModuleControl(ModuleDefID, "Edit", "Edit Log Settings", "Admin/Logging/EditLogTypes.ascx", "", SecurityAccessLevel.Host, 0)

                    'Add the Module/Page to all configured portals
                    AddAdminPages("Log Viewer", "icon_viewstats_16px.gif", True, ModuleDefID, "Log Viewer", "icon_viewstats_16px.gif")
                End If

                ' add the schedule module to the host tab
                If CoreModuleExists("Schedule") = False Then
                    ModuleDefID = AddModuleDefinition("Schedule", "Allows you to schedule tasks to be run at specified intervals.", "Schedule")
                    AddModuleControl(ModuleDefID, "", "", "Admin/Scheduling/ViewSchedule.ascx", "", SecurityAccessLevel.Admin, 0)
                    AddModuleControl(ModuleDefID, "Edit", "Edit Schedule", "Admin/Scheduling/EditSchedule.ascx", "", SecurityAccessLevel.Host, 0)
                    AddModuleControl(ModuleDefID, "History", "Schedule History", "Admin/Scheduling/ViewScheduleHistory.ascx", "", SecurityAccessLevel.Host, 0)
                    AddModuleControl(ModuleDefID, "Status", "Schedule Status", "Admin/Scheduling/ViewScheduleStatus.ascx", "", SecurityAccessLevel.Host, 0)

                    'Create New Host Page (or get existing one)
                    newPage = AddHostPage("Schedule", "icon_scheduler_16px.gif", True)

                    'Add Module To Page
                    AddModuleToPage(newPage, ModuleDefID, "Schedule", "icon_scheduler_16px.gif")
                End If

                ' add the skins module to the admin tab
                If CoreModuleExists("Skins") = False Then
                    ModuleDefID = AddModuleDefinition("Skins", "Allows you to manage your skins and containers.", "Skins")
                    AddModuleControl(ModuleDefID, "", "", "Admin/Skins/EditSkins.ascx", "", SecurityAccessLevel.Admin, 0)

                    'Add the Module/Page to all configured portals
                    AddAdminPages("Skins", "icon_skins_16px.gif", True, ModuleDefID, "Skins", "icon_skins_16px.gif")
                End If

                ' add the template module to the portals tab
                If Not CoreModuleExists("Template") Then
                    ModuleDefID = AddModuleDefinition("Template", "Allows you to export a portal template to be used to build new portals.", "Export Template")
                    AddModuleControl(ModuleDefID, "", "Export Template", "Admin/Portal/Template.ascx", "", SecurityAccessLevel.Host, 1)

                    'Create New Host Page (or get existing one)
                    newPage = AddHostPage("Portals", "", True)

                    'Add Module To Page
                    AddModuleToPage(newPage, ModuleDefID, "Export Template", "")
                End If

                ' add the language editor module to the host tab
                If Not CoreModuleExists("Languages") Then
                    ModuleDefID = AddModuleDefinition("Languages", "The Super User can manage the suported languages installed on the system.", "Languages")
                    AddModuleControl(ModuleDefID, "", "", "Admin/Localization/Languages.ascx", "", SecurityAccessLevel.Host, 0)
                    AddModuleControl(ModuleDefID, "TimeZone", "TimeZone Editor", "Admin/Localization/TimeZoneEditor.ascx", "", SecurityAccessLevel.Host, 0)
                    AddModuleControl(ModuleDefID, "Language", "Language Editor", "Admin/Localization/LanguageEditor.ascx", "", SecurityAccessLevel.Host, 0)
                    AddModuleControl(ModuleDefID, "FullEditor", "Language Editor", "Admin/Localization/LanguageEditorExt.ascx", "", SecurityAccessLevel.Host, 0)
                    AddModuleControl(ModuleDefID, "Verify", "Resource File Verifier", "Admin/Localization/ResourceVerifier.ascx", "", SecurityAccessLevel.Host, 0)
                    AddModuleControl(ModuleDefID, "Package", "Create Language Pack", "Admin/Localization/LanguagePack.ascx", "", SecurityAccessLevel.Host, 0)

                    'Create New Host Page (or get existing one)
                    newPage = AddHostPage("Languages", "icon_language_16px.gif", True)

                    'Add Module To Page
                    AddModuleToPage(newPage, ModuleDefID, "Languages", "icon_language_16px.gif")

                    ModuleDefID = AddModuleDefinition("Custom Locales", "Administrator can manage custom translations for portal.", "Custom Portal Locale")
                    AddModuleControl(ModuleDefID, "", "", "Admin/Localization/LanguageEditor.ascx", "", SecurityAccessLevel.Admin, 0)
                    AddModuleControl(ModuleDefID, "FullEditor", "Language Editor", "Admin/Localization/LanguageEditorExt.ascx", "", SecurityAccessLevel.Admin, 0)

                    'Add the Module/Page to all configured portals
                    AddAdminPages("Languages", "icon_language_16px.gif", True, ModuleDefID, "Languages", "icon_language_16px.gif")
                End If

                ' add the Search Admin module to the host tab
                If CoreModuleExists("Search Admin") = False Then
                    ModuleDefID = AddModuleDefinition("Search Admin", "The Search Admininstrator provides the ability to manage search settings.", "Search Admin")
                    AddModuleControl(ModuleDefID, "", "", "Admin/Search/SearchAdmin.ascx", "", SecurityAccessLevel.Host, 0)

                    'Create New Host Page (or get existing one)
                    newPage = AddHostPage("Search Admin", "icon_search_16px.gif", True)

                    'Add Module To Page
                    AddModuleToPage(newPage, ModuleDefID, "Search Admin", "icon_search_16px.gif")

                    'Add the Module/Page to all configured portals
                    'AddAdminPages("Search Admin", "icon_search_16px.gif", True, ModuleDefID, "Search Admin", "icon_search_16px.gif")
                End If

                ' add the Search Input module
                If CoreModuleExists("Search Input") = False Then
                    ModuleDefID = AddModuleDefinition("Search Input", "The Search Input module provides the ability to submit a search to a given search results module.", "Search Input", False, False)
                    AddModuleControl(ModuleDefID, "", "", "DesktopModules/SearchInput/SearchInput.ascx", "", SecurityAccessLevel.Anonymous, 0)
                    AddModuleControl(ModuleDefID, "Settings", "Search Input Settings", "DesktopModules/SearchInput/Settings.ascx", "", SecurityAccessLevel.Edit, 0)
                End If

                ' add the Search Results module
                If CoreModuleExists("Search Results") = False Then
                    ModuleDefID = AddModuleDefinition("Search Results", "The Search Reasults module provides the ability to display search results.", "Search Results", False, False)
                    AddModuleControl(ModuleDefID, "", "", "DesktopModules/SearchResults/SearchResults.ascx", "", SecurityAccessLevel.Anonymous, 0)
                    AddModuleControl(ModuleDefID, "Settings", "Search Results Settings", "DesktopModules/SearchResults/Settings.ascx", "", SecurityAccessLevel.Edit, 0)

                    'Add the Search Module/Page to all configured portals
                    AddSearchResults(ModuleDefID)
                End If

                ' add the site wizard module to the admin tab (but make it hidden, only available from icon bar)
                If CoreModuleExists("Site Wizard") = False Then
                    ModuleDefID = AddModuleDefinition("Site Wizard", "The Administrator can use this user-friendly wizard to set up the common features of the Portal/Site.", "Site Wizard")
                    AddModuleControl(ModuleDefID, "", "", "Admin/Portal/Sitewizard.ascx", "", SecurityAccessLevel.Admin, 0)
                    AddAdminPages("Site Wizard", "icon_sitesettings_16px.gif", False, ModuleDefID, "Site Wizard", "icon_sitesettings_16px.gif")
                End If

                ' add portal alias module
                If CoreModuleExists("Portal Aliases") = False Then
                    ModuleDefID = AddModuleDefinition("Portal Aliases", "Allows you to view portal aliases.", "Portal Aliases")
                    AddModuleControl(ModuleDefID, "", "", "Admin/Portal/PortalAlias.ascx", "", SecurityAccessLevel.Host, 0)
                    AddModuleControl(ModuleDefID, "Edit", "Portal Aliases", "Admin/Portal/EditPortalAlias.ascx", "", SecurityAccessLevel.Host, 0)

                    'Add the Module/Page to all configured portals (with InheritViewPermissions = False)
                    AddAdminPages("Site Settings", "icon_sitesettings_16px.gif", False, ModuleDefID, "Portal Aliases", "icon_sitesettings_16px.gif", False)
                End If

                'add Lists module and tab
                If HostTabExists("Lists") = False Then
                    ModuleDefID = AddModuleDefinition("Lists", "Allows you to edit common lists.", "Lists")
                    AddModuleControl(ModuleDefID, "", "", "Admin/Lists/ListEditor.ascx", "", SecurityAccessLevel.Host, 0)

                    'Create New Host Page (or get existing one)
                    newPage = AddHostPage("Lists", "icon_lists_16px.gif", True)

                    'Add Module To Page
                    AddModuleToPage(newPage, ModuleDefID, "Lists", "icon_lists_16px.gif")
                End If

                ' add the feedback settings control
                If CoreModuleExists("Feedback") = True Then
                    ModuleDefID = GetModuleDefinition("Feedback", "Feedback")
                    AddModuleControl(ModuleDefID, "Settings", "Feedback Settings", "DesktopModules/Feedback/Settings.ascx", "", SecurityAccessLevel.Edit, 0)
                End If

                If HostTabExists("Superuser Accounts") = False Then
                    'add SuperUser Accounts module and tab
                    Dim objDesktopModuleController As New DesktopModuleController
                    Dim objDesktopModuleInfo As DesktopModuleInfo
                    objDesktopModuleInfo = objDesktopModuleController.GetDesktopModuleByName("User Accounts")
                    Dim objModuleDefController As New ModuleDefinitionController
                    ModuleDefID = objModuleDefController.GetModuleDefinitionByName(objDesktopModuleInfo.DesktopModuleID, "User Accounts").ModuleDefID

                    'Create New Host Page (or get existing one)
                    newPage = AddHostPage("Superuser Accounts", "icon_users_16px.gif", True)

                    'Add Module To Page
                    AddModuleToPage(newPage, ModuleDefID, "Superuser Accounts", "icon_users_32px.gif")
                End If

                'Add Search Skin Object
                AddModuleControl(Null.NullInteger, "SEARCH", Null.NullString, "Admin/Skins/Search.ascx", "", SecurityAccessLevel.SkinObject, Null.NullInteger)

            Catch ex As Exception

                strExceptions += "Error: " & ex.Message & vbCrLf
                Try
                    LogException(ex)
                Catch
                    ' ignore
                End Try

            End Try

            Return strExceptions

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' UpgradeApplication - This overload is used for version specific application upgrade operations. 
        ''' </summary>
        ''' <remarks>
        '''	This should be used for file system modifications or upgrade operations which 
        '''	should only happen once. Database references are not recommended because future 
        '''	versions of the application may result in code incompatibilties.
        ''' </remarks>
        '''	<param name="Version">The Version being Upgraded</param>
        ''' <history>
        ''' 	[cnurse]	11/6/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Shared Function UpgradeApplication(ByVal Version As String) As String

            Dim strExceptions As String = ""

            Try

                Select Case Version
                    Case "02.00.00"
                        Dim dr As IDataReader

                        ' change portal upload directory from GUID to ID - this only executes for version 2.0.0
                        Dim strServerPath As String = HttpContext.Current.Request.MapPath(Common.Globals.ApplicationPath)
                        Dim strPortalsDirMapPath As String = FileSystemUtils.AddTrailingSlash(HttpContext.Current.Request.MapPath("Portals"))

                        dr = DataProvider.Instance().GetPortals()
                        While dr.Read
                            ' if GUID folder exists
                            If Directory.Exists(strPortalsDirMapPath & dr("GUID").ToString) = True Then
                                ' if ID folder exists ( this may happen because the 2.x release contains a default ID=0 folder )
                                If Directory.Exists(strPortalsDirMapPath & dr("PortalID").ToString) = True Then
                                    ' rename the ID folder
                                    Try
                                        Directory.Move(strPortalsDirMapPath & dr("PortalID").ToString, strServerPath & "\Portals\" & dr("PortalID").ToString & "_old")
                                    Catch ex As Exception
                                        ' error moving the directory - security issue?
                                        strExceptions += "Could Not Move Folder " & strPortalsDirMapPath & dr("GUID").ToString & " To " & strPortalsDirMapPath & dr("PortalID").ToString & ". Error: " & ex.Message & vbCrLf
                                    End Try
                                End If

                                ' move GUID folder to ID folder
                                Try
                                    Directory.Move(strPortalsDirMapPath & dr("GUID").ToString, strPortalsDirMapPath & dr("PortalID").ToString)
                                Catch ex As Exception
                                    ' error moving the directory - security issue?
                                    strExceptions += "Could Not Move Folder " & strPortalsDirMapPath & dr("GUID").ToString & " To " & strPortalsDirMapPath & dr("PortalID").ToString & ". Error: " & ex.Message & vbCrLf
                                End Try
                            End If
                        End While
                        dr.Close()

                        ' copy the default style sheet to the default portal ( if it does not already exist )
                        If File.Exists(strPortalsDirMapPath + "0\portal.css") = False Then
                            If File.Exists(HostMapPath + "portal.css") Then
                                File.Copy(HostMapPath + "portal.css", strPortalsDirMapPath + "0\portal.css")
                            End If
                        End If

                    Case "02.02.00"
                        Dim strProviderPath As String = PortalSettings.GetProviderPath()
                        If strProviderPath.StartsWith("ERROR:") Then
                            Exit Function
                        End If

                        ' these may need a different connection string
                        ' so they are not part of the script currently
                        ' -Dan
                        Dim objStreamReader As StreamReader
                        'objStreamReader = File.OpenText(strProviderPath + "InstallCommon.sql")
                        objStreamReader = File.OpenText(strProviderPath + "InstallRolesProfileMembership.sql")
                        Dim strScript As String = objStreamReader.ReadToEnd
                        objStreamReader.Close()
                        ' execute SQL installation script
                        strExceptions += PortalSettings.ExecuteScript(strScript)

                        Dim objPortalController As New PortalController
                        Dim arrPortals As ArrayList
                        arrPortals = objPortalController.GetPortals()

                        Dim OriginalApplicationName As String = Common.Globals.GetApplicationName
                        Dim objRoles As New Microsoft.ScalableHosting.Security.Roles

                        Dim intViewModulePermissionID As Integer
                        Dim intEditModulePermissionID As Integer

                        Dim intViewTabPermissionID As Integer
                        Dim intEditTabPermissionID As Integer

                        Dim intReadFolderPermissionID As Integer
                        Dim intWriteFolderPermissionID As Integer

                        Dim objPermissionController As New Security.Permissions.PermissionController
                        Dim objPermission As New Security.Permissions.PermissionInfo
                        objPermission.PermissionCode = "SYSTEM_MODULE_DEFINITION"
                        objPermission.PermissionKey = "VIEW"
                        objPermission.PermissionName = "View"
                        objPermission.ModuleDefID = Null.NullInteger
                        intViewModulePermissionID = objPermissionController.AddPermission(objPermission)

                        objPermission.PermissionKey = "EDIT"
                        objPermission.PermissionName = "Edit"
                        intEditModulePermissionID = objPermissionController.AddPermission(objPermission)

                        objPermission.PermissionCode = "SYSTEM_TAB"
                        objPermission.PermissionKey = "VIEW"
                        objPermission.PermissionName = "View Tab"
                        intViewTabPermissionID = objPermissionController.AddPermission(objPermission)

                        objPermission.PermissionKey = "EDIT"
                        objPermission.PermissionName = "Edit Tab"
                        intEditTabPermissionID = objPermissionController.AddPermission(objPermission)

                        objPermission.PermissionCode = "SYSTEM_FOLDER"
                        objPermission.PermissionKey = "READ"
                        objPermission.PermissionName = "View Folder"
                        intReadFolderPermissionID = objPermissionController.AddPermission(objPermission)

                        objPermission.PermissionKey = "WRITE"
                        objPermission.PermissionName = "Write to Folder"
                        intWriteFolderPermissionID = objPermissionController.AddPermission(objPermission)


                        Dim objFolderController As New Services.FileSystem.FolderController

                        Dim objFolderPermissionController As New Security.Permissions.FolderPermissionController
                        Dim PortalCount As Integer
                        For PortalCount = 0 To arrPortals.Count - 1
                            Dim objPortal As PortalInfo = CType(arrPortals(PortalCount), PortalInfo)
                            Dim FolderID As Integer
                            FolderID = objFolderController.AddFolder(objPortal.PortalID, "")

                            Dim objFolderPermission As New Security.Permissions.FolderPermissionInfo
                            objFolderPermission.FolderID = FolderID
                            objFolderPermission.PermissionID = intReadFolderPermissionID
                            objFolderPermission.AllowAccess = True
                            objFolderPermission.RoleID = objPortal.AdministratorRoleId
                            objFolderPermissionController.AddFolderPermission(objFolderPermission)

                            objFolderPermission.PermissionID = intWriteFolderPermissionID
                            objFolderPermissionController.AddFolderPermission(objFolderPermission)

                            'TODO: loop through folders recursively here
                            'in case they created any nested folders
                            'and assign priveledges accordingly
                        Next



                        Dim j As Integer

                        'Create super users in each portal
                        Dim arrSuperUsers As New ArrayList
                        Dim objUserController As New UserController
                        'need to call the data provider direct
                        'if you use the controller class you
                        'will not get the necessary fields back
                        'during the upgrade process

                        Dim dr As IDataReader = DataProvider.Instance().GetSuperUsers()

                        arrSuperUsers = ConvertLegacyUsers(dr)

                        TransferUsersToMembershipProvider(-1, arrSuperUsers, True)

                        For j = 0 To arrPortals.Count - 1

                            Dim objPortal As PortalInfo
                            objPortal = CType(arrPortals(j), PortalInfo)
                            Common.Globals.SetApplicationName(objPortal.PortalID)


                            Dim objRoleController As New RoleController
                            Dim arrRoles As ArrayList = objRoleController.GetPortalRoles(objPortal.PortalID)
                            Dim q As Integer
                            For q = 0 To arrRoles.Count - 1
                                Try
                                    objRoles.CreateRole(CType(arrRoles(q), RoleInfo).RoleName)
                                Catch exc As Exception
                                    LogException(exc)
                                End Try
                            Next
                            TransferUsersToMembershipProvider(objPortal.PortalID)
                        Next

                        Common.Globals.SetApplicationName(OriginalApplicationName)

                        Dim arrModuleDefinitions As ArrayList
                        Dim objModuleDefinitionController As New ModuleDefinitionController
                        arrModuleDefinitions = objModuleDefinitionController.GetModuleDefinitions(Null.NullInteger)


                        Dim arrModules As ArrayList
                        Dim objModuleController As New ModuleController
                        arrModules = objModuleController.GetAllModules()

                        Dim objModulePermissionController As New Security.Permissions.ModulePermissionController
                        Dim ModCount As Integer
                        For ModCount = 0 To arrModules.Count - 1
                            Dim objModule As ModuleInfo = CType(arrModules(ModCount), ModuleInfo)
                            Dim objModulePermission As New Security.Permissions.ModulePermissionInfo
                            objModulePermission.ModuleID = objModule.ModuleID
                            Dim k As Integer
                            Dim roles As String()
                            If objModule.AuthorizedViewRoles.IndexOf(";") > 0 Then
                                roles = Split(objModule.AuthorizedViewRoles, ";")
                                For k = 0 To roles.Length - 1
                                    If IsNumeric(roles(k)) Then
                                        objModulePermission.PermissionID = intViewModulePermissionID
                                        objModulePermission.AllowAccess = True
                                        objModulePermission.RoleID = Convert.ToInt32(roles(k))
                                        objModulePermissionController.AddModulePermission(objModulePermission)
                                    End If
                                Next
                            End If
                            If objModule.AuthorizedEditRoles.IndexOf(";") > 0 Then
                                roles = Split(objModule.AuthorizedEditRoles, ";")
                                For k = 0 To roles.Length - 1
                                    If IsNumeric(roles(k)) Then
                                        objModulePermission.PermissionID = intEditModulePermissionID
                                        objModulePermission.AllowAccess = True
                                        objModulePermission.RoleID = Convert.ToInt32(roles(k))
                                        objModulePermissionController.AddModulePermission(objModulePermission)
                                    End If
                                Next
                            End If
                        Next

                        Dim arrTabs As ArrayList
                        Dim objTabController As New TabController
                        arrTabs = objTabController.GetAllTabs

                        Dim objTabPermissionController As New Security.Permissions.TabPermissionController
                        For ModCount = 0 To arrTabs.Count - 1
                            Dim objTab As TabInfo = CType(arrTabs(ModCount), TabInfo)
                            Dim objTabPermission As New Security.Permissions.TabPermissionInfo
                            objTabPermission.TabID = objTab.TabID
                            Dim k As Integer
                            Dim roles As String()
                            If objTab.AuthorizedRoles.IndexOf(";") > 0 Then
                                roles = Split(objTab.AuthorizedRoles, ";")
                                For k = 0 To roles.Length - 1
                                    If IsNumeric(roles(k)) Then
                                        objTabPermission.PermissionID = intViewTabPermissionID
                                        objTabPermission.AllowAccess = True
                                        objTabPermission.RoleID = Convert.ToInt32(roles(k))
                                        objTabPermissionController.AddTabPermission(objTabPermission)
                                    End If
                                Next
                            End If
                            If objTab.AdministratorRoles.IndexOf(";") > 0 Then
                                roles = Split(objTab.AdministratorRoles, ";")
                                For k = 0 To roles.Length - 1
                                    If IsNumeric(roles(k)) Then
                                        objTabPermission.PermissionID = intEditTabPermissionID
                                        objTabPermission.AllowAccess = True
                                        objTabPermission.RoleID = Convert.ToInt32(roles(k))
                                        objTabPermissionController.AddTabPermission(objTabPermission)
                                    End If
                                Next
                            End If

                        Next
                    Case "03.00.01"

                        Dim arrTabs As ArrayList
                        Dim objTabController As New TabController
                        arrTabs = objTabController.GetAllTabs

                        Dim TabCount As Integer
                        For TabCount = 0 To arrTabs.Count - 1
                            Dim objTab As TabInfo = CType(arrTabs(TabCount), TabInfo)
                            If Not objTab Is Nothing Then
                                objTab.TabPath = GenerateTabPath(objTab.ParentId, objtab.TabName)
                                DataProvider.Instance().UpdateTab(objTab.TabID, objTab.TabName, objTab.IsVisible, objTab.DisableLink, objTab.ParentId, objTab.IconFile, objTab.Title, objTab.Description, objTab.KeyWords, objTab.IsDeleted, objTab.Url, objTab.SkinSrc, objTab.ContainerSrc, objTab.TabPath, objTab.StartDate, objTab.EndDate)
                            End If
                        Next
                    Case "03.00.06"
                        'Need to clear the cache to pick up new HostSettings from the SQLDataProvider script
                        DataCache.RemoveCache("GetHostSettings")
                End Select

            Catch ex As Exception

                strExceptions += "Error: " & ex.Message & vbCrLf
                Try
                    LogException(ex)
                Catch
                    ' ignore
                End Try

            End Try

            Return strExceptions

        End Function

#End Region

#Region "Public Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AutoUpgrade manages the Installation of a new DotNetNuke Application or
        '''	an Upgrade of an exisiting DotNetNuke Application 
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	11/06/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub AutoUpgrade()

            ' get path to script files
            Dim strProviderPath As String = PortalSettings.GetProviderPath()
            If Not strProviderPath.StartsWith("ERROR:") Then
                Dim strDatabaseVersion As String

                ' get current database version
                Dim dr As IDataReader = PortalSettings.GetDatabaseVersion
                If dr.Read Then
                    'Call Upgrade with the current DB Version to upgrade an
                    'existing DNN installation
                    strDatabaseVersion = Format(dr("Major"), "00") & Format(dr("Minor"), "00") & Format(dr("Build"), "00")
                    Upgrade(strProviderPath, strDatabaseVersion)
                Else
                    'Call Install
                    Install(strProviderPath)
                End If
                dr.Close()
            Else
                ' upgrade error
                Dim objStreamReader As StreamReader
                objStreamReader = File.OpenText(HttpContext.Current.Server.MapPath("~/500.htm"))
                Dim strHTML As String = objStreamReader.ReadToEnd
                objStreamReader.Close()
                strHTML = Replace(strHTML, "[MESSAGE]", strProviderPath)
                If Not HttpContext.Current Is Nothing Then
                    HttpContext.Current.Response.Write(strHTML)
                    HttpContext.Current.Response.End()
                End If
            End If

        End Sub

#End Region

    End Class

End Namespace
