'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports DotNetNuke.Entities.Tabs
Imports DotNetNuke.UI.Skins

Namespace DotNetNuke.Framework
	''' -----------------------------------------------------------------------------
	''' Project	 : DotNetNuke
	''' Class	 : CDefault
	''' 
	''' -----------------------------------------------------------------------------
	''' <summary>
	''' 
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[sun1]	1/19/2004	Created
	''' </history>
	''' -----------------------------------------------------------------------------
    Public MustInherit Class CDefault

		Inherits DotNetNuke.Framework.PageBase

        Public Comment As String = ""
        Public Title As String = ""
        Public Description As String = ""
        Public KeyWords As String = ""
        Public Copyright As String = ""
        Public Generator As String = ""
        Public Author As String = ""

        Protected ScrollTop As System.Web.UI.HtmlControls.HtmlInputHidden
        Protected SkinError As System.Web.UI.WebControls.Label
        Protected SkinPlaceHolder As System.Web.UI.WebControls.PlaceHolder

        Protected CSS As System.Web.UI.WebControls.PlaceHolder
        Protected FAVICON As System.Web.UI.WebControls.PlaceHolder

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

#End Region
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Contains the functionality to populate the Root aspx page with controls
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' - obtain PortalSettings from Current Context
        ''' - set global page settings.
        ''' - initialise reference paths to load the cascading style sheets
        ''' - add skin control placeholder.  This holds all the modules and content of the page.
        ''' </remarks>
        ''' <history>
        ''' 	[sun1]	1/19/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            '
            ' CODEGEN: This call is required by the ASP.NET Web Form Designer.
            '
            InitializeComponent()

            ' set global page settings
            InitializePage()

            ' process the current request
            ManageRequest()

            ' load skin control
            Dim ctlSkin As UserControl
            Dim objSkins As New UI.Skins.SkinController

            ' skin preview
            If (Not Request.QueryString("SkinSrc") Is Nothing) Then
                PortalSettings.ActiveTab.SkinSrc = objSkins.FormatSkinSrc(QueryStringDecode(Request.QueryString("SkinSrc")) & ".ascx", PortalSettings)
                ctlSkin = LoadSkin(PortalSettings.ActiveTab.SkinSrc)
            End If

            ' load assigned skin
            If ctlSkin Is Nothing Then
                If IsAdminControl() = True Or IsAdminTab(PortalSettings.ActiveTab.TabID, PortalSettings.ActiveTab.ParentId) = True Then
                    Dim objSkin As UI.Skins.SkinInfo
                    objSkin = objSkins.GetSkin(SkinInfo.RootSkin, PortalSettings.PortalId, SkinType.Admin)
                    If Not objSkin Is Nothing Then
                        PortalSettings.ActiveTab.SkinSrc = objSkins.FormatSkinSrc(objSkin.SkinSrc, PortalSettings)
                    Else
                        PortalSettings.ActiveTab.SkinSrc = ""
                    End If
                ElseIf PortalSettings.ActiveTab.SkinSrc <> "" Then
                    PortalSettings.ActiveTab.SkinSrc = objSkins.FormatSkinSrc(PortalSettings.ActiveTab.SkinSrc, PortalSettings)
                End If

                If PortalSettings.ActiveTab.SkinSrc <> "" Then
                    ctlSkin = LoadSkin(PortalSettings.ActiveTab.SkinSrc)
                End If
            End If

            ' error loading skin - load default
            If ctlSkin Is Nothing Then
                ' could not load skin control - load default skin
                If IsAdminControl() = True Or IsAdminTab(PortalSettings.ActiveTab.TabID, PortalSettings.ActiveTab.ParentId) = True Then
                    PortalSettings.ActiveTab.SkinSrc = Common.Globals.HostPath & SkinInfo.RootSkin & glbDefaultSkinFolder & glbDefaultAdminSkin
                Else
                    PortalSettings.ActiveTab.SkinSrc = Common.Globals.HostPath & SkinInfo.RootSkin & glbDefaultSkinFolder & glbDefaultSkin
                End If
                ctlSkin = LoadSkin(PortalSettings.ActiveTab.SkinSrc)
            End If

            ' set skin path
            PortalSettings.ActiveTab.SkinPath = objSkins.FormatSkinPath(PortalSettings.ActiveTab.SkinSrc)

            ' set skin id to an explicit short name to reduce page payload and make it standards compliant
            ctlSkin.ID = "dnn"

            ' add CSS links
            ManageStyleSheets(False)

            ' add Favicon
            ManageFavicon()

            ' add skin to page
            SkinPlaceHolder.Controls.Add(ctlSkin)

            ' add CSS links
            ManageStyleSheets(True)

		End Sub
		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Initialize the Scrolltop html control which controls the open / closed nature of each module 
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[sun1]	1/19/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Dim Scrolltop As HtmlControls.HtmlInputHidden = CType(Page.FindControl("ScrollTop"), HtmlControls.HtmlInputHidden)
            If Scrolltop.Value <> "" Then
                DotNetNuke.UI.Utilities.DNNClientAPI.AddBodyOnloadEventHandler(Page, "__dnn_setScrollTop(" & Scrolltop.Value & ");")
            End If
		End Sub
		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <remarks>
		''' - Obtain PortalSettings from Current Context
		''' - redirect to a specific tab based on name
		''' - if first time loading this page then reload to avoid caching
		''' - set page title and stylesheet
		''' - check to see if we should show the Assembly Version in Page Title 
		''' - set the background image if there is one selected
		''' - set META tags, copyright, keywords and description
		''' </remarks>
		''' <history>
		''' 	[sun1]	1/19/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub InitializePage()

			Dim objTabs As New TabController
            Dim objTab As TabInfo

			' redirect to a specific tab based on name
            If Request.QueryString("tabname") <> "" Then
                Dim strURL As String = ""

                objTab = objTabs.GetTabByName(Request.QueryString("TabName"), CType(HttpContext.Current.Items("PortalSettings"), PortalSettings).PortalId)
                If Not objTab Is Nothing Then

                    Dim actualParamCount As Integer = 0
                    For intParam As Integer = 0 To Request.QueryString.Count - 1
                        Select Case Request.QueryString.Keys(intParam).ToLower()
                            Case "tabid", "tabname"
                            Case Else
                                actualParamCount = actualParamCount + 1
                        End Select
                    Next

                    Dim params(actualParamCount) As String
                    Dim paramCount As Integer = 0
                    For intParam As Integer = 0 To Request.QueryString.Count - 1
                        Select Case Request.QueryString.Keys(intParam).ToLower()
                            Case "tabid", "tabname"
                            Case Else
                                params(paramCount) = Request.QueryString.Keys(intParam) + "=" + Request.QueryString(intParam)
                                paramCount = paramCount + 1
                        End Select
                    Next

                    Response.Redirect(NavigateURL(objTab.TabID, Null.NullString, params), True)

                End If
            End If

            ' avoid client side page caching for authenticated users
            If Request.IsAuthenticated = True Then
                Response.Cache.SetCacheability(HttpCacheability.ServerAndNoCache)
            End If

            ' page comment
            If GetHashValue(Common.Globals.HostSettings("Copyright"), "Y") = "Y" Then
                Comment += "<!--*************************************************************************************************************************************************************************-->" & vbCrLf & _
                  "<!-- DotNetNuke - http://www.dotnetnuke.com                                                                                                                                  -->" & vbCrLf & _
                  "<!-- Copyright (c) 2002-2004                                                                                                                                                 -->" & vbCrLf & _
                  "<!-- Shaun Walker - Perpetual Motion Interactive Systems Inc.                                                                                                                -->" & vbCrLf & _
                  "<!-- http://www.perpetualmotion.ca                                                                                                                                           -->" & vbCrLf & _
                  "<!-- sales@perpetualmotion.ca                                                                                                                                                -->" & vbCrLf & _
                  "<!--*************************************************************************************************************************************************************************-->" & vbCrLf
            End If

            ' set page title
            Dim strTitle As String = PortalSettings.PortalName
            For Each objTab In PortalSettings.ActiveTab.BreadCrumbs
                strTitle += " > " & objTab.TabName
            Next

            ' show copyright credits?
            If GetHashValue(Common.Globals.HostSettings("Copyright"), "Y") = "Y" Then
                strTitle += " ( DNN " & PortalSettings.Version & " )"
            End If

            ' tab title override
            If PortalSettings.ActiveTab.Title <> "" Then
                strTitle = PortalSettings.ActiveTab.Title
            End If
            Title = strTitle

            'set the background image if there is one selected
            If Not Me.FindControl("Body") Is Nothing Then
                If PortalSettings.BackgroundFile <> "" Then
                    CType(Me.FindControl("Body"), HtmlGenericControl).Attributes("background") = PortalSettings.HomeDirectory & PortalSettings.BackgroundFile
                End If
            End If

            ' META description
            If PortalSettings.ActiveTab.Description <> "" Then
                Description = PortalSettings.ActiveTab.Description
            Else
                Description = PortalSettings.Description
            End If

            ' META keywords
            If PortalSettings.ActiveTab.KeyWords <> "" Then
                KeyWords = PortalSettings.ActiveTab.KeyWords
            Else
                KeyWords = PortalSettings.KeyWords
            End If
            If GetHashValue(Common.Globals.HostSettings("Copyright"), "Y") = "Y" Then
                KeyWords += ",DotNetNuke,DNN"
            End If

            ' META copyright
            If PortalSettings.FooterText <> "" Then
                Copyright = PortalSettings.FooterText
            Else
                Copyright = "Copyright (c) " & Year(Now()) & " by " & PortalSettings.PortalName
            End If

            ' META author
            Author = PortalSettings.PortalName

            ' META generator
            If GetHashValue(Common.Globals.HostSettings("Copyright"), "Y") = "Y" Then
                Generator = "DotNetNuke " & PortalSettings.Version
            Else
                Generator = ""
            End If

		End Sub
		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <remarks>
		''' - manage affiliates
		''' - log visit to site
		''' </remarks>
		''' <history>
		''' 	[sun1]	1/19/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub ManageRequest()

			' affiliate processing
			Dim AffiliateId As Integer = -1
			If Not Request.QueryString("AffiliateId") Is Nothing Then
				If IsNumeric(Request.QueryString("AffiliateId")) Then
					AffiliateId = Int32.Parse(Request.QueryString("AffiliateId"))
					Dim objAffiliates As New Services.Vendors.AffiliateController
					objAffiliates.UpdateAffiliateStats(AffiliateId, 1, 0)

					' save the affiliateid for acquisitions
					If Request.Cookies("AffiliateId") Is Nothing Then					  ' do not overwrite
						Dim objCookie As HttpCookie = New HttpCookie("AffiliateId")
						objCookie.Value = AffiliateId.ToString
						objCookie.Expires = Now.AddYears(1)						 ' persist cookie for one year
						Response.Cookies.Add(objCookie)
					End If
				End If
			End If

			' site logging
            If PortalSettings.SiteLogHistory <> 0 Then
                ' get User ID

                ' URL Referrer
                Dim URLReferrer As String = ""
                If Not Request.UrlReferrer Is Nothing Then
                    URLReferrer = Request.UrlReferrer.ToString()
                End If

                Dim strSiteLogStorage As String = "D"
                If Convert.ToString(Common.Globals.HostSettings("SiteLogStorage")) <> "" Then
                    strSiteLogStorage = Convert.ToString(Common.Globals.HostSettings("SiteLogStorage"))
                End If
                Dim intSiteLogBuffer As Integer = 1
                If Convert.ToString(Common.Globals.HostSettings("SiteLogBuffer")) <> "" Then
                    intSiteLogBuffer = Integer.Parse(Convert.ToString(Common.Globals.HostSettings("SiteLogBuffer")))
                End If

                ' log visit
                Dim objSiteLogs As New Services.Log.SiteLog.SiteLogController

                Dim objUserInfo As UserInfo = UserController.GetCurrentUserInfo
                objSiteLogs.AddSiteLog(PortalSettings.PortalId, objUserInfo.UserID, URLReferrer, Request.Url.ToString(), Request.UserAgent, Request.UserHostAddress, Request.UserHostName, PortalSettings.ActiveTab.TabID, AffiliateId, intSiteLogBuffer, strSiteLogStorage)
            End If

		End Sub

		Private Sub ManageStyleSheets(ByVal PortalCSS As Boolean)

			' initialize reference paths to load the cascading style sheets
			Dim objCSS As Control = Me.FindControl("CSS")
			Dim objLink As HtmlGenericControl
			Dim ID As String

			Dim objCSSCache As Hashtable = CType(DataCache.GetCache("CSS"), Hashtable)
			If objCSSCache Is Nothing Then
				objCSSCache = New Hashtable
			End If

			If Not objCSS Is Nothing Then
				If PortalCSS = False Then
					' default style sheet ( required )
					ID = CreateValidID(Common.Globals.HostPath)
					objLink = New HtmlGenericControl("LINK")
					objLink.ID = ID
					objLink.Attributes("rel") = "stylesheet"
					objLink.Attributes("type") = "text/css"
					objLink.Attributes("href") = Common.Globals.HostPath & "default.css"
					objCSS.Controls.Add(objLink)

					' skin package style sheet
                    ID = CreateValidID(PortalSettings.ActiveTab.SkinPath)
					If objCSSCache.ContainsKey(ID) = False Then
                        If File.Exists(Server.MapPath(PortalSettings.ActiveTab.SkinPath) & "skin.css") Then
                            objCSSCache(ID) = PortalSettings.ActiveTab.SkinPath & "skin.css"
                        Else
                            objCSSCache(ID) = ""
                        End If
                        If Not Common.Globals.PerformanceSetting = Common.Globals.PerformanceSettings.NoCaching Then
                            DataCache.SetCache("CSS", objCSSCache)
                        End If
                    End If
					If objCSSCache(ID).ToString <> "" Then
						objLink = New HtmlGenericControl("LINK")
						objLink.ID = ID
						objLink.Attributes("rel") = "stylesheet"
						objLink.Attributes("type") = "text/css"
						objLink.Attributes("href") = objCSSCache(ID).ToString
						objCSS.Controls.Add(objLink)
					End If

					' skin file style sheet
                    ID = CreateValidID(Replace(PortalSettings.ActiveTab.SkinSrc, ".ascx", ".css"))
					If objCSSCache.ContainsKey(ID) = False Then
                        If File.Exists(Server.MapPath(Replace(PortalSettings.ActiveTab.SkinSrc, ".ascx", ".css"))) Then
                            objCSSCache(ID) = Replace(PortalSettings.ActiveTab.SkinSrc, ".ascx", ".css")
                        Else
                            objCSSCache(ID) = ""
                        End If
                        If Not Common.Globals.PerformanceSetting = Common.Globals.PerformanceSettings.NoCaching Then
                            DataCache.SetCache("CSS", objCSSCache)
                        End If
                    End If
					If objCSSCache(ID).ToString <> "" Then
						objLink = New HtmlGenericControl("LINK")
						objLink.ID = ID
						objLink.Attributes("rel") = "stylesheet"
						objLink.Attributes("type") = "text/css"
						objLink.Attributes("href") = objCSSCache(ID).ToString
						objCSS.Controls.Add(objLink)
					End If
				Else
					' portal style sheet
                    ID = CreateValidID(PortalSettings.HomeDirectory)
					objLink = New HtmlGenericControl("LINK")
					objLink.ID = ID
					objLink.Attributes("rel") = "stylesheet"
					objLink.Attributes("type") = "text/css"
                    objLink.Attributes("href") = PortalSettings.HomeDirectory & "portal.css"
					objCSS.Controls.Add(objLink)
				End If

			End If

		End Sub

        Private Sub ManageFavicon()
            Dim strFavicon As String = CType(DataCache.GetCache("FAVICON" & PortalSettings.PortalId.ToString), String)
            If strFavicon = "" Then
				If File.Exists(PortalSettings.HomeDirectoryMapPath & "favicon.ico") Then
					strFavicon = PortalSettings.HomeDirectory & "favicon.ico"
					If Not Common.Globals.PerformanceSetting = Common.Globals.PerformanceSettings.NoCaching Then
						DataCache.SetCache("FAVICON" & PortalSettings.PortalId.ToString, strFavicon)
					End If
				End If
			End If
			If strFavicon <> "" Then
				Dim objLink As HtmlGenericControl = New HtmlGenericControl("LINK")
				objLink.Attributes("rel") = "SHORTCUT ICON"
				objLink.Attributes("href") = strFavicon

				Dim ctlFavicon As Control = Me.FindControl("FAVICON")
				ctlFavicon.Controls.Add(objLink)
			End If
        End Sub

        Private Function LoadSkin(ByVal SkinPath As String) As UserControl
            Dim ctlSkin As UserControl

            Try
                If SkinPath.ToLower.IndexOf(Common.Globals.ApplicationPath.ToLower) <> -1 Then
                    SkinPath = SkinPath.Remove(0, Len(Common.Globals.ApplicationPath))
                End If
                ctlSkin = CType(LoadControl("~" & SkinPath), UserControl)
            Catch ex As Exception
                ' could not load user control
                SkinError.Text &= "<center>Could Not Load Skin: " & SkinPath & " Error: " & Server.HtmlEncode(ex.Message) & "</center><br>"
                SkinError.Visible = True
            End Try

            Return ctlSkin
        End Function

    End Class

End Namespace
