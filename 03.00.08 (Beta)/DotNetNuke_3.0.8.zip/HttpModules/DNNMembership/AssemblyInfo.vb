Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("DotNetNuke.HttpModules.DNNMembership")> 
<Assembly: AssemblyDescription("ASP.NET Open Source Portal Application DNNMembership HttpModule")> 
<Assembly: AssemblyCompany("Perpetual Motion Interactive Systems Inc.")> 
<Assembly: AssemblyProduct("http://www.dotnetnuke.com")> 
<Assembly: AssemblyCopyright("Portal engine source code is copyright &copy; 2002-YYYY by DotNetNuke. All Rights Reserved")> 
<Assembly: AssemblyTrademark("DotNetNuke")> 
<Assembly: CLSCompliant(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("7FF35751-D6A3-4DA0-A5E7-2F1AB026832B")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.*")> 
