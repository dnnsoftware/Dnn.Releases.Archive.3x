'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.Security
Imports System.Security.Principal
Imports System.Threading
Imports System.Web.Security
Imports System.IO
Imports Microsoft.ScalableHosting.Security
Imports DotNetNuke.Security.Roles

Namespace DotNetNuke.Common
	''' -----------------------------------------------------------------------------
	''' Project	 : DotNetNuke
	''' Class	 : Global
	''' 
	''' -----------------------------------------------------------------------------
	''' <summary>
	''' 
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[sun1]	1/18/2004	Created
	''' </history>
	''' -----------------------------------------------------------------------------
	Public Class Global
		Inherits System.Web.HttpApplication


        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Application_Start
        '''
        ''' Executes on the first web request into the portal application, 
        ''' when a new DLL is deployed, or when web.config is modified.
        ''' </summary>
        ''' <param name="Sender"></param>
        ''' <param name="E"></param>
        ''' <remarks>
        ''' - global variable initialization
        ''' </remarks>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Application_Start(ByVal Sender As Object, ByVal E As EventArgs)

            ' global variable initialization
            ServerName = Server.MachineName

            If HttpContext.Current.Request.ApplicationPath = "/" Then
                ApplicationPath = ""
            Else
                ApplicationPath = HttpContext.Current.Request.ApplicationPath
            End If
            ApplicationMapPath = HttpContext.Current.Server.MapPath(ApplicationPath)

            HostPath = ApplicationPath & "/Portals/_default/"
            HostMapPath = HttpContext.Current.Server.MapPath(HostPath)

            AssemblyPath = HttpContext.Current.Server.MapPath(ApplicationPath & "/bin/dotnetnuke.dll")

        End Sub

        Private Sub Application_AuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)

        End Sub

        Private Sub Application_AuthorizeRequest(ByVal sender As Object, ByVal e As System.EventArgs)

        End Sub

        Private Sub Application_BeginRequest(ByVal sender As Object, ByVal e As EventArgs)

        End Sub

        Private Sub Application_End(ByVal Sender As Object, ByVal E As EventArgs)

        End Sub

        Private Sub Application_EndRequest(ByVal sender As Object, ByVal e As System.EventArgs)

        End Sub

        Private Sub Application_Error(ByVal sender As Object, ByVal e As EventArgs)

        End Sub

    End Class

End Namespace
