'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.Services.Search
Imports System
Imports System.Configuration
Imports System.Data
Imports System.xml

Namespace DotNetNuke.Modules.Links
 

    ''' -----------------------------------------------------------------------------
    ''' Namespace:  DotNetNuke.Modules.Links
    ''' Project:    DotNetNuke
    ''' Class:      LinkController
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The LinkController Class represents the Links Business Layer
    ''' Methods in this class call methods in the Data Layer
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	9/23/2004	Moved Links to a separate Project
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class LinkController
        Implements Entities.Modules.ISearchable
        Implements Entities.Modules.IPortable
#Region "Pulic Methods"

        Public Sub AddLink(ByVal objLink As LinkInfo)

            DataProvider.Instance().AddLink(objLink.ModuleId, objLink.CreatedByUser, objLink.Title, objLink.Url, objLink.ViewOrder.ToString, objLink.Description)

        End Sub

        Public Sub DeleteLink(ByVal ItemID As Integer)

            DataProvider.Instance().DeleteLink(ItemID)

        End Sub

        Public Function GetLink(ByVal ItemID As Integer, ByVal ModuleId As Integer) As LinkInfo

            Return CType(CBO.FillObject(DataProvider.Instance().GetLink(ItemID, ModuleId), GetType(LinkInfo)), LinkInfo)

        End Function

        Public Function GetLinks(ByVal ModuleId As Integer) As ArrayList

            Return CBO.FillCollection(DataProvider.Instance().GetLinks(ModuleId), GetType(LinkInfo))

        End Function

        Public Sub UpdateLink(ByVal objLink As LinkInfo)

            DataProvider.Instance().UpdateLink(objLink.ItemId, objLink.CreatedByUser, objLink.Title, objLink.Url, objLink.ViewOrder.ToString, objLink.Description)

        End Sub

#End Region

#Region "Optional Interfaces"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetSearchItems implements the ISearchable Interface
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModInfo">The ModuleInfo for the module to be Indexed</param>
        ''' <history>
        '''		[cnurse]	11/17/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            Dim SearchItemCollection As New SearchItemInfoCollection

            Dim Links As ArrayList = GetLinks(ModInfo.ModuleID)

            Dim objLink As Object
            For Each objLink In Links
                Dim SearchItem As SearchItemInfo
                With CType(objLink, LinkInfo)
                    ' 
                    Dim UserId As Integer = Null.NullInteger
                    If IsNumeric(.CreatedByUser) Then
                        UserId = Integer.Parse(.CreatedByUser)
                    End If
                    SearchItem = New SearchItemInfo(ModInfo.ModuleTitle & " - " & .Title, .Description, UserId, .CreatedDate, ModInfo.ModuleID, .ItemId.ToString, .Description, "ItemId=" & .ItemId.ToString, Null.NullInteger)
                    SearchItemCollection.Add(SearchItem)
                End With
            Next

            Return SearchItemCollection
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ExportModule implements the IPortable ExportModule Interface
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModuleID">The Id of the module to be exported</param>
        ''' <history>
        '''		[cnurse]	11/17/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
            Dim strXML As String = ""

            Dim arrLinks As ArrayList = GetLinks(ModuleID)
            If arrLinks.Count <> 0 Then
                strXML += "<links>"
                Dim objLink As LinkInfo
                For Each objLink In arrLinks
                    strXML += "<link>"
                    strXML += "<title>" & XMLEncode(objLink.Title) & "</title>"
                    strXML += "<url>" & XMLEncode(objLink.Url) & "</url>"
                    strXML += "<vieworder>" & XMLEncode(objLink.ViewOrder.ToString) & "</vieworder>"
                    strXML += "<description>" & XMLEncode(objLink.Description) & "</description>"
                    strXML += "<newwindow>" & XMLEncode(objLink.NewWindow.ToString) & "</newwindow>"
                    strXML += "</link>"
                Next
                strXML += "</links>"
            End If

            Return strXML

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ImportModule implements the IPortable ImportModule Interface
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModuleID">The Id of the module to be imported</param>
        ''' <history>
        '''		[cnurse]	11/17/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserId As Integer) Implements Entities.Modules.IPortable.ImportModule
            Dim xmlLink As XmlNode
            Dim xmlLinks As XmlNode = GetContent(Content, "links")
            For Each xmlLink In xmlLinks.SelectNodes("link")
                Dim objLink As New LinkInfo
                objLink.ModuleId = ModuleID
                objLink.Title = xmlLink.Item("title").InnerText
                objLink.Url = xmlLink.Item("url").InnerText
                objLink.ViewOrder = Integer.Parse(xmlLink.Item("vieworder").InnerText)
                objLink.Description = xmlLink.Item("description").InnerText
                objLink.NewWindow = Boolean.Parse(xmlLink.Item("newwindow").InnerText)
                objLink.CreatedByUser = UserId.ToString
                AddLink(objLink)
            Next

        End Sub

#End Region
    End Class

End Namespace
