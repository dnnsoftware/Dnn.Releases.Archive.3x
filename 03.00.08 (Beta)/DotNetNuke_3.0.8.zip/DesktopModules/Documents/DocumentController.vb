'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports DotNetNuke.Services.Search
Imports System
Imports System.Configuration
Imports System.Data
Imports DotNetNuke
Imports System.XML


Namespace DotNetNuke.Modules.Documents

    ''' -----------------------------------------------------------------------------
    ''' Namespace:  DotNetNuke.Modules.Documents
    ''' Project:    DotNetNuke
    ''' Class:      DocumentController
    ''' -----------------------------------------------------------------------------
    ''' <summary>
  ''' The DocumentController Class represents the Documents Business Layer
  ''' Methods in this class call methods in the Data Layer
  ''' </summary>
  ''' <returns></returns>
  ''' <remarks>
  ''' </remarks>
  ''' <history>
  ''' 	[cnurse]	9/22/2004	Moved Documents to a separate Project
  ''' </history>
  ''' -----------------------------------------------------------------------------
    Public Class DocumentController
        Implements Entities.Modules.ISearchable
        Implements Entities.Modules.IPortable

#Region "Public Methods"

        Public Sub AddDocument(ByVal objDocument As DocumentInfo)

            DataProvider.Instance().AddDocument(objDocument.ModuleId, objDocument.Title, objDocument.Url, objDocument.CreatedByUser, objDocument.Category)

        End Sub

        Public Sub DeleteDocument(ByVal ItemID As Integer)

            DataProvider.Instance().DeleteDocument(ItemID)

        End Sub

        Public Function GetDocument(ByVal ItemId As Integer, ByVal ModuleId As Integer) As DocumentInfo

            Return CType(CBO.FillObject(DataProvider.Instance().GetDocument(ItemId, ModuleId), GetType(DocumentInfo)), DocumentInfo)

        End Function

        Public Function GetDocuments(ByVal ModuleId As Integer, ByVal PortalId As Integer) As ArrayList

            Return CBO.FillCollection(DataProvider.Instance().GetDocuments(ModuleId, PortalId), GetType(DocumentInfo))

        End Function

        Public Sub UpdateDocument(ByVal objDocument As DocumentInfo)

            DataProvider.Instance().UpdateDocument(objDocument.ItemId, objDocument.Title, objDocument.Url, objDocument.CreatedByUser, objDocument.Category)

        End Sub

#End Region

#Region "Optional Interfaces"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetSearchItems implements the ISearchable Interface
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModInfo">The ModuleInfo for the module to be Indexed</param>
        ''' <history>
        '''		[cnurse]	11/17/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            Dim SearchItemCollection As New SearchItemInfoCollection
            Dim Documents As ArrayList = GetDocuments(ModInfo.ModuleID, ModInfo.PortalID)

            Dim objDocument As Object
            For Each objDocument In Documents
                Dim SearchItem As SearchItemInfo
                With CType(objDocument, DocumentInfo)
                    Dim UserId As Integer = Null.NullInteger
                    If IsNumeric(.CreatedByUser) Then
                        UserId = Integer.Parse(.CreatedByUser)
                    End If
                    SearchItem = New SearchItemInfo(ModInfo.ModuleTitle & " - " & .Title, .Title, UserId, .CreatedDate, ModInfo.ModuleID, .ItemId.ToString, .Title, "ItemId=" & .ItemId.ToString)
                    SearchItemCollection.Add(SearchItem)
                End With
            Next

            Return SearchItemCollection
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ExportModule implements the IPortable ExportModule Interface
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModuleID">The Id of the module to be exported</param>
        ''' <history>
        '''		[cnurse]	11/17/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
            Dim strXML As String = ""

            Dim objModules As New Entities.Modules.ModuleController
            Dim objModule As Entities.Modules.ModuleInfo = objModules.GetModule(ModuleID, Null.NullInteger)

            Dim arrDocuments As ArrayList = GetDocuments(ModuleID, objModule.PortalID)
            If arrDocuments.Count <> 0 Then
                strXML += "<documents>"
                Dim objDocument As DocumentInfo
                For Each objDocument In arrDocuments
                    strXML += "<document>"
                    strXML += "<title>" & XMLEncode(objDocument.Title) & "</title>"
                    strXML += "<url>" & XMLEncode(objDocument.Url) & "</url>"
                    strXML += "<category>" & XMLEncode(objDocument.Category) & "</category>"
                    strXML += "</document>"
                Next
                strXML += "</documents>"
            End If

            Return strXML

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ImportModule implements the IPortable ImportModule Interface
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModuleID">The Id of the module to be imported</param>
        ''' <history>
        '''		[cnurse]	11/17/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserId As Integer) Implements Entities.Modules.IPortable.ImportModule
            Dim xmlDocument As XmlNode
            Dim xmlDocuments As XmlNode = GetContent(Content, "documents")
            For Each xmlDocument In xmlDocuments.SelectNodes("document")
                Dim objDocument As New DocumentInfo
                objDocument.ModuleId = ModuleID
                objDocument.Title = xmlDocument.Item("title").InnerText
                objDocument.Url = xmlDocument.Item("url").InnerText
                objDocument.Category = xmlDocument.Item("category").InnerText
                objDocument.CreatedByUser = UserId.ToString
                AddDocument(objDocument)
            Next
        End Sub

#End Region

    End Class

End Namespace
