'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Modules.Definitions
Imports DotNetNuke.Entities.Tabs


Namespace DotNetNuke.UI.ControlPanels

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' The IconBar ControlPanel provides an icon bar based Page/Module manager
	''' </summary>
	''' <returns></returns>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[cnurse]	10/06/2004	Updated to reflect design changes for Help, 508 support
	'''                       and localisation
	''' </history>
	''' -----------------------------------------------------------------------------
    Public MustInherit Class IconBar
        Inherits ControlPanelBase

#Region "Controls"

        Protected lblPageFunctons As System.Web.UI.WebControls.Label
        Protected imgAddTabIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdAddTabIcon As System.Web.UI.WebControls.LinkButton
        Protected imgEditTabIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdEditTabIcon As System.Web.UI.WebControls.LinkButton
        Protected imgDeleteTabIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdDeleteTabIcon As System.Web.UI.WebControls.LinkButton
        Protected imgCopyTabIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdCopyTabIcon As System.Web.UI.WebControls.LinkButton
        Protected imgPreviewTabIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdPreviewTabIcon As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdAddTab As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdEditTab As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDeleteTab As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCopyTab As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdPreviewTab As System.Web.UI.WebControls.LinkButton

        'Protected lblAddModule As System.Web.UI.WebControls.Label
        Protected WithEvents optModuleType As System.Web.UI.WebControls.RadioButtonList
        Protected lblModule As System.Web.UI.WebControls.Label
        Protected WithEvents cboTabs As System.Web.UI.WebControls.DropDownList
        Protected cboDesktopModules As System.Web.UI.WebControls.DropDownList
        Protected lblPane As System.Web.UI.WebControls.Label
        Protected cboPanes As System.Web.UI.WebControls.DropDownList
        Protected lblTitle As System.Web.UI.WebControls.Label
        Protected cboModules As System.Web.UI.WebControls.DropDownList
        Protected txtTitle As System.Web.UI.WebControls.TextBox
        Protected lblAlign As System.Web.UI.WebControls.Label
        Protected cboAlign As System.Web.UI.WebControls.DropDownList
        Protected imgAddModuleIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdAddModuleIcon As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdAddModule As System.Web.UI.WebControls.LinkButton

        Protected lblCommonTasks As System.Web.UI.WebControls.Label
        Protected imgWizardIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdWizardIcon As System.Web.UI.WebControls.LinkButton
        Protected imgSiteIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdSiteIcon As System.Web.UI.WebControls.LinkButton
        Protected imgUsersIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdUsersIcon As System.Web.UI.WebControls.LinkButton
        Protected imgFilesIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdFilesIcon As System.Web.UI.WebControls.LinkButton
        Protected imgHelpIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdHelpIcon As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdWizard As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdSite As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdUsers As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdFiles As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblPageFunctions As System.Web.UI.WebControls.Label
        Protected WithEvents chkVisible As System.Web.UI.WebControls.CheckBox
        Protected WithEvents cmdHelp As System.Web.UI.WebControls.LinkButton

#End Region

#Region "Private Methods"

        Private Function BuildURL(ByVal PortalID As Integer, ByVal TabName As String, ByVal ModuleTitle As String, ByVal ControlKey As String) As String

            Dim strURL As String = "~/" & glbDefaultPage

            If TabName <> "" Then
                Dim objTabs As New TabController
                Dim objTab As TabInfo = objTabs.GetTabByName(TabName, PortalID, Null.NullInteger)
                If Not objTab Is Nothing Then
                    strURL = NavigateURL(objTab.TabID)

                    If ModuleTitle <> "" Then
                        Dim objModules As New ModuleController
                        Dim arrModules As ArrayList = objModules.GetPortalTabModules(PortalID, objTab.TabID)
                        Dim objModule As ModuleInfo
                        Dim intModule As Integer
                        For intModule = 0 To arrModules.Count - 1
                            If CType(arrModules(intModule), ModuleInfo).ModuleTitle = ModuleTitle Then
                                objModule = CType(arrModules(intModule), ModuleInfo)
                            End If
                        Next intModule

                        If Not objModule Is Nothing Then
                            If ControlKey <> "" Then
                                strURL = NavigateURL(objTab.TabID, ControlKey, "mid=" & objModule.ModuleID.ToString)
                            Else
                                strURL = NavigateURL(objTab.TabID, Null.NullString, "mid=" & objModule.ModuleID.ToString)
                            End If
                        End If
                    End If
                End If
            End If

            Return strURL

        End Function

        Private Sub BindData()

            Select Case optModuleType.SelectedItem.Value
                Case "0" ' new module
                    cboTabs.Visible = False
                    cboModules.Visible = False
                    cboDesktopModules.Visible = True
                    txtTitle.Visible = True
                    lblModule.Text = Services.Localization.Localization.GetString("Module", Me.LocalResourceFile)
                    lblTitle.Text = Services.Localization.Localization.GetString("Title", Me.LocalResourceFile)

                    Dim objDesktopModules As New DesktopModuleController
                    cboDesktopModules.DataSource = objDesktopModules.GetDesktopModulesByPortal(PortalSettings.PortalId)
                    cboDesktopModules.DataBind()
                    cboDesktopModules.Items.Insert(0, New ListItem("<" + Services.Localization.Localization.GetString("None_Specified") + ">", "-1"))
                Case "1" ' existing module
                    cboTabs.Visible = True
                    cboModules.Visible = True
                    cboDesktopModules.Visible = False
                    txtTitle.Visible = False
                    lblModule.Text = Services.Localization.Localization.GetString("Tab", Me.LocalResourceFile)
                    lblTitle.Text = Services.Localization.Localization.GetString("Module", Me.LocalResourceFile)

                    Dim arrTabs As ArrayList = GetPortalTabs(PortalSettings.DesktopTabs, True, True)
                    Dim intTab As Integer
                    For intTab = 0 To arrTabs.Count - 1
                        If CType(arrTabs(intTab), TabInfo).TabID = PortalSettings.ActiveTab.TabID Then
                            arrTabs.RemoveAt(intTab)
                            Exit For
                        End If
                    Next intTab
                    cboTabs.DataSource = arrTabs
                    cboTabs.DataBind()
            End Select

        End Sub

#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded.
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	10/06/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                If Not Page.IsPostBack Then

                    ' localization
                    lblPageFunctions.Text = Services.Localization.Localization.GetString("PageFunctions", Me.LocalResourceFile)
                    optModuleType.Items.FindByValue("0").Selected = True
                    'lblAddModule.Text = Services.Localization.Localization.GetString("AddNewModule", Me.LocalResourceFile)
                    lblCommonTasks.Text = Services.Localization.Localization.GetString("CommonTasks", Me.LocalResourceFile)
                    imgAddTabIcon.AlternateText = Services.Localization.Localization.GetString("AddTab.AlternateText", Me.LocalResourceFile)
                    cmdAddTab.Text = Services.Localization.Localization.GetString("AddTab", Me.LocalResourceFile)
                    imgEditTabIcon.AlternateText = Services.Localization.Localization.GetString("EditTab.AlternateText", Me.LocalResourceFile)
                    cmdEditTab.Text = Services.Localization.Localization.GetString("EditTab", Me.LocalResourceFile)
                    imgDeleteTabIcon.AlternateText = Services.Localization.Localization.GetString("DeleteTab.AlternateText", Me.LocalResourceFile)
                    cmdDeleteTab.Text = Services.Localization.Localization.GetString("DeleteTab", Me.LocalResourceFile)
                    imgCopyTabIcon.AlternateText = Services.Localization.Localization.GetString("CopyTab.AlternateText", Me.LocalResourceFile)
                    cmdCopyTab.Text = Services.Localization.Localization.GetString("CopyTab", Me.LocalResourceFile)
                    imgPreviewTabIcon.AlternateText = Services.Localization.Localization.GetString("PreviewTab.AlternateText", Me.LocalResourceFile)
                    cmdPreviewTab.Text = Services.Localization.Localization.GetString("PreviewTab", Me.LocalResourceFile)
                    lblModule.Text = Services.Localization.Localization.GetString("Module", Me.LocalResourceFile)
                    lblPane.Text = Services.Localization.Localization.GetString("Pane", Me.LocalResourceFile)
                    lblTitle.Text = Services.Localization.Localization.GetString("Title", Me.LocalResourceFile)
                    lblAlign.Text = Services.Localization.Localization.GetString("Align", Me.LocalResourceFile)
                    imgAddModuleIcon.AlternateText = Services.Localization.Localization.GetString("AddModule.AlternateText", Me.LocalResourceFile)
                    cmdAddModule.Text = Services.Localization.Localization.GetString("AddModule", Me.LocalResourceFile)
                    imgWizardIcon.AlternateText = Services.Localization.Localization.GetString("Wizard.AlternateText", Me.LocalResourceFile)
                    cmdWizard.Text = Services.Localization.Localization.GetString("Wizard", Me.LocalResourceFile)
                    imgSiteIcon.AlternateText = Services.Localization.Localization.GetString("Site.AlternateText", Me.LocalResourceFile)
                    cmdSite.Text = Services.Localization.Localization.GetString("Site", Me.LocalResourceFile)
                    imgUsersIcon.AlternateText = Services.Localization.Localization.GetString("Users.AlternateText", Me.LocalResourceFile)
                    cmdUsers.Text = Services.Localization.Localization.GetString("Users", Me.LocalResourceFile)
                    imgFilesIcon.AlternateText = Services.Localization.Localization.GetString("Files.AlternateText", Me.LocalResourceFile)
                    cmdFiles.Text = Services.Localization.Localization.GetString("Files", Me.LocalResourceFile)
                    imgHelpIcon.AlternateText = Services.Localization.Localization.GetString("Help.AlternateText", Me.LocalResourceFile)
                    cmdHelp.Text = Services.Localization.Localization.GetString("Help", Me.LocalResourceFile)

                    If IsAdminTab(PortalSettings.ActiveTab.TabID, PortalSettings.ActiveTab.ParentId) Then
                        imgEditTabIcon.ImageUrl = "~/Admin/ControlPanel/images/iconbar_edittab_bw.gif"
                        cmdEditTab.Enabled = False
                        cmdEditTabIcon.Enabled = False
                        imgDeleteTabIcon.ImageUrl = "~/Admin/ControlPanel/images/iconbar_deletetab_bw.gif"
                        cmdDeleteTab.Enabled = False
                        cmdDeleteTabIcon.Enabled = False
                        imgCopyTabIcon.ImageUrl = "~/Admin/ControlPanel/images/iconbar_copytab_bw.gif"
                        cmdCopyTab.Enabled = False
                        cmdCopyTabIcon.Enabled = False
                        imgPreviewTabIcon.ImageUrl = "~/Admin/ControlPanel/images/iconbar_previewtab_bw.gif"
                        cmdPreviewTab.Enabled = False
                        cmdPreviewTabIcon.Enabled = False
                    Else
                        cmdDeleteTab.Attributes.Add("onClick", "javascript:return confirm('" & Services.Localization.Localization.GetString("DeleteTabConfirm", Me.LocalResourceFile) & "');")
                        cmdDeleteTabIcon.Attributes.Add("onClick", "javascript:return confirm('" & Services.Localization.Localization.GetString("DeleteTabConfirm", Me.LocalResourceFile) & "');")
                    End If

                    If IsAdminControl() Then
                        cmdAddModule.Enabled = False
                        imgAddModuleIcon.ImageUrl = "~/Admin/ControlPanel/images/iconbar_addmodule_bw.gif"
                        cmdAddModuleIcon.Enabled = False
                    End If

                    BindData()

                    Dim intItem As Integer
                    For intItem = 0 To PortalSettings.ActiveTab.Panes.Count - 1
                        cboPanes.Items.Add(Convert.ToString(PortalSettings.ActiveTab.Panes(intItem)))
                    Next intItem
                    cboPanes.Items.FindByValue(glbDefaultPane).Selected = True

                    If cboAlign.Items.Count > 0 Then
                        cboAlign.SelectedIndex = 0
                    End If

                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' PageFunctions_Click runs when any button in the Page toolbar is clicked
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	10/06/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub PageFunctions_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAddTab.Click, cmdAddTabIcon.Click, cmdEditTab.Click, cmdEditTabIcon.Click, cmdDeleteTab.Click, cmdDeleteTabIcon.Click, cmdCopyTab.Click, cmdCopyTabIcon.Click, cmdPreviewTab.Click, cmdPreviewTabIcon.Click
            Try

                Dim URL As String = Request.RawUrl

                Select Case CType(sender, LinkButton).ID
                    Case "cmdAddTab", "cmdAddTabIcon"
                        URL = NavigateURL("Tab")
                    Case "cmdEditTab", "cmdEditTabIcon"
                        URL = NavigateURL(PortalSettings.ActiveTab.TabID, "Tab", "action=edit")
                    Case "cmdDeleteTab", "cmdDeleteTabIcon"
                        URL = NavigateURL(PortalSettings.ActiveTab.TabID, "Tab", "action=delete")
                    Case "cmdCopyTab", "cmdCopyTabIcon"
                        URL = NavigateURL(PortalSettings.ActiveTab.TabID, "Tab", "action=copy")
                    Case "cmdPreviewTab", "cmdPreviewTabIcon"
                        Dim objPreview As HttpCookie

                        If Request.Cookies("_Tab_Admin_Preview" & PortalSettings.PortalId.ToString) Is Nothing Then
                            objPreview = New HttpCookie("_Tab_Admin_Preview" & PortalSettings.PortalId.ToString)
                            objPreview.Value = "False"
                            objPreview.Expires = DateTime.MaxValue       ' never expires
                            Response.AppendCookie(objPreview)
                        End If

                        objPreview = Request.Cookies("_Tab_Admin_Preview" & PortalSettings.PortalId.ToString)
                        If objPreview.Value = "True" Then
                            objPreview.Value = "False"
                        Else
                            objPreview.Value = "True"
                        End If
                        Response.SetCookie(objPreview)
                End Select

                Response.Redirect(URL, True)

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' CommonTasks_Click runs when any button in the Common Tasks toolbar is clicked
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	10/06/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub CommonTasks_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdWizard.Click, cmdWizardIcon.Click, cmdSite.Click, cmdSiteIcon.Click, cmdUsers.Click, cmdUsersIcon.Click, cmdFiles.Click, cmdFilesIcon.Click, cmdHelp.Click, cmdHelpIcon.Click
            Try

                Dim URL As String = Request.RawUrl

                Select Case CType(sender, LinkButton).ID
                    Case "cmdWizard", "cmdWizardIcon"
                        URL = BuildURL(PortalSettings.PortalId, "Site Wizard", "", "")
                    Case "cmdSite", "cmdSiteIcon"
                        URL = BuildURL(PortalSettings.PortalId, "Site Settings", "", "")
                    Case "cmdUsers", "cmdUsersIcon"
                        URL = BuildURL(PortalSettings.PortalId, "User Accounts", "Manage Users", "")
                    Case "cmdFiles", "cmdFilesIcon"
                        URL = BuildURL(PortalSettings.PortalId, "File Manager", "File Manager", "Edit")
                    Case "cmdHelp", "cmdHelpIcon"
                        If PortalSettings.HostSettings("HostURL").ToString <> "" Then
                            URL = AddHTTP(PortalSettings.HostSettings("HostURL").ToString)
                        Else
                            URL = "http://www.dotnetnuke.com"
                        End If
                End Select

                Response.Redirect(URL, True)

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddModule_Click runs when the Add Module Icon or text button is clicked
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	10/06/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub AddModule_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAddModule.Click, cmdAddModuleIcon.Click
            Try

                Dim objTabPermissions As Security.Permissions.TabPermissionCollection
                objTabPermissions = PortalSettings.ActiveTab.TabPermissions
                Dim objPermissionController As New Security.Permissions.PermissionController
                Dim objEventLog As New Services.Log.EventLog.EventLogController

                Dim UserId As Integer = -1
                If Request.IsAuthenticated Then

                    Dim objUserInfo As UserInfo = UserController.GetCurrentUserInfo
                    UserId = objUserInfo.UserID
                End If

                Select Case optModuleType.SelectedItem.Value
                    Case "0" ' new module
                        If cboDesktopModules.SelectedIndex > 0 Then

                            Dim objModuleDefinitions As New ModuleDefinitionController
                            Dim objModuleDefinition As ModuleDefinitionInfo

                            Dim intIndex As Integer
                            Dim arrModuleDefinitions As ArrayList = objModuleDefinitions.GetModuleDefinitions(Integer.Parse(cboDesktopModules.SelectedItem.Value))
                            For intIndex = 0 To arrModuleDefinitions.Count - 1
                                objModuleDefinition = CType(arrModuleDefinitions(intIndex), ModuleDefinitionInfo)

                                Dim objModule As New ModuleInfo
                                objModule.Initialize()

                                objModule.PortalID = PortalSettings.PortalId
                                objModule.TabID = PortalSettings.ActiveTab.TabID
                                objModule.ModuleOrder = -1
                                If txtTitle.Text <> "" Then
                                    objModule.ModuleTitle = txtTitle.Text
                                Else
                                    objModule.ModuleTitle = objModuleDefinition.FriendlyName
                                End If
                                objModule.PaneName = cboPanes.SelectedItem.Text
                                objModule.ModuleDefID = objModuleDefinition.ModuleDefID
                                objModule.CacheTime = 0

                                Dim objModulePermissions As New Security.Permissions.ModulePermissionCollection
                                Dim objTabPermission As Security.Permissions.TabPermissionInfo
                                For Each objTabPermission In objTabPermissions
                                    Dim objModulePermission As New Security.Permissions.ModulePermissionInfo
                                    Dim arrSystemModulePermissions As ArrayList = objPermissionController.GetPermissionByCodeAndKey("SYSTEM_MODULE_DEFINITION", objTabPermission.PermissionKey)
                                    Dim j As Integer
                                    For j = 0 To arrSystemModulePermissions.Count - 1
                                        Dim objSystemModulePermission As Security.Permissions.PermissionInfo
                                        objSystemModulePermission = CType(arrSystemModulePermissions(j), Security.Permissions.PermissionInfo)
                                        objModulePermission.ModuleID = objModule.ModuleID
                                        objModulePermission.PermissionID = objSystemModulePermission.PermissionID
                                        objModulePermission.RoleID = objTabPermission.RoleID
                                        objModulePermission.AllowAccess = objTabPermission.AllowAccess
                                        objModulePermissions.Add(objModulePermission)
                                    Next
                                Next

                                objModule.ModulePermissions = objModulePermissions
                                objModule.AllTabs = False
                                objModule.Visibility = VisibilityState.Maximized
                                objModule.Alignment = cboAlign.SelectedItem.Value

                                Dim objModules As New ModuleController
                                objModules.AddModule(objModule)
                                objEventLog.AddLog(objModule, PortalSettings, UserId, "", Services.Log.EventLog.EventLogInfo.EventLogType.MODULE_CREATED)
                            Next

                            ' Redirect to the same page to pick up changes
                            Response.Redirect(Request.RawUrl, True)
                        End If
                    Case "1" ' existing module
                        If Not cboModules.SelectedItem Is Nothing Then
                            Dim objModule As New ModuleInfo
                            objModule.Initialize()

                            objModule.PortalID = PortalSettings.PortalId
                            objModule.TabID = PortalSettings.ActiveTab.TabID
                            objModule.ModuleID = Integer.Parse(cboModules.SelectedItem.Value)
                            objModule.ModuleOrder = -1
                            objModule.PaneName = cboPanes.SelectedItem.Text
                            objModule.CacheTime = 0
                            objModule.Visibility = VisibilityState.Maximized
                            objModule.Alignment = cboAlign.SelectedItem.Value

                            Dim objModules As New ModuleController
                            objModules.AddModule(objModule)
                            objEventLog.AddLog(objModule, PortalSettings, UserId, "", Services.Log.EventLog.EventLogInfo.EventLogType.MODULE_CREATED)

                            ' Redirect to the same page to pick up changes
                            Response.Redirect(Request.RawUrl, True)
                        End If
                End Select

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub optModuleType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles optModuleType.SelectedIndexChanged

            BindData()

        End Sub

        Private Sub cboTabs_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboTabs.SelectedIndexChanged

            Dim objModules As New ModuleController
            cboModules.DataSource = objModules.GetPortalTabModules(PortalSettings.PortalId, Integer.Parse(cboTabs.SelectedItem.Value))
            cboModules.DataBind()

        End Sub

#End Region

#Region " Web Form Designer Generated Code "


        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

            Me.ID = "IconBar.ascx"
        End Sub

#End Region

    End Class

End Namespace
