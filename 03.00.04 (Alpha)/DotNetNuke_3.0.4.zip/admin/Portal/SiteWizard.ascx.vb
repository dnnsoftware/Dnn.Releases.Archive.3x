'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports System.Drawing.Imaging
Imports System.XML
Imports DotNetNuke.UI.Skins
Imports DotNetNuke.Services.Wizards
Imports DotNetNuke.UI.UserControls


Namespace DotNetNuke.Modules.Admin.PortalManagement

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' The SiteWizard Wizard is a user-friendly Wizard that leads the user through the
	'''	process of setting up a new site
	''' </summary>
	''' <returns></returns>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[cnurse]	10/8/2004	created
	''' </history>
	''' -----------------------------------------------------------------------------
	Public Class SiteWizard
		Inherits DotNetNuke.Services.Wizards.Wizard

#Region "Controls"

		'Wizard Framework Controls
		Protected WithEvents Wizard As System.Web.UI.HtmlControls.HtmlTable
		Protected WithEvents WizardBody As System.Web.UI.HtmlControls.HtmlTableCell

		'Page 1 Controls
        Protected WithEvents pnlTemplate As System.Web.UI.WebControls.Panel
        Protected WithEvents lblTemplateTitle As LabelControl
        Protected WithEvents chkTemplate As System.Web.UI.WebControls.CheckBox
        Protected WithEvents lstTemplate As System.Web.UI.WebControls.ListBox
		Protected WithEvents lblTemplateMessage As System.Web.UI.WebControls.Label
		Protected WithEvents lblMergeTitle As System.Web.UI.WebControls.Label
		Protected WithEvents optMerge As System.Web.UI.WebControls.RadioButtonList
		Protected WithEvents lblMergeWarning As System.Web.UI.WebControls.Label

        'Page 2 Controls
        Protected WithEvents pnlSkin As System.Web.UI.WebControls.Panel
        Protected WithEvents lblSkinTitle As LabelControl
		Protected WithEvents lblSkinDetail As System.Web.UI.WebControls.Label
		Protected WithEvents ctlPortalSkin As UI.Skins.SkinThumbNailControl

        'Page 3 Controls
		Protected WithEvents pnlDetails As System.Web.UI.WebControls.Panel
        Protected WithEvents lblDetailsTitle As LabelControl
        Protected WithEvents lblDetailsDetail As System.Web.UI.WebControls.Label
        Protected WithEvents lblPortalName As LabelControl
		Protected WithEvents txtPortalName As System.Web.UI.WebControls.TextBox
        Protected WithEvents lblDescription As LabelControl
		Protected WithEvents txtDescription As System.Web.UI.WebControls.TextBox
        Protected WithEvents lblKeyWords As LabelControl
		Protected WithEvents txtKeyWords As System.Web.UI.WebControls.TextBox

        'Page 4 Controls
        Protected WithEvents pnlLogo As System.Web.UI.WebControls.Panel
        Protected WithEvents lblLogoTitle As LabelControl
        Protected WithEvents lblLogo As LabelControl
		Protected WithEvents urlLogo As UI.UserControls.UrlControl

#End Region

#Region "Private Members"


#End Region

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetSkins gets the skins and containers and binds the lists to the controls
        '''	the buttons
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	11/04/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub GetSkins()

            Dim objSkins As New UI.Skins.SkinController
            Dim objSkin As UI.Skins.SkinInfo

            ctlPortalSkin.Width = "500px"
            ctlPortalSkin.Height = "250px"
            ctlPortalSkin.Border = "black 1px solid"
            ctlPortalSkin.Columns = 3
            ctlPortalSkin.SkinRoot = SkinInfo.RootSkin
            objSkin = objSkins.GetSkin(SkinInfo.RootSkin, PortalId, SkinType.Portal)
            If Not objSkin Is Nothing Then
                If objSkin.PortalId = PortalId Then
                    ctlPortalSkin.SkinSrc = objSkin.SkinSrc
                End If
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetTemplates gets the skins and containers and binds the lists to the control
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	11/04/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub GetTemplates()

            Dim strFolder As String
            Dim strFileName As String

            strFolder = Request.MapPath(Common.Globals.HostPath)
            If System.IO.Directory.Exists(strFolder) Then
                ' admin.template and a portal template are required at minimum
                Dim fileEntries As String() = System.IO.Directory.GetFiles(strFolder, "*.template")
                Me.EnableCommand(WizardCommand.NextPage, False)
                Me.EnableCommand(WizardCommand.Finish, False)

                For Each strFileName In fileEntries
                    If Path.GetFileNameWithoutExtension(strFileName) = "admin" Then
                        Me.EnableCommand(WizardCommand.NextPage, True)
                        Me.EnableCommand(WizardCommand.Finish, True)
                    Else
                        lstTemplate.Items.Add(Path.GetFileNameWithoutExtension(strFileName))
                    End If
                Next

                If lstTemplate.Items.Count = 0 Then
                    Me.EnableCommand(WizardCommand.NextPage, False)
                    Me.EnableCommand(WizardCommand.Finish, False)
                End If
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' UseTemplate sets the page ready to select a Template
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	11/04/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub UseTemplate()
            lstTemplate.Enabled = chkTemplate.Checked
            optMerge.Enabled = chkTemplate.Checked
            lblMergeTitle.Enabled = chkTemplate.Checked
            lblMergeWarning.Enabled = chkTemplate.Checked
            lblTemplateMessage.Text = ""
        End Sub

#End Region

#Region "Public Methods"

#End Region

#Region "Event Handlers"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Page_Load runs when the control is loaded
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	10/11/2004	created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try

                Me.AddPage(DotNetNuke.Services.Localization.Localization.GetString("ChooseTemplate.Title", Me.LocalResourceFile), "~/images/icon_portals_40px.gif", pnlTemplate, DotNetNuke.Services.Localization.Localization.GetString("Template.Help", Me.LocalResourceFile))
                Me.AddPage(DotNetNuke.Services.Localization.Localization.GetString("ChooseSkin.Title", Me.LocalResourceFile), "~/images/icon_skins_36px.gif", pnlSkin, DotNetNuke.Services.Localization.Localization.GetString("Skin.Help", Me.LocalResourceFile))
                Me.AddPage(DotNetNuke.Services.Localization.Localization.GetString("Details.Title", Me.LocalResourceFile), "~/images/icon_sitesettings_36px.gif", pnlDetails, DotNetNuke.Services.Localization.Localization.GetString("Details.Help", Me.LocalResourceFile))
                Me.AddPage(DotNetNuke.Services.Localization.Localization.GetString("Logo.Title", Me.LocalResourceFile), "~/images/icon_sitesettings_36px.gif", pnlLogo, DotNetNuke.Services.Localization.Localization.GetString("Logo.Help", Me.LocalResourceFile))

				If Not Page.IsPostBack Then

					'Get Templates for Page 1
					GetTemplates()
					chkTemplate.Checked = False
					lstTemplate.Enabled = False

                    'Get Skins for Pages 2
					GetSkins()

                    'Get Details for Page 3
					Dim objPortalController As New PortalController
					Dim objPortal As PortalInfo = objPortalController.GetPortal(PortalId)
					txtPortalName.Text = objPortal.PortalName
					txtDescription.Text = objPortal.Description
					txtKeyWords.Text = objPortal.KeyWords

                    'Get Details for Page 4
                    urlLogo.Url = objPortal.LogoFile

					Me.CurrentPage = 0
					Me.FinishPage = 2

					Me.DisplayCurrentPage()

                    UseTemplate()
                End If


            Catch exc As Exception    'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Page_BeforePageChanged runs when a Wizard page is about to be changed.  It provides
		'''	a mechanism for cancelling the page change if certain conditions aren't met.
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	10/12/2004	created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_BeforePageChanged(ByVal sender As Object, ByVal we As WizardCancelEventArgs) Handles MyBase.BeforePageChanged

			Dim strMessage As String

			Select Case we.PageNo
                Case 0    'Page 1
                    'Before we leave Page 1, the user must have selected a Portal
                    If lstTemplate.SelectedIndex = -1 Then
                        If chkTemplate.Checked Then
                            we.Cancel = True
                            lblTemplateMessage.Text = Services.Localization.Localization.GetString("TemplateRequired", Me.LocalResourceFile)
                        End If
                    Else
                        'Check Template Validity before proceeding
                        Dim xval As New PortalTemplateValidator
                        xval.SetXML(Request.MapPath(Common.Globals.HostPath) & lstTemplate.SelectedItem.Text & ".template")
                        Dim filename As String = Server.MapPath("admin/Portal/portal.template.xsd")
                        xval.LoadSchema(filename)
                        If Not xval.IsValid Then
                            strMessage = Services.Localization.Localization.GetString("InvalidTemplate", Me.LocalResourceFile)
                            lblTemplateMessage.Text = String.Format(strMessage, lstTemplate.SelectedItem.Text & ".template")
                            'Cancel Page move if invalid template
                            we.Cancel = True
                        End If
                    End If


            End Select
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Page_FinishWizard runs when the Finish Button on the Wizard is clicked.
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	10/12/2004	created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_FinishWizard(ByVal sender As Object, ByVal we As WizardEventArgs) Handles MyBase.FinishWizard

			Dim objPortalController As New PortalController

            ' use Portal Template to update portal content pages
			If lstTemplate.SelectedIndex <> -1 Then
				Dim strTemplateFile As String = lstTemplate.SelectedItem.Text & ".template"
				Select Case optMerge.SelectedValue
					Case "Ignore"
						objPortalController.ParseTemplate(PortalId, Request.MapPath(Common.Globals.HostPath), strTemplateFile, PortalSettings.AdministratorId, PortalTemplateModuleAction.Ignore)
					Case "Replace"
						objPortalController.ParseTemplate(PortalId, Request.MapPath(Common.Globals.HostPath), strTemplateFile, PortalSettings.AdministratorId, PortalTemplateModuleAction.Replace)
					Case "Merge"
						objPortalController.ParseTemplate(PortalId, Request.MapPath(Common.Globals.HostPath), strTemplateFile, PortalSettings.AdministratorId, PortalTemplateModuleAction.Merge)
				End Select
			End If

			' update Portal info in the database
			Dim objPortal As PortalInfo = objPortalController.GetPortal(PortalId)
			objPortal.Description = txtDescription.Text
			objPortal.KeyWords = txtKeyWords.Text
			objPortal.PortalName = txtPortalName.Text
			objPortal.LogoFile = urlLogo.Url
			objPortalController.UpdatePortalInfo(objPortal)

            Dim objSkins As New UI.Skins.SkinController

            'Set Portal Skin
            objSkins.SetSkin(SkinInfo.RootSkin, PortalId, SkinType.Portal, ctlPortalSkin.SkinSrc)
            objSkins.SetSkin(SkinInfo.RootSkin, PortalId, SkinType.Admin, ctlPortalSkin.SkinSrc)

            'Set Portal Default Container
            If ctlPortalSkin.SkinSrc <> "" Then
                Dim strContainerFolder As String = ctlPortalSkin.SkinSrc.Substring(0, ctlPortalSkin.SkinSrc.LastIndexOf("/"))
                strContainerFolder = strContainerFolder.Replace("Skins/", "Containers/")
                Dim strContainerFile As String = strContainerFolder & "/default.ascx"
                If File.Exists(Server.MapPath(objSkins.FormatSkinSrc(strContainerFile, PortalSettings))) Then
                    objSkins.SetSkin(SkinInfo.RootContainer, PortalId, SkinType.Portal, strContainerFile)
                    objSkins.SetSkin(SkinInfo.RootContainer, PortalId, SkinType.Admin, strContainerFile)
                Else
                    objSkins.SetSkin(SkinInfo.RootContainer, PortalId, SkinType.Portal, "")
                    objSkins.SetSkin(SkinInfo.RootContainer, PortalId, SkinType.Admin, "")
                End If
            Else
                objSkins.SetSkin(SkinInfo.RootContainer, PortalId, SkinType.Portal, "")
                objSkins.SetSkin(SkinInfo.RootContainer, PortalId, SkinType.Admin, "")
            End If

            Me.DisplaySuccessPage(DotNetNuke.Services.Localization.Localization.GetString("SuccessMessage", Me.LocalResourceFile))

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' chkTemplate_CheckedChanged runs when use template checkbox status is changed
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	10/13/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub chkTemplate_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkTemplate.CheckedChanged

            If chkTemplate.Checked Then
                lstTemplate.SelectedIndex = -1
            End If

            UseTemplate()

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' lstTemplate_SelectedIndexChanged runs when the selected template is changed
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	11/04/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub lstTemplate_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstTemplate.SelectedIndexChanged

            If lstTemplate.SelectedIndex > -1 Then
                Dim xmlDoc As New XmlDocument
                Dim node As XmlNode
                Dim strTemplatePath As String = Request.MapPath(Common.Globals.HostPath)
                Dim strTemplateFile As String = lstTemplate.SelectedItem.Text & ".template"

                ' open the XML file
                Try
                    xmlDoc.Load(strTemplatePath & strTemplateFile)
                    node = xmlDoc.SelectSingleNode("//portal/description")
                    If Not node Is Nothing Then
                        lblTemplateMessage.Text = node.InnerText
                    Else
                        lblTemplateMessage.Text = ""
                    End If
                Catch    ' error
                    lblTemplateMessage.Text = "Error Loading Template description"
                End Try
            Else
                lblTemplateMessage.Text = ""
            End If
        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.

            InitializeComponent()

        End Sub

#End Region

    End Class

End Namespace

