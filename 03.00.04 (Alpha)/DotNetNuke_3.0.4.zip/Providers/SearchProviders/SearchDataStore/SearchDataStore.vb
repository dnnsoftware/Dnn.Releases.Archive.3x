'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'


Imports DotNetNuke.Common.Utilities
Imports DotNetNuke.Framework
Imports System.Text.RegularExpressions
Imports System.IO
Imports System.Web
Imports DotNetNuke.Framework.Providers
Imports DotNetNuke.Entities.Portals

Namespace DotNetNuke.Services.Search

    ''' -----------------------------------------------------------------------------
    ''' Namespace:  DotNetNuke.Services.Search
    ''' Project:    DotNetNuke.Search.DataStore
    ''' Class:      SearchDataStore
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The SearchDataStore is an implementation of the abstract SearchDataStoreProvider
    ''' class
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    '''		[cnurse]	11/15/2004	documented
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class SearchDataStore
        Inherits SearchDataStoreProvider

#Region "Private Members"

        Private _settings As Hashtable
        Private _defaultSettings As Hashtable
        Private maxWordLength As Integer = 50
        Private minWordLength As Integer = 4
        Private includeNumbers As Boolean = True
        Private includeCommon As Boolean = False

#End Region

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddIndexWords adds the Index Words to the Data Store
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="IndexId">The Id of the SearchItem</param>
        ''' <param name="SearchItem">The SearchItem</param>
        ''' <param name="Locales">A hashtable of locales</param>
        ''' <history>
        '''		[cnurse]	11/15/2004	documented
        '''     [cnurse]    11/16/2004  replaced calls to separate content clean-up
        '''                             functions with new call to HtmlUtils.Clean().
        '''                             replaced logic to determine whether word should
        '''                             be indexed by call to CanIndexWord()
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub AddIndexWords(ByVal IndexId As Integer, ByVal SearchItem As SearchItemInfo, ByVal Locales As Hashtable)

            Dim IndexWords As New Hashtable
            Dim IndexPositions As New Hashtable
            Dim setting As String

            'Get the Settings for this Module
            _settings = SearchDataStoreController.GetSearchSettings(SearchItem.ModuleId)
            setting = GetSetting("MaxSearchWordLength")
            If setting <> "" Then
                maxWordLength = Integer.Parse(setting)
            End If
            setting = GetSetting("MinSearchWordLength")
            If setting <> "" Then
                minWordLength = Integer.Parse(setting)
            End If
            setting = GetSetting("SearchIncludeCommon")
            If setting = "Y" Then
                includeCommon = True
            End If
            setting = GetSetting("SearchIncludeNumeric")
            If setting = "N" Then
                includeNumbers = False
            End If

            Dim Content As String = SearchItem.Content

            ' clean content
            Content = HtmlUtils.Clean(Content, True)
            Content = Content.ToLower

            '' split content into words
            Dim ContentWords() As String = Split(Content, " ")

            ' process each word
            Dim intWord As Integer
            Dim strWord As String
            For Each strWord In ContentWords
                If CanIndexWord(strWord, CType(Locales(SearchItem.ModuleId.ToString), String)) Then
                    intWord = intWord + 1
                    If IndexWords.ContainsKey(strWord) = False Then
                        IndexWords.Add(strWord, 0)
                        IndexPositions.Add(strWord, 1)
                    End If
                    ' track number of occurrences of word in content
                    IndexWords(strWord) = CType(IndexWords(strWord), Integer) + 1
                    ' track positions of word in content
                    IndexPositions(strWord) = CType(IndexPositions(strWord), String) & "," & intWord.ToString
                End If
            Next

            ' get list of words ( non-common )
            Dim Words As Hashtable = GetSearchWords()    ' this could be cached
            Dim WordId As Integer

            '' iterate through each indexed word
            Dim objWord As Object
            For Each objWord In IndexWords.Keys
                strWord = CType(objWord, String)
                If Words.ContainsKey(strWord) Then
                    ' word is in the DataStore
                    WordId = CType(Words(strWord), Integer)
                Else
                    ' add the word to the DataStore
                    WordId = Data.DataProvider.Instance().AddSearchWord(strWord)
                    Words.Add(strWord, WordId)
                End If
                ' add the indexword
                Dim SearchItemWordID As Integer = Data.DataProvider.Instance().AddSearchItemWord(IndexId, WordId, CType(IndexWords(strWord), Integer))
                Data.DataProvider.Instance().AddSearchItemWordPosition(SearchItemWordID, CType(IndexPositions(strWord), String))
            Next

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' CanIndexWord determines whether the Word should be indexed
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="strWord">The Word to validate/param>
        ''' <returns>True if indexable, otherwise false</returns>
        ''' <history>
        '''		[cnurse]	11/16/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function CanIndexWord(ByVal strWord As String, ByVal Locale As String) As Boolean

            'Create Boolean to hold return value
            Dim retValue As Boolean = True

            ' get common words for exclusion
            Dim CommonWords As Hashtable = GetCommonWords(Locale)

            'Determine if Word is actually a number
            If IsNumeric(strWord) Then
                'Word is Numeric
                If Not includeNumbers Then
                    retValue = False
                End If
            Else
                'Word is Non-Numeric

                'Determine if Word satisfies Minimum/Maximum length
                If strWord.Length < minWordLength Or strWord.Length > maxWordLength Then
                    retValue = False
                Else
                    'Determine if Word is a Common Word (and should be excluded)
                    If CommonWords.ContainsKey(strWord) = True And Not includeCommon Then
                        retValue = False
                    End If
                End If
            End If


            Return retValue

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetCommonWords gets a list of the Common Words for the locale
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="Locale">The locale string</param>
        ''' <returns>A hashtable of common words</returns>
        ''' <history>
        '''		[cnurse]	11/15/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function GetCommonWords(ByVal Locale As String) As Hashtable
            Dim strCacheKey As String = "CommonWords" & Locale

            Dim objWords As Hashtable = CType(DataCache.GetCache(strCacheKey), Hashtable)
            'If objWords Is Nothing Then
            objWords = New Hashtable
            Dim drWords As IDataReader = Data.DataProvider.Instance().GetSearchCommonWordsByLocale(Locale)
            Try
                While drWords.Read
                    objWords.Add(drWords("CommonWord").ToString, drWords("CommonWord").ToString)
                End While
            Finally
                drWords.Close()
                drWords.Dispose()
            End Try
            DataCache.SetCache(strCacheKey, objWords)
            'End If
            Return objWords
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetSearchWords gets a list of the current Words in the Database's Index
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A hashtable of words</returns>
        ''' <history>
        '''		[cnurse]	11/15/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function GetSearchWords() As Hashtable
            Dim strCacheKey As String = "SearchWords"

            Dim objWords As Hashtable = CType(DataCache.GetCache(strCacheKey), Hashtable)
            If objWords Is Nothing Then
                objWords = New Hashtable
                Dim drWords As IDataReader = Data.DataProvider.Instance().GetSearchWords()
                Try
                    While drWords.Read
                        objWords.Add(drWords("Word").ToString, drWords("SearchWordsID"))
                    End While
                Finally
                    drWords.Close()
                    drWords.Dispose()
                End Try
                DataCache.SetCache(strCacheKey, objWords, TimeSpan.FromMinutes(2))
            End If
            Return objWords
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetSetting gets a Search Setting from the Portal Modules Settings table (or
        ''' from the Host Settings)
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	11/16/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function GetSetting(ByVal txtName As String) As String

            Dim settingValue As String = ""

            'Try Portal setting first
            If _settings(txtName) Is Nothing = False Then
                settingValue = CType(_settings(txtName), String)
            Else
                'Get Default setting
                If _defaultSettings(txtName) Is Nothing = False Then
                    settingValue = CType(_defaultSettings(txtName), String)
                End If
            End If

            Return settingValue

        End Function

#End Region

#Region "Public Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetSearchItems gets a collection of Search Items for a Module/Tab/Portal
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="PortalID">A Id of the Portal</param>
        ''' <param name="TabID">A Id of the Tab</param>
        ''' <param name="ModuleID">A Id of the Module</param>
        ''' <history>
        '''		[cnurse]	11/15/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Function GetSearchItems(ByVal PortalID As Integer, ByVal TabID As Integer, ByVal ModuleID As Integer) As SearchResultsInfoCollection
            Return New SearchResultsInfoCollection(CBO.FillCollection(Data.DataProvider.Instance().GetSearchItems(PortalID, TabID, ModuleID), GetType(SearchResultsInfo)))
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetSearchResults gets the search results for a passed in criteria string
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="PortalID">A Id of the Portal</param>
        ''' <param name="Criteria">The criteria string</param>
        ''' <history>
        '''		[cnurse]	11/15/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Function GetSearchResults(ByVal PortalID As Integer, ByVal Criteria As String) As SearchResultsInfoCollection

            'We will assume that the content is in the locale of the Portal
            Dim objPortalController As New PortalController
            Dim objPortal As PortalInfo = objPortalController.GetPortal(PortalID)
            Dim locale As String = objPortal.DefaultLanguage
            Dim CommonWords As Hashtable = GetCommonWords(locale)

            ' clean criteria
            Criteria = Criteria.ToLower

            ' split search criteria into words
            Dim SearchWords As New SearchCriteriaCollection(Criteria)

            Dim SearchResults As New Hashtable
            ' iterate through search criteria words
            Dim Criterion As SearchCriteria
            For Each Criterion In SearchWords
                If CommonWords.ContainsKey(Criterion.Criteria) = False Then
                    Dim ResultsCollection As SearchResultsInfoCollection = SearchDataStoreController.GetSearchResults(PortalID, Criterion.Criteria)
                    If Criterion.MustExclude = False Then
                        ' Add all these to the results
                        For Each Result As SearchResultsInfo In ResultsCollection
                            If SearchResults.ContainsKey(Result.SearchKey) Then
                                CType(SearchResults.Item(Result.SearchKey), SearchResultsInfo).Relevance += Result.Relevance
                            Else
                                SearchResults.Add(Result.SearchKey, Result)
                            End If
                        Next
                    End If
                    If Criterion.MustInclude Then
                        ' We need to remove items which do not include this term
                        Dim MandatoryResults As New Hashtable
                        For Each result As SearchResultsInfo In ResultsCollection
                            MandatoryResults.Add(result.SearchKey, 0)
                        Next
                        For Each Result As SearchResultsInfo In SearchResults.Values
                            If MandatoryResults.ContainsKey(result.SearchKey) = False Then
                                result.Delete = True
                            End If
                        Next
                    End If
                    If Criterion.MustExclude Then
                        ' We need to remove items which do include this term
                        Dim ExcludedResults As New Hashtable
                        For Each result As SearchResultsInfo In ResultsCollection
                            ExcludedResults.Add(result.SearchKey, 0)
                        Next
                        For Each Result As SearchResultsInfo In SearchResults.Values
                            If ExcludedResults.ContainsKey(result.SearchKey) = True Then
                                Result.Delete = True
                            End If
                        Next
                    End If
                End If
            Next

            'Remove any results that point to pages that we don't have permission for
            Dim ModuleRoles As New Hashtable
            Dim Results As New SearchResultsInfoCollection
            For Each SearchResult As SearchResultsInfo In SearchResults.Values
                Dim roles As String = ""
                If ModuleRoles.ContainsKey(SearchResult.ModuleId) Then
                    roles = CType(ModuleRoles(SearchResult.ModuleId), String)
                Else
                    Dim objModulePermissionController As New DotNetNuke.Security.Permissions.ModulePermissionController
                    Dim arrModulePermissions As ArrayList = objModulePermissionController.GetModulePermissionsByModuleID(SearchResult.ModuleId)
                    roles = objModulePermissionController.GetModulePermissionsByModuleID(arrModulePermissions, SearchResult.ModuleId, "VIEW")
                    If roles Is Nothing OrElse roles.Length = 0 OrElse roles = ";" Then
                        Dim objTabPermissionController As New DotNetNuke.Security.Permissions.TabPermissionController
                        arrModulePermissions = objTabPermissionController.GetTabPermissionsByTabID(SearchResult.TabId)
                        roles = objTabPermissionController.GetTabPermissionsByTabID(arrModulePermissions, SearchResult.TabId, "VIEW")
                    End If
                    ModuleRoles.Add(SearchResult.ModuleId, roles)
                End If
                If DotNetNuke.Security.PortalSecurity.IsInRoles(roles) = True AndAlso SearchResult.Delete = False Then
                    Results.Add(SearchResult)
                End If
            Next

            'Return Search Results Collection
            Return Results
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' StoreSearchItems adds the Search Item to the Data Store
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="SearchItems">A Collection of SearchItems</param>
        ''' <history>
        '''		[cnurse]	11/15/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Sub StoreSearchItems(ByVal SearchItems As SearchItemInfoCollection)

            'Get the default Search Settings
            _defaultSettings = Common.Globals.HostSettings


            ' delete the index item and cascade delete the IndexWords
            Dim ModuleList(SearchItems.Count - 1) As String
            Dim i As Integer
            For i = 0 To SearchItems.Count - 1
                ModuleList(i) = SearchItems(i).ModuleId.ToString
            Next
            Dim ModList As String = Join(ModuleList, ",")

            Dim dr As IDataReader = Data.DataProvider.Instance().GetDefaultLanguageByModule(ModList)

            Dim LocaleTable As New Hashtable
            Try
                While dr.Read
                    LocaleTable.Add(dr("ModuleID").ToString, dr("DefaultLanguage").ToString)
                End While
            Finally
                dr.Close()
                dr.Dispose()
            End Try

            ' add the index item
            Dim SearchItem As SearchItemInfo
            Dim IndexedItem As SearchItemInfo
            Dim IndexID As Integer
            Dim ModuleId As Integer

            For Each SearchItem In SearchItems
                'Check if item exists
                ModuleId = SearchItem.ModuleId
                IndexedItem = SearchDataStoreController.GetSearchItem(SearchItem.ModuleId, SearchItem.Key)
                If IndexedItem Is Nothing Then
                    'Add Item
                    IndexID = SearchDataStoreController.AddSearchItem(SearchItem)
                    ' index the content
                    AddIndexWords(IndexID, SearchItem, LocaleTable)
                Else
                    'Item exists so compare Dates to see if modified
                    If IndexedItem.PubDate < SearchItem.PubDate Then
                        'Content modified so update SearchItem and delete item's Words Collection
                        SearchItem.SearchItemId = IndexedItem.SearchItemId
                        SearchDataStoreController.UpdateSearchItem(SearchItem)
                        SearchDataStoreController.DeleteSearchItemWords(SearchItem.SearchItemId)

                        ' re-index the content
                        AddIndexWords(SearchItem.SearchItemId, SearchItem, LocaleTable)
                    End If
                End If
            Next

        End Sub

#End Region

    End Class
End Namespace