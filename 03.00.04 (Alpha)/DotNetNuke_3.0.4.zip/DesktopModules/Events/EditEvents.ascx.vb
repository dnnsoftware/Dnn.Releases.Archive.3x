'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports DotNetNuke
Imports System.Web.UI.WebControls

Namespace DotNetNuke.Modules.Events

  ''' -----------------------------------------------------------------------------
  ''' <summary>
  ''' The EditEvents Class provides the UI for managing the Events
  ''' </summary>
  ''' <returns></returns>
  ''' <remarks>
  ''' </remarks>
  ''' <history>
  ''' 	[cnurse]	9/22/2004	Moved Events to a separate Project
  ''' </history>
  ''' -----------------------------------------------------------------------------
    Public MustInherit Class EditEvents
		Inherits Entities.Modules.PortalModuleBase

#Region "Controls"

        Protected WithEvents pnlContent As System.Web.UI.WebControls.Panel
        Protected plTitle As UI.UserControls.LabelControl
        Protected WithEvents txtTitle As System.Web.UI.WebControls.TextBox
        Protected WithEvents valTitle As System.Web.UI.WebControls.RequiredFieldValidator
        Protected plDescription As UI.UserControls.LabelControl
        Protected WithEvents txtDescription As System.Web.UI.WebControls.TextBox
        Protected WithEvents valDescription As System.Web.UI.WebControls.RequiredFieldValidator
        Protected plImage As UI.UserControls.LabelControl
        Protected WithEvents ctlImage As UI.UserControls.UrlControl
        Protected plAlt As UI.UserControls.LabelControl
        Protected WithEvents txtAlt As System.Web.UI.WebControls.TextBox
        Protected WithEvents valAltText As System.Web.UI.WebControls.RequiredFieldValidator
        Protected plEvery As UI.UserControls.LabelControl
        Protected WithEvents txtEvery As System.Web.UI.WebControls.TextBox
        Protected WithEvents cboPeriod As System.Web.UI.WebControls.DropDownList
        Protected plStartDate As UI.UserControls.LabelControl
        Protected WithEvents txtStartDate As System.Web.UI.WebControls.TextBox
        Protected WithEvents cmdStartCalendar As System.Web.UI.WebControls.HyperLink
        Protected WithEvents valStartDate As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents valStartDate2 As System.Web.UI.WebControls.CompareValidator
        Protected plTime As UI.UserControls.LabelControl
        Protected WithEvents txtTime As System.Web.UI.WebControls.TextBox
        Protected plExpiryDate As UI.UserControls.LabelControl
        Protected WithEvents txtExpiryDate As System.Web.UI.WebControls.TextBox
        Protected WithEvents cmdExpiryCalendar As System.Web.UI.WebControls.HyperLink
        Protected WithEvents valExpiryDate As System.Web.UI.WebControls.CompareValidator

        'tasks
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

        'footer
        Protected WithEvents ctlAudit As DotNetNuke.UI.UserControls.ModuleAuditControl

#End Region

#Region "Private Members"

        Private itemId As Integer = -1

#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/22/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try
                Dim objModules As New Entities.Modules.ModuleController

                ' Determine ItemId of Events to Update
                If Not (Request.QueryString("ItemId") Is Nothing) Then
                    itemId = Int32.Parse(Request.QueryString("ItemId"))
                End If

                ' If the page is being requested the first time, determine if an
                ' event itemId value is specified, and if so populate page
                ' contents with the event details
                If Page.IsPostBack = False Then

                    cmdDelete.Attributes.Add("onClick", "javascript:return confirm('" & Localization.GetString("DeleteItem") & "');")
                    cmdStartCalendar.NavigateUrl = CType(Common.Utilities.Calendar.InvokePopupCal(txtStartDate), String)
                    cmdExpiryCalendar.NavigateUrl = CType(Common.Utilities.Calendar.InvokePopupCal(txtExpiryDate), String)

                    If Not Common.Utilities.Null.IsNull(itemId) Then

                        ' Obtain a single row of event information
                        Dim objEvents As New EventController
                        Dim objEvent As EventInfo = objEvents.GetEvent(itemId, ModuleId)

                        ' Read first row from database
                        If Not objEvent Is Nothing Then
                            txtTitle.Text = objEvent.Title
                            txtDescription.Text = objEvent.Description.ToString
                            ctlImage.FileFilter = glbImageFileTypes
                            ctlImage.Url = objEvent.IconFile
                            If Not objEvent.IconFile = "" Then
                                valAltText.Visible = False
                            Else
                                valAltText.Visible = True
                            End If
                            txtAlt.Text = objEvent.AltText
                            txtEvery.Text = objEvent.Every.ToString
                            If txtEvery.Text = "1" Then
                                txtEvery.Text = ""
                            End If
                            If objEvent.Period <> "" Then
                                cboPeriod.Items.FindByValue(objEvent.Period).Selected = True
                            Else
                                cboPeriod.Items(0).Selected = True
                            End If
                            txtStartDate.Text = objEvent.DateTime.ToShortDateString
                            txtTime.Text = objEvent.DateTime.ToShortTimeString
                            If objEvent.DateTime.ToString("HH:mm") = "00:00" Then
                                txtTime.Text = ""
                            End If
                            If Not Common.Utilities.Null.IsNull(objEvent.ExpireDate) Then
                                txtExpiryDate.Text = objEvent.ExpireDate.ToShortDateString
                            Else
                                txtExpiryDate.Text = ""
                            End If

                            ctlAudit.CreatedByUser = objEvent.CreatedByUser
                            ctlAudit.CreatedDate = objEvent.CreatedDate.ToString

                        Else       ' security violation attempt to access item not related to this Module

                            Response.Redirect(NavigateURL(), True)
                        End If
                    Else
                        cmdDelete.Visible = False
                        ctlAudit.Visible = False
                        valAltText.Visible = False
                    End If

                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdCancel_Click runs when the cancel button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/22/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdDelete_Click runs when the delete button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/22/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
            Try
                Dim objEvents As New EventController
                objEvents.DeleteEvent(itemId)
                objEvents = Nothing
                ' Redirect back to the portal home page
                Response.Redirect(NavigateURL(), True)
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' cmdUpdate_Click runs when the update button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	9/22/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
            Try
                Dim strDateTime As String
                
                ' Only Update if the Entered Data is Valid
                If Page.IsValid = True Then

                    strDateTime = txtStartDate.Text
                    If txtTime.Text <> "" Then
                        strDateTime += " " & txtTime.Text
                    End If

                    Dim objEvent As New EventInfo
                    objEvent.ItemId = itemId
                    objEvent.ModuleId = ModuleId
                    objEvent.CreatedByUser = UserInfo.UserID.ToString
                    objEvent.Description = txtDescription.Text
                    objEvent.DateTime = Convert.ToDateTime(strDateTime)
                    objEvent.Title = txtTitle.Text
                    If txtEvery.Text <> "" Then
                        objEvent.Every = Convert.ToInt32(txtEvery.Text)
                    Else
                        objEvent.Every = 1
                    End If
                    objEvent.Period = cboPeriod.SelectedItem.Value
                    objEvent.IconFile = ctlImage.Url
                    objEvent.AltText = txtAlt.Text
                    If txtExpiryDate.Text <> "" Then
                        objEvent.ExpireDate = Convert.ToDateTime(txtExpiryDate.Text)
                    End If
                    ' Create an instance of the Event DB component
                    Dim objEvents As New EventController

                    If Common.Utilities.Null.IsNull(itemId) Then
                        ' Add the event within the Events table
                        objEvents.AddEvent(objEvent)
                    Else
                        ' Update the event within the Events table
                        objEvents.UpdateEvent(objEvent)
                    End If
                    objEvents = Nothing
                    ' Redirect back to the portal home page
                    Response.Redirect(NavigateURL(), True)

                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class
End Namespace