'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports DotNetNuke
Imports System.Web.UI.WebControls
Imports DotNetNuke.Services.FileSystem

Namespace DotNetNuke.Modules.Documents

  ''' -----------------------------------------------------------------------------
  ''' <summary>
  ''' The Document Class provides the UI for displaying the Documents
  ''' </summary>
  ''' <returns></returns>
  ''' <remarks>
  ''' </remarks>
  ''' <history>
  ''' 	[cnurse]	9/22/2004	Moved Documents to a separate Project
  ''' </history>
  ''' -----------------------------------------------------------------------------
  Public MustInherit Class Document
		Inherits Entities.Modules.PortalModuleBase
        Implements Entities.Modules.IActionable
        Implements Entities.Modules.IPortable
        Implements Entities.Modules.ISearchable

#Region "Controls"

    Protected WithEvents grdDocuments As System.Web.UI.WebControls.DataGrid

#End Region

#Region "Public Methods"

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' FormatSize formats the size of a document correctly
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <param name="Size">The Size to format</param>
    ''' <returns>The formatted Size</returns>
    ''' <history>
    ''' 	[cnurse]	9/22/2004	Moved Documents to a separate Project
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Function FormatSize(ByVal Size As Integer) As String
      Try
				If Not Common.Utilities.Null.IsNull(Size) Then
					FormatSize = Format(Size / 1000, "#,##0.00")
				Else
					FormatSize = Localization.GetString("Unknown")
				End If
			Catch exc As Exception		  'Module failed to load
        ProcessModuleLoadException(Me, exc)
      End Try
    End Function

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' FormatURL formats the url of a document correctly
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <param name="Link">The Link to format</param>
    ''' <returns>The formatted Url</returns>
    ''' <history>
    ''' 	[cnurse]	9/22/2004	Moved Documents to a separate Project
    ''' </history>
    ''' -----------------------------------------------------------------------------
        Function FormatURL(ByVal Link As String, ByVal TrackClicks As Boolean) As String

            Return Common.Globals.LinkClick(Link, TabId, ModuleId, TrackClicks)

        End Function

#End Region

#Region "Event Handlers"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Page_Load runs when the control is loaded
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/22/2004	Moved Documents to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try
				Dim objDocuments As New DocumentController

				'Localize the Data Grid
				Localization.LocalizeDataGrid(grdDocuments, Me.LocalResourceFile)

				grdDocuments.DataSource = objDocuments.GetDocuments(ModuleId, PortalId)
				grdDocuments.DataBind()
			Catch exc As Exception		  'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' grdDocuments_Edit runs when an edit command is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/22/2004	Moved Documents to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Sub grdDocuments_Edit(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles grdDocuments.EditCommand
			Try

				Dim strLink As String = ""

				Dim ItemId As Integer = Integer.Parse(Convert.ToString(grdDocuments.DataKeys(e.Item.ItemIndex)))

				Dim objDocuments As New DocumentController
				Dim objDocument As DocumentInfo = objDocuments.GetDocument(ItemId, ModuleId)
				If Not objDocument Is Nothing Then
                    strLink = Common.Globals.LinkClick(objDocument.Url, TabId, ModuleId, objDocument.TrackClicks)
					If InStr(1, objDocument.Url, "://") = 0 Then
                        Dim objFiles As New FileController
                        Dim objFile As FileInfo = objFiles.GetFile(objDocument.Url, PortalId)
                        If Not objFile Is Nothing Then
                            strLink += "&contenttype=" & objFile.ContentType
                        End If
                    End If
                End If


                If strLink <> "" Then
                    Response.Redirect(strLink, True)
                End If
            Catch exc As Exception    'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' grdDocuments_ItemCreated runs when an item in the grid is creates
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/22/2004	Moved Documents to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Sub grdDocuments_ItemCreated(ByVal sender As Object, ByVal e As DataGridItemEventArgs) Handles grdDocuments.ItemCreated
			Try
				If e.Item.ItemType = ListItemType.Header Then
					e.Item.Cells(1).Attributes.Add("Scope", "col")
					e.Item.Cells(2).Attributes.Add("Scope", "col")
					e.Item.Cells(3).Attributes.Add("Scope", "col")
					e.Item.Cells(4).Attributes.Add("Scope", "col")
					e.Item.Cells(5).Attributes.Add("Scope", "col")
				End If
			Catch exc As Exception		  'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

#End Region

#Region "Optional Interfaces"

		Public ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
			Get
				Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
				Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.AddContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", EditURL(), False, Security.SecurityAccessLevel.Edit, True, False)
				Return Actions
			End Get
		End Property

        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Function

        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserId As Integer) Implements Entities.Modules.IPortable.ImportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Sub

        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
        End Function

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

            ' declare module actions
        End Sub

#End Region

    End Class

End Namespace
