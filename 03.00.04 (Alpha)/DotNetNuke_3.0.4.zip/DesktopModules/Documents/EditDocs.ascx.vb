'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports System.Web

Namespace DotNetNuke.Modules.Documents

  ''' -----------------------------------------------------------------------------
  ''' <summary>
  ''' The EditDocs Class provides the UI for manaing the Documents
  ''' </summary>
  ''' <returns></returns>
  ''' <remarks>
  ''' </remarks>
  ''' <history>
  ''' 	[cnurse]	9/22/2004	Moved Documents to a separate Project
  ''' </history>
  ''' -----------------------------------------------------------------------------
  Public MustInherit Class EditDocs
		Inherits Entities.Modules.PortalModuleBase

#Region "Controls"

		Protected WithEvents plName As UI.UserControls.LabelControl
		Protected WithEvents txtName As System.Web.UI.WebControls.TextBox
		Protected WithEvents valName As System.Web.UI.WebControls.RequiredFieldValidator
		Protected WithEvents plUrl As UI.UserControls.LabelControl
		Protected WithEvents ctlUrl As UI.UserControls.UrlControl
		Protected WithEvents plCategory As UI.UserControls.LabelControl
    Protected WithEvents txtCategory As System.Web.UI.WebControls.TextBox

    'tasks
    Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
    Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
    Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

    'footer
		Protected WithEvents ctlAudit As DotNetNuke.UI.UserControls.ModuleAuditControl
		Protected WithEvents ctlTracking As UI.UserControls.URLTrackingControl

#End Region

#Region "Private Members"

    Private itemId As Integer

#End Region

#Region "Event Handlers"

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' Page_Load runs when the control is loaded
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	9/22/2004	Updated to reflect design changes for Help, 508 support
    '''                       and localisation
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                Dim objModules As New Entities.Modules.ModuleController

                ' Determine ItemId of Document to Update
                If Not (Request.QueryString("ItemId") Is Nothing) Then
                    itemId = Int32.Parse(Request.QueryString("ItemId"))
                Else
                    itemId = Convert.ToInt32(Common.Utilities.Null.NullInteger)
                End If

                ' If the page is being requested the first time, determine if an
                ' document itemId value is specified, and if so populate page
                ' contents with the document details
                If Page.IsPostBack = False Then

                    cmdDelete.Attributes.Add("onClick", "javascript:return confirm('" & Localization.GetString("DeleteItem") & "');")

                    If Not Common.Utilities.Null.IsNull(itemId) Then

                        ' Obtain a single row of document information
                        Dim objDocuments As New DocumentController
                        Dim objDocument As DocumentInfo = objDocuments.GetDocument(itemId, ModuleId)

                        ' Load first row into Datareader
                        If Not objDocument Is Nothing Then

                            txtName.Text = objDocument.Title
                            ctlUrl.Url = objDocument.Url
                            txtCategory.Text = objDocument.Category

                            ctlAudit.CreatedByUser = objDocument.CreatedByUser
                            ctlAudit.CreatedDate = objDocument.CreatedDate.ToString

                            ctlTracking.URL = objDocument.Url
                            ctlTracking.ModuleID = ModuleId

                        Else       ' security violation attempt to access item not related to this Module
                            Response.Redirect(NavigateURL(), True)
                        End If
                    Else
                        cmdDelete.Visible = False
                        ctlAudit.Visible = False
                        ctlTracking.Visible = False
                    End If
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdCancel_Click runs when the cancel button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/22/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
			Try
				' Redirect back to the portal home page
				Response.Redirect(NavigateURL(), True)
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdDelete_Click runs when the delete button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/22/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
			Try
				If Not Common.Utilities.Null.IsNull(itemId) Then

					Dim objdocuments As New DocumentController
					objdocuments.DeleteDocument(itemId)

				End If

				' Redirect back to the portal home page
				Response.Redirect(NavigateURL(), True)
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdUpdate_Click runs when the update button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/22/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
			Try
				Dim strDocument As String

                ' Only Update if Input Data is Valid
				If Page.IsValid = True Then

					Dim objDocument As New DocumentInfo
					objDocument.ItemId = itemId
					objDocument.ModuleId = ModuleId
					objDocument.Title = txtName.Text
					objDocument.Url = ctlUrl.Url
					objDocument.Category = txtCategory.Text
					objDocument.CreatedByUser = UserInfo.UserID.ToString

					' Create an instance of the Document DB component
					Dim objDocuments As New DocumentController

					If Common.Utilities.Null.IsNull(itemId) Then
						objDocuments.AddDocument(objDocument)
					Else
						objDocuments.UpdateDocument(objDocument)
					End If

					' url tracking
					Dim objUrls As New UrlController
                    objUrls.UpdateUrl(PortalId, ctlUrl.Url, ctlUrl.UrlType, ctlUrl.Log, ctlUrl.Track, ModuleId, ctlUrl.NewWindow)

					' Redirect back to the portal home page
					Response.Redirect(NavigateURL(), True)

				End If
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

#End Region

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
      'CODEGEN: This method call is required by the Web Form Designer
      'Do not modify it using the code editor.
      InitializeComponent()
    End Sub

#End Region

  End Class

End Namespace