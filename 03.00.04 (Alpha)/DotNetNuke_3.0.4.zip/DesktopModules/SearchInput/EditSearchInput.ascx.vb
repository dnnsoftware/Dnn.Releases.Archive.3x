'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke
Imports System.Text.RegularExpressions
Imports System.Web

Namespace DotNetNuke.Modules.SearchInput

    Public MustInherit Class EditSearchInput
		Inherits Entities.Modules.PortalModuleBase
        Implements Entities.Modules.IActionable

#Region " Web Form Designer Generated Code "
        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub
#End Region

#Region "Controls"
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
		Protected WithEvents chkGo As System.Web.UI.WebControls.CheckBox
		Protected WithEvents chkSearchImage As System.Web.UI.WebControls.CheckBox
		Protected WithEvents cboModule As System.Web.UI.WebControls.DropDownList

#End Region

#Region "Event Handlers"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            If Not Page.IsPostBack Then
                BindSearchResults()

                Dim settings As Hashtable = PortalSettings.GetModuleSettings(ModuleId)

                Dim SearchTabID As String = CType(settings("SearchResultsModule"), String)
				Dim ShowGoImage As String = CType(settings("ShowGoImage"), String)
				Dim ShowSearchImage As String = CType(settings("ShowSearchImage"), String)
                Dim intPortalId As Integer = -1

                If Not (Request.QueryString("PortalID") Is Nothing) And PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                    intPortalId = Int32.Parse(Request.QueryString("PortalID"))
                Else
                    intPortalId = PortalId
                End If


                If Not cboModule.Items.FindByValue(SearchTabID) Is Nothing Then
                    cboModule.Items.FindByValue(SearchTabID).Selected = True
                End If

                If Not ShowGoImage Is Nothing Then
                    chkGo.Checked() = CType(ShowGoImage, Boolean)
                End If

                If Not ShowSearchImage Is Nothing Then
                    chkSearchImage.Checked() = CType(ShowSearchImage, Boolean)
                End If

            End If

        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click
            Dim admin As New Entities.Modules.ModuleController
            If Not cboModule.SelectedIndex = -1 Then
                admin.UpdateModuleSetting(Me.ModuleId, "SearchResultsModule", cboModule.SelectedItem.Value)
            End If

            admin.UpdateModuleSetting(Me.ModuleId, "ShowGoImage", chkGo.Checked.ToString)
            admin.UpdateModuleSetting(Me.ModuleId, "ShowSearchImage", chkSearchImage.Checked.ToString)

            ' Redirect back to the portal home page
            Response.Redirect(ApplicationURL, True)
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            ' Redirect back to the portal home page
            Response.Redirect(ApplicationURL, True)
        End Sub

#End Region

#Region "Private Methods"
		Private Sub BindSearchResults()
			Dim objSearch As New SearchInputController

			cboModule.DataSource = objSearch.GetSearchResultModules(PortalId)
			cboModule.DataTextField = "SearchTabName"
			cboModule.DataValueField = "TabID"
			cboModule.DataBind()

		End Sub
#End Region

#Region "Optional Interfaces"
		Public ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
			Get
				Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
				Actions.Add(GetNextActionID, "Cancel Edit", "", URL:=ApplicationURL, secure:=Security.SecurityAccessLevel.Edit, Visible:=True)

				Return Actions
			End Get
		End Property
#End Region

	End Class
End Namespace
