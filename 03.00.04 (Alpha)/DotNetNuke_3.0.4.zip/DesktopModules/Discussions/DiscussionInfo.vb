'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data

Imports DotNetNuke


Namespace DotNetNuke.Modules.Discussions

 
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The DiscussionInfo Class provides the Discussions Business Object
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	9/21/2004	Moved Discussions to a separate Project
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class DiscussionInfo

#Region "Private Members"

        Private _ItemID As Integer
        Private _ModuleID As Integer
        Private _Title As String
        Private _Body As String
        Private _DisplayOrder As String
        Private _Parent As String
        Private _ChildCount As String
        Private _CreatedByUser As String
        Private _CreatedDate As Date
        Private _ParentID As Integer
        Private _Indent As String

#End Region

#Region "Constructors"

        Public Sub New()
        End Sub

#End Region

#Region "Properties"

        Public Property ItemID() As Integer
            Get
                Return _ItemID
            End Get
            Set(ByVal Value As Integer)
                _ItemID = Value
            End Set
        End Property

        Public Property ModuleID() As Integer
            Get
                Return _ModuleID
            End Get
            Set(ByVal Value As Integer)
                _ModuleID = Value
            End Set
        End Property

        Public Property Title() As String
            Get
                Return _Title
            End Get
            Set(ByVal Value As String)
                _Title = Value
            End Set
        End Property

        Public Property Body() As String
            Get
                Return _Body
            End Get
            Set(ByVal Value As String)
                _Body = Value
            End Set
        End Property

        Public Property DisplayOrder() As String
            Get
                Return _DisplayOrder
            End Get
            Set(ByVal Value As String)
                _DisplayOrder = Value
            End Set
        End Property

        Public Property Parent() As String
            Get
                Return _Parent
            End Get
            Set(ByVal Value As String)
                _Parent = Value
            End Set
        End Property

        Public Property ChildCount() As String
            Get
                Return _ChildCount
            End Get
            Set(ByVal Value As String)
                _ChildCount = Value
            End Set
        End Property

        Public Property CreatedByUser() As String
            Get
                Return _CreatedByUser
            End Get
            Set(ByVal Value As String)
                _CreatedByUser = Value
            End Set
        End Property

        Public Property CreatedDate() As Date
            Get
                Return _CreatedDate
            End Get
            Set(ByVal Value As Date)
                _CreatedDate = Value
            End Set
        End Property

        Public Property ParentID() As Integer
            Get
                Return _ParentID
            End Get
            Set(ByVal Value As Integer)
                _ParentID = Value
            End Set
        End Property

        Public Property Indent() As String
            Get
                Return _Indent
            End Get
            Set(ByVal Value As String)
                _Indent = Value
            End Set
        End Property

#End Region

    End Class

End Namespace
