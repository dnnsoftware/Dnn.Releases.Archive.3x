'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.XML

Namespace DotNetNuke.Common.Utilities

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The XmlUtils class provides Shared/Static methods for manipulating xml files
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	11/08/2004	created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class XmlUtils

        Public Shared Function CreateElement(ByVal objDoc As XmlDocument, ByVal NodeName As String, ByVal NodeValue As String) As XmlElement

            Dim element As XmlElement = objDoc.CreateElement(NodeName)
            element.InnerText = NodeValue

            Return element

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the value of node
        ''' </summary>
        ''' <param name="objNode">Parent node</param>
        ''' <param name="NodeName">Child node to look for</param>
        ''' <param name="DefaultValue">Default value to return</param>
        ''' <returns></returns>
        ''' <remarks>
        ''' If the node does not exist or it causes any error the default value will be returned.
        ''' </remarks>
        ''' <history>
        ''' 	[VMasanas]	09/09/2004	Created
        ''' 	[cnurse]	11/08/2004	moved from PortalController and made Public Shared
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetNodeValue(ByVal objNode As XmlNode, ByVal NodeName As String, Optional ByVal DefaultValue As String = "") As String
            Dim strValue As String = DefaultValue

            Try
                strValue = objNode.Item(NodeName).InnerText

                If strValue = "" And DefaultValue <> "" Then
                    strValue = DefaultValue
                End If
            Catch
                ' node does not exist - legacy issue
            End Try

            Return strValue

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the value of node
        ''' </summary>
        ''' <param name="objNode">Parent node</param>
        ''' <param name="NodeName">Child node to look for</param>
        ''' <param name="DefaultValue">Default value to return</param>
        ''' <returns></returns>
        ''' <remarks>
        ''' If the node does not exist or it causes any error the default value will be returned.
        ''' </remarks>
        ''' <history>
        ''' 	[VMasanas]	09/09/2004	Added new method to return converted values
        ''' 	[cnurse]	11/08/2004	moved from PortalController and made Public Shared
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetNodeValueInt(ByVal objNode As XmlNode, ByVal NodeName As String, Optional ByVal DefaultValue As Integer = 0) As Integer
            Dim intValue As Integer = DefaultValue

            Try
                intValue = Convert.ToInt32(objNode.Item(NodeName).InnerText)
            Catch
                ' node does not exist / data conversion error - legacy issue: use default value
            End Try

            Return intValue

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the value of node
        ''' </summary>
        ''' <param name="objNode">Parent node</param>
        ''' <param name="NodeName">Child node to look for</param>
        ''' <param name="DefaultValue">Default value to return</param>
        ''' <returns></returns>
        ''' <remarks>
        ''' If the node does not exist or it causes any error the default value will be returned.
        ''' </remarks>
        ''' <history>
        ''' 	[VMasanas]	09/09/2004	Added new method to return converted values
        ''' 	[cnurse]	11/08/2004	moved from PortalController and made Public Shared
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetNodeValueSingle(ByVal objNode As XmlNode, ByVal NodeName As String, Optional ByVal DefaultValue As Single = 0) As Single
            Dim sValue As Single = DefaultValue

            Try
                sValue = Convert.ToSingle(objNode.Item(NodeName).InnerText)
            Catch
                ' node does not exist / data conversion error - legacy issue: use default value
            End Try

            Return sValue

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the value of node
        ''' </summary>
        ''' <param name="objNode">Parent node</param>
        ''' <param name="NodeName">Child node to look for</param>
        ''' <param name="DefaultValue">Default value to return</param>
        ''' <returns></returns>
        ''' <remarks>
        ''' If the node does not exist or it causes any error the default value will be returned.
        ''' </remarks>
        ''' <history>
        ''' 	[VMasanas]	09/09/2004	Added new method to return converted values
        ''' 	[cnurse]	11/08/2004	moved from PortalController and made Public Shared
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetNodeValueBoolean(ByVal objNode As XmlNode, ByVal NodeName As String, Optional ByVal DefaultValue As Boolean = False) As Boolean
            Dim bValue As Boolean = DefaultValue

            Try
                bValue = Convert.ToBoolean(objNode.Item(NodeName).InnerText)
            Catch
                ' node does not exist / data conversion error - legacy issue: use default value
            End Try

            Return bValue

        End Function

    End Class
End Namespace