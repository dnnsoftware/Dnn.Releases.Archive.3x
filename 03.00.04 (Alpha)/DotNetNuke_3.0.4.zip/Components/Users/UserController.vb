'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data
Imports System.Threading
Imports Microsoft.ScalableHosting.Security
Imports DotNetNuke.Security.Roles

Namespace DotNetNuke.Entities.Users

	Public Class UserController

		Public Shared Function GetCurrentUserInfo() As UserInfo
			If (HttpContext.Current Is Nothing) Then
				If Not (Thread.CurrentPrincipal.Identity.IsAuthenticated) Then
					Return New UserInfo
				Else
					Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
					Dim objUserController As UserController = New UserController
					Dim objUser As UserInfo
					objUser = objUserController.GetUserByUsername(_portalSettings.PortalId, Thread.CurrentPrincipal.Identity.Name)
					If Not objUser Is Nothing Then
						Return objUser
					Else
						Return New UserInfo
					End If
				End If
			Else
				Dim objUser As UserInfo = CType(HttpContext.Current.Items("UserInfo"), UserInfo)
				If Not ObjUser Is Nothing Then
					Return objUser
				Else
					Return New UserInfo
				End If
			End If
		End Function

		Public Function GetCacheKey(ByVal PortalID As Integer, ByVal Username As String) As String
			Return "UserInfo|" + PortalID.ToString + "|" + Username
		End Function

		Public Sub SynchronizeUsers(ByVal PortalID As Integer)

			Dim objUserController As New UserController
			Dim objMembers As MembershipUserCollection = Microsoft.ScalableHosting.Security.Membership.GetAllUsers()
			Dim objMember As MembershipUser
			For Each objMember In objMembers
				If objUserController.GetUserByUsername(PortalID, objMember.UserName) Is Nothing Then
					Dim objuser As New UserInfo
					objuser.PortalID = PortalID
					objuser.Membership.Username = objMember.UserName
					objuser.Membership.Approved = objMember.IsApproved
					objuser.AffiliateID = -1
					objUserController.AddUser(objuser, False)
				End If
			Next
		End Sub

		Public Function AddUser(ByVal objUser As UserInfo) As Integer
			Return AddUser(objUser, True)
		End Function

		Public Function AddUser(ByVal objUser As UserInfo, ByVal AddToMembershipProvider As Boolean) As Integer
			Dim originalAppName As String = Common.Globals.GetApplicationName()
			Dim UserId As Integer = -1

			Try
				Dim objStatus As Microsoft.ScalableHosting.Security.MembershipCreateStatus = MembershipCreateStatus.Success
				If AddToMembershipProvider Then
					If objUser.IsSuperUser Then
						Common.Globals.SetApplicationName(Common.Globals.glbSuperUserAppName)
					Else
						Common.Globals.SetApplicationName(objUser.PortalID)
					End If
					Dim objMembershipUser As MembershipUser
					objMembershipUser = Microsoft.ScalableHosting.Security.Membership.CreateUser(objUser.Membership.Username, objUser.Membership.Password, objUser.Membership.Email, objUser.Membership.PasswordQuestion, objUser.Membership.PasswordAnswer, objUser.Membership.Approved, objStatus)
				End If
				UserId = DataProvider.Instance().AddUser(objUser.PortalID, objUser.Membership.Username, objUser.Profile.FirstName, objUser.Profile.LastName, objUser.AffiliateID, objUser.IsSuperUser)
				Select Case objStatus
					Case MembershipCreateStatus.DuplicateEmail
						Return -1 * CType(MembershipCreateStatus.DuplicateEmail, Integer)
					Case MembershipCreateStatus.DuplicateProviderUserKey
						Return -1 * CType(MembershipCreateStatus.DuplicateProviderUserKey, Integer)
					Case MembershipCreateStatus.DuplicateUserName
						Return -1 * CType(MembershipCreateStatus.DuplicateUserName, Integer)
					Case MembershipCreateStatus.InvalidAnswer
						Return -1 * CType(MembershipCreateStatus.InvalidAnswer, Integer)
					Case MembershipCreateStatus.InvalidEmail
						Return -1 * CType(MembershipCreateStatus.InvalidEmail, Integer)
					Case MembershipCreateStatus.InvalidPassword
						Return -1 * CType(MembershipCreateStatus.InvalidPassword, Integer)
					Case MembershipCreateStatus.InvalidProviderUserKey
						Return -1 * CType(MembershipCreateStatus.InvalidProviderUserKey, Integer)
					Case MembershipCreateStatus.InvalidQuestion
						Return -1 * CType(MembershipCreateStatus.InvalidQuestion, Integer)
					Case MembershipCreateStatus.InvalidUserName
						Return -1 * CType(MembershipCreateStatus.InvalidUserName, Integer)
					Case MembershipCreateStatus.ProviderError
						Return -1 * CType(MembershipCreateStatus.ProviderError, Integer)
					Case MembershipCreateStatus.UserRejected
						Return -1 * CType(MembershipCreateStatus.UserRejected, Integer)
					Case MembershipCreateStatus.Success
						If AddToMembershipProvider Then
							Dim objProfile As Microsoft.ScalableHosting.Profile.ProfileBase
							objProfile = Microsoft.ScalableHosting.Profile.ProfileBase.Create(objUser.Membership.Username, True)
							objProfile("FirstName") = objUser.Profile.FirstName
							objProfile("LastName") = objUser.Profile.LastName
							objProfile("Unit") = objUser.Profile.Unit
							objProfile("Street") = objUser.Profile.Street
							objProfile("City") = objUser.Profile.City
							objProfile("Region") = objUser.Profile.Region
							objProfile("PostalCode") = objUser.Profile.PostalCode
							objProfile("Country") = objUser.Profile.Country
							objProfile("Telephone") = objUser.Profile.Telephone
							objProfile("Cell") = objUser.Profile.Cell
							objProfile("Fax") = objUser.Profile.Fax
							objProfile("IM") = objUser.Profile.IM
							objProfile("Website") = objUser.Profile.Website
							objProfile("TimeZone") = objUser.Profile.TimeZone
							objProfile("PreferredLocale") = objUser.Profile.PreferredLocale
							objProfile.Save()

							Dim objRoles As New RoleController
							Dim objRole As RoleInfo

							' autoassign user to portal roles
							Dim arrRoles As ArrayList = CBO.FillCollection(DataProvider.Instance().GetPortalRoles(objUser.PortalID), GetType(RoleInfo))
							Dim i As Integer
							For i = 0 To arrRoles.Count - 1
								objRole = CType(arrRoles(i), RoleInfo)
								If objRole.AutoAssignment = True Then
									objRoles.AddUserRole(objUser.PortalID, UserId, objRole.RoleID, Null.NullDate)
								End If
							Next
						End If
				End Select

				Return UserId

			Catch exc As Exception			 ' an unexpected error occurred
				LogException(exc)
			Finally
				Common.Globals.SetApplicationName(originalAppName)
			End Try
		End Function

		Friend Function GetRegistrationStatus(ByVal UserRegistrationStatus As MembershipCreateStatus) As String
			Select Case UserRegistrationStatus
				Case Microsoft.ScalableHosting.Security.MembershipCreateStatus.DuplicateEmail
					Return Services.Localization.Localization.GetString("UserEmailExists")
				Case Microsoft.ScalableHosting.Security.MembershipCreateStatus.InvalidAnswer
					Return Services.Localization.Localization.GetString("InvalidAnswer")
				Case Microsoft.ScalableHosting.Security.MembershipCreateStatus.InvalidEmail
					Return Services.Localization.Localization.GetString("InvalidEmail")
				Case Microsoft.ScalableHosting.Security.MembershipCreateStatus.InvalidPassword
					Return Services.Localization.Localization.GetString("InvalidPassword")
				Case Microsoft.ScalableHosting.Security.MembershipCreateStatus.InvalidQuestion
					Return Services.Localization.Localization.GetString("InvalidQuestion")
				Case Microsoft.ScalableHosting.Security.MembershipCreateStatus.InvalidUserName
					Return Services.Localization.Localization.GetString("InvalidUserName")
				Case Microsoft.ScalableHosting.Security.MembershipCreateStatus.UserRejected
					Return Services.Localization.Localization.GetString("UserRejected")
				Case Microsoft.ScalableHosting.Security.MembershipCreateStatus.DuplicateUserName
					Return Services.Localization.Localization.GetString("UserNameExists")
				Case Microsoft.ScalableHosting.Security.MembershipCreateStatus.ProviderError, Microsoft.ScalableHosting.Security.MembershipCreateStatus.DuplicateProviderUserKey, Microsoft.ScalableHosting.Security.MembershipCreateStatus.InvalidProviderUserKey
					Return Services.Localization.Localization.GetString("RegError")
			End Select
		End Function

		Public Function DeleteUser(ByVal PortalId As Integer, ByVal UserId As Integer) As Boolean
			Dim OriginalApplicationName As String = Common.Globals.GetApplicationName
			Try

				Dim objUser As UserInfo = Me.GetUser(PortalId, UserId)

				If objUser.IsSuperUser Then
					Common.Globals.SetApplicationName(Common.Globals.glbSuperUserAppName)
				Else
					Common.Globals.SetApplicationName(objUser.PortalID)
				End If

				Membership.DeleteUser(objUser.Username, True)

				Dim CanDelete As Boolean = True
				Dim dr As IDataReader

				dr = DataProvider.Instance().GetPortal(PortalId)
				If dr.Read Then
					If UserId = Convert.ToInt32(dr("AdministratorId")) Then
						CanDelete = False
					End If
				End If
				If Not dr Is Nothing Then
					dr.Close()
				End If
				If CanDelete Then
					' Obtain PortalSettings from Current Context
					Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings

					' send email notification to portal administrator that the user was removed from the portal
					SendNotification(_portalSettings.Email, _portalSettings.Email, "", Services.Localization.Localization.GetSystemMessage(PortalId, "EMAIL_USER_UNREGISTER_SUBJECT", UserId), Services.Localization.Localization.GetSystemMessage(PortalId, "EMAIL_USER_UNREGISTER_BODY", UserId))


					dr = DataProvider.Instance().GetRolesByUser(UserId, PortalId)
					While dr.Read
						DataProvider.Instance().DeleteUserRole(UserId, Convert.ToInt32(dr("RoleId")))
					End While
					dr.Close()

					dr = DataProvider.Instance().GetUsers(UserId)
					If Not dr.Read Then
						DataProvider.Instance().DeleteUser(UserId)
					End If
					dr.Close()
				End If


				Dim UserInfoCacheKey As String = GetCacheKey(objUser.PortalID, objUser.Username)
				DataCache.RemoveCache(UserInfoCacheKey)


				Return CanDelete

			Finally
				Common.Globals.SetApplicationName(OriginalApplicationName)
			End Try

		End Function

		Public Sub DeleteUsers(ByVal PortalId As Integer)
			Dim arr As New ArrayList

			Dim OriginalApplicationName As String = Common.Globals.GetApplicationName
			Try

				Common.Globals.SetApplicationName(PortalId)

				Dim objMembershipUsers As MembershipUserCollection = Membership.GetAllUsers
				Dim objMembershipUser As MembershipUser

				For Each objMembershipUser In objMembershipUsers
					If objMembershipUser.IsApproved = False Or objMembershipUser.LastLoginDate = Null.NullDate Then
						Dim objUser As UserInfo = Me.GetUserByUsername(PortalId, objMembershipUser.UserName)
						arr.Add(objUser)
					End If
				Next

			Finally
				Common.Globals.SetApplicationName(OriginalApplicationName)
			End Try

			Dim i As Integer
			For i = 0 To arr.Count - 1
				Dim objUser As UserInfo = CType(arr(i), UserInfo)
				DeleteUser(objUser.PortalID, objUser.UserID)
			Next

		End Sub

		Public Sub UpdateUser(ByVal objUser As UserInfo)
			Dim OriginalApplicationName As String = Common.Globals.GetApplicationName
			Try

				If objUser.IsSuperUser Then
					Common.Globals.SetApplicationName(Common.Globals.glbSuperUserAppName)
				Else
					Common.Globals.SetApplicationName(objUser.PortalID)
				End If

				Dim objProfile As Microsoft.ScalableHosting.Profile.ProfileBase
				objProfile = Microsoft.ScalableHosting.Profile.ProfileBase.Create(objUser.Membership.Username, True)
				objProfile("FirstName") = objUser.Profile.FirstName
				objProfile("LastName") = objUser.Profile.LastName
				objProfile("Unit") = objUser.Profile.Unit
				objProfile("Street") = objUser.Profile.Street
				objProfile("City") = objUser.Profile.City
				objProfile("Region") = objUser.Profile.Region
				objProfile("PostalCode") = objUser.Profile.PostalCode
				objProfile("Country") = objUser.Profile.Country
				objProfile("Telephone") = objUser.Profile.Telephone
				objProfile("Cell") = objUser.Profile.Cell
				objProfile("Fax") = objUser.Profile.Fax
				objProfile("IM") = objUser.Profile.IM
				objProfile("Website") = objUser.Profile.Website
				objProfile("TimeZone") = objUser.Profile.TimeZone
				objProfile("PreferredLocale") = objUser.Profile.PreferredLocale
				objProfile.Save()

				Dim objMembershipUser As Microsoft.ScalableHosting.Security.MembershipUser
				objMembershipUser = Microsoft.ScalableHosting.Security.Membership.GetUser(objUser.Membership.Username)
				objMembershipUser.Email = objUser.Membership.Email
				objMembershipUser.LastActivityDate = Now
				Microsoft.ScalableHosting.Security.Membership.UpdateUser(objMembershipUser)
				If objUser.Membership.Password <> "" Then
					objMembershipUser.ChangePassword(objMembershipUser.GetPassword, objUser.Membership.Password)
				End If

				Dim UserInfoCacheKey As String = GetCacheKey(objUser.PortalID, objUser.Username)
				DataCache.RemoveCache(UserInfoCacheKey)

			Finally
				Common.Globals.SetApplicationName(OriginalApplicationName)
			End Try
		End Sub

		Public Function GetUsers(ByVal SynchronizeUsers As Boolean, ByVal ProgressiveHydration As Boolean) As ArrayList
			Return GetUsers(-1, SynchronizeUsers, ProgressiveHydration)
		End Function

		Public Function GetUsers(ByVal PortalId As Integer, ByVal SynchronizeUsers As Boolean, ByVal ProgressiveHydration As Boolean) As ArrayList
			If SynchronizeUsers Then
				Me.SynchronizeUsers(PortalId)
			End If
			Return FillUserInfoCollection(DataProvider.Instance().GetUsers(PortalId), ProgressiveHydration)
		End Function

		Public Function GetUser(ByVal PortalId As Integer, ByVal UserId As Integer) As UserInfo
			Dim dr As IDataReader
			Try
				dr = DataProvider.Instance().GetUser(PortalId, UserId)
				If dr.Read Then
					Return FillUserInfo(dr)
				End If
			Finally
				If Not dr Is Nothing Then
					dr.Close()
				End If
			End Try
		End Function

		Public Function GetUserByUsername(ByVal PortalID As Integer, ByVal Username As String) As UserInfo
			Return GetUserByUsername(PortalID, Username, False)
		End Function

		Public Function GetUserByUsername(ByVal PortalID As Integer, ByVal Username As String, ByVal SynchronizeUsers As Boolean) As UserInfo
			Dim dr As IDataReader
			Try
				If SynchronizeUsers Then
					Me.SynchronizeUsers(PortalID)
				End If
				Dim objUser As UserInfo
				dr = DataProvider.Instance().GetUserByUsername(PortalID, Username)
				If dr.Read Then
					objUser = FillUserInfo(dr)
				End If
				Return objUser
			Finally
				If Not dr Is Nothing Then
					dr.Close()
				End If
			End Try
		End Function

		Public Function GetSuperUsers() As ArrayList

			Return FillUserInfoCollection(DataProvider.Instance().GetSuperUsers(), True)

		End Function

		Private Function FillUserInfoCollection(ByVal dr As IDataReader, ByVal ProgressiveHydration As Boolean) As ArrayList
			Try
				Dim arr As New ArrayList
				Dim obj As UserInfo
				While dr.Read
					' fill business object
					obj = FillUserInfo(dr, False, ProgressiveHydration)
					' add to collection
					arr.Add(obj)
				End While
				Return arr
			Catch exc As Exception
				LogException(exc)
			Finally
				' close datareader
				If Not dr Is Nothing Then
					dr.Close()
				End If
			End Try
		End Function

		Private Function FillUserInfo(ByVal dr As IDataReader, ByVal CheckForOpenDataReader As Boolean, ByVal ProgressiveHydration As Boolean) As UserInfo
			Dim OriginalApplicationName As String = Common.Globals.GetApplicationName
			Try
				Dim objUserInfo As New UserInfo
				' read datareader
				Dim Continue As Boolean = True

				If CheckForOpenDataReader Then
					Continue = False
					If dr.Read Then
						Continue = True
					End If
				End If
				If Continue Then

					'fill the base userInfo object
					objUserInfo = FillUserInfo(dr)

					If Not ProgressiveHydration Then
						'fill the Membership object
						objUserInfo.Membership = FillUserMembership(objUserInfo)

						'fill the Profile object
						objUserInfo.Profile = FillUserProfile(objUserInfo)
					End If
				Else
					objUserInfo = Nothing
				End If
				Return objUserInfo
			Finally
				If CheckForOpenDataReader Then
					If Not dr Is Nothing Then
						dr.Close()
					End If
				End If
				Common.Globals.SetApplicationName(OriginalApplicationName)
			End Try
		End Function

		Friend Function FillUserInfo(ByVal PortalID As Integer, ByVal Username As String) As UserInfo
			Dim dr As IDataReader
			Try
				dr = DataProvider.Instance().GetUserByUsername(PortalID, Username)
				If dr.Read Then
					Return FillUserInfo(dr)
				End If
			Finally
				If Not dr Is Nothing Then
					dr.Close()
				End If
			End Try
		End Function

		Friend Function FillUserInfo(ByVal dr As IDataReader) As UserInfo
			Dim objUserInfo As New UserInfo
			Try
				objUserInfo.UserID = Convert.ToInt32(dr("UserID"))
			Catch
			End Try
			Try
				objUserInfo.Username = Convert.ToString(dr("Username"))
			Catch
			End Try
			Try
				objUserInfo.PortalID = Convert.ToInt32(dr("PortalID"))
			Catch
			End Try
			Try
				objUserInfo.IsSuperUser = Convert.ToBoolean(dr("IsSuperUser"))
			Catch
			End Try
			Try
				objUserInfo.AffiliateID = Convert.ToInt32(dr("AffiliateID"))
			Catch
			End Try
			Return objUserInfo
		End Function

		Friend Function FillUserMembership(ByVal objUserInfo As UserInfo) As UserMembership

			If objUserInfo.IsSuperUser Then
				Common.Globals.SetApplicationName(Common.Globals.glbSuperUserAppName)
			Else
				Common.Globals.SetApplicationName(objUserInfo.PortalID)
			End If

			Dim objMembershipUser As Microsoft.ScalableHosting.Security.MembershipUser
			objMembershipUser = Microsoft.ScalableHosting.Security.Membership.GetUser(objUserInfo.Username)

			Dim u As New UserMembership
			Try
				u.Approved = objMembershipUser.IsApproved
			Catch
			End Try
			Try
				u.Username = objMembershipUser.UserName
			Catch
			End Try
			Try
				u.Password = objMembershipUser.GetPassword()
			Catch
			End Try
			Try
				u.CreatedDate = objMembershipUser.CreationDate
			Catch
			End Try
			Try
				u.LastLoginDate = objMembershipUser.LastLoginDate
			Catch
			End Try
			Try
				u.Email = objMembershipUser.Email
			Catch
			End Try
			Try
				u.PasswordQuestion = objMembershipUser.PasswordQuestion
			Catch
			End Try
			Return u
		End Function

		Friend Function FillUserProfile(ByVal objUserInfo As UserInfo) As UserProfile

			If objUserInfo.IsSuperUser Then
				Common.Globals.SetApplicationName(Common.Globals.glbSuperUserAppName)
			Else
				Common.Globals.SetApplicationName(objUserInfo.PortalID)
			End If

			Dim objProfile As Microsoft.ScalableHosting.Profile.ProfileBase
			objProfile = Microsoft.ScalableHosting.Profile.ProfileBase.Create(objUserInfo.Username, True)
			Dim u As New UserProfile
			Try
				u.City = Convert.ToString(objProfile("City"))
			Catch
			End Try
			Try
				u.Country = Convert.ToString(objProfile("Country"))
			Catch
			End Try
			Try
				u.Unit = Convert.ToString(objProfile("Unit"))
			Catch
			End Try
			Try
				u.PostalCode = Convert.ToString(objProfile("PostalCode"))
			Catch
			End Try
			Try
				u.Region = Convert.ToString(objProfile("Region"))
			Catch
			End Try
			Try
				u.Street = Convert.ToString(objProfile("Street"))
			Catch
			End Try
			Try
				u.Telephone = Convert.ToString(objProfile("Telephone"))
			Catch
			End Try
			Try
				u.FirstName = Convert.ToString(objProfile("FirstName"))
			Catch
			End Try
			Try
				u.LastName = Convert.ToString(objProfile("LastName"))
			Catch
			End Try
			Try
				u.Cell = Convert.ToString(objProfile("Cell"))
			Catch
			End Try
			Try
				u.Fax = Convert.ToString(objProfile("Fax"))
			Catch
			End Try
			Try
				u.IM = Convert.ToString(objProfile("IM"))
			Catch
			End Try
			Try
				u.Website = Convert.ToString(objProfile("Website"))
			Catch
			End Try
			Try
				u.TimeZone = Convert.ToInt32(objProfile("TimeZone"))
			Catch
			End Try
			Try
				u.PreferredLocale = Convert.ToString(objProfile("PreferredLocale"))
			Catch
			End Try
			Return u
		End Function

	End Class


End Namespace
