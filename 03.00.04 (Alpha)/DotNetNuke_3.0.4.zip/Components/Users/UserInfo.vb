'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Namespace DotNetNuke.Entities.Users

    Public Class UserInfo
        Private _UserID As Integer
        Private _Username As String
        Private _PortalID As Integer
        Private _IsSuperUser As Boolean
        Private _AffiliateID As Integer
        Private _Membership As UserMembership
        Private _Profile As UserProfile

        Public Sub New()

            _UserID = -1
            _Membership = New UserMembership
            _Profile = New UserProfile
            _IsSuperUser = False
        End Sub

        Public Property UserID() As Integer
            Get
                Return _UserID
            End Get
            Set(ByVal Value As Integer)
                _UserID = Value
            End Set
        End Property
        Public Property Username() As String
            Get
                Return _Username
            End Get
            Set(ByVal Value As String)
                _Username = Value
            End Set
        End Property
        Public Property PortalID() As Integer
            Get
                Return _PortalID
            End Get
            Set(ByVal Value As Integer)
                _PortalID = Value
            End Set
        End Property
        Public Property IsSuperUser() As Boolean
            Get
                Return _IsSuperUser
            End Get
            Set(ByVal Value As Boolean)
                _IsSuperUser = Value
            End Set
        End Property
        Public Property AffiliateID() As Integer
            Get
                Return _AffiliateID
            End Get
            Set(ByVal Value As Integer)
                _AffiliateID = Value
            End Set
        End Property
        Public Property Membership() As Entities.Users.UserMembership
            Get
                'implemented progressive hydration
                'this object will be hydrated on demand
                If Not _Membership.ObjectHydrated AndAlso Not Me.Username Is Nothing AndAlso Me.Username.Length > 0 Then
                    Dim objUserController As New UserController
                    _Membership = objUserController.FillUserMembership(Me)
                    _Membership.ObjectHydrated = True
                End If
                Return _Membership
            End Get
            Set(ByVal Value As Entities.Users.UserMembership)
                _Membership = Value
                _Membership.ObjectHydrated = True
            End Set
        End Property
        Public Property Profile() As Entities.Users.UserProfile
            Get
                'implemented progressive hydration
                'this object will be hydrated on demand
                If Not _Profile.ObjectHydrated AndAlso Not Me.Username Is Nothing AndAlso Me.Username.Length > 0 Then
                    Dim objUserController As New UserController
                    _Profile = objUserController.FillUserProfile(Me)
                    _Profile.ObjectHydrated = True
                End If
                Return _Profile
            End Get
            Set(ByVal Value As Entities.Users.UserProfile)
                _Profile = Value
                _Profile.ObjectHydrated = True
            End Set
        End Property
    End Class

    Public Enum UserRegistrationStatus
        AddUser = 0
        AddUserRoles = -1
        UsernameAlreadyExists = -2
        UserAlreadyRegistered = -3
        UnexpectedError = -4
    End Enum




End Namespace
