'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System

Namespace DotNetNuke.Data

	Public MustInherit Class DataProvider

#Region "Shared/Static Methods"

		' singleton reference to the instantiated object 
		Private Shared objProvider As DataProvider = Nothing

		' constructor
		Shared Sub New()
			CreateProvider()
		End Sub

		' dynamically create provider
		Private Shared Sub CreateProvider()
			objProvider = CType(Framework.Reflection.CreateObject("data"), DataProvider)
		End Sub

		' return the provider
		Public Shared Shadows Function Instance() As DataProvider
			Return objProvider
		End Function

#End Region

#Region "Abstract Methods"

		' upgrade
		Public MustOverride Function GetProviderPath() As String
		Public MustOverride Overloads Function ExecuteScript(ByVal SQL As String) As String
		Public MustOverride Overloads Function ExecuteScript(ByVal SQL As String, ByVal UseTransactions As Boolean) As String
		Public MustOverride Function GetDatabaseVersion() As IDataReader
		Public MustOverride Sub UpdateDatabaseVersion(ByVal Major As Integer, ByVal Minor As Integer, ByVal Build As Integer)
		Public MustOverride Function FindDatabaseVersion(ByVal Major As Integer, ByVal Minor As Integer, ByVal Build As Integer) As IDataReader
		Public MustOverride Sub UpgradeDatabaseSchema(ByVal Major As Integer, ByVal Minor As Integer, ByVal Build As Integer)

		' host
		Public MustOverride Function GetHostSettings() As IDataReader
		Public MustOverride Function GetHostSetting(ByVal SettingName As String) As IDataReader
		Public MustOverride Sub AddHostSetting(ByVal SettingName As String, ByVal SettingValue As String)
		Public MustOverride Sub UpdateHostSetting(ByVal SettingName As String, ByVal SettingValue As String)

		' portal
		Public MustOverride Function GetPortalByAlias(ByVal PortalAlias As String) As IDataReader
		Public MustOverride Function GetPortalByTab(ByVal TabId As Integer, ByVal PortalAlias As String) As IDataReader
		Public MustOverride Function AddPortalInfo(ByVal PortalName As String, ByVal Currency As String, ByVal FirstName As String, ByVal LastName As String, ByVal Username As String, ByVal Password As String, ByVal Email As String, ByVal ExpiryDate As Date, ByVal HostFee As Double, ByVal HostSpace As Double, ByVal SiteLogHistory As Integer, ByVal HomeDirectory As String) As Integer
        Public MustOverride Sub UpdatePortalInfo(ByVal PortalId As Integer, ByVal PortalName As String, ByVal LogoFile As String, ByVal FooterText As String, ByVal ExpiryDate As Date, ByVal UserRegistration As Integer, ByVal BannerAdvertising As Integer, ByVal Currency As String, ByVal AdministratorId As Integer, ByVal HostFee As Double, ByVal HostSpace As Double, ByVal PaymentProcessor As String, ByVal ProcessorUserId As String, ByVal ProcessorPassword As String, ByVal Description As String, ByVal KeyWords As String, ByVal BackgroundFile As String, ByVal SiteLogHistory As Integer, ByVal SplashTabId As Integer, ByVal HomeTabId As Integer, ByVal LoginTabId As Integer, ByVal UserTabId As Integer, ByVal DefaultLanguage As String, ByVal TimeZoneOffset As Integer, ByVal HomeDirectory As String)
        Public MustOverride Sub UpdatePortalSetup(ByVal PortalId As Integer, ByVal AdministratorId As Integer, ByVal AdministratorRoleId As Integer, ByVal RegisteredRoleId As Integer, ByVal SplashTabId As Integer, ByVal HomeTabId As Integer, ByVal LoginTabId As Integer, ByVal UserTabId As Integer, ByVal AdminTabId As Integer)
        Public MustOverride Sub DeletePortalInfo(ByVal PortalId As Integer)
        Public MustOverride Function GetPortals() As IDataReader
        Public MustOverride Function GetPortal(ByVal PortalId As Integer) As IDataReader
        Public MustOverride Function GetPortalSpaceUsed(ByVal PortalId As Integer) As IDataReader
        Public MustOverride Function VerifyPortalTab(ByVal PortalId As Integer, ByVal TabId As Integer) As IDataReader
        Public MustOverride Function VerifyPortal(ByVal PortalId As Integer) As IDataReader

        ' tab
        Public MustOverride Function AddTab(ByVal PortalId As Integer, ByVal TabName As String, ByVal IsVisible As Boolean, ByVal DisableLink As Boolean, ByVal ParentId As Integer, ByVal IconFile As String, ByVal Title As String, ByVal Description As String, ByVal KeyWords As String, ByVal Url As String, ByVal SkinSrc As String, ByVal ContainerSrc As String, ByVal TabPath As String, ByVal StartDate As Date, ByVal EndDate As Date) As Integer
        Public MustOverride Sub UpdateTab(ByVal TabId As Integer, ByVal TabName As String, ByVal IsVisible As Boolean, ByVal DisableLink As Boolean, ByVal ParentId As Integer, ByVal IconFile As String, ByVal Title As String, ByVal Description As String, ByVal KeyWords As String, ByVal IsDeleted As Boolean, ByVal Url As String, ByVal SkinSrc As String, ByVal ContainerSrc As String, ByVal TabPath As String, ByVal StartDate As Date, ByVal EndDate As Date)
        Public MustOverride Sub UpdateTabOrder(ByVal TabId As Integer, ByVal TabOrder As Integer, ByVal Level As Integer, ByVal ParentId As Integer)
        Public MustOverride Sub DeleteTab(ByVal TabId As Integer)
        Public MustOverride Function GetTabs(ByVal PortalId As Integer) As IDataReader
        Public MustOverride Function GetAllTabs() As IDataReader
        Public MustOverride Function GetTab(ByVal TabId As Integer) As IDataReader
        Public MustOverride Function GetTabByName(ByVal TabName As String, ByVal PortalId As Integer) As IDataReader
        Public MustOverride Function GetTabsByParentId(ByVal ParentId As Integer) As IDataReader
        Public MustOverride Function GetPortalTabModules(ByVal PortalId As Integer, ByVal TabId As Integer) As IDataReader
        Public MustOverride Function GetTabPanes(ByVal TabId As Integer) As IDataReader

        ' module
        Public MustOverride Function GetAllModules() As IDataReader
        Public MustOverride Function GetModules(ByVal PortalId As Integer) As IDataReader
        Public MustOverride Function GetModule(ByVal ModuleId As Integer, ByVal TabId As Integer) As IDataReader
        Public MustOverride Function GetModuleByDefinition(ByVal PortalId As Integer, ByVal FriendlyName As String) As IDataReader
        Public MustOverride Function AddModule(ByVal PortalID As Integer, ByVal ModuleDefID As Integer, ByVal ModuleTitle As String, ByVal AllTabs As Boolean, ByVal Header As String, ByVal Footer As String, ByVal StartDate As DateTime, ByVal EndDate As DateTime, ByVal InheritViewPermissions As Boolean, ByVal IsDeleted As Boolean) As Integer
        Public MustOverride Sub UpdateModule(ByVal ModuleId As Integer, ByVal ModuleTitle As String, ByVal AllTabs As Boolean, ByVal Header As String, ByVal Footer As String, ByVal StartDate As DateTime, ByVal EndDate As DateTime, ByVal InheritViewPermissions As Boolean, ByVal IsDeleted As Boolean)
        Public MustOverride Sub DeleteModule(ByVal ModuleId As Integer)
        Public MustOverride Function GetTabModuleOrder(ByVal TabId As Integer, ByVal PaneName As String) As IDataReader
        Public MustOverride Sub UpdateModuleOrder(ByVal TabId As Integer, ByVal ModuleId As Integer, ByVal ModuleOrder As Integer, ByVal PaneName As String)

        Public MustOverride Sub AddTabModule(ByVal TabId As Integer, ByVal ModuleId As Integer, ByVal ModuleOrder As Integer, ByVal PaneName As String, ByVal CacheTime As Integer, ByVal Alignment As String, ByVal Color As String, ByVal Border As String, ByVal IconFile As String, ByVal Visibility As Integer, ByVal ContainerSrc As String)
        Public MustOverride Sub UpdateTabModule(ByVal TabId As Integer, ByVal ModuleId As Integer, ByVal ModuleOrder As Integer, ByVal PaneName As String, ByVal CacheTime As Integer, ByVal Alignment As String, ByVal Color As String, ByVal Border As String, ByVal IconFile As String, ByVal Visibility As Integer, ByVal ContainerSrc As String)
        Public MustOverride Sub DeleteTabModule(ByVal TabId As Integer, ByVal ModuleId As Integer)

        Public MustOverride Function GetModuleSettings(ByVal ModuleId As Integer) As IDataReader
        Public MustOverride Function GetModuleSetting(ByVal ModuleId As Integer, ByVal SettingName As String) As IDataReader
        Public MustOverride Sub AddModuleSetting(ByVal ModuleId As Integer, ByVal SettingName As String, ByVal SettingValue As String)
        Public MustOverride Sub UpdateModuleSetting(ByVal ModuleId As Integer, ByVal SettingName As String, ByVal SettingValue As String)

        Public MustOverride Function GetTabModuleSettings(ByVal TabModuleId As Integer) As IDataReader
        Public MustOverride Function GetTabModuleSetting(ByVal TabModuleId As Integer, ByVal SettingName As String) As IDataReader
        Public MustOverride Sub AddTabModuleSetting(ByVal TabModuleId As Integer, ByVal SettingName As String, ByVal SettingValue As String)
        Public MustOverride Sub UpdateTabModuleSetting(ByVal TabModuleId As Integer, ByVal SettingName As String, ByVal SettingValue As String)

        ' module definition
        Public MustOverride Function GetDesktopModule(ByVal DesktopModuleId As Integer) As IDataReader
        Public MustOverride Function GetDesktopModuleByName(ByVal FriendlyName As String) As IDataReader
        Public MustOverride Function GetDesktopModules() As IDataReader
        Public MustOverride Function GetDesktopModulesByPortal(ByVal PortalID As Integer) As IDataReader
        Public MustOverride Function AddDesktopModule(ByVal FriendlyName As String, ByVal Description As String, ByVal Version As String, ByVal IsPremium As Boolean, ByVal IsAdmin As Boolean, ByVal BusinessControllerClass As String) As Integer
        Public MustOverride Sub UpdateDesktopModule(ByVal DesktopModuleId As Integer, ByVal FriendlyName As String, ByVal Description As String, ByVal Version As String, ByVal IsPremium As Boolean, ByVal IsAdmin As Boolean, ByVal BusinessControllerClass As String)
        Public MustOverride Sub DeleteDesktopModule(ByVal DesktopModuleId As Integer)

        Public MustOverride Function GetPortalDesktopModules(ByVal PortalID As Integer, ByVal DesktopModuleID As Integer) As IDataReader
        Public MustOverride Function AddPortalDesktopModule(ByVal PortalID As Integer, ByVal DesktopModuleID As Integer) As Integer
        Public MustOverride Sub DeletePortalDesktopModules(ByVal PortalID As Integer, ByVal DesktopModuleID As Integer)

        Public MustOverride Function GetModuleDefinitions(ByVal DesktopModuleId As Integer) As IDataReader
        Public MustOverride Function GetModuleDefinition(ByVal ModuleDefId As Integer) As IDataReader
        Public MustOverride Function GetModuleDefinitionByName(ByVal DesktopModuleId As Integer, ByVal FriendlyName As String) As IDataReader
        Public MustOverride Function AddModuleDefinition(ByVal DesktopModuleId As Integer, ByVal FriendlyName As String) As Integer
        Public MustOverride Sub DeleteModuleDefinition(ByVal ModuleDefId As Integer)

        Public MustOverride Function GetModuleControl(ByVal ModuleControlId As Integer) As IDataReader
        Public MustOverride Function GetModuleControls(ByVal ModuleDefID As Integer) As IDataReader
        Public MustOverride Function GetModuleControlsByKey(ByVal ControlKey As String, ByVal ModuleDefId As Integer) As IDataReader
        Public MustOverride Function GetModuleControlByKeyAndSrc(ByVal ModuleDefID As Integer, ByVal ControlKey As String, ByVal ControlSrc As String) As IDataReader
        Public MustOverride Function AddModuleControl(ByVal ModuleDefId As Integer, ByVal ControlKey As String, ByVal ControlTitle As String, ByVal ControlSrc As String, ByVal IconFile As String, ByVal ControlType As Integer, ByVal ViewOrder As Integer, ByVal HelpUrl As String) As Integer
        Public MustOverride Sub UpdateModuleControl(ByVal ModuleControlId As Integer, ByVal ModuleDefId As Integer, ByVal ControlKey As String, ByVal ControlTitle As String, ByVal ControlSrc As String, ByVal IconFile As String, ByVal ControlType As Integer, ByVal ViewOrder As Integer, ByVal HelpUrl As String)
        Public MustOverride Sub DeleteModuleControl(ByVal ModuleControlId As Integer)

        ' files
        Public MustOverride Function GetFiles(ByVal PortalId As Integer, ByVal Folder As String) As IDataReader
        Public MustOverride Function GetFile(ByVal FileName As String, ByVal PortalId As Integer, ByVal Folder As String) As IDataReader
        Public MustOverride Sub DeleteFile(ByVal FileName As String, ByVal PortalId As Integer)
        Public MustOverride Sub DeleteFiles(ByVal PortalId As Integer)
        Public MustOverride Function AddFile(ByVal PortalId As Integer, ByVal FileName As String, ByVal Extension As String, ByVal Size As String, ByVal Width As String, ByVal Height As String, ByVal ContentType As String, ByVal Folder As String) As Integer
        Public MustOverride Sub UpdateFile(ByVal FileId As Integer, ByVal FileName As String, ByVal Extension As String, ByVal Size As String, ByVal Width As String, ByVal Height As String, ByVal ContentType As String, ByVal Folder As String)

        ' site log
        Public MustOverride Sub AddSiteLog(ByVal DateTime As Date, ByVal PortalId As Integer, ByVal UserId As Integer, ByVal Referrer As String, ByVal URL As String, ByVal UserAgent As String, ByVal UserHostAddress As String, ByVal UserHostName As String, ByVal TabId As Integer, ByVal AffiliateId As Integer)
        Public MustOverride Function GetSiteLogReports() As IDataReader
        Public MustOverride Function GetSiteLog(ByVal PortalId As Integer, ByVal PortalAlias As String, ByVal ReportName As String, ByVal StartDate As Date, ByVal EndDate As Date) As IDataReader
        Public MustOverride Sub DeleteSiteLog(ByVal DateTime As Date, ByVal PortalId As Integer)

        ' database 
        Public MustOverride Function ExecuteSQL(ByVal Script As String) As IDataReader
        Public MustOverride Function GetTables() As IDataReader
        Public MustOverride Function GetFields(ByVal TableName As String) As IDataReader

        ' security
        Public MustOverride Function UserLogin(ByVal Username As String, ByVal Password As String) As IDataReader
        Public MustOverride Function GetAuthRoles(ByVal PortalId As Integer, ByVal ModuleId As Integer) As IDataReader

        ' users
        Public MustOverride Function GetUsers(ByVal PortalId As Integer) As IDataReader
        Public MustOverride Function GetUser(ByVal PortalId As Integer, ByVal UserId As Integer) As IDataReader
        Public MustOverride Function GetUserByUsername(ByVal PortalID As Integer, ByVal Username As String) As IDataReader
        Public MustOverride Function GetSuperUsers() As IDataReader
        Public MustOverride Function AddUser(ByVal PortalID As Integer, ByVal Username As String, ByVal FirstName As String, ByVal LastName As String, ByVal AffiliateId As Integer, ByVal IsSuperUser As Boolean) As Integer
        Public MustOverride Sub DeleteUser(ByVal UserId As Integer)
        Public MustOverride Sub UpdateUser(ByVal UserId As Integer, ByVal FirstName As String, ByVal LastName As String)
        Public MustOverride Function GetPortalRoles(ByVal PortalId As Integer) As IDataReader
        Public MustOverride Function GetRoles() As IDataReader
        Public MustOverride Function GetRole(ByVal RoleID As Integer, ByVal PortalID As Integer) As IDataReader
        Public MustOverride Function GetRoleByName(ByVal PortalId As Integer, ByVal RoleName As String) As IDataReader
        Public MustOverride Function AddRole(ByVal PortalId As Integer, ByVal RoleName As String, ByVal Description As String, ByVal ServiceFee As Double, ByVal BillingPeriod As String, ByVal BillingFrequency As String, ByVal TrialFee As Double, ByVal TrialPeriod As Integer, ByVal TrialFrequency As String, ByVal IsPublic As Boolean, ByVal AutoAssignment As Boolean) As Integer
        Public MustOverride Sub DeleteRole(ByVal RoleId As Integer)
        Public MustOverride Sub UpdateRole(ByVal RoleId As Integer, ByVal Description As String, ByVal ServiceFee As Double, ByVal BillingPeriod As String, ByVal BillingFrequency As String, ByVal TrialFee As Double, ByVal TrialPeriod As Integer, ByVal TrialFrequency As String, ByVal IsPublic As Boolean, ByVal AutoAssignment As Boolean)
        Public MustOverride Function GetRolesByUser(ByVal UserId As Integer, ByVal PortalId As Integer) As IDataReader
        Public MustOverride Function GetUserRole(ByVal PortalID As Integer, ByVal UserId As Integer, ByVal RoleId As Integer) As IDataReader
        Public MustOverride Function GetUserRolesByUsername(ByVal PortalID As Integer, ByVal Username As String, ByVal Rolename As String) As IDataReader
        Public MustOverride Function AddUserRole(ByVal PortalID As Integer, ByVal UserId As Integer, ByVal RoleId As Integer, ByVal ExpiryDate As Date) As Integer
        Public MustOverride Sub UpdateUserRole(ByVal UserRoleId As Integer, ByVal ExpiryDate As Date)
        Public MustOverride Sub DeleteUserRole(ByVal UserId As Integer, ByVal RoleId As Integer)
        Public MustOverride Function GetServices(ByVal PortalId As Integer, ByVal UserId As Integer) As IDataReader

        ' vendors
        Public MustOverride Function GetVendors(ByVal PortalId As Integer, ByVal Filter As String) As IDataReader
        Public MustOverride Function GetVendor(ByVal VendorID As Integer, ByVal PortalID As Integer) As IDataReader
        Public MustOverride Sub DeleteVendor(ByVal VendorID As Integer)
        Public MustOverride Function AddVendor(ByVal PortalID As Integer, ByVal VendorName As String, ByVal Unit As String, ByVal Street As String, ByVal City As String, ByVal Region As String, ByVal Country As String, ByVal PostalCode As String, ByVal Telephone As String, ByVal Fax As String, ByVal Cell As String, ByVal Email As String, ByVal Website As String, ByVal FirstName As String, ByVal LastName As String, ByVal UserName As String, ByVal LogoFile As String, ByVal KeyWords As String, ByVal Authorized As String) As Integer
        Public MustOverride Sub UpdateVendor(ByVal VendorID As Integer, ByVal VendorName As String, ByVal Unit As String, ByVal Street As String, ByVal City As String, ByVal Region As String, ByVal Country As String, ByVal PostalCode As String, ByVal Telephone As String, ByVal Fax As String, ByVal Cell As String, ByVal Email As String, ByVal Website As String, ByVal FirstName As String, ByVal LastName As String, ByVal UserName As String, ByVal LogoFile As String, ByVal KeyWords As String, ByVal Authorized As String)
        Public MustOverride Function GetVendorClassifications(ByVal VendorId As Integer) As IDataReader
        Public MustOverride Sub DeleteVendorClassifications(ByVal VendorId As Integer)
        Public MustOverride Function AddVendorClassification(ByVal VendorId As Integer, ByVal ClassificationId As Integer) As Integer

        ' banners
        Public MustOverride Function GetBanners(ByVal VendorId As Integer) As IDataReader
        Public MustOverride Function GetBanner(ByVal BannerId As Integer, ByVal VendorId As Integer) As IDataReader
        Public MustOverride Sub DeleteBanner(ByVal BannerId As Integer)
        Public MustOverride Function AddBanner(ByVal BannerName As String, ByVal VendorId As Integer, ByVal ImageFile As String, ByVal URL As String, ByVal Impressions As Integer, ByVal CPM As Double, ByVal StartDate As Date, ByVal EndDate As Date, ByVal UserName As String, ByVal BannerTypeId As Integer, ByVal Description As String, ByVal GroupName As String, ByVal Criteria As Integer) As Integer
        Public MustOverride Sub UpdateBanner(ByVal BannerId As Integer, ByVal BannerName As String, ByVal ImageFile As String, ByVal URL As String, ByVal Impressions As Integer, ByVal CPM As Double, ByVal StartDate As Date, ByVal EndDate As Date, ByVal UserName As String, ByVal BannerTypeId As Integer, ByVal Description As String, ByVal GroupName As String, ByVal Criteria As Integer)
        Public MustOverride Function FindBanners(ByVal PortalId As Integer, ByVal BannerTypeId As Integer, ByVal GroupName As String) As IDataReader
        Public MustOverride Sub UpdateBannerViews(ByVal BannerId As Integer, ByVal StartDate As Date, ByVal EndDate As Date)
        Public MustOverride Sub UpdateBannerClickThrough(ByVal BannerId As Integer, ByVal VendorId As Integer)

        ' affiliates
        Public MustOverride Function GetAffiliates(ByVal VendorId As Integer) As IDataReader
        Public MustOverride Function GetAffiliate(ByVal AffiliateId As Integer, ByVal VendorId As Integer) As IDataReader
        Public MustOverride Sub DeleteAffiliate(ByVal AffiliateId As Integer)
        Public MustOverride Function AddAffiliate(ByVal VendorId As Integer, ByVal StartDate As Date, ByVal EndDate As Date, ByVal CPC As Double, ByVal CPA As Double) As Integer
        Public MustOverride Sub UpdateAffiliate(ByVal AffiliateId As Integer, ByVal StartDate As Date, ByVal EndDate As Date, ByVal CPC As Double, ByVal CPA As Double)
        Public MustOverride Sub UpdateAffiliateStats(ByVal AffiliateId As Integer, ByVal Clicks As Integer, ByVal Acquisitions As Integer)

        ' skins/containers
        Public MustOverride Function GetSkin(ByVal SkinRoot As String, ByVal PortalId As Integer, ByVal SkinType As Integer) As IDataReader
        Public MustOverride Sub DeleteSkin(ByVal SkinRoot As String, ByVal PortalId As Integer, ByVal SkinType As Integer)
        Public MustOverride Function AddSkin(ByVal SkinRoot As String, ByVal PortalId As Integer, ByVal SkinType As Integer, ByVal SkinSrc As String) As Integer

        ' personalization
        Public MustOverride Function GetProfile(ByVal UserId As Integer, ByVal PortalId As Integer) As IDataReader
        Public MustOverride Sub AddProfile(ByVal UserId As Integer, ByVal PortalId As Integer)
        Public MustOverride Sub UpdateProfile(ByVal UserId As Integer, ByVal PortalId As Integer, ByVal ProfileData As String)

        ' users online
        Public MustOverride Sub UpdateUsersOnline(ByVal UserList As Hashtable)
        Public MustOverride Sub DeleteUsersOnline(ByVal TimeWindow As Integer)

        ' urls
        Public MustOverride Function GetUrls(ByVal PortalID As Integer) As IDataReader
        Public MustOverride Function GetUrl(ByVal PortalID As Integer, ByVal Url As String) As IDataReader
        Public MustOverride Sub AddUrl(ByVal PortalID As Integer, ByVal Url As String)
        Public MustOverride Sub DeleteUrl(ByVal PortalID As Integer, ByVal Url As String)
        Public MustOverride Function GetUrlTracking(ByVal PortalID As Integer, ByVal Url As String, ByVal ModuleId As Integer) As IDataReader
        Public MustOverride Sub AddUrlTracking(ByVal PortalID As Integer, ByVal Url As String, ByVal UrlType As String, ByVal LogActivity As Boolean, ByVal TrackClicks As Boolean, ByVal ModuleId As Integer, ByVal NewWindow As Boolean)
        Public MustOverride Sub UpdateUrlTracking(ByVal PortalID As Integer, ByVal Url As String, ByVal LogActivity As Boolean, ByVal TrackClicks As Boolean, ByVal ModuleId As Integer, ByVal NewWindow As Boolean)
        Public MustOverride Sub DeleteUrlTracking(ByVal PortalID As Integer, ByVal Url As String, ByVal ModuleId As Integer)
        Public MustOverride Sub UpdateUrlTrackingStats(ByVal PortalID As Integer, ByVal Url As String, ByVal ModuleId As Integer)
        Public MustOverride Function GetUrlLog(ByVal UrlTrackingID As Integer, ByVal StartDate As Date, ByVal EndDate As Date) As IDataReader
        Public MustOverride Sub AddUrlLog(ByVal UrlTrackingID As Integer, ByVal UserID As Integer)

        'Folders
        Public MustOverride Function GetFoldersByPortal(ByVal PortalID As Integer) As IDataReader
        Public MustOverride Function GetFolder(ByVal PortalID As Integer, ByVal FolderID As Integer) As IDataReader
        Public MustOverride Function GetFolder(ByVal PortalID As Integer, ByVal FolderPath As String) As IDataReader
        Public MustOverride Function AddFolder(ByVal PortalID As Integer, ByVal FolderPath As String) As Integer
        Public MustOverride Sub UpdateFolder(ByVal PortalID As Integer, ByVal FolderID As Integer, ByVal FolderPath As String)
        Public MustOverride Sub DeleteFolder(ByVal PortalID As Integer, ByVal FolderPath As String)

        'Permission
        Public MustOverride Function GetPermission(ByVal permissionID As Integer) As IDataReader
        Public MustOverride Function GetPermissionsByModuleID(ByVal ModuleID As Integer) As IDataReader
        Public MustOverride Function GetPermissionsByFolderPath(ByVal PortalID As Integer, ByVal Folder As String) As IDataReader
        Public MustOverride Function GetPermissionByCodeAndKey(ByVal PermissionCode As String, ByVal PermissionKey As String) As IDataReader
        Public MustOverride Function GetPermissionsByTabID(ByVal TabID As Integer) As IDataReader
        Public MustOverride Sub DeletePermission(ByVal permissionID As Integer)
        Public MustOverride Function AddPermission(ByVal permissionCode As String, ByVal moduleDefID As Integer, ByVal permissionKey As String, ByVal permissionName As String) As Integer
        Public MustOverride Sub UpdatePermission(ByVal permissionID As Integer, ByVal permissionCode As String, ByVal moduleDefID As Integer, ByVal permissionKey As String, ByVal permissionName As String)

        'ModulePermission
        Public MustOverride Function GetModulePermission(ByVal modulePermissionID As Integer) As IDataReader
        Public MustOverride Function GetModulePermissionsByModuleID(ByVal moduleID As Integer, ByVal PermissionID As Integer) As IDataReader
        Public MustOverride Function GetModulePermissionsByPortal(ByVal PortalID As Integer) As IDataReader
        Public MustOverride Sub DeleteModulePermissionsByModuleID(ByVal ModuleID As Integer)
        Public MustOverride Sub DeleteModulePermission(ByVal modulePermissionID As Integer)
        Public MustOverride Function AddModulePermission(ByVal moduleID As Integer, ByVal PermissionID As Integer, ByVal roleID As Integer, ByVal AllowAccess As Boolean) As Integer
        Public MustOverride Sub UpdateModulePermission(ByVal modulePermissionID As Integer, ByVal moduleID As Integer, ByVal PermissionID As Integer, ByVal roleID As Integer, ByVal AllowAccess As Boolean)

        'TabPermission
        Public MustOverride Function GetTabPermissionsByPortal(ByVal PortalID As Integer) As IDataReader
        Public MustOverride Function GetTabPermissionsByTabID(ByVal TabID As Integer, ByVal PermissionID As Integer) As IDataReader
        Public MustOverride Sub DeleteTabPermissionsByTabID(ByVal TabID As Integer)
        Public MustOverride Sub DeleteTabPermission(ByVal TabPermissionID As Integer)
        Public MustOverride Function AddTabPermission(ByVal TabID As Integer, ByVal PermissionID As Integer, ByVal roleID As Integer, ByVal AllowAccess As Boolean) As Integer
        Public MustOverride Sub UpdateTabPermission(ByVal TabPermissionID As Integer, ByVal TabID As Integer, ByVal PermissionID As Integer, ByVal roleID As Integer, ByVal AllowAccess As Boolean)

        'FolderPermission
        Public MustOverride Function GetFolderPermission(ByVal FolderPermissionID As Integer) As IDataReader
        Public MustOverride Function GetFolderPermissionsByFolderPath(ByVal PortalID As Integer, ByVal FolderPath As String, ByVal PermissionID As Integer) As IDataReader
        Public MustOverride Sub DeleteFolderPermissionsByFolderPath(ByVal PortalID As Integer, ByVal FolderPath As String)
        Public MustOverride Sub DeleteFolderPermission(ByVal FolderPermissionID As Integer)
        Public MustOverride Function AddFolderPermission(ByVal FolderID As Integer, ByVal PermissionID As Integer, ByVal roleID As Integer, ByVal AllowAccess As Boolean) As Integer
        Public MustOverride Sub UpdateFolderPermission(ByVal FolderPermissionID As Integer, ByVal FolderID As Integer, ByVal PermissionID As Integer, ByVal roleID As Integer, ByVal AllowAccess As Boolean)

        ' search engine
        Public MustOverride Function GetSearchIndexers() As IDataReader

        ' content search datastore
        Public MustOverride Sub DeleteSearchItems(ByVal ModuleList As String)
        Public MustOverride Sub DeleteSearchItem(ByVal SearchItemId As Integer)
        Public MustOverride Sub DeleteSearchItemWords(ByVal SearchItemId As Integer)
        Public MustOverride Function AddSearchItem(ByVal Title As String, ByVal Description As String, ByVal Author As Integer, ByVal PubDate As Date, ByVal ModuleId As Integer, ByVal Key As String, ByVal Guid As String, ByVal ImageFileId As Integer) As Integer
        Public MustOverride Function GetSearchCommonWordsByLocale(ByVal Locale As String) As IDataReader
        Public MustOverride Function GetDefaultLanguageByModule(ByVal ModuleList As String) As IDataReader
        Public MustOverride Function GetSearchSettings(ByVal ModuleId As Integer) As IDataReader
        Public MustOverride Function GetSearchWords() As IDataReader
        Public MustOverride Function AddSearchWord(ByVal Word As String) As Integer
        Public MustOverride Function AddSearchItemWord(ByVal SearchItemId As Integer, ByVal SearchWordsID As Integer, ByVal Occurrences As Integer) As Integer
        Public MustOverride Sub AddSearchItemWordPosition(ByVal SearchItemWordID As Integer, ByVal ContentPositions As String)
        Public MustOverride Function GetSearchResults(ByVal PortalID As Integer, ByVal Word As String) As IDataReader
        Public MustOverride Function GetSearchItems(ByVal PortalID As Integer, ByVal TabID As Integer, ByVal ModuleID As Integer) As IDataReader
        Public MustOverride Function GetSearchItem(ByVal ModuleID As Integer, ByVal SearchKey As String) As IDataReader
        Public MustOverride Sub UpdateSearchItem(ByVal SearchItemId As Integer, ByVal Title As String, ByVal Description As String, ByVal Author As Integer, ByVal PubDate As Date, ByVal ModuleId As Integer, ByVal Key As String, ByVal Guid As String, ByVal HitCount As Integer, ByVal ImageFileId As Integer)

        'Lists
        Public MustOverride Function GetListGroup() As IDataReader
        Public MustOverride Function GetList(ByVal ListName As String, ByVal ParentKey As String, ByVal DefinitionID As Integer) As IDataReader
        Public MustOverride Function GetListEntries(ByVal ListName As String, ByVal ParentKey As String, ByVal EntryID As Integer, ByVal DefinitionID As Integer) As IDataReader
        Public MustOverride Function GetListEntriesByListName(ByVal ListName As String, ByVal Value As String, ByVal ParentKey As String) As IDataReader
        Public MustOverride Function AddListEntry(ByVal ListName As String, ByVal Value As String, ByVal Text As String, ByVal ParentKey As String, ByVal EnableSortOrder As Boolean, ByVal DefinitionID As Integer, ByVal Description As String) As Integer
        Public MustOverride Sub UpdateListEntry(ByVal EntryID As Integer, ByVal ListName As String, ByVal Value As String, ByVal Text As String, ByVal Description As String)
        Public MustOverride Sub DeleteListEntryByID(ByVal EntryID As Integer, ByVal DeleteChild As Boolean)
        Public MustOverride Sub DeleteList(ByVal ListName As String, ByVal ParentKey As String)
        Public MustOverride Sub DeleteListEntryByListName(ByVal ListName As String, ByVal Value As String, ByVal DeleteChild As Boolean)
        Public MustOverride Sub UpdateListSortOrder(ByVal EntryID As Integer, ByVal MoveUp As Boolean)

        'portal alias
        Public MustOverride Function GetPortalAlias(ByVal PortalAlias As String, ByVal PortalID As Integer) As IDataReader
        Public MustOverride Function GetPortalAliasByPortalID(ByVal PortalID As Integer) As IDataReader
        Public MustOverride Function GetPortalAliasByPortalAliasID(ByVal PortalAliasID As Integer) As IDataReader
        Public MustOverride Function GetPortalByPortalAliasID(ByVal PortalAliasId As Integer) As IDataReader
        Public MustOverride Sub UpdatePortalAlias(ByVal PortalAlias As String)
        Public MustOverride Sub UpdatePortalAliasInfo(ByVal PortalAliasID As Integer, ByVal PortalID As Integer, ByVal HTTPAlias As String)
        Public MustOverride Function AddPortalAlias(ByVal PortalID As Integer, ByVal HTTPAlias As String) As Integer
        Public MustOverride Sub DeletePortalAlias(ByVal PortalAliasID As Integer)
#End Region

	End Class

End Namespace
