'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Reflection


Namespace DotNetNuke.Services.Scheduling


	Public Enum EventName
		'do not add APPLICATION_END
		'it will not reliably complete
		APPLICATION_START
	End Enum

	Public Enum ScheduleSource
		STARTED_FROM_EVENT
		STARTED_FROM_TIMER
	End Enum

	Public Enum ScheduleStatus
		WAITING_FOR_OPEN_THREAD
		RUNNING_EVENT_SCHEDULE
		RUNNING_TIMER_SCHEDULE
		SHUTTING_DOWN
		STOPPED
	End Enum

	Public Class ScheduleQueueItem
		Inherits ScheduleItem

	End Class

	Public Class ScheduleHistoryItem
		Inherits ScheduleItem
		Private _ScheduleHistoryID As Integer
		Private _StartDate As Date
		Private _EndDate As Date
		Private _Succeeded As Boolean
		Private _LogNotes As System.Text.StringBuilder

		Public Sub New()
			_ScheduleHistoryID = Null.NullInteger
			_StartDate = Null.NullDate
			_EndDate = Null.NullDate
			_Succeeded = Null.NullBoolean
			_LogNotes = New System.Text.StringBuilder
		End Sub

		Public Property ScheduleHistoryID() As Integer
			Get
				Return _ScheduleHistoryID
			End Get
			Set(ByVal Value As Integer)
				_ScheduleHistoryID = Value
			End Set
		End Property

		Public Property StartDate() As Date
			Get
				Return _StartDate
			End Get
			Set(ByVal Value As Date)
				_StartDate = Value
			End Set
		End Property

		Public ReadOnly Property Overdue() As Boolean
			Get
				If NextStart < Now And EndDate = Null.NullDate Then
					Return True
				Else
					Return False
				End If
			End Get
		End Property

		Public ReadOnly Property OverdueBy() As Double
			Get
				Try
					If NextStart <= Now And EndDate = Null.NullDate Then
						Return Now.Subtract(NextStart).TotalSeconds
					Else
						Return 0
					End If
				Catch
					OverdueBy = 0
				End Try
			End Get
		End Property

		Public ReadOnly Property RemainingTime() As Double
			Get
				Try
					If NextStart > Now And EndDate = Null.NullDate Then
						Return NextStart.Subtract(Now).TotalSeconds
					Else
						Return 0
					End If
				Catch
					RemainingTime = 0
				End Try
			End Get
		End Property

		Public Property EndDate() As Date
			Get
				Return _EndDate
			End Get
			Set(ByVal Value As Date)
				_EndDate = Value
			End Set
		End Property

		Public ReadOnly Property ElapsedTime() As Double
			Get
				Try
					If _EndDate = Null.NullDate And _StartDate <> Null.NullDate Then
						Return Now.Subtract(_StartDate).TotalSeconds()
					ElseIf _StartDate <> Null.NullDate Then
						Return _EndDate.Subtract(_StartDate).TotalSeconds()
					Else
						Return 0
					End If
				Catch
					ElapsedTime = 0
				End Try
			End Get
		End Property

		Public Property Succeeded() As Boolean
			Get
				Return _Succeeded
			End Get
			Set(ByVal Value As Boolean)
				_Succeeded = Value
			End Set
		End Property

		Public Property LogNotes() As String
			Get
				Return _LogNotes.ToString
			End Get
			Set(ByVal Value As String)
				_LogNotes = New System.Text.StringBuilder(Value)
			End Set
		End Property

		Public Sub AddLogNote(ByVal Notes As String)
			_LogNotes.Append(Notes + vbCrLf)
		End Sub

	End Class

	Public Class ScheduleItem
		'''''''''''''''''''''''''''''''''''''''''''''''''''
		'This custom business object represents
		'a single item on the schedule.
		'''''''''''''''''''''''''''''''''''''''''''''''''''
		Private _ScheduleID As Integer
		Private _TypeFullName As String
		Private _TimeLapse As Integer
		Private _TimeLapseMeasurement As String
		Private _RetryTimeLapse As Integer
		Private _RetryTimeLapseMeasurement As String
		Private _ObjectDependencies As String
		Private _RetainHistoryNum As Integer
		Private _NextStart As Date
		Private _CatchUpEnabled As Boolean
		Private _Enabled As Boolean
		Private _AttachToEvent As String
		Private _ThreadID As Integer
		Private _ProcessGroup As Integer
		Private _ScheduleSource As ScheduleSource
		Private _ScheduleItemSettings As Hashtable

		Public Sub New()
			_ScheduleItemSettings = New Hashtable
			_ScheduleID = Null.NullInteger
			_TypeFullName = Null.NullString
			_TimeLapse = Null.NullInteger
			_TimeLapseMeasurement = Null.NullString
			_RetryTimeLapse = Null.NullInteger
			_RetryTimeLapseMeasurement = Null.NullString
			_ObjectDependencies = Null.NullString
			_RetainHistoryNum = Null.NullInteger
			_NextStart = Null.NullDate
			_CatchUpEnabled = Null.NullBoolean
			_Enabled = Null.NullBoolean
			_AttachToEvent = Null.NullString
			_ThreadID = Null.NullInteger
			_ProcessGroup = Null.NullInteger
		End Sub



		Public Property ScheduleID() As Integer
			Get
				Return _ScheduleID
			End Get
			Set(ByVal Value As Integer)
				_ScheduleID = Value
			End Set
		End Property

		Public Property TypeFullName() As String
			Get
				Return _TypeFullName
			End Get
			Set(ByVal Value As String)
				_TypeFullName = Value
			End Set
		End Property

		Public Property TimeLapse() As Integer
			Get
				Return _TimeLapse
			End Get
			Set(ByVal Value As Integer)
				_TimeLapse = Value
			End Set
		End Property
		Public Property TimeLapseMeasurement() As String
			Get
				Return _TimeLapseMeasurement
			End Get
			Set(ByVal Value As String)
				_TimeLapseMeasurement = Value
			End Set
		End Property
		Public Property RetryTimeLapse() As Integer
			Get
				Return _RetryTimeLapse
			End Get
			Set(ByVal Value As Integer)
				_RetryTimeLapse = Value
			End Set
		End Property
		Public Property RetryTimeLapseMeasurement() As String
			Get
				Return _RetryTimeLapseMeasurement
			End Get
			Set(ByVal Value As String)
				_RetryTimeLapseMeasurement = Value
			End Set
		End Property
		Public Property ObjectDependencies() As String
			Get
				Return _ObjectDependencies
			End Get
			Set(ByVal Value As String)
				_ObjectDependencies = Value
			End Set
		End Property

		Public Property RetainHistoryNum() As Integer
			Get
				Return _RetainHistoryNum
			End Get
			Set(ByVal Value As Integer)
				_RetainHistoryNum = Value
			End Set
		End Property

		Public Property NextStart() As Date
			Get
				Return _NextStart
			End Get
			Set(ByVal Value As Date)
				_NextStart = Value
			End Set
		End Property
		Public Property ScheduleSource() As ScheduleSource
			Get
				Return _ScheduleSource
			End Get
			Set(ByVal Value As ScheduleSource)
				_ScheduleSource = Value
			End Set
		End Property

		Public Property CatchUpEnabled() As Boolean
			Get
				Return _CatchUpEnabled
			End Get
			Set(ByVal Value As Boolean)
				_CatchUpEnabled = Value
			End Set
		End Property

		Public Property Enabled() As Boolean
			Get
				Return _Enabled
			End Get
			Set(ByVal Value As Boolean)
				_Enabled = Value
			End Set
		End Property

		Public Property AttachToEvent() As String
			Get
				Return _AttachToEvent
			End Get
			Set(ByVal Value As String)
				_AttachToEvent = Value
			End Set
		End Property

		Public Property ThreadID() As Integer
			Get
				Return _ThreadID
			End Get
			Set(ByVal Value As Integer)
				_ThreadID = Value
			End Set
		End Property

		Public Property ProcessGroup() As Integer
			Get
				Return _ProcessGroup
			End Get
			Set(ByVal Value As Integer)
				_ProcessGroup = Value
			End Set
		End Property




		Public Function HasObjectDependencies(ByVal strObjectDependencies As String) As Boolean
			If strObjectDependencies.IndexOf(",") > -1 Then
				Dim a() As String
				a = Split(strObjectDependencies.ToLower, ",")
				Dim i As Integer
				For i = 0 To a.Length - 1
					If a(i) = strObjectDependencies.ToLower Then
						Return True
					End If
				Next
			Else
				If ObjectDependencies.ToLower.IndexOf(strObjectDependencies.ToLower) > -1 Then
					Return True
				End If
			End If

			Return False
		End Function

		Public Sub AddSetting(ByVal Key As String, ByVal Value As String)
			_ScheduleItemSettings.Add(Key, Value)
		End Sub
		Public Function GetSetting(ByVal Key As String) As String
			If _ScheduleItemSettings.ContainsKey(Key) Then
				Return Convert.ToString(_ScheduleItemSettings(Key))
			Else
				Return ""
			End If
		End Function
		Public Function GetSettings() As Hashtable
			Return _ScheduleItemSettings
		End Function
		Public Sub SetSettings(ByVal Settings As Hashtable)
			_ScheduleItemSettings = Settings
		End Sub
	End Class


	Public Class SchedulerClient

		'''''''''''''''''''''''''''''''''''''''''''''''''''
		'This class is inherited by any class that wants
		'to run tasks in the scheduler.
		'''''''''''''''''''''''''''''''''''''''''''''''''''
		Public Event ProcessStarted As WorkStarted
		Public Event ProcessProgressing As WorkProgressing
		Public Event ProcessCompleted As WorkCompleted
		Public Event ProcessErrored As WorkErrored

		Public Sub Started()
			RaiseEvent ProcessStarted(Me)
		End Sub
		Public Sub Progressing()
			RaiseEvent ProcessProgressing(Me)
		End Sub
		Public Sub Completed()
			RaiseEvent ProcessCompleted(Me)
		End Sub
		Public Sub Errored(ByRef objException As Exception)
			RaiseEvent ProcessErrored(Me, objException)
		End Sub

		'''''''''''''''''''''''''''''''''''''''''''''''''''
		'This is the sub that kicks off the actual
		'work within the SchedulerClient's subclass
		'''''''''''''''''''''''''''''''''''''''''''''''''''
		Public Overridable Sub DoWork()
		End Sub

		Private _SchedulerEventGUID As String
		Private _ProcessMethod As String
		Private _Status As String
		Private _ScheduleHistoryItem As ScheduleHistoryItem

		Public Sub New()
			'''''''''''''''''''''''''''''''''''''''''''''''''''
			'Assign the event a unique ID for tracking purposes.
			'''''''''''''''''''''''''''''''''''''''''''''''''''
			_SchedulerEventGUID = Null.NullString
			_ProcessMethod = Null.NullString
			_Status = Null.NullString
			_ScheduleHistoryItem = New ScheduleHistoryItem

		End Sub



		Public Property ScheduleHistoryItem() As ScheduleHistoryItem
			Get
				Return _ScheduleHistoryItem
			End Get
			Set(ByVal Value As ScheduleHistoryItem)
				_ScheduleHistoryItem = Value
			End Set
		End Property
		Public Property SchedulerEventGUID() As String
			Get
				Return _SchedulerEventGUID
			End Get
			Set(ByVal Value As String)
				_SchedulerEventGUID = Value
			End Set
		End Property
		Public Property aProcessMethod() As String
			Get
				Return _ProcessMethod
			End Get
			Set(ByVal Value As String)
				_ProcessMethod = Value
			End Set
		End Property
		Public Property Status() As String
			Get
				Return _Status
			End Get
			Set(ByVal Value As String)
				_Status = Value
			End Set
		End Property

		Public ReadOnly Property ThreadID() As Integer
			Get
				Return AppDomain.GetCurrentThreadId()
			End Get
		End Property




	End Class

	Class PurgeScheduleHistory
		Inherits DotNetNuke.Services.Scheduling.SchedulerClient

		Public Sub New(ByVal objScheduleHistoryItem As DotNetNuke.Services.Scheduling.ScheduleHistoryItem)
			MyBase.new()
			Me.ScheduleHistoryItem = objScheduleHistoryItem
		End Sub
		Public Overrides Sub DoWork()
			Try

				'notification that the event is progressing
				Me.Progressing()				'OPTIONAL

				SchedulingProvider.Instance.PurgeScheduleHistory()

				'update the result to success since no exception was thrown
				Me.ScheduleHistoryItem.Succeeded = True
				Me.ScheduleHistoryItem.AddLogNote("Schedule history purged.")

			Catch exc As Exception
				Me.ScheduleHistoryItem.Succeeded = False
				Me.ScheduleHistoryItem.AddLogNote("Schedule history purge failed." + exc.ToString)
				Me.ScheduleHistoryItem.Succeeded = False

				'notification that we have errored
				Me.Errored(exc)

				'log the exception
				LogException(exc)
			End Try
		End Sub

	End Class


	Class SampleScheduleTask
		Inherits DotNetNuke.Services.Scheduling.SchedulerClient

		Public Sub New(ByVal objScheduleHistoryItem As DotNetNuke.Services.Scheduling.ScheduleHistoryItem)
			MyBase.new()
			Me.ScheduleHistoryItem = objScheduleHistoryItem			 'REQUIRED
		End Sub
		Public Overrides Sub DoWork()
			Try

				'notification that the event is progressing
				'this is optional
				Me.Progressing()				'OPTIONAL

				'optional settings are stored in the
				'ScheduleSettings Table
				Dim SleepFor As Integer = Convert.ToInt32(Me.ScheduleHistoryItem.GetSetting("Milliseconds"))
				Threading.Thread.CurrentThread.Sleep(SleepFor)

				Me.ScheduleHistoryItem.Succeeded = True				'REQUIRED
				Me.ScheduleHistoryItem.AddLogNote(String.Format("Sample scheduled task completed.", SleepFor.ToString))				  'OPTIONAL

			Catch exc As Exception			 'REQUIRED

				Me.ScheduleHistoryItem.Succeeded = False				'REQUIRED

				Me.ScheduleHistoryItem.AddLogNote(String.Format("Sample scheduled task failed.", exc.ToString))				'OPTIONAL

				'notification that we have errored
				Me.Errored(exc)				'REQUIRED

				'log the exception
				LogException(exc)				'OPTIONAL
			End Try
		End Sub

	End Class


End Namespace
