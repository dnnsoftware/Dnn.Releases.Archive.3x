'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data

Namespace DotNetNuke.Common.Lists

    Public Class ListController

        Public Enum CacheScope
            None
            Lists
            ListCollection
        End Enum

        Const ENTRY_LIST_CACHE_KEY As String = "Lists"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Get entry list(s)
        ''' Optional parent key to specifed if result is all entries in that category or a subset
        ''' </summary>
        ''' <remarks>
        '''     To be used with Method 2:
        '''     This method query each array of entries when it needed 
        '''     An option to specified if arraylist object will be stored in cache or not        
        '''     pro: stored data in cache only if specified; don't have populate all entries into collection      
        '''     con: call database more than previous method; store to cache need to be considered each time using this method
        ''' </remarks>        


#Region "ListInfo"
        Public Function GetListInfo(ByVal ListName As String) As ListInfo
            Return GetListInfo(ListName, "")
        End Function

        Public Function GetListInfo(ByVal ListName As String, ByVal ParentKey As String) As ListInfo
            Return GetListInfo(ListName, ParentKey, -1)
        End Function

        Public Function GetListInfo(ByVal ListName As String, ByVal ParentKey As String, ByVal DefinitionID As Integer) As ListInfo
            Return FillListInfo(ListName, ParentKey, DefinitionID)
        End Function
        Public Function GetListInfoCollection() As ListInfoCollection
            Return GetListInfoCollection("")
        End Function
        Public Function GetListInfoCollection(ByVal ListName As String) As ListInfoCollection
            Return GetListInfoCollection(ListName, "")
        End Function
        Public Function GetListInfoCollection(ByVal ListName As String, ByVal ParentKey As String) As ListInfoCollection
            Return GetListInfoCollection(ListName, ParentKey, -1)
        End Function
        Public Function GetListInfoCollection(ByVal ListName As String, ByVal ParentKey As String, ByVal DefinitionID As Integer) As ListInfoCollection
            Dim objListInfoCollection As IList = New ListInfoCollection
            Dim objListInfo As New ListInfo

            Return CType(CBO.FillCollection(DataProvider.Instance().GetList(ListName, ParentKey, DefinitionID), GetType(ListInfo), objListInfoCollection), ListInfoCollection)
        End Function
#End Region

#Region "ListEntryInfo"

        Public Function GetListEntryInfoCollection(ByVal ListName As String) As ListEntryInfoCollection ' Get collection of entry lists
            Return GetListEntryInfoCollection(ListName, "")
        End Function
        Public Function GetListEntryInfoCollection(ByVal ListName As String, ByVal Value As String) As ListEntryInfoCollection ' Get collection of entry lists
            Return GetListEntryInfoCollection(ListName, Value, "")
        End Function
        Public Function GetListEntryInfoCollection(ByVal ListName As String, ByVal Value As String, ByVal ParentKey As String) As ListEntryInfoCollection ' Get collection of entry lists
            Dim objListEntryInfoCollection As IList = New ListEntryInfoCollection
            Return CType(CBO.FillCollection(DataProvider.Instance().GetListEntriesByListName(ListName, Value, ParentKey), GetType(ListEntryInfo), objListEntryInfoCollection), ListEntryInfoCollection)
        End Function

        Public Function GetListEntryInfo(ByVal EntryID As Integer) As ListEntryInfo ' Get single entry by ID
            Return CType(CBO.FillObject(DataProvider.Instance().GetListEntries("", "", EntryID, -1), GetType(ListEntryInfo)), ListEntryInfo)
        End Function

        Public Function GetListEntryInfo(ByVal ListName As String, ByVal Value As String) As ListEntryInfo ' Get single entry by ListName/Value
            Return GetListEntryInfo(ListName, Value, "")
        End Function
        Public Function GetListEntryInfo(ByVal ListName As String, ByVal Value As String, ByVal ParentKey As String) As ListEntryInfo ' Get single entry by ListName/Value
            Return CType(CBO.FillObject(DataProvider.Instance().GetListEntriesByListName(ListName, Value, ParentKey), GetType(ListEntryInfo)), ListEntryInfo)
        End Function

#End Region

        Public Function AddListEntry(ByVal ListEntry As ListEntryInfo) As Integer
            Dim EnableSortOrder As Boolean = (ListEntry.SortOrder > 0)
            Return DataProvider.Instance().AddListEntry(ListEntry.ListName, ListEntry.Value, ListEntry.Text, ListEntry.ParentKey, EnableSortOrder, ListEntry.DefinitionID, ListEntry.Description)
        End Function

        Public Sub UpdateListEntry(ByVal ListEntry As ListEntryInfo)
            DataProvider.Instance().UpdateListEntry(ListEntry.EntryID, ListEntry.ListName, ListEntry.Value, ListEntry.Text, ListEntry.Description)
        End Sub

        Public Sub DeleteList(ByVal ListName As String, ByVal ParentKey As String)
            DataProvider.Instance().DeleteList(ListName, ParentKey)
        End Sub

        Public Sub DeleteListEntryByID(ByVal EntryID As Integer, ByVal DeleteChild As Boolean)
            DataProvider.Instance().DeleteListEntryByID(EntryID, DeleteChild)
        End Sub

        Public Sub DeleteListEntryByListName(ByVal ListName As String, ByVal Value As String, ByVal DeleteChild As Boolean)
            DataProvider.Instance().DeleteListEntryByListName(ListName, Value, DeleteChild)
        End Sub

        Public Sub UpdateListSortOrder(ByVal EntryID As Integer, ByVal MoveUp As Boolean)
            DataProvider.Instance().UpdateListSortOrder(EntryID, MoveUp)
        End Sub


        Public Function FillListInfo(ByVal ListName As String, ByVal ParentKey As String, ByVal DefinitionID As Integer) As ListInfo  ' Get single entry list by Name
            Dim dr As IDataReader = DataProvider.Instance().GetList(ListName, ParentKey, DefinitionID)
            Dim objListInfo As ListInfo = Nothing

            Try
                If dr.Read Then
                    objListInfo = New ListInfo(Convert.ToString(dr("ListName")))
                    With objListInfo
                        .DisplayName = Convert.ToString(dr("DisplayName"))
                        .Level = Convert.ToInt32(dr("Level"))
                        .DefinitionID = Convert.ToInt32(dr("DefinitionID"))
                        .Key = Convert.ToString(dr("Key"))
                        .EntryCount = Convert.ToInt32(dr("EntryCount"))
                        .ParentID = Convert.ToInt32(dr("ParentID"))
                        .ParentKey = Convert.ToString(dr("ParentKey"))
                        .Parent = Convert.ToString(dr("Parent"))
                        .ParentList = Convert.ToString(dr("ParentList"))
                        .EnableSortOrder = (Convert.ToInt32(dr("MaxSortOrder")) > 0)
                    End With
                End If
            Catch exc As Exception
                LogException(exc)
            Finally
                ' close datareader
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try

            Return objListInfo

        End Function

    End Class

End Namespace

