'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports ICSharpCode.SharpZipLib.Zip
Imports ICSharpCode.SharpZipLib.Checksums
Imports ICSharpCode.SharpZipLib.GZip
Imports System.IO
Imports System.Xml
Imports System.Xml.Serialization
Imports DotNetNuke.Modules.Admin.ResourceInstaller
Imports DotNetNuke.Entities.Modules.Definitions
Imports DotNetNuke.Services.Localization
Imports DotNetNuke.Framework.Providers

Namespace DotNetNuke.Entities.Modules

    ''' -----------------------------------------------------------------------------
    ''' Project  : DotNetNuke
    ''' Class  : PaWriter
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The PaWriter class packages a Module as a Private Assembly.
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    '''  [cnurse] 01/13/2005 created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class PaWriter

#Region "Private Members"

        Private _ProgressLog As New PaLogger
        Private _IncludeSource As Boolean = False
        Private _ZipFile As String

        'Source Folder of PA
        Private _Folder As String

        'Name of PA
        Private _Name As String

        'List of Files to include in PA
        Private _Files As New ArrayList


#End Region

#Region "Constructors"

        Public Sub New()
            Me.New(False, "")
        End Sub

        Public Sub New(ByVal IncludeSource As Boolean, ByVal ZipFile As String)
            _IncludeSource = IncludeSource
            _ZipFile = ZipFile
        End Sub

#End Region

#Region "Public Properties"

        Public Property IncludeSource() As Boolean
            Get
                Return _IncludeSource
            End Get
            Set(ByVal Value As Boolean)
                _IncludeSource = Value
            End Set
        End Property

        Public ReadOnly Property ProgressLog() As PaLogger
            Get
                Return _ProgressLog
            End Get
        End Property

        Public Property ZipFile() As String
            Get
                Return _ZipFile
            End Get
            Set(ByVal Value As String)
                _ZipFile = Value
            End Set
        End Property

#End Region

#Region "Private Methods"

        Private Sub AddSourceFiles(ByVal folder As DirectoryInfo, ByVal fileType As String, ByRef resourcesFile As ZipOutputStream)

            'Get the Source Files in the folder
            Dim sourceFiles As FileInfo() = folder.GetFiles(fileType)

            For Each sourceFile As FileInfo In sourceFiles
                Dim filePath As String = sourceFile.FullName
                Dim fileName As String = sourceFile.Name
                Dim folderName As String = folder.FullName.Replace(_Folder, "")
                If folderName <> "" Then
                    folderName += "\"
                End If
                If folderName.StartsWith("\") Then
                    folderName = folderName.Substring(1)
                End If

                FileSystemUtils.AddToZip(resourcesFile, filePath, fileName, folderName)
            Next

        End Sub

        Private Sub CreateDnnManifest(ByVal objDesktopModule As DesktopModuleInfo)

            Dim filename As String = ""

            'Create Manifest Document
            Dim xmlManifest As New XmlDocument

            'Root Element
            Dim nodeRoot As XmlNode = xmlManifest.CreateElement("dotnetnuke")
            nodeRoot.Attributes.Append(XmlUtils.CreateAttribute(xmlManifest, "version", "3.0"))
            nodeRoot.Attributes.Append(XmlUtils.CreateAttribute(xmlManifest, "type", "Module"))

            'Folders Element
            Dim nodeFolders As XmlNode = xmlManifest.CreateElement("folders")
            nodeRoot.AppendChild(nodeFolders)

            'Folder Element
            Dim nodeFolder As XmlNode = xmlManifest.CreateElement("folder")
            nodeFolders.AppendChild(nodeFolder)

            'Desktop Module Info
            _Name = objDesktopModule.ModuleName
            _Folder = Common.Globals.ApplicationMapPath & "\DesktopModules\" & objDesktopModule.FolderName
            nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "name", _Name))
            nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "friendlyname", objDesktopModule.FriendlyName))
            nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "foldername", objDesktopModule.FolderName))
            nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "modulename", _Name))
            nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "description", objDesktopModule.Description))
            If objDesktopModule.Version = Null.NullString Then
                objDesktopModule.Version = "01.00.00"
            End If
            nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "version", objDesktopModule.Version))
            nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "businesscontrollerclass", objDesktopModule.BusinessControllerClass))

            'Add Source files
            If _IncludeSource Then
                Dim resourcesFile As String = objDesktopModule.ModuleName & ".resources"
                CreateResourceFile(_Folder & "\" & resourcesFile)
                nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "resourcefile", resourcesFile))
            End If

            'Modules Element
            Dim nodeModules As XmlNode = xmlManifest.CreateElement("modules")
            nodeFolder.AppendChild(nodeModules)

            'Get the Module Definitions for this Module
            Dim objModuleDefinitionController As New ModuleDefinitionController
            Dim arrModuleDefinitions As ArrayList = objModuleDefinitionController.GetModuleDefinitions(objDesktopModule.DesktopModuleID)

            'Iterate through Module Definitions
            For Each objModuleInfo As ModuleDefinitionInfo In arrModuleDefinitions
                Dim nodeModule As XmlNode = xmlManifest.CreateElement("module")

                'Add module definition properties
                nodeModule.AppendChild(XmlUtils.CreateElement(xmlManifest, "friendlyname", objModuleInfo.FriendlyName))

                'Add Cache properties
                nodeModule.AppendChild(XmlUtils.CreateElement(xmlManifest, "cachetime", objModuleInfo.DefaultCacheTime.ToString))


                'Get the Module Controls for this Module Definition
                Dim objModuleControlController As New ModuleControlController
                Dim arrModuleControls As ArrayList = objModuleControlController.GetModuleControls(objModuleInfo.ModuleDefID)

                'Controls Element
                Dim nodeControls As XmlNode = xmlManifest.CreateElement("controls")
                nodeModule.AppendChild(nodeControls)

                'Iterate through Module Controls
                For Each objModuleControl As ModuleControlInfo In arrModuleControls
                    Dim nodeControl As XmlNode = xmlManifest.CreateElement("control")

                    'Dim src As String = objModuleControl.ControlSrc.Replace("DesktopModules/" & _Name & "/", "")

                    'Add module control properties
                    XmlUtils.AppendElement(xmlManifest, nodeControl, "key", objModuleControl.ControlKey, False)
                    XmlUtils.AppendElement(xmlManifest, nodeControl, "title", objModuleControl.ControlTitle, False)

                    XmlUtils.AppendElement(xmlManifest, nodeControl, "src", objModuleControl.ControlSrc, True)
                    XmlUtils.AppendElement(xmlManifest, nodeControl, "iconfile", objModuleControl.IconFile, False)
                    XmlUtils.AppendElement(xmlManifest, nodeControl, "type", objModuleControl.ControlType.ToString, True)
                    XmlUtils.AppendElement(xmlManifest, nodeControl, "helpurl", objModuleControl.HelpURL, False)

                    'Add control Node to controls
                    nodeControls.AppendChild(nodeControl)

                    'Determine the filename for the Manifest file (It should be saved witht the other Module files)
                    If filename = "" Then
                        filename = _Folder & "\" & objDesktopModule.ModuleName + ".dnn"
                    End If
                Next

                'Add module Node to modules
                nodeModules.AppendChild(nodeModule)
            Next

            'Create File List
            CreateFileList()

            'Files Element
            Dim nodeFiles As XmlNode = xmlManifest.CreateElement("files")
            nodeFolder.AppendChild(nodeFiles)

            'Add the files
            For Each file As PaFileInfo In _Files
                Dim nodeFile As XmlNode = xmlManifest.CreateElement("file")

                'Add file properties
                XmlUtils.AppendElement(xmlManifest, nodeFile, "path", file.Path, False)
                XmlUtils.AppendElement(xmlManifest, nodeFile, "name", file.Name, False)

                'Add file Node to files
                nodeFiles.AppendChild(nodeFile)
            Next

            'Add Root element to document
            xmlManifest.AppendChild(nodeRoot)

            'Save Manifest file
            xmlManifest.Save(filename)

            'Add Manifest file to file list
            AddFile(New PaFileInfo(objDesktopModule.ModuleName & ".dnn", "", _Folder), True)

        End Sub

        Private Sub CreateFileList()

            Dim assemblyName As String = ""
            Dim assemblyFolder As String = ApplicationMapPath & "/bin"

            'Create the DirectoryInfo object
            Dim folder As New DirectoryInfo(_Folder)

            'Get the Project File in the folder
            Dim files As FileInfo() = folder.GetFiles("*.??proj")

            'Parse the Project files (probably only one)
            For Each projFile As FileInfo In files

                'Create and load the Project file xml
                Dim xmlProject As New XmlDocument
                xmlProject.Load(files(0).FullName)

                'Get the Assembly Name and add to File List
                Dim xmlSettings As XmlNode = xmlProject.SelectSingleNode("//Settings")
                assemblyName = xmlSettings.Attributes("AssemblyName").Value
                AddFile(New PaFileInfo(assemblyName & ".dll", "", assemblyFolder))

                Dim xmlFiles As XmlNodeList = xmlProject.SelectNodes("//File")

                'Iterate through files
                For Each xmlFile As XmlNode In xmlFiles
                    Dim attributeBuildAction As XmlAttribute = xmlFile.Attributes("BuildAction")
                    Dim attributeDependUpon As XmlAttribute = xmlFile.Attributes("DependentUpon")

                    Dim bIncludeFile As Boolean = False
                    If attributeBuildAction.Value = "None" Then bIncludeFile = True
                    If attributeBuildAction.Value = "Content" Then
                        If attributeDependUpon Is Nothing Then bIncludeFile = True
                    End If

                    If bIncludeFile Then
                        Dim relPath As String = xmlFile.Attributes("RelPath").Value.Replace("/", "\")
                        Dim path As String = ""
                        Dim name As String = relPath
                        Dim fullPath As String = _Folder
                        If relPath.LastIndexOf("\") > -1 Then
                            path = relPath.Substring(0, relPath.LastIndexOf("\"))
                            name = relPath.Replace(path & "\", "")
                            fullPath = fullPath & "\" & path
                        End If

                        AddFile(New PaFileInfo(name, path, fullPath))
                    End If
                Next
            Next

            'Get the Localization Files
            If Directory.Exists(_Folder & "\App_LocalResources") Then
                Dim localFolder As New DirectoryInfo(_Folder & "\App_LocalResources")
                Dim localFiles As FileInfo() = localFolder.GetFiles("*.resx")

                For Each localFile As FileInfo In localFiles
                    AddFile(New PaFileInfo(localFile.Name, "App_LocalResources", localFolder.FullName))
                Next
            End If

            'Get the Data Provider Files
            Dim objProviderConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration("data")

            For Each entry As DictionaryEntry In objProviderConfiguration.Providers
                Dim strName As String = CType(entry.Key, String)
                Dim objProvider As Provider = CType(entry.Value, Provider)
                Dim providerName As String = objProvider.Name

                'Assume the scripts are located in Providers\DataProviders\ProviderName\*.ProviderName
                Dim providerPath As String = _Folder & "\Providers\DataProviders\" & providerName
                If Directory.Exists(providerPath) Then
                    'Add Provider Assembly
                    AddFile(New PaFileInfo(assemblyName & "." & providerName & ".dll", "", assemblyFolder))

                    Dim scriptFolder As New DirectoryInfo(providerPath)
                    Dim scripts As FileInfo() = scriptFolder.GetFiles("*." & providerName)

                    For Each script As FileInfo In scripts
                        AddFile(New PaFileInfo(script.Name, "", scriptFolder.FullName))
                    Next

                End If
            Next

        End Sub

        Private Function CreateZipFile() As String
            Dim CompressionLevel As Integer = 9
            Dim ZipFileShortName As String = _Name
            Dim ZipFileName As String = _ZipFile
            If ZipFileName = "" Then
                ZipFileName = ZipFileShortName & ".zip"
            End If
            ZipFileName = Common.Globals.HostMapPath & ZipFileName

            Dim strmZipFile As FileStream = Nothing
            Try
                ProgressLog.AddInfo(String.Format(Localization.GetString("LOG.PAWriter.CreateArchive"), ZipFileShortName))
                strmZipFile = File.Create(ZipFileName)
                Dim strmZipStream As ZipOutputStream = Nothing
                Try
                    strmZipStream = New ZipOutputStream(strmZipFile)
                    strmZipStream.SetLevel(CompressionLevel)
                    For Each PaFile As PaFileInfo In _Files
                        FileSystemUtils.AddToZip(strmZipStream, PaFile.FullName, PaFile.Name, "")
                        ProgressLog.AddInfo(String.Format(Localization.GetString("LOG.PAWriter.SavedFile"), PaFile.Name))
                    Next
                Catch ex As Exception
                    LogException(ex)
                    ProgressLog.AddFailure(String.Format(Localization.GetString("LOG.PAWriter.ERROR.SavingFile"), ex))
                Finally
                    If Not strmZipStream Is Nothing Then
                        strmZipStream.Finish()
                        strmZipStream.Close()
                    End If
                End Try
            Catch ex As Exception
                LogException(ex)
                ProgressLog.AddFailure(String.Format(Localization.GetString("LOG.PAWriter.ERROR.SavingFile"), ex))
            Finally
                If Not strmZipFile Is Nothing Then
                    strmZipFile.Close()
                End If
            End Try

            Return ZipFileName
        End Function

        Private Sub CreateResourceFile(ByVal fileName As String)

            'Create the DirectoryInfo object
            Dim folder As New DirectoryInfo(_Folder)

            'Create Zip File to hold files
            Dim resourcesFile As ZipOutputStream = New ZipOutputStream(File.Create(fileName))
            resourcesFile.SetLevel(6)

            ParseFolder(folder, resourcesFile)

            'Add Resources File to File List
            AddFile(New PaFileInfo(fileName.Replace(_Folder & "\", ""), "", _Folder))

            'Finish and Close Zip file
            resourcesFile.Finish()
            resourcesFile.Close()

        End Sub

        Private Sub ParseFolder(ByVal folder As DirectoryInfo, ByRef resourcesFile As ZipOutputStream)
            'Add the resource files
            AddSourceFiles(folder, "*.sln", resourcesFile)
            AddSourceFiles(folder, "*.??proj", resourcesFile)
            AddSourceFiles(folder, "*.cs", resourcesFile)
            AddSourceFiles(folder, "*.vb", resourcesFile)
            AddSourceFiles(folder, "*.resx", resourcesFile)

            'Check for Provider scripts
            Dim objProviderConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration("data")
            For Each entry As DictionaryEntry In objProviderConfiguration.Providers
                Dim objProvider As Provider = CType(entry.Value, Provider)
                Dim providerName As String = objProvider.Name
                AddSourceFiles(folder, "*." & providerName, resourcesFile)
            Next

            'Get the sub-folders in the folder
            Dim folders As DirectoryInfo() = folder.GetDirectories

            'Recursively call ParseFolder to add files from sub-folder tree
            For Each subfolder As DirectoryInfo In folders
                ParseFolder(subfolder, resourcesFile)
            Next
        End Sub

        'Make sure files are not added twice
        Private Sub AddFile(ByVal File As PaFileInfo, ByVal AllowUnsafeExtensions As Boolean)
            Dim objPaFileInfo As PaFileInfo
            Dim blnAdd As Boolean = True
            For Each objPaFileInfo In _Files
                If objPaFileInfo.FullName = File.FullName Then
                    blnAdd = False
                    Exit For
                End If
            Next
            If Not AllowUnsafeExtensions Then
                If Right(File.FullName, 3).ToLower = "dnn" Then blnAdd = False
            End If

            If blnAdd Then
                _Files.Add(File)
            End If

        End Sub

        Private Sub AddFile(ByVal File As PaFileInfo)
            AddFile(File, False)
        End Sub

#End Region

#Region "Public Methods"

        Public Function CreatePrivateAssembly(ByVal DesktopModuleId As Integer) As String

            Dim Result As String = ""

            'Get the Module Definition File for this Module
            Dim objDesktopModuleController As New DesktopModuleController
            Dim objModule As DesktopModuleInfo = objDesktopModuleController.GetDesktopModule(DesktopModuleId)


            ProgressLog.StartJob(String.Format(Localization.GetString("LOG.PAWriter.CreateManifest"), objModule.FriendlyName))
            CreateDnnManifest(objModule)
            ProgressLog.EndJob((String.Format(Localization.GetString("LOG.PAWriter.CreateManifest"), objModule.FriendlyName)))

            ProgressLog.StartJob(String.Format(Localization.GetString("LOG.PAWriter.CreateZipFile"), objModule.FriendlyName))
            CreateZipFile()
            ProgressLog.EndJob((String.Format(Localization.GetString("LOG.PAWriter.CreateZipFile"), objModule.FriendlyName)))

            Return Result
        End Function

#End Region

    End Class
End Namespace