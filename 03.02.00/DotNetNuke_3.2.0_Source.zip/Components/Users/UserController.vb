'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data
Imports System.Threading
Imports System.Web

Imports AspNetProfile = Microsoft.ScalableHosting.Profile
Imports AspNetSecurity = Microsoft.ScalableHosting.Security

Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Security
Imports DotNetNuke.Security.Roles

Namespace DotNetNuke.Entities.Users

    ''' -----------------------------------------------------------------------------
    ''' Project:    DotNetNuke
    ''' Namespace:  DotNetNuke.Entities.Users
    ''' Class:      UserController
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The UserController class provides Business Layer methods for Users
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    '''     [cnurse]	02/18/2004	documented
    '''     [cnurse]    05/23/2005  made compatible with .NET 2.0
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class UserController

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Deletes a user from a portal
        ''' </summary>
        ''' <param name="PortalId">Id of the portal</param>
        ''' <param name="UserId">Id of the user</param>
        ''' <param name="notify">Flag to determine whether email notification is sent to the Administrator</param>
        ''' <param name="deleteAdmin">Flag to determine whether to delete the Admin User</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	02/18/2005	moved code from Public overload
        '''     [gve]       05/15/2005  moved SetApplicationName code just before Membership call
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function DeleteUser(ByVal PortalId As Integer, ByVal UserId As Integer, ByVal notify As Boolean, ByVal deleteAdmin As Boolean) As Boolean
            Try

                Dim objUser As UserInfo = Me.GetUser(PortalId, UserId)

                Dim CanDelete As Boolean = True
                Dim dr As IDataReader

                dr = DataProvider.Instance().GetPortal(PortalId)
                If dr.Read Then
                    If UserId = Convert.ToInt32(dr("AdministratorId")) Then
                        CanDelete = deleteAdmin
                    End If
                End If
                If Not dr Is Nothing Then
                    dr.Close()
                End If
                If CanDelete Then
                    If notify Then
                        ' Obtain PortalSettings from Current Context
                        Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings

                        ' send email notification to portal administrator that the user was removed from the portal
                        DotNetNuke.Services.Mail.Mail.SendMail(_portalSettings.Email, _portalSettings.Email, "", _
                            Services.Localization.Localization.GetSystemMessage(_portalSettings, "EMAIL_USER_UNREGISTER_SUBJECT", objUser), _
                            Services.Localization.Localization.GetSystemMessage(_portalSettings, "EMAIL_USER_UNREGISTER_BODY", objUser), _
                            "", "", "", "", "", "")
                    End If
                    If objUser.IsSuperUser Then
                        Common.Globals.SetApplicationName(Common.Globals.glbSuperUserAppName)
                    Else
                        Common.Globals.SetApplicationName(objUser.PortalID)
                    End If
                    ' Explicit call to delete user profile data.
                    AspNetProfile.ProfileManager.DeleteProfile(objUser.Username)
                    AspNetSecurity.Membership.DeleteUser(objUser.Username, True)

                    dr = DataProvider.Instance().GetRolesByUser(UserId, PortalId)
                    While dr.Read
                        DataProvider.Instance().DeleteUserRole(UserId, Convert.ToInt32(dr("RoleId")))
                    End While
                    dr.Close()

                    dr = DataProvider.Instance().GetUserByUsername(-1, objUser.Username)
                    dr.Read()
                    'check if user exists in any other portal
                    If Not dr.Read Then
                        DataProvider.Instance().DeleteUser(UserId)
                    Else
                        DataProvider.Instance().DeleteUserPortal(UserId, PortalId)
                    End If
                    dr.Close()
                End If

                Dim UserInfoCacheKey As String = GetCacheKey(objUser.PortalID, objUser.Username)
                DataCache.RemoveCache(UserInfoCacheKey)

                Return CanDelete
            Catch Exc As Exception
                Dim a As New Object

            Finally
                Common.Globals.SetApplicationName(PortalId)
            End Try

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Builds a collection (ArrayList) of User Info objects from
        ''' a dataReader
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="dr">The datareader containing the user info</param>
        ''' <param name="PortalId">Id of the portal</param>
        ''' <param name="ProgressiveHydration">Flag to determine whether the membership and Profile
        ''' objects are progressively hydrated</param>
        ''' <returns>An ArrayList of UserInfo objects</returns>
        ''' <history>
        ''' 	[cnurse]	02/22/2005	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function FillUserInfoCollection(ByVal dr As IDataReader, ByVal PortalId As Integer, ByVal ProgressiveHydration As Boolean) As ArrayList
            Dim arr As New ArrayList
            Try
                Dim obj As UserInfo
                While dr.Read
                    ' fill business object
                    obj = FillUserInfo(dr, PortalId, False, ProgressiveHydration)
                    ' add to collection
                    arr.Add(obj)
                End While
            Catch exc As Exception
                LogException(exc)
            Finally
                ' close datareader
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try
            Return arr
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Builds a User Info object from a dataReader
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="dr">The datareader containing the user info</param>
        ''' <param name="PortalId">Id of the portal</param>
        ''' <param name="CheckForOpenDataReader">Flag to determine whether to chcek if the datareader is open</param>
        ''' <param name="ProgressiveHydration">Flag to determine whether the membership and Profile
        ''' objects are progressively hydrated</param>
        ''' <returns>An ArrayList of UserInfo objects</returns>
        ''' <history>
        ''' 	[cnurse]	02/22/2005	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function FillUserInfo(ByVal dr As IDataReader, ByVal PortalId As Integer, ByVal CheckForOpenDataReader As Boolean, ByVal ProgressiveHydration As Boolean) As UserInfo
            Try
                Dim objUserInfo As New UserInfo
                ' read datareader
                Dim bContinue As Boolean = True

                If CheckForOpenDataReader Then
                    bContinue = False
                    If dr.Read Then
                        bContinue = True
                    End If
                End If
                If bContinue Then
                    'fill the base userInfo object
                    objUserInfo = FillUserInfo(dr, PortalId)

                    If Not ProgressiveHydration Then
                        'fill the Membership object
                        objUserInfo.Membership = FillUserMembership(objUserInfo)

                        'fill the Profile object
                        objUserInfo.Profile = FillUserProfile(objUserInfo)
                    End If
                Else
                    objUserInfo = Nothing
                End If
                Return objUserInfo
            Finally
                If CheckForOpenDataReader Then
                    If Not dr Is Nothing Then
                        dr.Close()
                    End If
                End If
            End Try
        End Function

#End Region

#Region "Friends Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Builds a User Info object from a dataReader
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="PortalId">Id of the portal</param>
        ''' <param name="Username">The name of the user</param>
        ''' <returns>A UserInfo object</returns>
        ''' <history>
        ''' 	[cnurse]	02/22/2005	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function FillUserInfo(ByVal PortalID As Integer, ByVal Username As String) As UserInfo
            Dim dr As IDataReader = DataProvider.Instance().GetUserByUsername(PortalID, Username)
            Dim retValue As UserInfo = Nothing
            Try
                If dr.Read Then
                    retValue = FillUserInfo(dr, PortalID)
                End If
            Finally
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try
            Return retValue
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Builds a User Info object from a dataReader
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="dr">The datareader containing the user info</param>
        ''' <param name="PortalId">Id of the portal</param>
        ''' <returns>A UserInfo object</returns>
        ''' <history>
        ''' 	[cnurse]	02/22/2005	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Friend Function FillUserInfo(ByVal dr As IDataReader, ByVal PortalId As Integer) As UserInfo
            Try
                Dim objUserInfo As New UserInfo

                ' portalid and issuperuser must be set first because they are used by the progressive hydration 
                Try
                    objUserInfo.PortalID = PortalId
                Catch
                End Try
                Try
                    objUserInfo.IsSuperUser = Convert.ToBoolean(Null.SetNull(dr("IsSuperUser"), objUserInfo.IsSuperUser))
                Catch
                End Try

                If objUserInfo.IsSuperUser Then
                    Common.Globals.SetApplicationName(Common.Globals.glbSuperUserAppName)
                Else
                    Common.Globals.SetApplicationName(PortalId)
                End If

                Try
                    objUserInfo.UserID = Convert.ToInt32(Null.SetNull(dr("UserID"), objUserInfo.UserID))
                Catch
                End Try
                Try
                    objUserInfo.Username = Convert.ToString(Null.SetNull(dr("Username"), objUserInfo.Username))
                Catch
                End Try
                Try
                    objUserInfo.FirstName = Convert.ToString(Null.SetNull(dr("FirstName"), objUserInfo.FirstName))
                Catch
                End Try
                Try
                    objUserInfo.LastName = Convert.ToString(Null.SetNull(dr("LastName"), objUserInfo.LastName))
                Catch
                End Try
                Try
                    objUserInfo.AffiliateID = Convert.ToInt32(Null.SetNull(dr("AffiliateID"), objUserInfo.AffiliateID))
                Catch
                End Try

                objUserInfo.FullName = objUserInfo.FirstName & " " & objUserInfo.LastName

                Return objUserInfo
            Finally
                'Reset the Application Name
                Common.Globals.SetApplicationName(Common.Globals.GetApplicationName(PortalId))
            End Try
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Builds a User Info object's Membership Property
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="objUserInfo">The UserInfo objecto</param>
        ''' <returns>A UserMembership object</returns>
        ''' <history>
        ''' 	[cnurse]	02/22/2005	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Friend Function FillUserMembership(ByVal objUserInfo As UserInfo) As UserMembership
            Try
                If objUserInfo.IsSuperUser Then
                    Common.Globals.SetApplicationName(Common.Globals.glbSuperUserAppName)
                Else
                    Common.Globals.SetApplicationName(objUserInfo.PortalID)
                End If

                Dim objMembershipUser As AspNetSecurity.MembershipUser
                objMembershipUser = AspNetSecurity.Membership.GetUser(objUserInfo.Username)

                Dim u As New UserMembership
                Try
                    u.Approved = objMembershipUser.IsApproved
                Catch
                End Try
                Try
                    u.LockedOut = objMembershipUser.IsLockedOut
                Catch
                End Try
                Try
                    u.Username = objMembershipUser.UserName
                Catch
                End Try
                Try
                    u.Password = objMembershipUser.GetPassword()
                Catch
                End Try
                Try
                    u.CreatedDate = objMembershipUser.CreationDate
                Catch
                End Try
                Try
                    u.LastLoginDate = objMembershipUser.LastLoginDate
                Catch
                End Try
                Try
                    u.Email = objMembershipUser.Email
                Catch
                End Try
                Try
                    u.LastLockoutDate = objMembershipUser.LastLockoutDate
                Catch
                End Try
                Return u

            Finally
                'Reset the Application Name
                Common.Globals.SetApplicationName(Common.Globals.GetApplicationName(objUserInfo.PortalID))
            End Try

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Builds a User Info object's Profile Property
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="objUserInfo">The UserInfo objecto</param>
        ''' <returns>A UserProfile object</returns>
        ''' <history>
        ''' 	[cnurse]	02/22/2005	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Friend Function FillUserProfile(ByVal objUserInfo As UserInfo) As UserProfile
            Try
                If objUserInfo.IsSuperUser Then
                    Common.Globals.SetApplicationName(Common.Globals.glbSuperUserAppName)
                Else
                    Common.Globals.SetApplicationName(objUserInfo.PortalID)
                End If

                Dim objProfile As AspNetProfile.ProfileBase
                objProfile = AspNetProfile.ProfileBase.Create(objUserInfo.Username, True)
                Dim u As New UserProfile
                ' Sets all profile properties in Hashtable.
                For Each o As AspNetProfile.SettingsProperty In AspNetProfile.ProfileBase.Properties
                    u.ProfileProperties.Add(o.Name, objProfile.Item(o.Name))
                Next
                Return u
            Finally
                'Reset the Application Name
                Common.Globals.SetApplicationName(Common.Globals.GetApplicationName(objUserInfo.PortalID))
            End Try

        End Function

#End Region

#Region "Public Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Adds a User
        ''' </summary>
        ''' <remarks>This overload adds the User to the Membership Provider
        ''' </remarks>
        ''' <param name="objUser">The userInfo object to persist to the Database</param>
        ''' <returns>The Id of the new User</returns>
        ''' <history>
        ''' 	[cnurse]	02/18/2005	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function AddUser(ByVal objUser As UserInfo) As Integer
            Return AddUser(objUser, True)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Adds a User
        ''' </summary>
        ''' <remarks>This overload provides the option of adding the User to the Membership
        ''' Provider
        ''' </remarks>
        ''' <param name="objUser">The userInfo object to persist to the Database</param>
        ''' <param name="AddToMembershipProvider">A flag that determines whether the user is added
        ''' to the Membership Provider</param>
        ''' <returns>The Id of the new User</returns>
        ''' <history>
        ''' 	[cnurse]	02/18/2005	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function AddUser(ByVal objUser As UserInfo, ByVal AddToMembershipProvider As Boolean) As Integer
            Dim UserId As Integer = -1
            Dim Status As UserRegistrationStatus

            Try
                ' check if username exists in database for any portal
                Dim objVerifyUser As UserInfo = GetUserByUsername(Null.NullInteger, objUser.Membership.Username)
                If Not objVerifyUser Is Nothing Then
                    If objVerifyUser.IsSuperUser Then
                        ' the username belongs to an existing super user
                        Status = UserRegistrationStatus.UserAlreadyRegistered
                    Else
                        ' the username exists so we should now verify the password
                        Common.Globals.SetApplicationName(objVerifyUser.PortalID)
                        If AspNetSecurity.Membership.ValidateUser(objUser.Membership.Username, objUser.Membership.Password) Then
                            ' the specified password matches the password on file
                            UserId = objVerifyUser.UserID

                            ' check if user exists for the portal specified
                            objVerifyUser = GetUserByUsername(objUser.PortalID, objUser.Membership.Username)
                            If Not objVerifyUser Is Nothing Then
                                ' the user is already registered for this portal
                                Status = UserRegistrationStatus.UserAlreadyRegistered
                            Else
                                ' the user does not exist in this portal - add them
                                Status = UserRegistrationStatus.AddUser
                            End If
                        Else
                            ' not the same person - prevent registration
                            Status = UserRegistrationStatus.UsernameAlreadyExists
                        End If
                    End If
                Else
                    ' the user does not exist
                    Status = UserRegistrationStatus.AddUser
                End If

                If Status = UserRegistrationStatus.AddUser Then
                    Dim objSecurity As New PortalSecurity
                    Dim objStatus As AspNetSecurity.MembershipCreateStatus = AspNetSecurity.MembershipCreateStatus.Success
                    If AddToMembershipProvider Then
                        If objUser.IsSuperUser Then
                            Common.Globals.SetApplicationName(Common.Globals.glbSuperUserAppName)
                        Else
                            Common.Globals.SetApplicationName(objUser.PortalID)
                        End If

                        Dim objMembershipUser As AspNetSecurity.MembershipUser
                        objMembershipUser = AspNetSecurity.Membership.CreateUser(objSecurity.InputFilter(objUser.Membership.Username, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoMarkup), objUser.Membership.Password, objSecurity.InputFilter(objUser.Membership.Email, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoMarkup), Nothing, Nothing, objUser.Membership.Approved, objStatus)
                    End If

                    Select Case objStatus
                        Case AspNetSecurity.MembershipCreateStatus.DuplicateEmail
                            Return -1 * CType(AspNetSecurity.MembershipCreateStatus.DuplicateEmail, Integer)
                        Case AspNetSecurity.MembershipCreateStatus.DuplicateProviderUserKey
                            Return -1 * CType(AspNetSecurity.MembershipCreateStatus.DuplicateProviderUserKey, Integer)
                        Case AspNetSecurity.MembershipCreateStatus.DuplicateUserName
                            Return -1 * CType(AspNetSecurity.MembershipCreateStatus.DuplicateUserName, Integer)
                        Case AspNetSecurity.MembershipCreateStatus.InvalidAnswer
                            Return -1 * CType(AspNetSecurity.MembershipCreateStatus.InvalidAnswer, Integer)
                        Case AspNetSecurity.MembershipCreateStatus.InvalidEmail
                            Return -1 * CType(AspNetSecurity.MembershipCreateStatus.InvalidEmail, Integer)
                        Case AspNetSecurity.MembershipCreateStatus.InvalidPassword
                            Return -1 * CType(AspNetSecurity.MembershipCreateStatus.InvalidPassword, Integer)
                        Case AspNetSecurity.MembershipCreateStatus.InvalidProviderUserKey
                            Return -1 * CType(AspNetSecurity.MembershipCreateStatus.InvalidProviderUserKey, Integer)
                        Case AspNetSecurity.MembershipCreateStatus.InvalidQuestion
                            Return -1 * CType(AspNetSecurity.MembershipCreateStatus.InvalidQuestion, Integer)
                        Case AspNetSecurity.MembershipCreateStatus.InvalidUserName
                            Return -1 * CType(AspNetSecurity.MembershipCreateStatus.InvalidUserName, Integer)
                        Case AspNetSecurity.MembershipCreateStatus.ProviderError
                            Return -1 * CType(AspNetSecurity.MembershipCreateStatus.ProviderError, Integer)
                        Case AspNetSecurity.MembershipCreateStatus.UserRejected
                            Return -1 * CType(AspNetSecurity.MembershipCreateStatus.UserRejected, Integer)
                        Case AspNetSecurity.MembershipCreateStatus.Success
                            UserId = DataProvider.Instance().AddUser(objUser.PortalID, objSecurity.InputFilter(objUser.Membership.Username, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoMarkup), objSecurity.InputFilter(objUser.Profile.FirstName, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoMarkup), objSecurity.InputFilter(objUser.Profile.LastName, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoMarkup), objUser.AffiliateID, objUser.IsSuperUser, objUser.Membership.Email)
                            If AddToMembershipProvider AndAlso UserId <> -1 Then
                                ' Created seperate method to save profile data.
                                SaveProfileProperty(objUser.Membership.Username, objUser.Profile.ProfileProperties)

                                If Not objUser.IsSuperUser Then
                                    Dim objRoles As New RoleController
                                    Dim objRole As RoleInfo

                                    ' autoassign user to portal roles
                                    Dim arrRoles As ArrayList = CBO.FillCollection(DataProvider.Instance().GetPortalRoles(objUser.PortalID), GetType(RoleInfo))
                                    Dim i As Integer
                                    For i = 0 To arrRoles.Count - 1
                                        objRole = CType(arrRoles(i), RoleInfo)
                                        If objRole.AutoAssignment = True Then
                                            objRoles.AddUserRole(objUser.PortalID, UserId, objRole.RoleID, Null.NullDate)
                                        End If
                                    Next
                                End If
                            End If
                    End Select
                End If

                Return UserId

            Catch exc As Exception    ' an unexpected error occurred
                LogException(exc)
            Finally
                Common.Globals.SetApplicationName(objUser.PortalID)
            End Try
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Deletes all users for a portal
        ''' </summary>
        ''' <param name="PortalId">Id of the portal</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	02/18/2005	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub DeleteAllUsers(ByVal PortalId As Integer)
            Try
                Common.Globals.SetApplicationName(PortalId)

                Dim objMembershipUsers As AspNetSecurity.MembershipUserCollection = AspNetSecurity.Membership.GetAllUsers
                Dim objMembershipUser As AspNetSecurity.MembershipUser
                Dim objUser As UserInfo

                For Each objMembershipUser In objMembershipUsers
                    objUser = GetUserByUsername(PortalId, objMembershipUser.UserName)
                    ' if an external application using the Membership provider created some users, 
                    ' it is possible that they may not exist in DotNetNuke
                    If Not objUser Is Nothing Then
                        DeleteUser(objUser.PortalID, objUser.UserID, False, True)
                    End If
                Next

            Finally
                Common.Globals.SetApplicationName(PortalId)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Deletes a user from a portal
        ''' </summary>
        ''' <param name="PortalId">Id of the portal</param>
        ''' <param name="UserId">Id of the user</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	02/18/2005	Documented and modified to call helper method where
        '''                 the code was ported to.
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function DeleteUser(ByVal PortalId As Integer, ByVal UserId As Integer) As Boolean
            'Call private method with notify=true, deleteAdmin=false
            Return DeleteUser(PortalId, UserId, True, False)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Deletes all the users from a portal
        ''' </summary>
        ''' <param name="PortalId">Id of the portal</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	02/18/2005	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub DeleteUsers(ByVal PortalId As Integer)
            Dim arr As New ArrayList

            Try
                Common.Globals.SetApplicationName(PortalId)

                Dim objMembershipUsers As AspNetSecurity.MembershipUserCollection = AspNetSecurity.Membership.GetAllUsers
                Dim objMembershipUser As AspNetSecurity.MembershipUser

                For Each objMembershipUser In objMembershipUsers
                    If objMembershipUser.IsApproved = False Or objMembershipUser.LastLoginDate = Null.NullDate Then
                        Dim objUser As UserInfo = Me.GetUserByUsername(PortalId, objMembershipUser.UserName)
                        arr.Add(objUser)
                    End If
                Next

                Dim i As Integer
                For i = 0 To arr.Count - 1
                    Dim objUser As UserInfo = CType(arr(i), UserInfo)
                    DeleteUser(objUser.PortalID, objUser.UserID)
                Next

            Finally
                Common.Globals.SetApplicationName(PortalId)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the User's Cache Key
        ''' </summary>
        ''' <param name="PortalID">The Id of the Partal</param>
        ''' <param name="Username">The name of the User</param>
        ''' <returns>A String</returns>
        ''' <history>
        ''' 	[cnurse]	05/23/2005	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetCacheKey(ByVal PortalID As Integer, ByVal Username As String) As String
            Return "UserInfo|" + PortalID.ToString + "|" + Username
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Retruns a String corresponding to the Registration Status of the User
        ''' </summary>
        ''' <param name="UserRegistrationStatus">The AspNetSecurity.MembershipCreateStatus</param>
        ''' <returns>A String</returns>
        ''' <history>
        ''' 	[cnurse]	05/23/2005	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetRegistrationStatus(ByVal UserRegistrationStatus As AspNetSecurity.MembershipCreateStatus) As String
            Select Case UserRegistrationStatus
                Case AspNetSecurity.MembershipCreateStatus.DuplicateEmail
                    Return Services.Localization.Localization.GetString("UserEmailExists")
                Case AspNetSecurity.MembershipCreateStatus.InvalidAnswer
                    Return Services.Localization.Localization.GetString("InvalidAnswer")
                Case AspNetSecurity.MembershipCreateStatus.InvalidEmail
                    Return Services.Localization.Localization.GetString("InvalidEmail")
                Case AspNetSecurity.MembershipCreateStatus.InvalidPassword
                    Return Services.Localization.Localization.GetString("InvalidPassword")
                Case AspNetSecurity.MembershipCreateStatus.InvalidQuestion
                    Return Services.Localization.Localization.GetString("InvalidQuestion")
                Case AspNetSecurity.MembershipCreateStatus.InvalidUserName
                    Return Services.Localization.Localization.GetString("InvalidUserName")
                Case AspNetSecurity.MembershipCreateStatus.UserRejected
                    Return Services.Localization.Localization.GetString("UserRejected")
                Case AspNetSecurity.MembershipCreateStatus.DuplicateUserName
                    Return Services.Localization.Localization.GetString("UserNameExists")
                Case AspNetSecurity.MembershipCreateStatus.ProviderError, AspNetSecurity.MembershipCreateStatus.DuplicateProviderUserKey, AspNetSecurity.MembershipCreateStatus.InvalidProviderUserKey
                    Return Services.Localization.Localization.GetString("RegError")
                Case Else
                    Return Nothing
            End Select
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Returns all the SuperUsers
        ''' </summary>
        ''' <returns>An Arraylist of UserInfo objects</returns>
        ''' <history>
        ''' 	[cnurse]	05/23/2005	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetSuperUsers() As ArrayList
            Return FillUserInfoCollection(DataProvider.Instance().GetSuperUsers(), -1, True)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets a single User
        ''' </summary>
        ''' <param name="PortalID">The Id of the portal</param>
        ''' <param name="UserId">The Id of the user</param>
        ''' <returns>A UserInfo object</returns>
        ''' <history>
        ''' 	[cnurse]	05/23/2005	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetUser(ByVal PortalId As Integer, ByVal UserId As Integer) As UserInfo
            Dim dr As IDataReader = DataProvider.Instance().GetUser(PortalId, UserId)
            Dim retValue As UserInfo = Nothing
            Try
                If dr.Read Then
                    retValue = FillUserInfo(dr, PortalId)
                End If
            Finally
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try
            Return retValue
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets a User by Name
        ''' </summary>
        ''' <param name="PortalID">The Id of the portal</param>
        ''' <param name="Username">The username of the user</param>
        ''' <returns>A UserInfo object</returns>
        ''' <history>
        ''' 	[cnurse]	05/23/2005	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetUserByUsername(ByVal PortalID As Integer, ByVal Username As String) As UserInfo
            Return GetUserByUsername(PortalID, Username, False)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets a User by Name
        ''' </summary>
        ''' <param name="PortalID">The Id of the portal</param>
        ''' <param name="Username">The username of the user</param>
        ''' <param name="SynchronizeUsers">Flag that indicates whether to synchronize the
        ''' users before returning the collection</param>
        ''' <returns>A UserInfo object</returns>
        ''' <history>
        ''' 	[cnurse]	05/23/2005	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetUserByUsername(ByVal PortalID As Integer, ByVal Username As String, ByVal SynchronizeUsers As Boolean) As UserInfo
            Dim objUser As UserInfo = Nothing
            Dim dr As IDataReader = DataProvider.Instance().GetUserByUsername(PortalID, Username)
            Try
                If SynchronizeUsers Then
                    Me.SynchronizeUsers(PortalID)
                End If
                If dr.Read Then
                    If PortalID = -1 Then
                        PortalID = Convert.ToInt32(Null.SetNull(dr("PortalID"), PortalID))
                    End If
                    objUser = FillUserInfo(dr, PortalID)
                End If
            Finally
                If Not dr Is Nothing Then
                    dr.Close()
                End If
            End Try

            Return objUser
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This overload returns all the Users
        ''' </summary>
        ''' <param name="SynchronizeUsers">Flag that indicates whether to synchronize the
        ''' users before returning the collection</param>
        ''' <param name="ProgressiveHydration">Flag that determines whether to use Progressive
        ''' Hydration</param>
        ''' <returns>An Arraylist of UserInfo objects</returns>
        ''' <history>
        ''' 	[cnurse]	05/23/2005	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetUsers(ByVal SynchronizeUsers As Boolean, ByVal ProgressiveHydration As Boolean) As ArrayList
            Return GetUsers(-1, SynchronizeUsers, ProgressiveHydration)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' This overload returns all the users of a Portal
        ''' </summary>
        ''' <param name="PortalId"></param>
        ''' <param name="SynchronizeUsers"></param>
        ''' <param name="ProgressiveHydration"></param>
        ''' <returns>An Arraylist of UserInfo objects</returns>
        ''' <history>
        ''' 	[cnurse]	05/23/2005	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetUsers(ByVal PortalId As Integer, ByVal SynchronizeUsers As Boolean, ByVal ProgressiveHydration As Boolean) As ArrayList
            If SynchronizeUsers Then
                Me.SynchronizeUsers(PortalId)
            End If
            Return FillUserInfoCollection(DataProvider.Instance().GetUsers(PortalId), PortalId, ProgressiveHydration)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Sets the password in the Membership Provider
        ''' </summary>
        ''' <param name="objUser">The use to update</param>
        ''' <param name="newPassword">The new password</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	03/04/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function SetPassword(ByVal objUser As UserInfo, ByVal newPassword As String) As Boolean
            Return SetPassword(objUser, objUser.Membership.Password, newPassword)
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Sets the password in the Membership Provider
        ''' </summary>
        ''' <param name="objUser">The use to update</param>
        ''' <param name="oldPassword">The old password</param>
        ''' <param name="newPassword">The new password</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	02/18/2005	Documented
        '''     [cnurse]    03/03/2005  Modified to support SuperUsers
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function SetPassword(ByVal objUser As UserInfo, ByVal oldPassword As String, ByVal newPassword As String) As Boolean
            Dim retValue As Boolean = False

            Try
                If objUser.IsSuperUser Then
                    Common.Globals.SetApplicationName(Common.Globals.glbSuperUserAppName)
                Else
                    Common.Globals.SetApplicationName(objUser.PortalID)
                End If

                Dim objMembershipUser As AspNetSecurity.MembershipUser
                objMembershipUser = AspNetSecurity.Membership.GetUser(objUser.Username)
                objMembershipUser.ChangePassword(oldPassword, newPassword)

                Dim confirmPassword As String = objMembershipUser.GetPassword()

                If confirmPassword = newPassword Then
                    retValue = True
                End If

            Catch ex As Exception
                LogException(ex)
            Finally
                Common.Globals.SetApplicationName(objUser.PortalID)
            End Try

            Return retValue

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Synchronizes users between the DNN Users Table and the AspNet Users for a Portal
        ''' </summary>
        ''' <param name="PortalID">The Id of the Portal to synchronize</param>
        ''' <history>
        ''' 	[cnurse]	05/23/2005	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub SynchronizeUsers(ByVal PortalID As Integer)

            Dim objUserController As New UserController
            Dim objMembers As AspNetSecurity.MembershipUserCollection = AspNetSecurity.Membership.GetAllUsers()
            Dim objMember As AspNetSecurity.MembershipUser
            For Each objMember In objMembers
                If objUserController.GetUserByUsername(PortalID, objMember.UserName) Is Nothing Then
                    Dim objuser As New UserInfo
                    objuser.PortalID = PortalID
                    objuser.Membership.Username = objMember.UserName
                    objuser.Membership.Approved = objMember.IsApproved
                    objuser.AffiliateID = -1
                    objUserController.AddUser(objuser, False)
                End If
            Next
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Unlock a User Account
        ''' </summary>
        ''' <param name="objUser">The User to unlock</param>
        ''' <history>
        ''' 	[cnurse]	05/23/2005	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub UnlockUserAccount(ByVal objUser As UserInfo)
            Try
                If objUser.IsSuperUser Then
                    Common.Globals.SetApplicationName(Common.Globals.glbSuperUserAppName)
                Else
                    Common.Globals.SetApplicationName(objUser.PortalID)
                End If

                Dim objMembershipUser As AspNetSecurity.MembershipUser
                objMembershipUser = AspNetSecurity.Membership.GetUser(objUser.Membership.Username)
                objMembershipUser.UnlockUser()

                Dim UserInfoCacheKey As String = GetCacheKey(objUser.PortalID, objUser.Username)
                DataCache.RemoveCache(UserInfoCacheKey)

            Finally
                Common.Globals.SetApplicationName(objUser.PortalID)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Updates a User
        ''' </summary>
        ''' <param name="objUser">The use to update</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	02/18/2005	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub UpdateUser(ByVal objUser As UserInfo)
            Try
                Dim objSecurity As New PortalSecurity
                Dim objUserController As New UserController
                DataProvider.Instance.UpdateUser(objUser.UserID, objSecurity.InputFilter(objUser.Profile.FirstName, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoMarkup), objSecurity.InputFilter(objUser.Profile.LastName, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoMarkup), objUser.Membership.Email)

                If objUser.IsSuperUser Then
                    Common.Globals.SetApplicationName(Common.Globals.glbSuperUserAppName)
                Else
                    Common.Globals.SetApplicationName(objUser.PortalID)
                End If

                ' Created seperate method to save profile data.
                SaveProfileProperty(objUser.Membership.Username, objUser.Profile.ProfileProperties)

                Dim objMembershipUser As AspNetSecurity.MembershipUser
                objMembershipUser = AspNetSecurity.Membership.GetUser(objUser.Membership.Username)
                objMembershipUser.Email = objSecurity.InputFilter(objUser.Membership.Email, PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoMarkup)
                objMembershipUser.IsApproved = objUser.Membership.Approved
                objMembershipUser.LastActivityDate = Now
                AspNetSecurity.Membership.UpdateUser(objMembershipUser)

                If objUser.Membership.Password <> "" Then
                    objMembershipUser.ChangePassword(objMembershipUser.GetPassword, objUser.Membership.Password)
                End If

                Dim UserInfoCacheKey As String = GetCacheKey(objUser.PortalID, objUser.Username)
                DataCache.RemoveCache(UserInfoCacheKey)
            Catch ex As Exception
                LogException(ex)
            Finally
                Common.Globals.SetApplicationName(objUser.PortalID)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Saves Profile Propertis
        ''' </summary>
        ''' <param name="userName">the username</param>
        ''' <param name="propHash">Hashtable of profile key/value pairs</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub SaveProfileProperty(ByVal userName As String, ByVal propHash As Hashtable)
            Dim objProfile As AspNetProfile.ProfileBase
            Dim objSecurity As New PortalSecurity

            objProfile = AspNetProfile.ProfileBase.Create(userName, True)

            'Looping through each key in profile hashtable.
            'Each key is profile property name.
            For Each key As Object In propHash.Keys
                'checking if property's datatype is string.
                'if it is string then we do input filter on value.
                If AspNetProfile.ProfileBase.Properties(key.ToString()).PropertyType Is GetType(String) Then
                    'Checking if value is set or not? if value is set then do input filter
                    'otherwise assign Nullstring.
                    If propHash.ContainsKey(key) AndAlso Not propHash(key) Is Nothing Then
                        objProfile(key.ToString()) = objSecurity.InputFilter(propHash(key).ToString(), PortalSecurity.FilterFlag.NoScripting Or PortalSecurity.FilterFlag.NoMarkup)
                    Else
                        objProfile(key.ToString()) = Null.NullString
                    End If
                Else
                    objProfile(key.ToString()) = Null.SetNull(propHash(key), AspNetProfile.ProfileBase.Properties(key.ToString()).PropertyType)
                End If
            Next
            objProfile.Save()

        End Sub
#End Region

#Region "Shared/Static Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Get the current UserInfo object
        ''' </summary>
        ''' <returns>The current UserInfo</returns>
        ''' <history>
        ''' 	[cnurse]	05/23/2005	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetCurrentUserInfo() As UserInfo
            If (HttpContext.Current Is Nothing) Then
                If Not (Thread.CurrentPrincipal.Identity.IsAuthenticated) Then
                    Return New UserInfo
                Else
                    Dim _portalSettings As PortalSettings = PortalController.GetCurrentPortalSettings
                    Dim objUserController As UserController = New UserController
                    Dim objUser As UserInfo
                    objUser = objUserController.GetUserByUsername(_portalSettings.PortalId, Thread.CurrentPrincipal.Identity.Name)
                    If Not objUser Is Nothing Then
                        Return objUser
                    Else
                        Return New UserInfo
                    End If
                End If
            Else
                Dim objUser As UserInfo = CType(HttpContext.Current.Items("UserInfo"), UserInfo)
                If Not objUser Is Nothing Then
                    Return objUser
                Else
                    Return New UserInfo
                End If
            End If
        End Function

#End Region

    End Class


End Namespace
