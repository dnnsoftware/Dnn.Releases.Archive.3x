'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Web

Imports Localize = DotNetNuke.Services.Localization.Localization

Namespace DotNetNuke.Services.Mail

    Public Enum MailFormat
        Text
        Html
    End Enum

    Public Enum MailPriority
        Normal
        Low
        High
    End Enum

    Public Enum MessageType
        PasswordReminder
        ProfileUpdated
        UserRegistrationAdmin
        UserRegistrationPrivate
        UserRegistrationPublic
        UserRegistrationVerified
    End Enum


    Public Class Mail

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' <summary>Send an email notification</summary>
        ''' </summary>
        ''' <param name="user">The user to whom the message is being sent</param>
        ''' <param name="msgType">The type of message being sent</param>
        ''' <param name="settings">Portal Settings</param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        ''' <history>
        '''     [cnurse]        09/29/2005  Moved to Mail class
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function SendMail(ByVal user As UserInfo, ByVal msgType As MessageType, ByVal settings As PortalSettings) As String

            'Send Notification to User
            Dim userEmail As String = user.Email
            Dim locale As String = user.Profile.PreferredLocale
            Dim subject As String = ""
            Dim body As String = ""
            Dim custom As ArrayList = Nothing

            Select Case msgType
                Case MessageType.UserRegistrationAdmin
                    subject = "EMAIL_USER_REGISTRATION_ADMINISTRATOR_SUBJECT"
                    body = "EMAIL_USER_REGISTRATION_ADMINISTRATOR_BODY"
                    userEmail = settings.Email
                Case MessageType.UserRegistrationPrivate
                    subject = "EMAIL_USER_REGISTRATION_PRIVATE_SUBJECT"
                    body = "EMAIL_USER_REGISTRATION_PRIVATE_BODY"
                Case MessageType.UserRegistrationPublic
                    subject = "EMAIL_USER_REGISTRATION_PUBLIC_SUBJECT"
                    body = "EMAIL_USER_REGISTRATION_PUBLIC_BODY"
                Case MessageType.UserRegistrationVerified
                    subject = "EMAIL_USER_REGISTRATION_VERIFIED_SUBJECT"
                    body = "EMAIL_USER_REGISTRATION_VERIFIED_BODY"
                    If Not HttpContext.Current Is Nothing Then
                        custom = New ArrayList
                        custom.Add(HttpContext.Current.Server.UrlEncode(user.Username))
                    End If
                Case MessageType.PasswordReminder
                    subject = "EMAIL_PASSWORD_REMINDER_SUBJECT"
                    body = "EMAIL_PASSWORD_REMINDER_BODY"
                Case MessageType.ProfileUpdated
                    subject = "EMAIL_PROFILE_UPDATED_SUBJECT"
                    body = "EMAIL_PROFILE_UPDATED_BODY"
            End Select

            Return SendMail(settings.Email, userEmail, "", _
                Localize.GetSystemMessage(locale, settings, subject, user), _
                Localize.GetSystemMessage(locale, settings, body, user, Localize.GlobalResourceFile, custom), _
                "", "", "", "", "", "")


        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' <summary>Send a simple email.</summary>
        ''' </summary>
        ''' <param name="MailFrom"></param>
        ''' <param name="MailTo"></param>
        ''' <param name="Bcc"></param>
        ''' <param name="Subject"></param>
        ''' <param name="Body"></param>
        ''' <param name="Attachment"></param>
        ''' <param name="BodyType"></param>
        ''' <param name="SMTPServer"></param>
        ''' <param name="SMTPAuthentication"></param>
        ''' <param name="SMTPUsername"></param>
        ''' <param name="SMTPPassword"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        ''' <history>
        '''     [cnurse]        09/29/2005  Moved to Mail class
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function SendMail(ByVal MailFrom As String, ByVal MailTo As String, ByVal Bcc As String, ByVal Subject As String, ByVal Body As String, ByVal Attachment As String, ByVal BodyType As String, ByVal SMTPServer As String, ByVal SMTPAuthentication As String, ByVal SMTPUsername As String, ByVal SMTPPassword As String) As String

            ' SMTP server configuration
            If SMTPServer = "" Then
                If Convert.ToString(Common.Globals.HostSettings("SMTPServer")) <> "" Then
                    SMTPServer = Convert.ToString(Common.Globals.HostSettings("SMTPServer"))
                End If
            End If
            If SMTPAuthentication = "" Then
                If Convert.ToString(Common.Globals.HostSettings("SMTPAuthentication")) <> "" Then
                    SMTPAuthentication = Convert.ToString(Common.Globals.HostSettings("SMTPAuthentication"))
                End If
            End If
            If SMTPUsername = "" Then
                If Convert.ToString(Common.Globals.HostSettings("SMTPUsername")) <> "" Then
                    SMTPUsername = Convert.ToString(Common.Globals.HostSettings("SMTPUsername"))
                End If
            End If
            If SMTPPassword = "" Then
                If Convert.ToString(Common.Globals.HostSettings("SMTPPassword")) <> "" Then
                    SMTPPassword = Convert.ToString(Common.Globals.HostSettings("SMTPPassword"))
                End If
            End If

            ' here we check if we want to format the email as html or plain text.
            Dim objBodyFormat As MailFormat
            If BodyType <> "" Then
                Select Case LCase(BodyType)
                    Case "html"
                        objBodyFormat = MailFormat.Html
                    Case "text"
                        objBodyFormat = MailFormat.Text
                End Select
            End If

            Return SendMail(MailFrom, MailTo, "", Bcc, MailPriority.Normal, _
                Subject, objBodyFormat, System.Text.Encoding.UTF8, Body, Attachment, SMTPServer, _
                SMTPAuthentication, SMTPUsername, SMTPPassword)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>Send a simple email.</summary>
        ''' <param name="MailFrom"></param>
        ''' <param name="MailTo"></param>
        ''' <param name="Cc"></param>
        ''' <param name="Bcc"></param>
        ''' <param name="Priority"></param>
        ''' <param name="Subject"></param>
        ''' <param name="BodyFormat"></param>
        ''' <param name="BodyEncoding"></param>
        ''' <param name="Body"></param>
        ''' <param name="Attachment"></param>
        ''' <param name="SMTPServer"></param>
        ''' <param name="SMTPAuthentication"></param>
        ''' <param name="SMTPUsername"></param>
        ''' <param name="SMTPPassword"></param>
        ''' <returns></returns>
        ''' <remarks></remarks>
        ''' <history>
        ''' 	[Nik Kalyani]	10/15/2004	Replaced brackets in member names
        '''     [cnurse]        09/29/2005  Moved to Mail class
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function SendMail(ByVal MailFrom As String, ByVal MailTo As String, _
            ByVal Cc As String, ByVal Bcc As String, ByVal Priority As MailPriority, _
            ByVal Subject As String, ByVal BodyFormat As MailFormat, _
            ByVal BodyEncoding As System.Text.Encoding, ByVal Body As String, _
            ByVal Attachment As String, ByVal SMTPServer As String, ByVal SMTPAuthentication As String, _
            ByVal SMTPUsername As String, ByVal SMTPPassword As String) As String

            Dim objMail As New Web.Mail.MailMessage
            objMail.From = MailFrom
            objMail.To = MailTo
            If Cc <> "" Then
                objMail.Cc = Cc
            End If
            If Bcc <> "" Then
                objMail.Bcc = Bcc
            End If
            objMail.Priority = CType(Priority, Web.Mail.MailPriority)
            objMail.BodyFormat = CType(BodyFormat, Web.Mail.MailFormat)

            If Attachment <> "" Then
                objMail.Attachments.Add(New Web.Mail.MailAttachment(Attachment))
            End If

            ' message
            objMail.Subject = Subject
            objMail.Subject = HtmlUtils.StripWhiteSpace(Subject, True)
            objMail.BodyEncoding = BodyEncoding
            objMail.Body = Body

            ' external SMTP server
            If SMTPServer <> "" Then
                Dim portPos As Integer = SMTPServer.IndexOf(":")
                If portPos > -1 Then
                    objMail.Fields("http://schemas.microsoft.com/cdo/configuration/smtpserverport") = SMTPServer.Substring(portPos + 1, SMTPServer.Length - portPos - 1)
                    SMTPServer = SMTPServer.Substring(0, portPos)
                End If
                Web.Mail.SmtpMail.SmtpServer = SMTPServer
                Select Case SMTPAuthentication
                    Case "", "0" ' anonymous
                    Case "1" ' basic
                        If SMTPUsername <> "" And SMTPPassword <> "" Then
                            objMail.Fields("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate") = 1
                            objMail.Fields("http://schemas.microsoft.com/cdo/configuration/sendusername") = SMTPUsername
                            objMail.Fields("http://schemas.microsoft.com/cdo/configuration/sendpassword") = SMTPPassword
                        End If
                    Case "2" ' NTLM
                        objMail.Fields("http://schemas.microsoft.com/cdo/configuration/smtpauthenticate") = 2
                End Select
            End If

            Try
                Web.Mail.SmtpMail.Send(objMail)
                SendMail = ""
            Catch objException As Exception
                ' mail configuration problem
                SendMail = objException.InnerException.InnerException.Message
                LogException(objException.InnerException)
            End Try

        End Function


    End Class

End Namespace

