'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System
Imports System.Data
Imports DotNetNuke

Namespace DotNetNuke.Security.Permissions


#Region "FolderPermissionController"
	Public Class FolderPermissionController

        Public Function AddFolderPermission(ByVal objFolderPermission As FolderPermissionInfo) As Integer

            Return CType(DataProvider.Instance().AddFolderPermission(objFolderPermission.FolderID, objFolderPermission.PermissionID, objFolderPermission.RoleID, objFolderPermission.AllowAccess), Integer)

        End Function

        Public Sub DeleteFolderPermission(ByVal FolderPermissionID As Integer)

            DataProvider.Instance().DeleteFolderPermission(FolderPermissionID)

        End Sub

        Public Sub DeleteFolderPermissionsByFolder(ByVal PortalID As Integer, ByVal FolderPath As String)

            DataProvider.Instance().DeleteFolderPermissionsByFolderPath(PortalID, FolderPath)

        End Sub

        Public Function GetFolderPermission(ByVal FolderPermissionID As Integer) As FolderPermissionInfo

            Return CType(CBO.FillObject(DataProvider.Instance().GetFolderPermission(FolderPermissionID), GetType(FolderPermissionInfo)), FolderPermissionInfo)

        End Function

        Public Function GetFolderPermissionsByFolder(ByVal PortalID As Integer, ByVal Folder As String) As ArrayList

            Return CBO.FillCollection(DataProvider.Instance().GetFolderPermissionsByFolderPath(PortalID, Folder, -1), GetType(FolderPermissionInfo))

        End Function

        Public Function GetFolderPermissionsByFolder(ByVal arrFolderPermissions As ArrayList, ByVal FolderPath As String) As Security.Permissions.FolderPermissionCollection

            Dim p As New Security.Permissions.FolderPermissionCollection

            Dim i As Integer
            For i = 0 To arrFolderPermissions.Count - 1
                Dim objFolderPermission As Security.Permissions.FolderPermissionInfo = CType(arrFolderPermissions(i), Security.Permissions.FolderPermissionInfo)
                If objFolderPermission.FolderPath = FolderPath Then
                    p.Add(objFolderPermission)
                End If
            Next
            Return p
        End Function

        Public Function GetFolderPermissionsByFolderPath(ByVal arrFolderPermissions As ArrayList, ByVal FolderPath As String, ByVal PermissionKey As String) As String

            Dim strRoles As String = ";"
            Dim i As Integer
            For i = 0 To arrFolderPermissions.Count - 1
                Dim objFolderPermission As Security.Permissions.FolderPermissionInfo = CType(arrFolderPermissions(i), Security.Permissions.FolderPermissionInfo)
                If objFolderPermission.FolderPath = FolderPath AndAlso objFolderPermission.AllowAccess = True AndAlso objFolderPermission.PermissionKey = PermissionKey Then
                    strRoles += objFolderPermission.RoleName + ";"
                End If
            Next
            Return strRoles
        End Function

        Public Function GetFolderPermissionsCollectionByFolderPath(ByVal PortalID As Integer, ByVal FolderPath As String) As Security.Permissions.FolderPermissionCollection
            Dim objFolderPermissionCollection As IList = New Security.Permissions.FolderPermissionCollection
            CBO.FillCollection(DataProvider.Instance().GetFolderPermissionsByFolderPath(PortalID, FolderPath, -1), GetType(FolderPermissionInfo), objFolderPermissionCollection)
            Return CType(objFolderPermissionCollection, Security.Permissions.FolderPermissionCollection)
        End Function

        Public Function GetFolderPermissionsCollectionByFolderPath(ByVal arrFolderPermissions As ArrayList, ByVal FolderPath As String) As Security.Permissions.FolderPermissionCollection
            Dim objFolderPermissionCollection As New Security.Permissions.FolderPermissionCollection(arrFolderPermissions, FolderPath)
            Return objFolderPermissionCollection
        End Function

        Public Shared Function HasFolderPermission(ByVal objFolderPermissions As Security.Permissions.FolderPermissionCollection, ByVal PermissionKey As String) As Boolean
            Dim m As Security.Permissions.FolderPermissionCollection = objFolderPermissions
            Dim i As Integer
            For i = 0 To m.Count - 1
                Dim mp As Security.Permissions.FolderPermissionInfo
                mp = m(i)
                If mp.PermissionKey = PermissionKey AndAlso PortalSecurity.IsInRoles(mp.RoleName) Then
                    Return True
                End If
            Next
            Return False
        End Function

        Public Sub UpdateFolderPermission(ByVal objFolderPermission As FolderPermissionInfo)

            DataProvider.Instance().UpdateFolderPermission(objFolderPermission.FolderPermissionID, objFolderPermission.FolderID, objFolderPermission.PermissionID, objFolderPermission.RoleID, objFolderPermission.AllowAccess)

        End Sub

    End Class
#End Region


End Namespace
