'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by DotNetNuke Corporation
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports FreeTextBoxControls
Imports DotNetNuke.Common
Imports DotNetNuke.Common.Utilities
Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Security
Imports DotNetNuke.Services.FileSystem

Namespace DotNetNuke.HtmlEditor

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The FTBImageGallery Class provides the Image Gallery for the FTB Provider
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' [cnurse] 12/14/2004 documented and updated to work with FTB3.0
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class FTBImageGallery
        Inherits DotNetNuke.Framework.PageBase

        Public Title As String = ""

        Protected WithEvents imgGallery As DNNImageGallery

        Protected ReadOnly Property CurrentFolder() As String
            Get
                Dim strCurrentFolder As String = Server.MapPath(imgGallery.CurrentImagesFolder)
                If Not strCurrentFolder.EndsWith("\") Then
                    strCurrentFolder &= "\"
                End If

                If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                    strCurrentFolder = strCurrentFolder.Substring(Common.Globals.HostMapPath.Length)
                Else
                    strCurrentFolder = strCurrentFolder.Substring(PortalSettings.HomeDirectoryMapPath.Length)
                End If

                Return strCurrentFolder.Replace("\", "/")
            End Get
        End Property

        Protected ReadOnly Property FolderPortalId() As Integer
            Get
                If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                    Return Null.NullInteger
                Else
                    Return PortalSettings.PortalId
                End If
            End Get
        End Property

        Private Sub InitFolderAccess()
            Dim AllowWriteAccess As Boolean = False
            Dim AllowReadAccess As Boolean = False
            Try
                ' Check permissions for current directory
                Dim roles As String = FileSystemUtils.GetRoles(CurrentFolder, PortalSettings.PortalId, "WRITE")
                If PortalSecurity.IsInRoles(roles) Then
                    AllowWriteAccess = True
                End If
                roles = FileSystemUtils.GetRoles(CurrentFolder, PortalSettings.PortalId, "READ")
                If PortalSecurity.IsInRoles(roles) Then
                    AllowReadAccess = True
                End If
            Catch ex As Exception 'wrong directory
                AllowWriteAccess = False
                AllowReadAccess = False
            End Try
            ' Set WRITE rights
            imgGallery.AllowDirectoryCreate = AllowWriteAccess
            imgGallery.AllowDirectoryDelete = AllowWriteAccess
            imgGallery.AllowImageDelete = AllowWriteAccess
            imgGallery.AllowImageUpload = AllowWriteAccess

            If Not AllowReadAccess Then
                'NO ACCESS
                Dim noimage() As System.IO.FileInfo = New System.IO.FileInfo() {}
                imgGallery.CurrentImages = noimage
            End If
        End Sub

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            ' set page title
            Dim strTitle As String = PortalSettings.PortalName & " > Image Gallery"

            ' show copyright credits?
            If GetHashValue(Common.Globals.HostSettings("Copyright"), "Y") = "Y" Then
                strTitle += " ( DNN " & PortalSettings.Version & " )"
            End If

            Title = strTitle
            imgGallery.JavaScriptLocation = ResourceLocation.ExternalFile
            imgGallery.UtilityImagesLocation = ResourceLocation.ExternalFile
            imgGallery.SupportFolder = DotNetNuke.Common.Globals.ResolveUrl("~/Providers/HtmlEditorProviders/Ftb3HtmlEditorProvider/ftb3/")
        End Sub

        Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender

            InitFolderAccess()

            'Get the list of sub-directories
            Dim arrFolders As ArrayList = FileSystemUtils.GetFoldersByParentFolder(FolderPortalId, CurrentFolder)
            Dim alFolders As New ArrayList

            For Each folder As Services.FileSystem.FolderInfo In arrFolders
                If folder.StorageLocation = FolderController.StorageLocationTypes.InsecureFileSystem Then
                    Dim roles As String = FileSystemUtils.GetRoles(folder.FolderPath, PortalSettings.PortalId, "READ")
                    If PortalSecurity.IsInRoles(roles) Then
                        'add folder to list
                        alFolders.Add(folder.FolderName)
                    End If
                End If
            Next

            imgGallery.CurrentDirectories = CType(alFolders.ToArray(GetType(System.String)), String())

        End Sub

#Region " Web Form Designer Generated Code "
        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object
        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub
#End Region

    End Class

End Namespace
