'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Web
Imports DotNetNuke
Imports DotNetNuke.Security
Imports DotNetNuke.Common.Globals
Imports DotNetNuke.Security.Authentication
Imports DotNetNuke.Entities.Portals

Imports DotNetNuke.Security.Authentication.Configuration

Namespace DotNetNuke.HttpModules

    Public Class AuthenticationModule
        Implements IHttpModule

        Public ReadOnly Property ModuleName() As String
            Get
                Return "AuthenticationModule"
            End Get
        End Property

        Public Sub Init(ByVal application As HttpApplication) Implements IHttpModule.Init
            'Call this method to make sure that portalsettings is stored in Context
            Dim _portalSettings As PortalSettings = Common.GetPortalSettings
            AuthenticationController.SetStatus(_portalSettings.PortalId, AuthenticationStatus.Undefined)
            AddHandler application.AuthenticateRequest, AddressOf Me.OnAuthenticateRequest
        End Sub

        Public Sub OnAuthenticateRequest(ByVal s As Object, ByVal e As EventArgs)
            Dim _portalSettings As PortalSettings = Common.GetPortalSettings
            Dim config As Authentication.Configuration = Authentication.Configuration.GetConfig()

            If config.WindowsAuthentication Then
                Dim Request As HttpRequest = HttpContext.Current.Request
                Dim Response As HttpResponse = HttpContext.Current.Response

                Dim blnWinLogon As Boolean = (Request.RawUrl.ToLower.IndexOf((AUTHENTICATION_LOGON_PAGE).ToLower) > -1)
                Dim blnWinLogoff As Boolean = (AuthenticationController.GetStatus(_portalSettings.PortalId) = AuthenticationStatus.WinLogon) AndAlso (Request.RawUrl.ToLower.IndexOf((AUTHENTICATION_LOGOFF_PAGE).ToLower) > -1)

                If (AuthenticationController.GetStatus(_portalSettings.PortalId) = AuthenticationStatus.Undefined) Then  'OrElse (blnWinLogon) Then
                    AuthenticationController.SetStatus(_portalSettings.PortalId, AuthenticationStatus.WinProcess)
                    Dim url As String
                    If Request.ApplicationPath = "/" Then
                        url = "/Admin/Security/WindowsSignin.aspx?tabid=" & _portalSettings.ActiveTab.TabID.ToString
                    Else
                        url = Request.ApplicationPath & "/Admin/Security/WindowsSignin.aspx?tabid=" & _portalSettings.ActiveTab.TabID.ToString
                    End If
                    Response.Redirect(url)
                ElseIf (Not AuthenticationController.GetStatus(_portalSettings.PortalId) = AuthenticationStatus.WinLogoff) AndAlso blnWinLogoff Then
                    Dim objAuthentication As New AuthenticationController
                    objAuthentication.AuthenticationLogoff()
                ElseIf (AuthenticationController.GetStatus(_portalSettings.PortalId) = AuthenticationStatus.WinLogoff) AndAlso blnWinLogon Then ' has been logoff before
                    AuthenticationController.SetStatus(_portalSettings.PortalId, AuthenticationStatus.Undefined)
                    Response.Redirect(Request.RawUrl)
                End If

            End If

        End Sub

        Public Sub Dispose() Implements IHttpModule.Dispose
            ' Should check to see why this routine is never called
            'AuthenticationController.SetStatus(AuthenticationStatus.Undefined)
        End Sub

    End Class

End Namespace
