'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.Xml.Serialization

Namespace DotNetNuke.Services.Log.EventLog

    <XmlRoot("log", IsNullable:=False)> Public Class LogInfo

#Region "Private Members"

        Private _LogGUID As String
        Private _LogFileID As String
        Private _LogTypeKey As String
        Private _LogUserID As Integer
        Private _LogUserName As String
        Private _LogPortalID As Integer
        Private _LogPortalName As String
        Private _LogCreateDate As Date
        Private _LogCreateDateNum As Long
        Private _BypassBuffering As Boolean
        Private _LogServerName As String
        Private _LogProperties As LogProperties
        Private _LogConfigID As String

#End Region

#Region "Constructors"

        Public Sub New()
            _LogGUID = Guid.NewGuid.ToString
            _BypassBuffering = False
            LogProperties = New LogProperties
            _LogPortalID = -1
            _LogPortalName = ""
            _LogUserID = -1
            _LogUserName = ""
        End Sub

#End Region

#Region "Properties"

        <XmlAttributeAttribute("LogGUID")> Public Property LogGUID() As String
            Get
                Return _LogGUID
            End Get
            Set(ByVal Value As String)
                _LogGUID = Value
            End Set
        End Property
        <XmlAttributeAttribute("LogFileID")> Public Property LogFileID() As String
            Get
                Return _LogFileID
            End Get
            Set(ByVal Value As String)
                _LogFileID = Value
            End Set
        End Property
        <XmlAttributeAttribute("LogTypeKey")> Public Property LogTypeKey() As String
            Get
                Return _LogTypeKey
            End Get
            Set(ByVal Value As String)
                _LogTypeKey = Value
            End Set
        End Property
        <XmlAttributeAttribute("LogUserID")> Public Property LogUserID() As Integer
            Get
                Return _LogUserID
            End Get
            Set(ByVal Value As Integer)
                _LogUserID = Value
            End Set
        End Property
        <XmlAttributeAttribute("LogUserName")> Public Property LogUserName() As String
            Get
                Return _LogUserName
            End Get
            Set(ByVal Value As String)
                _LogUserName = Value
            End Set
        End Property
        <XmlAttributeAttribute("LogPortalID")> Public Property LogPortalID() As Integer
            Get
                Return _LogPortalID
            End Get
            Set(ByVal Value As Integer)
                _LogPortalID = Value
            End Set
        End Property
        <XmlAttributeAttribute("LogPortalName")> Public Property LogPortalName() As String
            Get
                Return _LogPortalName
            End Get
            Set(ByVal Value As String)
                _LogPortalName = Value
            End Set
        End Property
        <XmlAttributeAttribute("LogCreateDate")> Public Property LogCreateDate() As Date
            Get
                Return _LogCreateDate
            End Get
            Set(ByVal Value As Date)
                _LogCreateDate = Value
            End Set
        End Property
        <XmlAttributeAttribute("LogCreateDateNum")> Public Property LogCreateDateNum() As Long
            Get
                Return _LogCreateDateNum
            End Get
            Set(ByVal Value As Long)
                _LogCreateDateNum = Value
            End Set
        End Property
        <XmlArray("properties"), XmlArrayItem(ElementName:="property", Type:=GetType(DotNetNuke.Services.Log.EventLog.LogDetailInfo))> Public Property LogProperties() As LogProperties
            Get
                Return _LogProperties
            End Get
            Set(ByVal Value As LogProperties)
                _LogProperties = Value
            End Set
        End Property
        <XmlAttributeAttribute("BypassBuffering")> Public Property BypassBuffering() As Boolean
            Get
                Return _BypassBuffering
            End Get
            Set(ByVal Value As Boolean)
                _BypassBuffering = Value
            End Set
        End Property

        <XmlAttributeAttribute("LogServerName")> Public Property LogServerName() As String
            Get
                Return _LogServerName
            End Get
            Set(ByVal Value As String)
                _LogServerName = Value
            End Set
        End Property

        <XmlAttributeAttribute("LogConfigID")> Public Property LogConfigID() As String
            Get
                Return _LogConfigID
            End Get
            Set(ByVal Value As String)
                _LogConfigID = Value
            End Set
        End Property

#End Region

#Region "Public Methods"

        Public Sub AddProperty(ByVal PropertyName As String, ByVal PropertyValue As String)
            Try
                If PropertyName.Length > 50 Then
                    PropertyName = Left(PropertyName, 50)
                End If
                If PropertyValue.Length > 500 Then
                    PropertyValue = "(TRUNCATED TO 500 CHARS): " + Left(PropertyValue, 500)
                End If
                Dim objLogDetailInfo As New LogDetailInfo
                objLogDetailInfo.PropertyName = PropertyName
                objLogDetailInfo.PropertyValue = PropertyValue
                _LogProperties.Add(objLogDetailInfo)
            Catch exc As Exception
                ProcessPageLoadException(exc)
            End Try
        End Sub

        Public Shared Function IsSystemType(ByVal PropName As String) As Boolean
            Select Case PropName
                Case "LogGUID", "LogFileID", "LogTypeKey", "LogCreateDate", "LogCreateDateNum", "LogPortalID", "LogPortalName", "LogUserID", "LogUserName", "BypassBuffering", "LogServerName"
                    Return True
            End Select

            Return False
        End Function

        Public Overrides Function ToString() As String
            Dim str As New System.Text.StringBuilder
            str.Append("<b>LogGUID:</b> " + LogGUID + "<br>")
            str.Append("<b>LogType:</b> " + LogTypeKey + "<br>")
            str.Append("<b>UserID:</b> " + LogUserID.ToString + "<br>")
            str.Append("<b>Username:</b> " + LogUserName + "<br>")
            str.Append("<b>PortalID:</b> " + LogPortalID.ToString + "<br>")
            str.Append("<b>PortalName:</b> " + LogPortalName + "<br>")
            str.Append("<b>CreateDate:</b> " + LogCreateDate.ToString + "<br>")
            str.Append("<b>ServerName:</b> " + LogServerName + "<br>")
            str.Append(LogProperties.ToString)
            Return str.ToString
        End Function

#End Region

    End Class

End Namespace




