'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System
Imports System.Collections
Imports System.Reflection
Imports System.Web.Caching
Imports DotNetNuke.Services.Exceptions

Namespace DotNetNuke.Services.Scheduling.DNNScheduling
	Public MustInherit Class DataProvider

		' provider constants - eliminates need for Reflection later
        Private Const ProviderType As String = "data"    ' maps to <sectionGroup> in web.config
		Private Const ProviderNamespace As String = "DotNetNuke.Services.Scheduling.DNNScheduling"		  ' project namespace
        Private Const ProviderAssemblyName As String = "DotNetNuke.DNNScheduler"    ' project assemblyname

        Public Shared Shadows Function Instance() As DataProvider

            Dim strCacheKey As String = ProviderNamespace & "." & ProviderType & "provider"

            ' Use the cache because the reflection used later is expensive
            Dim objConstructor As ConstructorInfo = CType(Common.Utilities.DataCache.GetCache(strCacheKey), ConstructorInfo)

            If objConstructor Is Nothing Then
                ' Get the provider configuration based on the type
                Dim objProviderConfiguration As Framework.Providers.ProviderConfiguration = Framework.Providers.ProviderConfiguration.GetProviderConfiguration(ProviderType)

                ' The assembly should be in \bin or GAC, so we simply need to get an instance of the type
                Try

                    ' Override the typename if a ProviderName is specified ( this allows the application to load a different DataProvider assembly for custom modules )
                    Dim strTypeName As String = ProviderNamespace & "." & objProviderConfiguration.DefaultProvider & ", " & ProviderAssemblyName & "." & objProviderConfiguration.DefaultProvider


                    ' Use reflection to store the constructor of the class that implements DataProvider
                    Dim t As Type = Type.GetType(strTypeName, True)
                    objConstructor = t.GetConstructor(System.Type.EmptyTypes)

                    ' Insert the type into the cache
                    Common.Utilities.DataCache.SetCache(strCacheKey, objConstructor)

                Catch e As Exception
                    ' Could not load the provider - this is likely due to binary compatibility issues 
                    ProcessSchedulerException(e)
                End Try
            End If

            Return CType(objConstructor.Invoke(Nothing), DataProvider)

        End Function

        ' all core methods defined below

        Public MustOverride Function GetSchedule() As IDataReader
        Public MustOverride Function GetSchedule(ByVal ScheduleID As Integer) As IDataReader
        Public MustOverride Function GetSchedule(ByVal EventName As String) As IDataReader
        Public MustOverride Function GetScheduleHistory(ByVal ScheduleID As Integer) As IDataReader

        Public MustOverride Function AddSchedule(ByVal TypeFullName As String, ByVal TimeLapse As Integer, ByVal TimeLapseMeasurement As String, ByVal RetryTimeLapse As Integer, ByVal RetryTimeLapseMeasurement As String, ByVal RetainHistoryNum As Integer, ByVal AttachToEvent As String, ByVal CatchUpEnabled As Boolean, ByVal Enabled As Boolean, ByVal ObjectDependencies As String) As Integer
        Public MustOverride Sub UpdateSchedule(ByVal ScheduleID As Integer, ByVal TypeFullName As String, ByVal TimeLapse As Integer, ByVal TimeLapseMeasurement As String, ByVal RetryTimeLapse As Integer, ByVal RetryTimeLapseMeasurement As String, ByVal RetainHistoryNum As Integer, ByVal AttachToEvent As String, ByVal CatchUpEnabled As Boolean, ByVal Enabled As Boolean, ByVal ObjectDependencies As String)
        Public MustOverride Sub DeleteSchedule(ByVal ScheduleID As Integer)
        Public MustOverride Function GetScheduleItemSettings(ByVal ScheduleID As Integer) As IDataReader
        Public MustOverride Function AddScheduleHistory(ByVal ScheduleID As Integer, ByVal StartDate As Date) As Integer
        Public MustOverride Sub UpdateScheduleHistory(ByVal ScheduleHistoryID As Integer, ByVal EndDate As Date, ByVal Succeeded As Boolean, ByVal LogNotes As String, ByVal NextStart As Date)
        Public MustOverride Sub PurgeScheduleHistory()

    End Class

End Namespace