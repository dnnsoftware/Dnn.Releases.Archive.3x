

CREATE TABLE {databaseOwner}[aspnet_SchemaVersions] (
	[Feature] [nvarchar] (128)  NOT NULL ,
	[CompatibleSchemaVersion] [nvarchar] (128)  NOT NULL ,
	[IsCurrentVersion] [bit] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE {databaseOwner}[aspnet_Applications] (
	[ApplicationName] [nvarchar] (256)  NOT NULL ,
	[LoweredApplicationName] [nvarchar] (256)  NOT NULL ,
	[ApplicationId] [uniqueidentifier] NOT NULL ,
	[Description] [nvarchar] (256)  NULL 
) ON [PRIMARY]
GO

CREATE TABLE {databaseOwner}[aspnet_Membership] (
	[UserId] [uniqueidentifier] NOT NULL ,
	[Password] [nvarchar] (128)  NOT NULL ,
	[PasswordFormat] [int] NOT NULL ,
	[PasswordSalt] [nvarchar] (128)  NOT NULL ,
	[MobilePIN] [nvarchar] (16)  NULL ,
	[Email] [nvarchar] (128)  NULL ,
	[LoweredEmail] [nvarchar] (128)  NULL ,
	[PasswordQuestion] [nvarchar] (256)  NULL ,
	[PasswordAnswer] [nvarchar] (128)  NULL ,
	[IsApproved] [bit] NOT NULL ,
	[IsLockedOut] [bit] NOT NULL ,
	[CreateDate] [datetime] NOT NULL ,
	[LastLoginDate] [datetime] NOT NULL ,
	[LastPasswordChangedDate] [datetime] NOT NULL ,
	[LastLockoutDate] [datetime] NOT NULL ,
	[FailedPasswordAttemptCount] [int] NOT NULL ,
	[FailedPasswordAttemptWindowStart] [datetime] NOT NULL ,
	[FailedPasswordAnswerAttemptCount] [int] NOT NULL ,
	[FailedPasswordAnswerAttemptWindowStart] [datetime] NOT NULL ,
	[Comment] [ntext]  NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE {databaseOwner}[aspnet_Profile] (
	[UserId] [uniqueidentifier] NOT NULL ,
	[PropertyNames] [ntext]  NOT NULL ,
	[PropertyValuesString] [ntext]  NOT NULL ,
	[PropertyValuesBinary] [image] NOT NULL ,
	[LastUpdatedDate] [datetime] NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

CREATE TABLE {databaseOwner}[aspnet_Roles] (
	[ApplicationId] [uniqueidentifier] NOT NULL ,
	[RoleId] [uniqueidentifier] NOT NULL ,
	[RoleName] [nvarchar] (256)  NOT NULL ,
	[LoweredRoleName] [nvarchar] (256)  NOT NULL ,
	[Description] [nvarchar] (256)  NULL 
) ON [PRIMARY]
GO

CREATE TABLE {databaseOwner}[aspnet_Users] (
	[ApplicationId] [uniqueidentifier] NOT NULL ,
	[UserId] [uniqueidentifier] NOT NULL ,
	[UserName] [nvarchar] (256)  NOT NULL ,
	[LoweredUserName] [nvarchar] (256)  NOT NULL ,
	[MobileAlias] [nvarchar] (16)  NULL ,
	[IsAnonymous] [bit] NOT NULL ,
	[LastActivityDate] [datetime] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE {databaseOwner}[aspnet_UsersInRoles] (
	[UserId] [uniqueidentifier] NOT NULL ,
	[RoleId] [uniqueidentifier] NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE {databaseOwner}[aspnet_SchemaVersions] WITH NOCHECK ADD 
	 PRIMARY KEY  CLUSTERED 
	(
		[Feature],
		[CompatibleSchemaVersion]
	)  ON [PRIMARY] 
GO

ALTER TABLE {databaseOwner}[aspnet_Profile] WITH NOCHECK ADD 
	 PRIMARY KEY  CLUSTERED 
	(
		[UserId]
	)  ON [PRIMARY] 
GO

 CREATE  CLUSTERED  INDEX [aspnet_Applications_Index] ON {databaseOwner}[aspnet_Applications]([LoweredApplicationName]) ON [PRIMARY]
GO

 CREATE  CLUSTERED  INDEX [aspnet_Membership_index] ON {databaseOwner}[aspnet_Membership]([LoweredEmail]) ON [PRIMARY]
GO

 CREATE  CLUSTERED  INDEX [aspnet_Roles_index1] ON {databaseOwner}[aspnet_Roles]([ApplicationId], [RoleName]) ON [PRIMARY]
GO

 CREATE  UNIQUE  CLUSTERED  INDEX [aspnet_Users_Index] ON {databaseOwner}[aspnet_Users]([LoweredUserName], [ApplicationId]) ON [PRIMARY]
GO

 CREATE  CLUSTERED  INDEX [aspnet_UsersInRoles_index1] ON {databaseOwner}[aspnet_UsersInRoles]([UserId]) ON [PRIMARY]
GO

ALTER TABLE {databaseOwner}[aspnet_Applications] ADD 
	CONSTRAINT [DF__aspnet_Ap__Appli__7B905C75] DEFAULT (newid()) FOR [ApplicationId],
	 PRIMARY KEY  NONCLUSTERED 
	(
		[ApplicationId]
	)  ON [PRIMARY] ,
	 UNIQUE  NONCLUSTERED 
	(
		[LoweredApplicationName]
	)  ON [PRIMARY] ,
	 UNIQUE  NONCLUSTERED 
	(
		[ApplicationName]
	)  ON [PRIMARY] 
GO

ALTER TABLE {databaseOwner}[aspnet_Membership] ADD 
	CONSTRAINT [DF__aspnet_Me__Passw__2C3393D0] DEFAULT (0) FOR [PasswordFormat],
	 PRIMARY KEY  NONCLUSTERED 
	(
		[UserId]
	)  ON [PRIMARY] 
GO

ALTER TABLE {databaseOwner}[aspnet_Profile] ADD 
	CONSTRAINT [DF__aspnet_Pr__LastU__21B6055D] DEFAULT (getdate()) FOR [LastUpdatedDate]
GO

ALTER TABLE {databaseOwner}[aspnet_Roles] ADD 
	CONSTRAINT [DF__aspnet_Ro__RoleI__0EA330E9] DEFAULT (newid()) FOR [RoleId],
	 PRIMARY KEY  NONCLUSTERED 
	(
		[RoleId]
	)  ON [PRIMARY] 
GO

ALTER TABLE {databaseOwner}[aspnet_Users] ADD 
	CONSTRAINT [DF__aspnet_Us__UserI__7F60ED59] DEFAULT (newid()) FOR [UserId],
	CONSTRAINT [DF__aspnet_Us__Mobil__00551192] DEFAULT (null) FOR [MobileAlias],
	CONSTRAINT [DF__aspnet_Us__IsAno__014935CB] DEFAULT (0) FOR [IsAnonymous],
	 PRIMARY KEY  NONCLUSTERED 
	(
		[UserId]
	)  ON [PRIMARY] 
GO

ALTER TABLE {databaseOwner}[aspnet_UsersInRoles] ADD 
	 PRIMARY KEY  NONCLUSTERED 
	(
		[UserId],
		[RoleId]
	)  ON [PRIMARY] 
GO

 CREATE  INDEX [aspnet_UsersInRoles_index2] ON {databaseOwner}[aspnet_UsersInRoles]([RoleId]) ON [PRIMARY]
GO

ALTER TABLE {databaseOwner}[aspnet_Membership] ADD 
	 FOREIGN KEY 
	(
		[UserId]
	) REFERENCES {databaseOwner}[aspnet_Users] (
		[UserId]
	)
GO

ALTER TABLE {databaseOwner}[aspnet_Profile] ADD 
	 FOREIGN KEY 
	(
		[UserId]
	) REFERENCES {databaseOwner}[aspnet_Users] (
		[UserId]
	)
GO

ALTER TABLE {databaseOwner}[aspnet_Roles] ADD 
	 FOREIGN KEY 
	(
		[ApplicationId]
	) REFERENCES {databaseOwner}[aspnet_Applications] (
		[ApplicationId]
	)
GO

ALTER TABLE {databaseOwner}[aspnet_Users] ADD 
	 FOREIGN KEY 
	(
		[ApplicationId]
	) REFERENCES {databaseOwner}[aspnet_Applications] (
		[ApplicationId]
	)
GO

ALTER TABLE {databaseOwner}[aspnet_UsersInRoles] ADD 
	 FOREIGN KEY 
	(
		[RoleId]
	) REFERENCES {databaseOwner}[aspnet_Roles] (
		[RoleId]
	),
	 FOREIGN KEY 
	(
		[UserId]
	) REFERENCES {databaseOwner}[aspnet_Users] (
		[UserId]
	)
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


  CREATE VIEW {databaseOwner}[vw_aspnet_Applications]
  AS SELECT {databaseOwner}[aspnet_Applications].[ApplicationName], {databaseOwner}[aspnet_Applications].[ApplicationId], {databaseOwner}[aspnet_Applications].[Description]
  FROM {databaseOwner}[aspnet_Applications]
  
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


  CREATE VIEW {databaseOwner}[vw_aspnet_SchemaVersions]
  AS SELECT {databaseOwner}[aspnet_SchemaVersions].[Feature], {databaseOwner}[aspnet_SchemaVersions].[CompatibleSchemaVersion], {databaseOwner}[aspnet_SchemaVersions].[IsCurrentVersion]
  FROM {databaseOwner}[aspnet_SchemaVersions]
  
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


  CREATE VIEW {databaseOwner}[vw_aspnet_Roles]
  AS SELECT {databaseOwner}[aspnet_Roles].[ApplicationId], {databaseOwner}[aspnet_Roles].[RoleId], {databaseOwner}[aspnet_Roles].[RoleName], {databaseOwner}[aspnet_Roles].[Description]
  FROM {databaseOwner}[aspnet_Roles]
  
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


  CREATE VIEW {databaseOwner}[vw_aspnet_Users]
  AS SELECT {databaseOwner}[aspnet_Users].[ApplicationId], {databaseOwner}[aspnet_Users].[UserId], {databaseOwner}[aspnet_Users].[UserName], {databaseOwner}[aspnet_Users].[MobileAlias], {databaseOwner}[aspnet_Users].[IsAnonymous], {databaseOwner}[aspnet_Users].[LastActivityDate]
  FROM {databaseOwner}[aspnet_Users]
  
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


  CREATE VIEW {databaseOwner}[vw_aspnet_MembershipUsers]
  AS SELECT {databaseOwner}[aspnet_Membership].[UserId],
            {databaseOwner}[aspnet_Membership].[PasswordFormat],
            {databaseOwner}[aspnet_Membership].[MobilePIN],
            {databaseOwner}[aspnet_Membership].[Email],
            {databaseOwner}[aspnet_Membership].[PasswordQuestion],
            {databaseOwner}[aspnet_Membership].[PasswordAnswer],
            {databaseOwner}[aspnet_Membership].[IsApproved],
            {databaseOwner}[aspnet_Membership].[IsLockedOut],
            {databaseOwner}[aspnet_Membership].[CreateDate],
            {databaseOwner}[aspnet_Membership].[LastLoginDate],
            {databaseOwner}[aspnet_Membership].[LastPasswordChangedDate],
            {databaseOwner}[aspnet_Membership].[LastLockoutDate],
            {databaseOwner}[aspnet_Membership].[FailedPasswordAttemptCount],
            {databaseOwner}[aspnet_Membership].[FailedPasswordAttemptWindowStart],
            {databaseOwner}[aspnet_Membership].[FailedPasswordAnswerAttemptCount],
            {databaseOwner}[aspnet_Membership].[FailedPasswordAnswerAttemptWindowStart],
            {databaseOwner}[aspnet_Membership].[Comment],
            {databaseOwner}[aspnet_Users].[ApplicationId],
            {databaseOwner}[aspnet_Users].[UserName],
            {databaseOwner}[aspnet_Users].[MobileAlias],
            {databaseOwner}[aspnet_Users].[IsAnonymous],
            {databaseOwner}[aspnet_Users].[LastActivityDate]
  FROM {databaseOwner}[aspnet_Membership] INNER JOIN {databaseOwner}[aspnet_Users]
      ON {databaseOwner}[aspnet_Membership].[UserId] = {databaseOwner}[aspnet_Users].[UserId]
  
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


  CREATE VIEW {databaseOwner}[vw_aspnet_Profiles]
  AS SELECT {databaseOwner}[aspnet_Profile].[UserId], {databaseOwner}[aspnet_Profile].[LastUpdatedDate],
      [DataSize]=  DATALENGTH({databaseOwner}[aspnet_Profile].[PropertyNames])
                 + DATALENGTH({databaseOwner}[aspnet_Profile].[PropertyValuesString])
                 + DATALENGTH({databaseOwner}[aspnet_Profile].[PropertyValuesBinary])
  FROM {databaseOwner}[aspnet_Profile]
  
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


  CREATE VIEW {databaseOwner}[vw_aspnet_UsersInRoles]
  AS SELECT {databaseOwner}[aspnet_UsersInRoles].[UserId], {databaseOwner}[aspnet_UsersInRoles].[RoleId]
  FROM {databaseOwner}[aspnet_UsersInRoles]
  
GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_Applications_CreateApplication
    @ApplicationName      NVARCHAR(256),
    @ApplicationId        UNIQUEIDENTIFIER OUTPUT
AS
BEGIN
    SELECT  @ApplicationId = NEWID()
    INSERT  {databaseOwner}aspnet_Applications (ApplicationId, ApplicationName, LoweredApplicationName)
    VALUES  (@ApplicationId, @ApplicationName, LOWER(@ApplicationName))
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_CheckSchemaVersion
    @Feature                   NVARCHAR(128),
    @CompatibleSchemaVersion   NVARCHAR(128)
AS
BEGIN
    SELECT * FROM {databaseOwner}aspnet_SchemaVersions
    WHERE Feature = LOWER( @Feature ) AND CompatibleSchemaVersion = @CompatibleSchemaVersion

    IF( @@rowcount = 0 )
        RETURN 1

    RETURN 0
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE {databaseOwner}aspnet_Membership_ChangePasswordQuestionAndAnswer
    @ApplicationName       NVARCHAR(256),
    @UserName              NVARCHAR(256),
    @NewPasswordQuestion   NVARCHAR(256),
    @NewPasswordAnswer     NVARCHAR(128)
AS
BEGIN
    DECLARE @UserId UNIQUEIDENTIFIER
    SELECT  @UserId = NULL
    SELECT  @UserId = u.UserId
    FROM    {databaseOwner}aspnet_Membership m, {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_Applications a
    WHERE   LoweredUserName = LOWER(@UserName) AND
            u.ApplicationId = a.ApplicationId  AND
            LOWER(@ApplicationName) = a.LoweredApplicationName AND
            u.UserId = m.UserId
    IF (@UserId IS NULL)
    BEGIN
        RETURN(1)
    END

    UPDATE {databaseOwner}aspnet_Membership
    SET    PasswordQuestion = @NewPasswordQuestion, PasswordAnswer = @NewPasswordAnswer
    WHERE  UserId=@UserId
    RETURN(0)
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE {databaseOwner}aspnet_Membership_CreateUser
    @ApplicationName                        NVARCHAR(256),
    @UserName                               NVARCHAR(256),
    @Password                               NVARCHAR(128),
    @PasswordSalt                           NVARCHAR(128),
    @Email                                  NVARCHAR(128),
    @PasswordQuestion                       NVARCHAR(256),
    @PasswordAnswer                         NVARCHAR(128),
    @IsApproved                             BIT,
    @TimeZoneAdjustment                     INT,
    @CreateDate                             DATETIME = NULL,
    @UniqueEmail                            INT      = 0,
    @PasswordFormat                         INT      = 0,
    @UserId                                 UNIQUEIDENTIFIER OUTPUT
AS
BEGIN
    DECLARE @ApplicationId UNIQUEIDENTIFIER
    SELECT  @ApplicationId = NULL

    DECLARE @NewUserId UNIQUEIDENTIFIER
    SELECT @NewUserId = NULL

    DECLARE @IsLockedOut BIT
    SET @IsLockedOut = 0

    DECLARE @LastLockoutDate  DATETIME
    SET @LastLockoutDate = CAST( '1/1/1753' AS DATETIME )

    DECLARE @FailedPasswordAttemptCount INT
    SET @FailedPasswordAttemptCount = 0

    DECLARE @FailedPasswordAttemptWindowStart  DATETIME
    SET @FailedPasswordAttemptWindowStart = CAST( '1/1/1753' AS DATETIME )

    DECLARE @FailedPasswordAnswerAttemptCount INT
    SET @FailedPasswordAnswerAttemptCount = 0

    DECLARE @FailedPasswordAnswerAttemptWindowStart  DATETIME
    SET @FailedPasswordAnswerAttemptWindowStart = CAST( '1/1/1753' AS DATETIME )

    DECLARE @ReturnValue   INT
    SET @ReturnValue = 0

    DECLARE @ErrorCode     INT
    SET @ErrorCode = 0

    DECLARE @TranStarted   BIT
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
	    BEGIN TRANSACTION
	    SET @TranStarted = 1
    END
    ELSE
    	SET @TranStarted = 0

    SELECT  @ApplicationId = ApplicationId FROM {databaseOwner}aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        EXEC {databaseOwner}aspnet_Applications_CreateApplication @ApplicationName, @ApplicationId OUTPUT

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    IF (@CreateDate IS NULL)
    BEGIN
        SELECT  @CreateDate = GETDATE()
    END
    SELECT  @CreateDate = DATEADD(n, -@TimeZoneAdjustment, @CreateDate) -- switch to UTC time

    SELECT  @NewUserId = UserId FROM {databaseOwner}aspnet_Users WHERE LOWER(@UserName) = LoweredUserName AND @ApplicationId = ApplicationId
    IF ( @NewUserId IS NULL )
    BEGIN
        SET @NewUserId = @UserId
        EXEC @ReturnValue = {databaseOwner}aspnet_Users_CreateUser @ApplicationId, @UserName, 0, @CreateDate, @NewUserId OUTPUT
    END
    ELSE
    BEGIN
        IF( @NewUserId <> @UserId AND @UserId IS NOT NULL )
        BEGIN
            SET @ErrorCode = 6
            GOTO Cleanup
        END
    END

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    IF( @ReturnValue = -1 )
    BEGIN
        SET @ErrorCode = 10
        GOTO Cleanup
    END

    IF ( EXISTS ( SELECT UserId
                  FROM   {databaseOwner}aspnet_Membership
                  WHERE  @NewUserId = UserId ) )
    BEGIN
        SET @ErrorCode = 6
        GOTO Cleanup
    END

    SET @UserId = @NewUserId

    IF (@UniqueEmail = 1)
    BEGIN
        IF (EXISTS (SELECT *
                    FROM  {databaseOwner}aspnet_Membership m WITH ( UPDLOCK, HOLDLOCK ), {databaseOwner}aspnet_Users u
                    WHERE (u.UserId = m.UserId AND u.ApplicationId = @ApplicationId AND m.LoweredEmail = LOWER(@Email))))
        BEGIN
            SET @ErrorCode = 7
            GOTO Cleanup
        END
    END

    INSERT INTO {databaseOwner}aspnet_Membership
                ( UserId,
                  Password,
                  PasswordSalt,
                  Email,
                  LoweredEmail,
                  PasswordQuestion,
                  PasswordAnswer,
                  PasswordFormat,
                  IsApproved,
                  IsLockedOut,
                  CreateDate,
                  LastLoginDate,
                  LastPasswordChangedDate,
                  LastLockoutDate,
                  FailedPasswordAttemptCount,
                  FailedPasswordAttemptWindowStart,
                  FailedPasswordAnswerAttemptCount,
                  FailedPasswordAnswerAttemptWindowStart )
         VALUES ( @UserId,
                  @Password,
                  @PasswordSalt,
                  @Email,
                  LOWER(@Email),
                  @PasswordQuestion,
                  @PasswordAnswer,
                  @PasswordFormat,
                  @IsApproved,
                  @IsLockedOut,
                  @CreateDate,
                  @CreateDate,
                  @CreateDate,
                  @LastLockoutDate,
                  @FailedPasswordAttemptCount,
                  @FailedPasswordAttemptWindowStart,
                  @FailedPasswordAnswerAttemptCount,
                  @FailedPasswordAnswerAttemptWindowStart )

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    UPDATE {databaseOwner}aspnet_Users
    SET    LastActivityDate = @CreateDate
    WHERE  @UserId = UserId

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    SELECT @CreateDate

    IF( @TranStarted = 1 )
    BEGIN
	SET @TranStarted = 0
	COMMIT TRANSACTION
    END

    RETURN 0

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

    RETURN @ErrorCode

END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE {databaseOwner}aspnet_Membership_FindUsersByEmail
    @ApplicationName       NVARCHAR(256),
    @EmailToMatch          NVARCHAR(256),
    @PageIndex             INT,
    @PageSize              INT,
    @TimeZoneAdjustment    INT
AS
BEGIN
    DECLARE @ApplicationId UNIQUEIDENTIFIER
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM {databaseOwner}aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN 0

    -- Set the page bounds
    DECLARE @PageLowerBound INT
    DECLARE @PageUpperBound INT
    DECLARE @TotalRecords   INT
    SET @PageLowerBound = @PageSize * @PageIndex
    SET @PageUpperBound = @PageSize - 1 + @PageLowerBound

    -- Create a temp table to store the select results
    CREATE TABLE #PageIndexForUsers
    (
        IndexId int IDENTITY (0, 1) NOT NULL,
        UserId UNIQUEIDENTIFIER
    )

    -- Insert into our temp table
    IF( @EmailToMatch IS NULL )
        INSERT INTO #PageIndexForUsers (UserId)
            SELECT u.UserId
            FROM   {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_Membership m
            WHERE  u.ApplicationId = @ApplicationId AND m.UserId = u.UserId AND m.Email IS NULL
            ORDER BY u.UserName
    ELSE
        INSERT INTO #PageIndexForUsers (UserId)
            SELECT u.UserId
            FROM   {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_Membership m
            WHERE  u.ApplicationId = @ApplicationId AND m.UserId = u.UserId AND m.LoweredEmail LIKE LOWER(@EmailToMatch)
            ORDER BY u.UserName

    SELECT  u.UserName, m.Email, m.PasswordQuestion, m.Comment, m.IsApproved,
            DATEADD(n, @TimeZoneAdjustment, m.CreateDate),
            DATEADD(n, @TimeZoneAdjustment, m.LastLoginDate),
            DATEADD(n, @TimeZoneAdjustment, u.LastActivityDate),
            DATEADD(n, @TimeZoneAdjustment, m.LastPasswordChangedDate),
            u.UserId, m.IsLockedOut,
            DATEADD(n, @TimeZoneAdjustment, m.LastLockoutDate)
    FROM   {databaseOwner}aspnet_Membership m, {databaseOwner}aspnet_Users u, #PageIndexForUsers p
    WHERE  u.UserId = p.UserId AND u.UserId = m.UserId AND
           p.IndexId >= @PageLowerBound AND p.IndexId <= @PageUpperBound
    ORDER BY u.UserName

    SELECT  @TotalRecords = COUNT(*)
    FROM    #PageIndexForUsers
    RETURN @TotalRecords
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE {databaseOwner}aspnet_Membership_FindUsersByName
    @ApplicationName       NVARCHAR(256),
    @UserNameToMatch       NVARCHAR(256),
    @PageIndex             INT,
    @PageSize              INT,
    @TimeZoneAdjustment    INT
AS
BEGIN
    DECLARE @ApplicationId UNIQUEIDENTIFIER
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM {databaseOwner}aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN 0

    -- Set the page bounds
    DECLARE @PageLowerBound INT
    DECLARE @PageUpperBound INT
    DECLARE @TotalRecords   INT
    SET @PageLowerBound = @PageSize * @PageIndex
    SET @PageUpperBound = @PageSize - 1 + @PageLowerBound

    -- Create a temp table to store the select results
    CREATE TABLE #PageIndexForUsers
    (
        IndexId int IDENTITY (0, 1) NOT NULL,
        UserId UNIQUEIDENTIFIER
    )

    -- Insert into our temp table
    INSERT INTO #PageIndexForUsers (UserId)
        SELECT u.UserId
        FROM   {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_Membership m
        WHERE  u.ApplicationId = @ApplicationId AND m.UserId = u.UserId AND u.LoweredUserName LIKE LOWER(@UserNameToMatch)
        ORDER BY u.UserName


    SELECT  u.UserName, m.Email, m.PasswordQuestion, m.Comment, m.IsApproved,
            DATEADD(n, @TimeZoneAdjustment, m.CreateDate),
            DATEADD(n, @TimeZoneAdjustment, m.LastLoginDate),
            DATEADD(n, @TimeZoneAdjustment, u.LastActivityDate),
            DATEADD(n, @TimeZoneAdjustment, m.LastPasswordChangedDate),
            u.UserId, m.IsLockedOut,
            DATEADD(n, @TimeZoneAdjustment, m.LastLockoutDate)
    FROM   {databaseOwner}aspnet_Membership m, {databaseOwner}aspnet_Users u, #PageIndexForUsers p
    WHERE  u.UserId = p.UserId AND u.UserId = m.UserId AND
           p.IndexId >= @PageLowerBound AND p.IndexId <= @PageUpperBound
    ORDER BY u.UserName

    SELECT  @TotalRecords = COUNT(*)
    FROM    #PageIndexForUsers
    RETURN @TotalRecords
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE {databaseOwner}aspnet_Membership_GetAllUsers
    @ApplicationName       NVARCHAR(256),
    @PageIndex             INT,
    @PageSize              INT,
    @TimeZoneAdjustment    INT
AS
BEGIN
    DECLARE @ApplicationId UNIQUEIDENTIFIER
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM {databaseOwner}aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN 0


    -- Set the page bounds
    DECLARE @PageLowerBound INT
    DECLARE @PageUpperBound INT
    DECLARE @TotalRecords   INT
    SET @PageLowerBound = @PageSize * @PageIndex
    SET @PageUpperBound = @PageSize - 1 + @PageLowerBound

    -- Create a temp table to store the select results
    CREATE TABLE #PageIndexForUsers
    (
        IndexId int IDENTITY (0, 1) NOT NULL,
        UserId UNIQUEIDENTIFIER
    )

    -- Insert into our temp table
    INSERT INTO #PageIndexForUsers (UserId)
    SELECT u.UserId
    FROM   {databaseOwner}aspnet_Membership m, {databaseOwner}aspnet_Users u
    WHERE  u.ApplicationId = @ApplicationId AND u.UserId = m.UserId
    ORDER BY u.UserName

    SELECT @TotalRecords = @@ROWCOUNT

    SELECT u.UserName, m.Email, m.PasswordQuestion, m.Comment, m.IsApproved,
            DATEADD(n, @TimeZoneAdjustment, m.CreateDate),
            DATEADD(n, @TimeZoneAdjustment, m.LastLoginDate),
            DATEADD(n, @TimeZoneAdjustment, u.LastActivityDate),
            DATEADD(n, @TimeZoneAdjustment, m.LastPasswordChangedDate),
            u.UserId, m.IsLockedOut,
            DATEADD(n, @TimeZoneAdjustment, m.LastLockoutDate)
    FROM   {databaseOwner}aspnet_Membership m, {databaseOwner}aspnet_Users u, #PageIndexForUsers p
    WHERE  u.UserId = p.UserId AND u.UserId = m.UserId AND
           p.IndexId >= @PageLowerBound AND p.IndexId <= @PageUpperBound
    ORDER BY u.UserName
    RETURN @TotalRecords
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE {databaseOwner}aspnet_Membership_GetNumberOfUsersOnline
    @ApplicationName            NVARCHAR(256),
    @MinutesSinceLastInActive   INT,
    @TimeZoneAdjustment         INT
AS
BEGIN
    DECLARE @DateActive DATETIME
    SELECT  @DateActive = DATEADD(minute,  -(@MinutesSinceLastInActive + @TimeZoneAdjustment), GETDATE())

    DECLARE @NumOnline INT
    SELECT  @NumOnline = COUNT(*)
    FROM    {databaseOwner}aspnet_Users u(NOLOCK),
            {databaseOwner}aspnet_Applications a(NOLOCK),
            {databaseOwner}aspnet_Membership m(NOLOCK)
    WHERE   u.ApplicationId = a.ApplicationId                  AND
            LastActivityDate > @DateActive                     AND
            a.LoweredApplicationName = LOWER(@ApplicationName) AND
            u.UserId = m.UserId
    RETURN(@NumOnline)
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE {databaseOwner}aspnet_Membership_GetPassword
    @ApplicationName                NVARCHAR(256),
    @UserName                       NVARCHAR(256),
    @PasswordAttemptThreshold       INT,
    @PasswordAttemptWindow          INT,
    @TimeZoneAdjustment             INT,
    @PasswordAnswer                 NVARCHAR(128) = NULL
AS
BEGIN
    DECLARE @UserId                                 UNIQUEIDENTIFIER
    DECLARE @PasswordFormat                         INT
    DECLARE @Password                               NVARCHAR(128)
    DECLARE @passAns                                NVARCHAR(128)
    DECLARE @IsLockedOut                            BIT
    DECLARE @LastLockoutDate                        DATETIME
    DECLARE @FailedPasswordAttemptCount             INT
    DECLARE @FailedPasswordAttemptWindowStart       DATETIME
    DECLARE @FailedPasswordAnswerAttemptCount       INT
    DECLARE @FailedPasswordAnswerAttemptWindowStart DATETIME

    DECLARE @ErrorCode     INT
    SET @ErrorCode = 0

    DECLARE @TranStarted   BIT
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
	    BEGIN TRANSACTION
	    SET @TranStarted = 1
    END
    ELSE
    	SET @TranStarted = 0

    SELECT  @UserId = u.UserId,
            @Password = m.Password,
            @passAns = m.PasswordAnswer,
            @PasswordFormat = m.PasswordFormat,
            @IsLockedOut = m.IsLockedOut,
            @LastLockoutDate = m.LastLockoutDate,
            @FailedPasswordAttemptCount = m.FailedPasswordAttemptCount,
            @FailedPasswordAttemptWindowStart = m.FailedPasswordAttemptWindowStart,
            @FailedPasswordAnswerAttemptCount = m.FailedPasswordAnswerAttemptCount,
            @FailedPasswordAnswerAttemptWindowStart = m.FailedPasswordAnswerAttemptWindowStart
    FROM    {databaseOwner}aspnet_Applications a, {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_Membership m WITH ( ROWLOCK, XLOCK )
    WHERE   @ApplicationName = a.ApplicationName AND
            u.ApplicationId = a.ApplicationId    AND
            u.UserId = m.UserId AND
            LOWER(@UserName) = u.LoweredUserName

    IF ( @@rowcount = 0 )
    BEGIN
        SET @ErrorCode = 1
        GOTO Cleanup
    END

    IF( @IsLockedOut = 1 )
    BEGIN
        SET @ErrorCode = 99
        GOTO Cleanup
    END

    IF ( NOT( @PasswordAnswer IS NULL ) )
    BEGIN
        IF( ( @passAns IS NULL ) OR ( LOWER( @passAns ) <> LOWER( @PasswordAnswer ) ) )
        BEGIN
            IF( DATEADD(n, -@TimeZoneAdjustment, GETDATE()) > DATEADD( minute, @PasswordAttemptWindow, @FailedPasswordAnswerAttemptWindowStart ) )
            BEGIN
                SET @FailedPasswordAnswerAttemptCount = 1
                SET @FailedPasswordAnswerAttemptWindowStart = DATEADD(n, -@TimeZoneAdjustment, GETDATE())
            END
            ELSE
            BEGIN
                SET @FailedPasswordAnswerAttemptCount = @FailedPasswordAnswerAttemptCount + 1
                IF( @FailedPasswordAnswerAttemptCount >= @PasswordAttemptThreshold )
                BEGIN
                    SET @IsLockedOut = 1
                    SET @LastLockoutDate = DATEADD(n, -@TimeZoneAdjustment, GETDATE())
                END
            END

            SET @ErrorCode = 3
        END
        ELSE
        BEGIN
            IF( @FailedPasswordAnswerAttemptCount > 0 )
            BEGIN
                SET @FailedPasswordAnswerAttemptCount = 0
                SET @FailedPasswordAnswerAttemptWindowStart = CAST( '1/1/1753' AS DATETIME )
            END
        END

        UPDATE {databaseOwner}aspnet_Membership
        SET IsLockedOut = @IsLockedOut, LastLockoutDate = @LastLockoutDate,
            FailedPasswordAttemptCount = @FailedPasswordAttemptCount,
            FailedPasswordAttemptWindowStart = @FailedPasswordAttemptWindowStart,
            FailedPasswordAnswerAttemptCount = @FailedPasswordAnswerAttemptCount,
            FailedPasswordAnswerAttemptWindowStart = @FailedPasswordAnswerAttemptWindowStart
        WHERE @UserId = UserId

        IF( @@ERROR <> 0 )
        BEGIN
            SET @ErrorCode = -1
            GOTO Cleanup
        END
    END

    IF( @TranStarted = 1 )
    BEGIN
	SET @TranStarted = 0
	COMMIT TRANSACTION
    END

    IF( @ErrorCode = 0 )
        SELECT @Password, @PasswordFormat

    RETURN @ErrorCode

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

    RETURN @ErrorCode

END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE {databaseOwner}aspnet_Membership_GetPasswordWithFormat
    @ApplicationName                NVARCHAR(256),
    @UserName                       NVARCHAR(256)
AS
BEGIN
    DECLARE @Password                               NVARCHAR(128)
    DECLARE @PasswordFormat                         INT
    DECLARE @PasswordSalt                           NVARCHAR(128)
    DECLARE @IsLockedOut                            BIT
    DECLARE @FailedPasswordAttemptCount             INT
    DECLARE @FailedPasswordAnswerAttemptCount       INT

    SELECT  @Password = m.Password,
            @PasswordFormat = m.PasswordFormat,
            @PasswordSalt = m.PasswordSalt,
            @IsLockedOut = m.IsLockedOut,
            @FailedPasswordAttemptCount = m.FailedPasswordAttemptCount,
            @FailedPasswordAnswerAttemptCount = m.FailedPasswordAnswerAttemptCount
    FROM    {databaseOwner}aspnet_Applications a, {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_Membership m
    WHERE   @ApplicationName = a.ApplicationName AND
            u.ApplicationId = a.ApplicationId    AND
            u.UserId = m.UserId AND
            LOWER(@UserName) = u.LoweredUserName

    IF( @@rowcount = 0 )
        RETURN 1

    IF( @IsLockedOut = 1 )
        RETURN 99

    SELECT @Password,
           @PasswordFormat,
           @PasswordSalt,
           @FailedPasswordAttemptCount,
           @FailedPasswordAnswerAttemptCount

    RETURN 0
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE {databaseOwner}aspnet_Membership_GetUserByEmail
    @ApplicationName  NVARCHAR(256),
    @Email            NVARCHAR(128)
AS
BEGIN
    IF( @Email IS NULL )
        SELECT  u.UserName
        FROM    {databaseOwner}aspnet_Applications a, {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_Membership m
        WHERE   @ApplicationName = a.ApplicationName AND
                u.ApplicationId = a.ApplicationId    AND
                u.UserId = m.UserId AND
                m.LoweredEmail IS NULL
    ELSE
        SELECT  u.UserName
        FROM    {databaseOwner}aspnet_Applications a, {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_Membership m
        WHERE   @ApplicationName = a.ApplicationName AND
                u.ApplicationId = a.ApplicationId    AND
                u.UserId = m.UserId AND
                LOWER(@Email) = m.LoweredEmail

    IF (@@rowcount = 0)
        RETURN(1)
    RETURN(0)
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE {databaseOwner}aspnet_Membership_GetUserByName
    @ApplicationName      NVARCHAR(256),
    @UserName             NVARCHAR(256),
    @TimeZoneAdjustment   INT,
    @UpdateLastActivity   BIT = 0
AS
BEGIN
    IF (@UpdateLastActivity = 1)
    BEGIN
        UPDATE   {databaseOwner}aspnet_Users
        SET      LastActivityDate = DATEADD(n, -@TimeZoneAdjustment, GETDATE())
        FROM     {databaseOwner}aspnet_Applications a, {databaseOwner}aspnet_Users u
        WHERE    @ApplicationName = a.ApplicationName AND
                 u.ApplicationId = a.ApplicationId    AND
                 u.LoweredUserName = LOWER(@UserName)

        IF (@@ROWCOUNT = 0) -- Username not found
            RETURN -1
    END


    SELECT  m.Email, m.PasswordQuestion, m.Comment, m.IsApproved,
            DATEADD(n, @TimeZoneAdjustment, m.CreateDate),
            DATEADD(n, @TimeZoneAdjustment, m.LastLoginDate),
            DATEADD(n, @TimeZoneAdjustment, u.LastActivityDate),
            DATEADD(n, @TimeZoneAdjustment, m.LastPasswordChangedDate),
            u.UserId, m.IsLockedOut,
            DATEADD(n, @TimeZoneAdjustment, m.LastLockoutDate)
    FROM    {databaseOwner}aspnet_Applications a, {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_Membership m
    WHERE   @ApplicationName = a.ApplicationName AND
            u.ApplicationId = a.ApplicationId    AND
            u.LoweredUserName = LOWER(@UserName) AND
            u.UserId = m.UserId
    IF (@@ROWCOUNT = 0) -- Username not found
       RETURN -1

    RETURN 0
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE {databaseOwner}aspnet_Membership_GetUserByUserId
    @UserId               UNIQUEIDENTIFIER,
    @TimeZoneAdjustment   INT,
    @UpdateLastActivity   BIT = 0
AS
BEGIN
    IF ( @UpdateLastActivity = 1 )
    BEGIN
        UPDATE   {databaseOwner}aspnet_Users
        SET      LastActivityDate = DATEADD(n, -@TimeZoneAdjustment, GETDATE())
        FROM     {databaseOwner}aspnet_Users
        WHERE    @UserId = UserId

        IF ( @@ROWCOUNT = 0 ) -- User ID not found
            RETURN -1
    END

    SELECT  m.Email, m.PasswordQuestion, m.Comment, m.IsApproved,
            DATEADD(n, @TimeZoneAdjustment, m.CreateDate),
            DATEADD(n, @TimeZoneAdjustment, m.LastLoginDate),
            DATEADD(n, @TimeZoneAdjustment, u.LastActivityDate),
            DATEADD(n, @TimeZoneAdjustment, m.LastPasswordChangedDate),
            u.UserId, m.IsLockedOut,
            DATEADD(n, @TimeZoneAdjustment, m.LastLockoutDate)
    FROM    {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_Membership m
    WHERE   @UserId = u.UserId AND u.UserId = m.UserId

    IF ( @@ROWCOUNT = 0 ) -- User ID not found
       RETURN -1

    RETURN 0
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE {databaseOwner}aspnet_Membership_ResetPassword
    @ApplicationName            NVARCHAR(256),
    @UserName                   NVARCHAR(256),
    @NewPassword                NVARCHAR(128),
    @PasswordAttemptThreshold   INT,
    @PasswordAttemptWindow      INT,
    @PasswordSalt               NVARCHAR(128),
    @TimeZoneAdjustment         INT,
    @PasswordFormat             INT = 0,
    @PasswordAnswer             NVARCHAR(128) = NULL
AS
BEGIN
    DECLARE @IsLockedOut                            BIT
    DECLARE @LastLockoutDate                        DATETIME
    DECLARE @FailedPasswordAttemptCount             INT
    DECLARE @FailedPasswordAttemptWindowStart       DATETIME
    DECLARE @FailedPasswordAnswerAttemptCount       INT
    DECLARE @FailedPasswordAnswerAttemptWindowStart DATETIME

    DECLARE @UserId                                 UNIQUEIDENTIFIER
    SET     @UserId = NULL

    DECLARE @ErrorCode     INT
    SET @ErrorCode = 0

    DECLARE @TranStarted   BIT
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
	    BEGIN TRANSACTION
	    SET @TranStarted = 1
    END
    ELSE
    	SET @TranStarted = 0

    SELECT  @UserId = u.UserId
    FROM    {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_Applications a, {databaseOwner}aspnet_Membership m
    WHERE   LoweredUserName = LOWER(@UserName) AND
            u.ApplicationId = a.ApplicationId  AND
            LoweredApplicationName = a.LoweredApplicationName AND
            u.UserId = m.UserId

    IF ( @UserId IS NULL )
    BEGIN
        SET @ErrorCode = 1
        GOTO Cleanup
    END

    SELECT @IsLockedOut = IsLockedOut,
           @LastLockoutDate = LastLockoutDate,
           @FailedPasswordAttemptCount = FailedPasswordAttemptCount,
           @FailedPasswordAttemptWindowStart = FailedPasswordAttemptWindowStart,
           @FailedPasswordAnswerAttemptCount = FailedPasswordAnswerAttemptCount,
           @FailedPasswordAnswerAttemptWindowStart = FailedPasswordAnswerAttemptWindowStart
    FROM {databaseOwner}aspnet_Membership WITH ( ROWLOCK, XLOCK )
    WHERE @UserId = UserId

    IF( @IsLockedOut = 1 )
    BEGIN
        SET @ErrorCode = 99
        GOTO Cleanup
    END

    UPDATE {databaseOwner}aspnet_Membership
    SET    Password = @NewPassword,
           LastPasswordChangedDate = DATEADD(n, -@TimeZoneAdjustment, GETDATE()),
           PasswordFormat = @PasswordFormat,
           PasswordSalt = @PasswordSalt
    WHERE  @UserId = UserId AND
           ( ( @PasswordAnswer IS NULL ) OR ( LOWER( PasswordAnswer ) = LOWER( @PasswordAnswer ) ) )

    IF ( @@ROWCOUNT = 0 )
        BEGIN
            IF( DATEADD(n, -@TimeZoneAdjustment, GETDATE()) > DATEADD( minute, @PasswordAttemptWindow, @FailedPasswordAnswerAttemptWindowStart ) )
            BEGIN
                SET @FailedPasswordAnswerAttemptCount = 1
                SET @FailedPasswordAnswerAttemptWindowStart = DATEADD(n, -@TimeZoneAdjustment, GETDATE())
            END
            ELSE
            BEGIN
                SET @FailedPasswordAnswerAttemptCount = @FailedPasswordAnswerAttemptCount + 1
                IF( @FailedPasswordAnswerAttemptCount >= @PasswordAttemptThreshold )
                BEGIN
                    SET @IsLockedOut = 1
                    SET @LastLockoutDate = DATEADD(n, -@TimeZoneAdjustment, GETDATE())
                END
            END

            SET @ErrorCode = 3
        END
    ELSE
        BEGIN
            IF( @FailedPasswordAnswerAttemptCount > 0 OR
                @FailedPasswordAttemptCount > 0 )
            BEGIN
                SET @FailedPasswordAttemptCount = 0
                SET @FailedPasswordAttemptWindowStart = CAST( '1/1/1753' AS DATETIME )
                SET @FailedPasswordAnswerAttemptCount = 0
                SET @FailedPasswordAnswerAttemptWindowStart = CAST( '1/1/1753' AS DATETIME )
            END
        END

    IF( NOT ( @PasswordAnswer IS NULL ) )
    BEGIN
        UPDATE {databaseOwner}aspnet_Membership
        SET IsLockedOut = @IsLockedOut, LastLockoutDate = @LastLockoutDate,
            FailedPasswordAttemptCount = @FailedPasswordAttemptCount,
            FailedPasswordAttemptWindowStart = @FailedPasswordAttemptWindowStart,
            FailedPasswordAnswerAttemptCount = @FailedPasswordAnswerAttemptCount,
            FailedPasswordAnswerAttemptWindowStart = @FailedPasswordAnswerAttemptWindowStart
        WHERE @UserId = UserId

        IF( @@ERROR <> 0 )
        BEGIN
            SET @ErrorCode = -1
            GOTO Cleanup
        END
    END

    IF( @TranStarted = 1 )
    BEGIN
	SET @TranStarted = 0
	COMMIT TRANSACTION
    END

    RETURN @ErrorCode

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

    RETURN @ErrorCode

END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE {databaseOwner}aspnet_Membership_SetPassword
    @ApplicationName  NVARCHAR(256),
    @UserName         NVARCHAR(256),
    @NewPassword      NVARCHAR(128),
    @PasswordSalt     NVARCHAR(128),
    @TimeZoneAdjustment  INT,
    @PasswordFormat   INT = 0
AS
BEGIN
    DECLARE @UserId UNIQUEIDENTIFIER
    SELECT  @UserId = NULL
    SELECT  @UserId = u.UserId
    FROM    {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_Applications a, {databaseOwner}aspnet_Membership m
    WHERE   LoweredUserName = LOWER(@UserName) AND
            u.ApplicationId = a.ApplicationId  AND
            LOWER(@ApplicationName) = a.LoweredApplicationName AND
            u.UserId = m.UserId

    IF (@UserId IS NULL)
        RETURN(1)

    UPDATE {databaseOwner}aspnet_Membership
    SET Password = @NewPassword, PasswordFormat = @PasswordFormat, PasswordSalt = @PasswordSalt,
        LastPasswordChangedDate = DATEADD(n, -@TimeZoneAdjustment, GETDATE())
    WHERE @UserId = UserId
    RETURN(0)
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE {databaseOwner}aspnet_Membership_UnlockUser
    @ApplicationName                         NVARCHAR(256),
    @UserName                                NVARCHAR(256)
AS
BEGIN
    DECLARE @UserId UNIQUEIDENTIFIER
    SELECT  @UserId = NULL
    SELECT  @UserId = u.UserId
    FROM    {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_Applications a, {databaseOwner}aspnet_Membership m
    WHERE   LoweredUserName = LOWER(@UserName) AND
            u.ApplicationId = a.ApplicationId  AND
            LOWER(@ApplicationName) = a.LoweredApplicationName AND
            u.UserId = m.UserId

    IF ( @UserId IS NULL )
        RETURN 1

    UPDATE {databaseOwner}aspnet_Membership
    SET IsLockedOut = 0,
        FailedPasswordAttemptCount = 0,
        FailedPasswordAttemptWindowStart = CAST( '1/1/1753' AS DATETIME ),
        FailedPasswordAnswerAttemptCount = 0,
        FailedPasswordAnswerAttemptWindowStart = CAST( '1/1/1753' AS DATETIME )
    WHERE @UserId = UserId

    RETURN 0
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE {databaseOwner}aspnet_Membership_UpdateLastLoginAndActivityDates
    @ApplicationName          NVARCHAR(256),
    @UserName                 NVARCHAR(256),
    @TimeZoneAdjustment       INT
AS
BEGIN
    DECLARE @UserId UNIQUEIDENTIFIER
    SELECT  @UserId = NULL
    SELECT  @UserId = u.UserId
    FROM    {databaseOwner}aspnet_Membership m, {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_Applications a
    WHERE   LoweredUserName = LOWER(@UserName) AND
            u.ApplicationId = a.ApplicationId  AND
            LOWER(@ApplicationName) = a.LoweredApplicationName AND
            u.UserId = m.UserId
    IF (@UserId IS NULL)
    BEGIN
        RETURN
    END

    DECLARE @TranStarted   BIT
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
	    BEGIN TRANSACTION
	    SET @TranStarted = 1
    END
    ELSE
	SET @TranStarted = 0

    UPDATE  {databaseOwner}aspnet_Membership
    SET     LastLoginDate = DATEADD(n, -@TimeZoneAdjustment, GETDATE())
    WHERE   UserId = @UserId

    IF( @@ERROR <> 0 )
        GOTO Cleanup

    UPDATE  {databaseOwner}aspnet_Users
    SET     LastActivityDate = DATEADD(n, -@TimeZoneAdjustment, GETDATE())
    WHERE   @UserId = UserId

    IF( @@ERROR <> 0 )
        GOTO Cleanup

    IF( @TranStarted = 1 )
    BEGIN
	SET @TranStarted = 0
	COMMIT TRANSACTION
    END

    RETURN

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
	    ROLLBACK TRANSACTION
    END

    RETURN -1

END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE {databaseOwner}aspnet_Membership_UpdateUser
    @ApplicationName      NVARCHAR(256),
    @UserName             NVARCHAR(256),
    @Email                NVARCHAR(128),
    @Comment              NTEXT,
    @IsApproved           BIT,
    @LastLoginDate        DATETIME,
    @LastActivityDate     DATETIME,
    @UniqueEmail          INT,
    @TimeZoneAdjustment   INT
AS
BEGIN
    DECLARE @UserId UNIQUEIDENTIFIER
    DECLARE @ApplicationId UNIQUEIDENTIFIER
    SELECT  @UserId = NULL
    SELECT  @UserId = u.UserId, @ApplicationId = a.ApplicationId
    FROM    {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_Applications a, {databaseOwner}aspnet_Membership m
    WHERE   LoweredUserName = LOWER(@UserName) AND
            u.ApplicationId = a.ApplicationId  AND
            LOWER(@ApplicationName) = a.LoweredApplicationName AND
            u.UserId = m.UserId

    IF (@UserId IS NULL)
        RETURN(1)

    IF (@UniqueEmail = 1)
    BEGIN
        IF (EXISTS (SELECT *
                    FROM  {databaseOwner}aspnet_Membership m, {databaseOwner}aspnet_Users u
                    WHERE (u.UserId = m.UserId AND u.ApplicationId = @ApplicationId AND m.LoweredEmail = LOWER(@Email) AND @UserId <> u.UserId)))
        BEGIN
            RETURN(7)
        END
    END

    DECLARE @TranStarted   BIT
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
	    BEGIN TRANSACTION
	    SET @TranStarted = 1
    END
    ELSE
	SET @TranStarted = 0

    UPDATE {databaseOwner}aspnet_Membership
    SET
         Email            = @Email,
         LoweredEmail     = LOWER(@Email),
         Comment          = @Comment,
         IsApproved       = @IsApproved,
         LastLoginDate    = DATEADD(n, -@TimeZoneAdjustment, @LastLoginDate)
    WHERE
       @UserId = UserId

    IF( @@ERROR <> 0 )
        GOTO Cleanup

    UPDATE {databaseOwner}aspnet_Users
    SET
         LastActivityDate = DATEADD(n, -@TimeZoneAdjustment, @LastActivityDate)
    WHERE
       @UserId = UserId

    IF( @@ERROR <> 0 )
        GOTO Cleanup

    IF( @TranStarted = 1 )
    BEGIN
	SET @TranStarted = 0
	COMMIT TRANSACTION
    END

    RETURN 0

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

    RETURN -1
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE {databaseOwner}aspnet_Membership_UpdateUserInfo
    @ApplicationName                NVARCHAR(256),
    @UserName                       NVARCHAR(256),
    @IsPasswordCorrect              BIT,
    @UpdateLastLoginActivityDate    BIT,
    @PasswordAttemptThreshold       INT,
    @PasswordAttemptWindow          INT,
    @TimeZoneAdjustment             INT
AS
BEGIN
    DECLARE @UserId                                 UNIQUEIDENTIFIER
    DECLARE @IsApproved                             BIT
    DECLARE @IsLockedOut                            BIT
    DECLARE @LastLockoutDate                        DATETIME
    DECLARE @FailedPasswordAttemptCount             INT
    DECLARE @FailedPasswordAttemptWindowStart       DATETIME
    DECLARE @FailedPasswordAnswerAttemptCount       INT
    DECLARE @FailedPasswordAnswerAttemptWindowStart DATETIME

    DECLARE @ErrorCode     INT
    SET @ErrorCode = 0

    DECLARE @TranStarted   BIT
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
	    BEGIN TRANSACTION
	    SET @TranStarted = 1
    END
    ELSE
    	SET @TranStarted = 0

    SELECT  @UserId = u.UserId,
            @IsApproved = m.IsApproved,
            @IsLockedOut = m.IsLockedOut,
            @LastLockoutDate = m.LastLockoutDate,
            @FailedPasswordAttemptCount = m.FailedPasswordAttemptCount,
            @FailedPasswordAttemptWindowStart = m.FailedPasswordAttemptWindowStart,
            @FailedPasswordAnswerAttemptCount = m.FailedPasswordAnswerAttemptCount,
            @FailedPasswordAnswerAttemptWindowStart = m.FailedPasswordAnswerAttemptWindowStart
    FROM    {databaseOwner}aspnet_Applications a, {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_Membership m WITH ( ROWLOCK, XLOCK )
    WHERE   @ApplicationName = a.ApplicationName AND
            u.ApplicationId = a.ApplicationId    AND
            u.UserId = m.UserId AND
            LOWER(@UserName) = u.LoweredUserName

    IF ( @@rowcount = 0 )
    BEGIN
        SET @ErrorCode = 1
        GOTO Cleanup
    END

    IF( @IsLockedOut = 1 )
    BEGIN
        GOTO Cleanup
    END

    IF( @IsPasswordCorrect = 0 )
    BEGIN
        IF( DATEADD(n, -@TimeZoneAdjustment, GETDATE()) > DATEADD( minute, @PasswordAttemptWindow, @FailedPasswordAttemptWindowStart ) )
        BEGIN
            SET @FailedPasswordAttemptCount = 1
            SET @FailedPasswordAttemptWindowStart = DATEADD(n, -@TimeZoneAdjustment, GETDATE())
        END
        ELSE
        BEGIN
            SET @FailedPasswordAttemptCount = @FailedPasswordAttemptCount + 1
            IF( @FailedPasswordAttemptCount >= @PasswordAttemptThreshold )
            BEGIN
                SET @IsLockedOut = 1
                SET @LastLockoutDate = DATEADD(n, -@TimeZoneAdjustment, GETDATE())
            END
        END
    END
    ELSE
    BEGIN
        IF( @UpdateLastLoginActivityDate = 1 )
        BEGIN
            UPDATE  {databaseOwner}aspnet_Membership
            SET     LastLoginDate = DATEADD(n, -@TimeZoneAdjustment, GETDATE())
            WHERE   UserId = @UserId

            IF( @@ERROR <> 0 )
            BEGIN
                SET @ErrorCode = -1
                GOTO Cleanup
            END

            UPDATE  {databaseOwner}aspnet_Users
            SET     LastActivityDate = DATEADD(n, -@TimeZoneAdjustment, GETDATE())
            WHERE   @UserId = UserId

            IF( @@ERROR <> 0 )
            BEGIN
                SET @ErrorCode = -1
                GOTO Cleanup
            END
        END

        IF( @FailedPasswordAttemptCount > 0 OR @FailedPasswordAnswerAttemptCount > 0 )
        BEGIN
            SET @FailedPasswordAttemptCount = 0
            SET @FailedPasswordAttemptWindowStart = CAST( '1/1/1753' AS DATETIME )
            SET @FailedPasswordAnswerAttemptCount = 0
            SET @FailedPasswordAnswerAttemptWindowStart = CAST( '1/1/1753' AS DATETIME )
        END
    END

    UPDATE {databaseOwner}aspnet_Membership
    SET IsLockedOut = @IsLockedOut, LastLockoutDate = @LastLockoutDate,
        FailedPasswordAttemptCount = @FailedPasswordAttemptCount,
        FailedPasswordAttemptWindowStart = @FailedPasswordAttemptWindowStart,
        FailedPasswordAnswerAttemptCount = @FailedPasswordAnswerAttemptCount,
        FailedPasswordAnswerAttemptWindowStart = @FailedPasswordAnswerAttemptWindowStart
    WHERE @UserId = UserId

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    IF( @TranStarted = 1 )
    BEGIN
	SET @TranStarted = 0
	COMMIT TRANSACTION
    END

    RETURN @ErrorCode

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

    RETURN @ErrorCode

END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_Profile_DeleteInactiveProfiles
    @ApplicationName        NVARCHAR(256),
    @ProfileAuthOptions     INT,
    @InactiveSinceDate      DATETIME,
    @TimeZoneAdjustment     INT
AS
BEGIN
    DECLARE @ApplicationId UNIQUEIDENTIFIER
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
    BEGIN
        SELECT  0
        RETURN
    END

    SELECT @InactiveSinceDate = DATEADD(n, -@TimeZoneAdjustment, @InactiveSinceDate)

    DELETE
    FROM    {databaseOwner}aspnet_Profile
    WHERE   UserId IN
            (   SELECT  UserId
                FROM    {databaseOwner}aspnet_Users u
                WHERE   ApplicationId = @ApplicationId
                        AND (LastActivityDate <= @InactiveSinceDate)
                        AND (
                                ((@ProfileAuthOptions & 3) = 3)
                             OR ((@ProfileAuthOptions & 1) = 1 AND IsAnonymous = 1)
                             OR ((@ProfileAuthOptions & 2) = 2 AND IsAnonymous = 0)
                            )
            )

    SELECT  @@ROWCOUNT
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_Profile_DeleteProfiles
    @ApplicationName        NVARCHAR(256),
    @UserNames              NVARCHAR(4000)
AS
BEGIN
    DECLARE @UserName     NVARCHAR(256)
    DECLARE @CurrentPos   INT
    DECLARE @NextPos      INT
    DECLARE @NumDeleted   INT
    DECLARE @DeletedUser  INT
    DECLARE @TranStarted  BIT
    DECLARE @ErrorCode    INT

    SET @ErrorCode = 0
    SET @CurrentPos = 1
    SET @NumDeleted = 0
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
        BEGIN TRANSACTION
        SET @TranStarted = 1
    END
    ELSE
    	SET @TranStarted = 0

    WHILE (@CurrentPos <= LEN(@UserNames))
    BEGIN
        SELECT @NextPos = CHARINDEX(N',', @UserNames,  @CurrentPos)
        IF (@NextPos = 0 OR @NextPos IS NULL)
            SELECT @NextPos = LEN(@UserNames) + 1

        SELECT @UserName = RTRIM(LTRIM(SUBSTRING(@UserNames, @CurrentPos, @NextPos - @CurrentPos)))
        SELECT @CurrentPos = @NextPos+1

        IF (LEN(@UserName) > 0)
        BEGIN
            SELECT @DeletedUser = 0
            EXEC {databaseOwner}aspnet_Users_DeleteUser @ApplicationName, @UserName, 4, @DeletedUser OUTPUT
            IF( @@ERROR <> 0 )
            BEGIN
                SET @ErrorCode = -1
                GOTO Cleanup
            END
            IF (@DeletedUser <> 0)
                SELECT @NumDeleted = @NumDeleted + 1
        END
    END
    SELECT @NumDeleted
    IF (@TranStarted = 1)
    BEGIN
    	SET @TranStarted = 0
    	COMMIT TRANSACTION
    END
    SET @TranStarted = 0

    RETURN 0

Cleanup:
    IF (@TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END
    RETURN @ErrorCode
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_Profile_GetNumberOfInactiveProfiles
    @ApplicationName        NVARCHAR(256),
    @ProfileAuthOptions     INT,
    @InactiveSinceDate      DATETIME,
    @TimeZoneAdjustment     INT
AS
BEGIN
    DECLARE @ApplicationId UNIQUEIDENTIFIER
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
    BEGIN
        SELECT 0
        RETURN
    END

    SELECT @InactiveSinceDate = DATEADD(n, -@TimeZoneAdjustment, @InactiveSinceDate)

    SELECT  COUNT(*)
    FROM    {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_Profile p
    WHERE   ApplicationId = @ApplicationId
        AND u.UserId = p.UserId
        AND (LastActivityDate <= @InactiveSinceDate)
        AND (
               ((@ProfileAuthOptions & 3) = 3)
            OR ((@ProfileAuthOptions & 1) = 1 AND IsAnonymous = 1)
            OR ((@ProfileAuthOptions & 2) = 2 AND IsAnonymous = 0)
            )
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_Profile_GetProfiles
    @ApplicationName        NVARCHAR(256),
    @ProfileAuthOptions     INT,
    @PageIndex              INT,
    @PageSize               INT,
    @TimeZoneAdjustment     INT,
    @UserNameToMatch        NVARCHAR(256) = NULL,
    @InactiveSinceDate      DATETIME      = NULL
AS
BEGIN
    DECLARE @ApplicationId UNIQUEIDENTIFIER
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN

    IF (NOT(@InactiveSinceDate IS NULL))
        SELECT @InactiveSinceDate = DATEADD(n, -@TimeZoneAdjustment, @InactiveSinceDate)

    -- Set the page bounds
    DECLARE @PageLowerBound INT
    DECLARE @PageUpperBound INT
    DECLARE @TotalRecords   INT
    SET @PageLowerBound = @PageSize * @PageIndex
    SET @PageUpperBound = @PageSize - 1 + @PageLowerBound

    -- Create a temp table to store the select results
    CREATE TABLE #PageIndexForUsers
    (
        IndexId int IDENTITY (0, 1) NOT NULL,
        UserId UNIQUEIDENTIFIER
    )

    -- Insert into our temp table
    INSERT INTO #PageIndexForUsers (UserId)
        SELECT  u.UserId
        FROM    {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_Profile p
        WHERE   ApplicationId = @ApplicationId
            AND u.UserId = p.UserId
            AND (@InactiveSinceDate IS NULL OR LastActivityDate <= @InactiveSinceDate)
            AND (    ((@ProfileAuthOptions & 3) = 3)
                  OR ((@ProfileAuthOptions & 1) = 1 AND IsAnonymous = 1)
                  OR ((@ProfileAuthOptions & 2) = 2 AND IsAnonymous = 0)   )
            AND (@UserNameToMatch IS NULL OR LoweredUserName LIKE LOWER(@UserNameToMatch))
        ORDER BY UserName

    SELECT  u.UserName, u.IsAnonymous,
            DATEADD(n, @TimeZoneAdjustment, u.LastActivityDate),
            DATEADD(n, @TimeZoneAdjustment, p.LastUpdatedDate),
            DATALENGTH(p.PropertyNames) + DATALENGTH(p.PropertyValuesString) + DATALENGTH(p.PropertyValuesBinary)
    FROM    {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_Profile p, #PageIndexForUsers i
    WHERE   u.UserId = p.UserId AND p.UserId = i.UserId AND i.IndexId >= @PageLowerBound AND i.IndexId <= @PageUpperBound

    SELECT COUNT(*)
    FROM   #PageIndexForUsers

    DROP TABLE #PageIndexForUsers
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_Profile_GetProperties
    @ApplicationName      NVARCHAR(256),
    @UserName             NVARCHAR(256),
    @TimeZoneAdjustment   INT
AS
BEGIN
    DECLARE @ApplicationId UNIQUEIDENTIFIER
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM {databaseOwner}aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN

    DECLARE @UserId UNIQUEIDENTIFIER
    SELECT  @UserId = NULL

    SELECT @UserId = UserId
    FROM   {databaseOwner}aspnet_Users
    WHERE  ApplicationId = @ApplicationId AND LoweredUserName = LOWER(@UserName)

    IF (@UserId IS NULL)
        RETURN
    SELECT TOP 1 PropertyNames, PropertyValuesString, PropertyValuesBinary
    FROM         {databaseOwner}aspnet_Profile
    WHERE        UserId = @UserId

    IF (@@ROWCOUNT > 0)
    BEGIN
        UPDATE {databaseOwner}aspnet_Users
        SET    LastActivityDate=DATEADD(n, -@TimeZoneAdjustment, GETDATE())
        WHERE  UserId = @UserId
    END
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_Profile_SetProperties
    @ApplicationName        NVARCHAR(256),
    @PropertyNames          NTEXT,
    @PropertyValuesString   NTEXT,
    @PropertyValuesBinary   IMAGE,
    @UserName               NVARCHAR(256),
    @IsUserAnonymous        BIT,
    @TimeZoneAdjustment     INT
AS
BEGIN
    DECLARE @ApplicationId UNIQUEIDENTIFIER
    SELECT  @ApplicationId = NULL

    DECLARE @ErrorCode     INT
    SET @ErrorCode = 0

    DECLARE @TranStarted   BIT
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
       BEGIN TRANSACTION
       SET @TranStarted = 1
    END
    ELSE
    	SET @TranStarted = 0

    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        EXEC {databaseOwner}aspnet_Applications_CreateApplication @ApplicationName, @ApplicationId OUTPUT

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    DECLARE @UserId UNIQUEIDENTIFIER
    DECLARE @LastActivityDate DATETIME
    SELECT  @UserId = NULL
    SELECT @LastActivityDate = DATEADD(n, -@TimeZoneAdjustment, GETDATE())

    SELECT @UserId = UserId
    FROM   {databaseOwner}aspnet_Users
    WHERE  ApplicationId = @ApplicationId AND LoweredUserName = LOWER(@UserName)
    IF (@UserId IS NULL)
        EXEC {databaseOwner}aspnet_Users_CreateUser @ApplicationId, @UserName, @IsUserAnonymous, @LastActivityDate, @UserId OUTPUT

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    IF (EXISTS( SELECT *
               FROM   {databaseOwner}aspnet_Profile
               WHERE  UserId = @UserId))
        UPDATE {databaseOwner}aspnet_Profile
        SET    PropertyNames=@PropertyNames, PropertyValuesString = @PropertyValuesString,
               PropertyValuesBinary = @PropertyValuesBinary, LastUpdatedDate=DATEADD(n, -@TimeZoneAdjustment, GETDATE())
        WHERE  UserId = @UserId
    ELSE
        INSERT INTO {databaseOwner}aspnet_Profile(UserId, PropertyNames, PropertyValuesString, PropertyValuesBinary)
             VALUES (@UserId, @PropertyNames, @PropertyValuesString, @PropertyValuesBinary)

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    UPDATE {databaseOwner}aspnet_Users
    SET    LastActivityDate=DATEADD(n, -@TimeZoneAdjustment, GETDATE())
    WHERE  UserId = @UserId

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    IF( @TranStarted = 1 )
    BEGIN
    	SET @TranStarted = 0
    	COMMIT TRANSACTION
    END

    RETURN 0

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

    RETURN @ErrorCode

END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_RegisterSchemaVersion
    @Feature                   NVARCHAR(128),
    @CompatibleSchemaVersion   NVARCHAR(128),
    @IsCurrentVersion          BIT,
    @RemoveIncompatibleSchema  BIT
AS
BEGIN
    IF( @RemoveIncompatibleSchema = 1 )
    BEGIN
        DELETE FROM {databaseOwner}aspnet_SchemaVersions WHERE Feature = LOWER( @Feature )
    END
    ELSE
    BEGIN
        IF( @IsCurrentVersion = 1 )
        BEGIN
            UPDATE {databaseOwner}aspnet_SchemaVersions
            SET IsCurrentVersion = 0
            WHERE Feature = LOWER( @Feature )
        END
    END

    INSERT  {databaseOwner}aspnet_SchemaVersions( Feature, CompatibleSchemaVersion, IsCurrentVersion )
    VALUES( LOWER( @Feature ), @CompatibleSchemaVersion, @IsCurrentVersion )
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE {databaseOwner}aspnet_Roles_CreateRole
    @ApplicationName  NVARCHAR(256),
    @RoleName         NVARCHAR(256)
AS
BEGIN
    DECLARE @ApplicationId UNIQUEIDENTIFIER
    SELECT  @ApplicationId = NULL

    DECLARE @ErrorCode     INT
    SET @ErrorCode = 0

    DECLARE @TranStarted   BIT
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
	    BEGIN TRANSACTION
	    SET @TranStarted = 1
    END
    ELSE
    	SET @TranStarted = 0

    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        EXEC {databaseOwner}aspnet_Applications_CreateApplication @ApplicationName, @ApplicationId OUTPUT
    
    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    IF (EXISTS(SELECT RoleId FROM {databaseOwner}aspnet_Roles WHERE LoweredRoleName = LOWER(@RoleName) AND ApplicationId = @ApplicationId))
    BEGIN
        SET @ErrorCode = 1
        GOTO Cleanup
    END        

    INSERT INTO {databaseOwner}aspnet_Roles
                (ApplicationId, RoleName, LoweredRoleName)
         VALUES (@ApplicationId, @RoleName, LOWER(@RoleName))

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    IF( @TranStarted = 1 )
    BEGIN
    	SET @TranStarted = 0
    	COMMIT TRANSACTION
    END

    RETURN(0)

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

    RETURN @ErrorCode

END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_Roles_DeleteRole
    @ApplicationName            NVARCHAR(256),
    @RoleName                   NVARCHAR(256),
    @DeleteOnlyIfRoleIsEmpty    BIT
AS
BEGIN
    DECLARE @ApplicationId UNIQUEIDENTIFIER
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN(1)
    DECLARE @RoleId   UNIQUEIDENTIFIER
    SELECT  @RoleId = NULL
    SELECT  @RoleId = RoleId FROM {databaseOwner}aspnet_Roles WHERE LoweredRoleName = LOWER(@RoleName) AND ApplicationId = @ApplicationId

    IF (@RoleId IS NULL)
        RETURN(1)

    IF (@DeleteOnlyIfRoleIsEmpty <> 0)
    BEGIN
        IF (EXISTS (SELECT RoleId FROM {databaseOwner}aspnet_UsersInRoles  WHERE @RoleId = RoleId))
            RETURN(2)
    END

    DECLARE @ErrorCode     INT
    SET @ErrorCode = 0

    DECLARE @TranStarted   BIT
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
	    BEGIN TRANSACTION
	    SET @TranStarted = 1
    END
    ELSE
    	SET @TranStarted = 0

    DELETE FROM {databaseOwner}aspnet_UsersInRoles  WHERE @RoleId = RoleId

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    DELETE FROM {databaseOwner}aspnet_Roles WHERE @RoleId = RoleId  AND ApplicationId = @ApplicationId

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    IF( @TranStarted = 1 )
    BEGIN
    	SET @TranStarted = 0
    	COMMIT TRANSACTION
    END

    RETURN(0)

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

    RETURN @ErrorCode

END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_Roles_GetAllRoles (
    @ApplicationName           NVARCHAR(256))
AS
BEGIN
    DECLARE @ApplicationId UNIQUEIDENTIFIER
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN
    SELECT RoleName
    FROM   {databaseOwner}aspnet_Roles WHERE ApplicationId = @ApplicationId
    ORDER BY RoleName
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_Roles_RoleExists
    @ApplicationName  NVARCHAR(256),
    @RoleName         NVARCHAR(256)
AS
BEGIN
    DECLARE @ApplicationId UNIQUEIDENTIFIER
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN(0)
    IF (EXISTS (SELECT RoleName FROM {databaseOwner}aspnet_Roles WHERE LOWER(@RoleName) = LoweredRoleName AND ApplicationId = @ApplicationId ))
        RETURN(1)
    ELSE
        RETURN(0)
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_Setup_RemoveAllRoleMembers
    @name   sysname
AS
BEGIN
    CREATE TABLE #aspnet_RoleMembers
    (
        Group_name      sysname,
        Group_id        smallint,
        Users_in_group  sysname,
        User_id         smallint
    )

    INSERT INTO #aspnet_RoleMembers
    EXEC sp_helpuser @name

    DECLARE @user_id smallint
    DECLARE @cmd nvarchar(500)
    DECLARE c1 CURSOR FORWARD_ONLY FOR
        SELECT User_id FROM #aspnet_RoleMembers

    OPEN c1

    FETCH c1 INTO @user_id
    WHILE (@@fetch_status = 0)
    BEGIN
        SET @cmd = 'EXEC sp_droprolemember ' + '''' + @name + ''', ''' + USER_NAME(@user_id) + ''''
        EXEC (@cmd)
        FETCH c1 INTO @user_id
    END

    close c1
    deallocate c1
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_Setup_RestorePermissions
    @name   sysname
AS
BEGIN
    DECLARE @object sysname
    DECLARE @protectType char(10)
    DECLARE @action varchar(20)
    DECLARE @grantee sysname
    DECLARE @cmd nvarchar(500)
    DECLARE c1 CURSOR FORWARD_ONLY FOR
        SELECT Object, ProtectType, [Action], Grantee FROM #aspnet_Permissions where Object = @name

    OPEN c1

    FETCH c1 INTO @object, @protectType, @action, @grantee
    WHILE (@@fetch_status = 0)
    BEGIN
        SET @cmd = @protectType + ' ' + @action + ' on ' + @object + ' to [' + @grantee + ']'
        EXEC (@cmd)
        FETCH c1 INTO @object, @protectType, @action, @grantee
    END

    close c1
    deallocate c1
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_UsersInRoles_AddUsersToRoles
    @ApplicationName  NVARCHAR(256),
    @UserNames        NVARCHAR(4000),
    @RoleNames        NVARCHAR(4000)
AS
BEGIN
    DECLARE @ApplicationId UNIQUEIDENTIFIER
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN(2)


    DECLARE @RoleId UNIQUEIDENTIFIER
    DECLARE @UserId UNIQUEIDENTIFIER
    DECLARE @UserName     NVARCHAR(256)
    DECLARE @RoleName     NVARCHAR(256)

    DECLARE @CurrentPosU  INT
    DECLARE @NextPosU     INT
    DECLARE @CurrentPosR  INT
    DECLARE @NextPosR     INT

    SELECT  @CurrentPosU = 1

    WHILE(@CurrentPosU <= LEN(@UserNames))
    BEGIN
        SELECT @NextPosU = CHARINDEX(N',', @UserNames,  @CurrentPosU)
        IF (@NextPosU = 0 OR @NextPosU IS NULL)
            SELECT @NextPosU = LEN(@UserNames) + 1

        SELECT @UserName = RTRIM(LTRIM(SUBSTRING(@UserNames, @CurrentPosU, @NextPosU - @CurrentPosU)))
        SELECT @CurrentPosU = @NextPosU+1

        SELECT @CurrentPosR = 1
        WHILE(@CurrentPosR <= LEN(@RoleNames))
        BEGIN
            SELECT @NextPosR = CHARINDEX(N',', @RoleNames,  @CurrentPosR)
            IF (@NextPosR = 0 OR @NextPosR IS NULL)
                SELECT @NextPosR = LEN(@RoleNames) + 1
            SELECT @RoleName = RTRIM(LTRIM(SUBSTRING(@RoleNames, @CurrentPosR, @NextPosR - @CurrentPosR)))
            SELECT @CurrentPosR = @NextPosR+1


            SELECT @RoleId = NULL
            SELECT @RoleId = RoleId FROM {databaseOwner}aspnet_Roles WHERE LoweredRoleName = LOWER(@RoleName) AND ApplicationId = @ApplicationId
            IF (@RoleId IS NULL)
            BEGIN
                SELECT @RoleName
                RETURN(2)
            END

            DECLARE @DateNow DATETIME
            SELECT @DateNow = GETDATE()
            SELECT @UserId = NULL
            SELECT @UserId = UserId FROM {databaseOwner}aspnet_Users WHERE LoweredUserName = LOWER(@UserName) AND ApplicationId = @ApplicationId
            IF (@UserId IS NULL)
                EXEC {databaseOwner}aspnet_Users_CreateUser @ApplicationId, @UserName, 0, @DateNow, @UserId OUTPUT

            IF (EXISTS(SELECT * FROM {databaseOwner}aspnet_UsersInRoles WHERE @UserId = UserId AND @RoleId = RoleId))
            BEGIN
                SELECT @UserName, @RoleName
                RETURN(3)
            END
            INSERT INTO {databaseOwner}aspnet_UsersInRoles (UserId, RoleId) VALUES(@UserId, @RoleId)
        END
    END
    RETURN(0)
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_UsersInRoles_FindUsersInRole
    @ApplicationName  NVARCHAR(256),
    @RoleName         NVARCHAR(256),
    @UserNameToMatch  NVARCHAR(256)
AS
BEGIN
    DECLARE @ApplicationId UNIQUEIDENTIFIER
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN(1)
     DECLARE @RoleId UNIQUEIDENTIFIER
     SELECT  @RoleId = NULL

     SELECT  @RoleId = RoleId
     FROM    {databaseOwner}aspnet_Roles
     WHERE   LOWER(@RoleName) = LoweredRoleName AND ApplicationId = @ApplicationId

     IF (@RoleId IS NULL)
         RETURN(1)

    SELECT u.UserName
    FROM   {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_UsersInRoles ur
    WHERE  u.UserId = ur.UserId AND @RoleId = ur.RoleId AND u.ApplicationId = @ApplicationId AND LoweredUserName LIKE LOWER(@UserNameToMatch)
    ORDER BY u.UserName
    RETURN(0)
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_UsersInRoles_GetRolesForUser
    @ApplicationName  NVARCHAR(256),
    @UserName         NVARCHAR(256)
AS
BEGIN
    DECLARE @ApplicationId UNIQUEIDENTIFIER
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN(1)
    DECLARE @UserId UNIQUEIDENTIFIER
    SELECT  @UserId = NULL

    SELECT  @UserId = UserId
    FROM    {databaseOwner}aspnet_Users
    WHERE   LoweredUserName = LOWER(@UserName) AND ApplicationId = @ApplicationId

    IF (@UserId IS NULL)
        RETURN(1)

    SELECT r.RoleName
    FROM   {databaseOwner}aspnet_Roles r, {databaseOwner}aspnet_UsersInRoles ur
    WHERE  r.RoleId = ur.RoleId AND r.ApplicationId = @ApplicationId AND ur.UserId = @UserId
    ORDER BY r.RoleName
    RETURN (0)
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_UsersInRoles_GetUsersInRoles
    @ApplicationName  NVARCHAR(256),
    @RoleName         NVARCHAR(256)
AS
BEGIN
    DECLARE @ApplicationId UNIQUEIDENTIFIER
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN(1)
     DECLARE @RoleId UNIQUEIDENTIFIER
     SELECT  @RoleId = NULL

     SELECT  @RoleId = RoleId
     FROM    {databaseOwner}aspnet_Roles
     WHERE   LOWER(@RoleName) = LoweredRoleName AND ApplicationId = @ApplicationId

     IF (@RoleId IS NULL)
         RETURN(1)

    SELECT u.UserName
    FROM   {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_UsersInRoles ur
    WHERE  u.UserId = ur.UserId AND @RoleId = ur.RoleId AND u.ApplicationId = @ApplicationId
    ORDER BY u.UserName
    RETURN(0)
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_UsersInRoles_IsUserInRole
    @ApplicationName  NVARCHAR(256),
    @UserName         NVARCHAR(256),
    @RoleName         NVARCHAR(256)
AS
BEGIN
    DECLARE @ApplicationId UNIQUEIDENTIFIER
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN(2)
    DECLARE @UserId UNIQUEIDENTIFIER
    SELECT  @UserId = NULL
    DECLARE @RoleId UNIQUEIDENTIFIER
    SELECT  @RoleId = NULL

    SELECT  @UserId = UserId
    FROM    {databaseOwner}aspnet_Users
    WHERE   LoweredUserName = LOWER(@UserName) AND ApplicationId = @ApplicationId

    IF (@UserId IS NULL)
        RETURN(2)

    SELECT  @RoleId = RoleId
    FROM    {databaseOwner}aspnet_Roles
    WHERE   LoweredRoleName = LOWER(@RoleName) AND ApplicationId = @ApplicationId

    IF (@RoleId IS NULL)
        RETURN(3)

    IF (EXISTS( SELECT * FROM {databaseOwner}aspnet_UsersInRoles WHERE  UserId = @UserId AND RoleId = @RoleId))
        RETURN(1)
    ELSE
        RETURN(0)
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_UsersInRoles_RemoveUsersFromRoles
    @ApplicationName  NVARCHAR(256),
    @UserNames        NVARCHAR(4000),
    @RoleNames        NVARCHAR(4000)
AS
BEGIN
    DECLARE @ApplicationId UNIQUEIDENTIFIER
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN(2)


    DECLARE @RoleId UNIQUEIDENTIFIER
    DECLARE @UserId UNIQUEIDENTIFIER
    DECLARE @UserName     NVARCHAR(256)
    DECLARE @RoleName     NVARCHAR(256)

    DECLARE @CurrentPosU  INT
    DECLARE @NextPosU     INT
    DECLARE @CurrentPosR  INT
    DECLARE @NextPosR     INT

    SELECT  @CurrentPosU = 1

    WHILE(@CurrentPosU <= LEN(@UserNames))
    BEGIN
        SELECT @NextPosU = CHARINDEX(N',', @UserNames,  @CurrentPosU)
        IF (@NextPosU = 0  OR @NextPosU IS NULL)
            SELECT @NextPosU = LEN(@UserNames)+1
        SELECT @UserName = RTRIM(LTRIM(SUBSTRING(@UserNames, @CurrentPosU, @NextPosU - @CurrentPosU)))
        SELECT @CurrentPosU = @NextPosU+1

        SELECT @CurrentPosR = 1
        WHILE(@CurrentPosR <= LEN(@RoleNames))
        BEGIN
            SELECT @NextPosR = CHARINDEX(N',', @RoleNames,  @CurrentPosR)
            IF (@NextPosR = 0 OR @NextPosR IS NULL)
                SELECT @NextPosR = LEN(@RoleNames)+1
            SELECT @RoleName = RTRIM(LTRIM(SUBSTRING(@RoleNames, @CurrentPosR, @NextPosR - @CurrentPosR)))
            SELECT @CurrentPosR = @NextPosR+1

            SELECT @RoleId = NULL
            SELECT @RoleId = RoleId FROM {databaseOwner}aspnet_Roles WHERE LoweredRoleName = LOWER(@RoleName) AND ApplicationId = @ApplicationId
            IF (@RoleId IS NULL)
            BEGIN
                SELECT N'', @RoleName
                RETURN(2)
            END

            SELECT @UserId = NULL
            SELECT @UserId = UserId FROM {databaseOwner}aspnet_Users WHERE LoweredUserName = LOWER(@UserName) AND ApplicationId = @ApplicationId
            IF (@UserId IS NULL)
            BEGIN
                SELECT @UserName, N''
                RETURN(1)
            END

            IF (NOT(EXISTS(SELECT * FROM {databaseOwner}aspnet_UsersInRoles WHERE @UserId = UserId AND @RoleId = RoleId)))
            BEGIN
                SELECT @UserName, @RoleName
                RETURN(3)
            END
            DELETE FROM {databaseOwner}aspnet_UsersInRoles WHERE (UserId = @UserId AND RoleId = @RoleId)
        END
    END
    RETURN(0)
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


CREATE PROCEDURE {databaseOwner}aspnet_Users_CreateUser
    @ApplicationId    UNIQUEIDENTIFIER,
    @UserName         NVARCHAR(256),
    @IsUserAnonymous  BIT,
    @LastActivityDate DATETIME,
    @UserId           UNIQUEIDENTIFIER OUTPUT
AS
BEGIN
    IF( @UserId IS NULL )
        SELECT @UserId = NEWID()
    ELSE
    BEGIN
        IF( EXISTS( SELECT UserId FROM {databaseOwner}aspnet_Users
                    WHERE @UserId = UserId ) )
            RETURN -1
    END

    INSERT {databaseOwner}aspnet_Users (ApplicationId, UserId, UserName, LoweredUserName, IsAnonymous, LastActivityDate)
    VALUES (@ApplicationId, @UserId, @UserName, LOWER(@UserName), @IsUserAnonymous, @LastActivityDate)

    RETURN 0
END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

CREATE PROCEDURE {databaseOwner}aspnet_Users_DeleteUser
    @ApplicationName  NVARCHAR(256),
    @UserName         NVARCHAR(256),
    @TablesToDeleteFrom INT,
    @NumTablesDeletedFrom INT OUTPUT
AS
BEGIN
    DECLARE @UserId               UNIQUEIDENTIFIER
    SELECT  @UserId               = NULL
    SELECT  @NumTablesDeletedFrom = 0

    SELECT  @UserId = u.UserId
    FROM    {databaseOwner}aspnet_Users u, {databaseOwner}aspnet_Applications a
    WHERE   u.LoweredUserName       = LOWER(@UserName)
        AND u.ApplicationId         = a.ApplicationId
        AND LOWER(@ApplicationName) = a.LoweredApplicationName

    IF (@UserId IS NULL)
        RETURN

    DECLARE @TranStarted   BIT
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
	    BEGIN TRANSACTION
	    SET @TranStarted = 1
    END
    ELSE
	SET @TranStarted = 0

    DECLARE @ErrorCode   INT
    DECLARE @RowCount    INT

    SET @ErrorCode = 0
    SET @RowCount  = 0

    IF ((@TablesToDeleteFrom & 1) <> 0 AND (EXISTS (SELECT name FROM sysobjects WHERE (name = N'aspnet_Membership') AND (type = 'U'))))
    BEGIN
        DELETE FROM aspnet_Membership WHERE @UserId = UserId

        SELECT @ErrorCode = @@ERROR,
               @RowCount = @@ROWCOUNT

        IF( @ErrorCode <> 0 )
            GOTO Cleanup

        IF (@RowCount <> 0)
            SELECT  @NumTablesDeletedFrom = @NumTablesDeletedFrom + 1
    END

    IF( @NumTablesDeletedFrom > 0 OR ( @TablesToDeleteFrom & 1 ) = 0 )
    BEGIN
        IF ((@TablesToDeleteFrom & 2) <> 0  AND (EXISTS (SELECT name FROM sysobjects WHERE (name = N'aspnet_UsersInRoles') AND (type = 'U'))))
        BEGIN
            DELETE FROM {databaseOwner}aspnet_UsersInRoles WHERE @UserId = UserId

            SELECT @ErrorCode = @@ERROR,
                   @RowCount = @@ROWCOUNT

            IF( @ErrorCode <> 0 )
                GOTO Cleanup

            IF (@RowCount <> 0)
                SELECT  @NumTablesDeletedFrom = @NumTablesDeletedFrom + 1
        END

        IF ((@TablesToDeleteFrom & 4) <> 0  AND (EXISTS (SELECT name FROM sysobjects WHERE (name = N'aspnet_Profile') AND (type = 'U'))))
        BEGIN
            DELETE FROM {databaseOwner}aspnet_Profile WHERE @UserId = UserId

            SELECT @ErrorCode = @@ERROR,
                   @RowCount = @@ROWCOUNT

            IF( @ErrorCode <> 0 )
                GOTO Cleanup

            IF (@RowCount <> 0)
                SELECT  @NumTablesDeletedFrom = @NumTablesDeletedFrom + 1
        END
    
        IF ((@TablesToDeleteFrom & 8) <> 0  AND (EXISTS (SELECT name FROM sysobjects WHERE (name = N'aspnet_PersonalizationPerUser') AND (type = 'U'))))
        BEGIN
            DELETE FROM aspnet_PersonalizationPerUser WHERE @UserId = UserId
    
            SELECT @ErrorCode = @@ERROR,
                   @RowCount = @@ROWCOUNT

            IF( @ErrorCode <> 0 )
                GOTO Cleanup

            IF (@RowCount <> 0)
                SELECT  @NumTablesDeletedFrom = @NumTablesDeletedFrom + 1
        END

        IF ((@TablesToDeleteFrom & 1) <> 0 AND (@TablesToDeleteFrom & 2) <> 0 AND (@TablesToDeleteFrom & 4) <> 0 AND (@TablesToDeleteFrom & 8) <> 0)
        BEGIN
            DELETE FROM {databaseOwner}aspnet_Users WHERE @UserId = UserId

            SELECT @ErrorCode = @@ERROR,
                   @RowCount = @@ROWCOUNT

            IF( @ErrorCode <> 0 )
                GOTO Cleanup

            IF (@RowCount <> 0)
                SELECT  @NumTablesDeletedFrom = @NumTablesDeletedFrom + 1
        END
    END

    IF( @TranStarted = 1 )
    BEGIN
	    SET @TranStarted = 0
	    COMMIT TRANSACTION
    END

    RETURN 0

Cleanup:
    SET @NumTablesDeletedFrom = 0

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
	    ROLLBACK TRANSACTION
    END

    RETURN -1

END

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO


INSERT INTO {databaseOwner}aspnet_SchemaVersions
(Feature, CompatibleSchemaVersion, IsCurrentVersion)
VALUES ('common',1,1)
GO
INSERT INTO {databaseOwner}aspnet_SchemaVersions
(Feature, CompatibleSchemaVersion, IsCurrentVersion)
VALUES ('membership',1,1)
GO
INSERT INTO {databaseOwner}aspnet_SchemaVersions
(Feature, CompatibleSchemaVersion, IsCurrentVersion)
VALUES ('profile',1,1)
GO
INSERT INTO {databaseOwner}aspnet_SchemaVersions
(Feature, CompatibleSchemaVersion, IsCurrentVersion)
VALUES ('role manager',1,1)
GO

