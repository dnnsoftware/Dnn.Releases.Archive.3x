'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports DotNetNuke
Imports System.Web.UI.WebControls

Namespace DotNetNuke.Modules.Events

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' The Events Class provides the UI for displaying the Events
	''' </summary>
	''' <returns></returns>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[cnurse]	9/22/2004	Moved Events to a separate Project
	'''		[cnurse]	10/20/2004	Removed ViewOptions from Action menu
	''' </history>
	''' -----------------------------------------------------------------------------
	Public MustInherit Class Events

		Inherits Entities.Modules.PortalModuleBase
		Implements Entities.Modules.IActionable
		Implements Entities.Modules.IPortable
        Implements Entities.Modules.ISearchable

#Region "Controls"

		Protected WithEvents lstEvents As System.Web.UI.WebControls.DataList
		Protected WithEvents calEvents As System.Web.UI.WebControls.Calendar

#End Region

#Region "Private Members"

		Dim arrEvents(31) As String
		Dim intMonth As Integer

#End Region

#Region "Private Methods"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' GetCalendarEvents gets the events for the calendar
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <param name="StartDate">The Start Date</param>
		''' <param name="EndDate">The End Date</param>
		''' <history>
		''' 	[cnurse]	9/22/2004	Moved Events to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub GetCalendarEvents(ByVal StartDate As String, ByVal EndDate As String)
			Try
				Dim objEvents As New EventController
				Dim strDayText As String
				Dim datTargetDate As Date
				Dim datDate As Date
				Dim blnDisplay As Boolean

				Array.Clear(arrEvents, 0, 32)

				Dim Arr As ArrayList = objEvents.GetEvents(ModuleId, Convert.ToDateTime(StartDate), Convert.ToDateTime(EndDate))
				Dim i As Integer
				For i = 0 To Arr.Count - 1

					Dim objEvent As EventInfo = CType(Arr(i), EventInfo)
					'While dr.Read()
					If objEvent.Period.ToString = "" Then
						strDayText = "<br>"
                        If Not objEvent.IconFile = "" Then
                            strDayText += "<img alt=""" & objEvent.AltText & """ src=""" & FormatImage(objEvent.IconFile) & """ border=""0""><br>"
                        End If
                        If IsEditable Then
                            strDayText += "<a href=""" & CType(Common.Globals.ApplicationPath, String) & "/" & glbDefaultPage & "?tabid=" & TabId & "&mid=" & ModuleId & "&ctl=Edit" & "&ItemID=" & objEvent.ItemId & "&VisibleDate=" & calEvents.VisibleDate.ToShortDateString & """><img alt=""" & Localization.GetString("Edit") & """ src=""" & CType(Common.Globals.ApplicationPath, String) & "/images/edit.gif"" border=""0""></a>&nbsp;"
                        End If
                        strDayText += "<span class=""ItemTitle"">" & objEvent.Title & "</span>"
                        If objEvent.DateTime.ToString("HH:mm") <> "00:00" Then
                            strDayText += "<br><span class=""Normal"">" & objEvent.DateTime.ToShortTimeString & "</span>"
                        End If
                        strDayText += "<br><span class=""Normal"">" & Server.HtmlDecode(objEvent.Description) & "</span>"

                        arrEvents(CDate(objEvent.DateTime).Day) += strDayText
                    Else    ' recurring event
						datTargetDate = CType(objEvent.DateTime, Date)
						datDate = Date.Parse(StartDate)
						While datDate <= Date.Parse(EndDate)
							blnDisplay = False
							Select Case objEvent.Period
								Case CType("D", Char)						 ' day
									If DateDiff(DateInterval.Day, datTargetDate.Date, datDate) Mod objEvent.Every = 0 Then
										blnDisplay = True
									End If
								Case CType("W", Char)						 ' week
									If DateAdd(DateInterval.WeekOfYear, DateDiff(DateInterval.WeekOfYear, datTargetDate.Date, datDate), datTargetDate.Date) = datDate Then
										If DateDiff(DateInterval.WeekOfYear, datTargetDate.Date, datDate) Mod objEvent.Every = 0 Then
											blnDisplay = True
										End If
									End If
								Case CType("M", Char)						 ' month
									If DateAdd(DateInterval.Month, DateDiff(DateInterval.Month, datTargetDate.Date, datDate), datTargetDate.Date) = datDate Then
										If DateDiff(DateInterval.Month, datTargetDate.Date, datDate) Mod objEvent.Every = 0 Then
											blnDisplay = True
										End If
									End If
								Case CType("Y", Char)						 ' year
									If DateAdd(DateInterval.Year, DateDiff(DateInterval.Year, datTargetDate.Date, datDate), datTargetDate.Date) = datDate Then
										If DateDiff(DateInterval.Year, datTargetDate.Date, datDate) Mod objEvent.Every = 0 Then
											blnDisplay = True
										End If
									End If
							End Select
							If blnDisplay Then
								If datDate < datTargetDate.Date Then
									blnDisplay = False
								End If
							End If
							If blnDisplay Then
								If Not Common.Utilities.Null.IsNull(objEvent.ExpireDate) Then
									If datDate > CType(objEvent.ExpireDate, Date) Then
										blnDisplay = False
									End If
								End If
							End If
							If blnDisplay Then
								strDayText = "<br>"
                                If Not objEvent.IconFile = "" Then
                                    strDayText += "<img alt=""" & objEvent.AltText & """ src=""" & FormatImage(objEvent.IconFile) & """ border=""0""><br>"
                                End If
                                If IsEditable Then
                                    strDayText += "<a href=""" & CType(Common.Globals.ApplicationPath, String) & "/" & glbDefaultPage & "?tabid=" & TabId & "&mid=" & ModuleId & "&ctl=Edit" & "&ItemID=" & objEvent.ItemId & "&VisibleDate=" & calEvents.VisibleDate.ToShortDateString & """><img alt=""Edit"" src=""" & CType(Common.Globals.ApplicationPath, String) & "/images/edit.gif"" border=""0""></a>&nbsp;"
                                End If
                                strDayText += "<span class=""ItemTitle"">" & objEvent.Title & "</span>"
                                If objEvent.DateTime.ToString("HH:mm") <> "00:00" Then
                                    strDayText += "<br><span class=""Normal"">" & objEvent.DateTime.ToShortTimeString & "</span>"
                                End If
                                strDayText += "<br><span class=""Normal"">" & Server.HtmlDecode(objEvent.Description) & "</span>"

                                arrEvents(datDate.Day) += strDayText
                            End If
							datDate = DateAdd(DateInterval.Day, 1, datDate)
						End While
					End If
				Next

				intMonth = CDate(StartDate).Month

				calEvents.DataBind()

			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

#End Region

#Region "Public Methods"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' FormatDateTime correctly formats a date
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <param name="DateTime">The Date to format</param>
		''' <returns>The formatted date</returns>
		''' <history>
		''' 	[cnurse]	9/22/2004	Moved Events to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Function FormatDateTime(ByVal DateTime As Date) As String
			Try
				FormatDateTime = DateTime.ToLongDateString
				If DatePart(DateInterval.Hour, DateTime) <> 0 Or DatePart(DateInterval.Minute, DateTime) <> 0 Or DatePart(DateInterval.Second, DateTime) <> 0 Then
					FormatDateTime = FormatDateTime & " at " & DateTime.ToShortTimeString
				End If
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' FormatImage correctly formats an icon url
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <param name="IconFile">The icon url to format</param>
		''' <returns>The formatted url</returns>
		''' <history>
		''' 	[cnurse]	9/22/2004	Moved Events to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Function FormatImage(ByVal IconFile As String) As String
			Try
				If Not IconFile = "" Then
					FormatImage = PortalSettings.HomeDirectory & IconFile.ToString
				End If
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try

		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' GetFirstDayofMonth gets the first day of the current month as a string
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <param name="datDate">A day in the current month</param>
		''' <returns>The first day as a string</returns>
		''' <history>
		''' 	[cnurse]	9/22/2004	Moved Events to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Function GetFirstDayofMonth(ByVal datDate As Date) As String
			Try
				Dim datFirstDayofMonth As Date = DateSerial(datDate.Year, datDate.Month, 1)
				Return GetMediumDate(datFirstDayofMonth.ToString)
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' GetLastDayofMonth gets the last day of the current month as a string
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <param name="datDate">A day in the current month</param>
		''' <returns>The last day as a string</returns>
		''' <history>
		''' 	[cnurse]	9/22/2004	Moved Events to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Function GetLastDayofMonth(ByVal datDate As Date) As String
			Try
				Dim intDaysInMonth As Integer = Date.DaysInMonth(datDate.Year, datDate.Month)
				Dim datLastDayofMonth As Date = DateSerial(datDate.Year, datDate.Month, intDaysInMonth)
				Return GetMediumDate(datLastDayofMonth.ToString)
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Function

#End Region

#Region "Event Handlers"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Page_Load runs when the control is loaded
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/22/2004	Moved Events to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try
				Dim EventView As String = CType(Settings("eventview"), String)
				If EventView Is Nothing Then
					EventView = "C"				   ' calendar
				End If

				Dim objEvents As New EventController

				Select Case EventView
					Case "L"				   ' list
						lstEvents.Visible = True
						calEvents.Visible = False

                        lstEvents.DataSource = objEvents.GetEvents(ModuleId, Convert.ToDateTime(Common.Utilities.Null.NullDate), Convert.ToDateTime(Common.Utilities.Null.NullDate))
						lstEvents.DataBind()
					Case "C"				   ' calendar
						lstEvents.Visible = False
						calEvents.Visible = True

						If Not Page.IsPostBack Then
                            If Not Request.QueryString("VisibleDate") Is Nothing Then
                                calEvents.VisibleDate = CType(Request.QueryString("VisibleDate"), Date)
                            Else
                                calEvents.VisibleDate = Now
                            End If

                            If CType(Settings("eventcalendarcellwidth"), String) <> "" Then
                                calEvents.Width = System.Web.UI.WebControls.Unit.Parse(CType(Settings("eventcalendarcellwidth"), String) & "px")
                            End If
                            If CType(Settings("eventcalendarcellheight"), String) <> "" Then
                                calEvents.Height = System.Web.UI.WebControls.Unit.Parse(CType(Settings("eventcalendarcellheight"), String) & "px")
                            End If
                        Else
							If calEvents.VisibleDate = #12:00:00 AM# Then
								calEvents.VisibleDate = Now
							End If
						End If

						Dim StartDate As String = GetFirstDayofMonth(calEvents.VisibleDate) & " 00:00"
						Dim EndDate As String = GetLastDayofMonth(calEvents.VisibleDate) & " 23:59"

						GetCalendarEvents(StartDate, EndDate)

				End Select
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' calEvents_DayRender runs when a day in the calendar renders
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/22/2004	Moved Events to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub calEvents_DayRender(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DayRenderEventArgs) Handles calEvents.DayRender
			Try
				If e.Day.Date.Month = intMonth Then
					Dim ctlLabel As Label = New Label
					ctlLabel.Text = arrEvents(e.Day.Date.Day)
					e.Cell.Controls.Add(ctlLabel)
				End If
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' calEvents_VisibleMonthChanged runs when the visible month changes
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/22/2004	Moved Events to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub calEvents_VisibleMonthChanged(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.MonthChangedEventArgs) Handles calEvents.VisibleMonthChanged
			Try
				Dim StartDate As String = GetFirstDayofMonth(e.NewDate.Date) & " 00:00"
				Dim EndDate As String = GetLastDayofMonth(e.NewDate.Date) & " 23:59"

				GetCalendarEvents(StartDate, EndDate)
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

#End Region

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()

			'declare module actions
		End Sub

#End Region

#Region "Optional Interfaces"

        Public ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
            Get
                Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
                Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.AddContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", EditUrl(), False, Security.SecurityAccessLevel.Edit, True, False)
                Return Actions
            End Get
        End Property

        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Function

        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserId As Integer) Implements Entities.Modules.IPortable.ImportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Sub

        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
        End Function

#End Region
    End Class

End Namespace
