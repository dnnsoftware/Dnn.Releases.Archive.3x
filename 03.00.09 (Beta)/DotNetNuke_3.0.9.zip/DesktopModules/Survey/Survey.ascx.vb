'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke

Namespace DotNetNuke.Modules.Survey

    Public MustInherit Class Survey
        Inherits DotNetNuke.Entities.Modules.PortalModuleBase
        Implements Entities.Modules.IActionable

        Protected WithEvents pnlSurvey As System.Web.UI.WebControls.Panel
        Protected WithEvents lstSurvey As System.Web.UI.WebControls.DataList
        Protected WithEvents cmdSubmit As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdResults As System.Web.UI.WebControls.LinkButton

        Protected WithEvents pnlResults As System.Web.UI.WebControls.Panel
        Protected WithEvents lstResults As System.Web.UI.WebControls.DataList
        Protected WithEvents cmdSurvey As System.Web.UI.WebControls.LinkButton

        Private strCookie As String
        Private strClosingDate As String
        Private blnPersonal As Boolean
        Private blnVoted As Boolean
        Private blnPrivateResults As Boolean

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            strCookie = "_Module" & ModuleId.ToString & "_Survey"

            strClosingDate = CType(Settings("surveyclosingdate"), String)
            If strClosingDate = "" Then
                strClosingDate = Now.ToString
            End If

            ' Check the settings to see if this module is using Personalization for vote tracking
            If Not Settings("surveytracking") Is Nothing Then
                blnPersonal = CType(Settings("surveytracking"), Boolean)
            Else
                blnPersonal = False
            End If

            ' Check the settings to see if the results are Private or Public
            If Not Settings("surveyresultstype") Is Nothing Then
                blnPrivateResults = CType(Settings("surveyresultstype"), Boolean)
            Else
                blnPrivateResults = True
            End If

            If Not Page.IsPostBack Then

                ' If the results are private, hide the links to the results
                If blnPrivateResults And Not DotNetNuke.Security.PortalSecurity.IsInRoles(Me.ModuleConfiguration.AuthorizedEditRoles) Then
                    cmdResults.Visible = False
                End If

                If Request.Cookies(strCookie) Is Nothing And DateDiff(DateInterval.Day, Now, Date.Parse(strClosingDate)) >= 0 Then
                    If blnPersonal = True Then
                        ' This means the module vote tracking is using personalization, so check the database to see if this user has voted
                        ' We first must make sure the user is a registered user who is logged in
                        If UserId <> -1 Then
                            ' Check if the user has voted before
                            If Not DotNetNuke.Services.Personalization.Personalization.GetProfile(ModuleId.ToString, "Voted") Is Nothing Then
                                blnVoted = CType(DotNetNuke.Services.Personalization.Personalization.GetProfile(ModuleId.ToString, "Voted"), Boolean)
                            Else
                                blnVoted = False
                            End If
                            'If not voted before show the Survey items, otherwise just show the results
                            If blnVoted = False Then
                                DisplaySurvey()
                            Else
                                DisplayResults()
                            End If
                        Else
                            ' The User is not logged in and the module is using personalization, so present the user a message that he needs to login first
                            DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("Survey_MustBeSignedIn", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                            cmdSubmit.Visible = False
                            DisplaySurvey()
                        End If
                    Else
                        ' Survey is not personalized, so just show Survey items 
                        DisplaySurvey()
                    End If
                Else
                    ' Survey has expired or cookie was found, so just show the results
                    DisplayResults()
                End If
            End If

        End Sub

        Private Sub DisplaySurvey()

            Dim objSurveys As New SurveyController

            lstSurvey.DataSource = objSurveys.GetSurveys(ModuleId)
            lstSurvey.DataBind()

            pnlSurvey.Visible = True
            pnlResults.Visible = False

            If lstSurvey.Items.Count = 0 Then
                cmdSubmit.Visible = False
                cmdResults.Visible = False
            End If

        End Sub

        Private Sub DisplayResults()

            If Not blnPrivateResults Then
                ' The results are public, so we can show them.

                ' If a cookie has been found or the Survey has expired, we have to hide the button to show the survey items
                If Request.Cookies(strCookie) Is Nothing And DateDiff(DateInterval.Day, Now, Date.Parse(strClosingDate)) >= 0 Then
                    cmdSurvey.Visible = True
                Else
                    cmdSurvey.Visible = False
                End If

                Dim objSurveys As New SurveyController
                lstResults.DataSource = objSurveys.GetSurveys(ModuleId)
                lstResults.DataBind()

                ' Hide the survey items, show the results
                pnlSurvey.Visible = False
                pnlResults.Visible = True
            Else
                ' The survey results are not for public viewing
                If DotNetNuke.Security.PortalSecurity.IsInRoles(PortalSettings.AdministratorRoleId.ToString) Then
                    ' The user is an admin, they need to see the results regardless
                    If Request.Cookies(strCookie) Is Nothing And DateDiff(DateInterval.Day, Now, Date.Parse(strClosingDate)) >= 0 Then
                        cmdSurvey.Visible = True
                    Else
                        cmdSurvey.Visible = False
                    End If

                    Dim objSurveys As New SurveyController
                    lstResults.DataSource = objSurveys.GetSurveys(ModuleId)
                    lstResults.DataBind()
                Else
                    If blnPersonal Then
                        ' Check if the user has voted already
                        If Not DotNetNuke.Services.Personalization.Personalization.GetProfile(ModuleId.ToString, "Voted") Is Nothing Then
                            blnVoted = CType(DotNetNuke.Services.Personalization.Personalization.GetProfile(ModuleId.ToString, "Voted"), Boolean)
                        Else
                            blnVoted = False
                        End If
                    End If
                    'If voted before show a thank you message
                    If blnVoted Or Not Request.Cookies(strCookie) Is Nothing Then
                        ' The user should not be able to see survey results
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("Survey_ThankYou", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        cmdSurvey.Visible = False
                    End If
                End If

                pnlSurvey.Visible = False
                pnlResults.Visible = True
            End If

        End Sub

        Public Function FormatQuestion(ByVal strQuestion As String, ByVal ItemNumber As Integer) As String

            Return ItemNumber.ToString & ". " & strQuestion

        End Function

        Private Sub lstSurvey_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataListItemEventArgs) Handles lstSurvey.ItemDataBound

            Dim objSurveys As New SurveyController
            Dim objSurveyOptions As New SurveyOptionController

            Dim objSurvey As SurveyInfo = objSurveys.GetSurvey(Int32.Parse(lstSurvey.DataKeys(e.Item.ItemIndex).ToString), ModuleId)
            If Not objSurvey Is Nothing Then
                Select Case objSurvey.OptionType
                    Case "R"
                        Dim optOptions As RadioButtonList = CType(e.Item.FindControl("optOptions"), RadioButtonList)
                        optOptions.DataSource = objSurveyOptions.GetSurveyOptions(objSurvey.SurveyId)
                        optOptions.DataBind()
                        optOptions.Visible = True
                    Case "C"
                        Dim chkOptions As CheckBoxList = CType(e.Item.FindControl("chkOptions"), CheckBoxList)
                        chkOptions.DataSource = objSurveyOptions.GetSurveyOptions(objSurvey.SurveyId)
                        chkOptions.DataBind()
                        chkOptions.Visible = True
                End Select
            End If

        End Sub

        Private Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSubmit.Click

            Dim objSurveys As New SurveyController
            Dim objSurvey As SurveyInfo
            Dim intSurvey As Integer
            Dim objSurveyOptions As New SurveyOptionController
            Dim objSurveyOption As SurveyOptionInfo
            Dim intSurveyOption As Integer
            Dim intQuestion As Integer
            Dim intOption As Integer
            Dim blnValid As Boolean = True

            intQuestion = -1
            Dim arrSurveys As ArrayList = objSurveys.GetSurveys(ModuleId)
            For intSurvey = 0 To arrSurveys.Count - 1
                objSurvey = CType(arrSurveys(intSurvey), SurveyInfo)
                intQuestion += 1
                Select Case objSurvey.OptionType
                    Case "R"
                        If Request.Form(lstSurvey.UniqueID & ":_ctl" & intQuestion.ToString & ":optOptions") = "" Then
                            blnValid = False
                        End If
                    Case "C"
                        blnValid = False
                        intOption = -1
                        Dim arrSurveyOptions As ArrayList = objSurveyOptions.GetSurveyOptions(objSurvey.SurveyId)
                        For intSurveyOption = 0 To arrSurveyOptions.Count - 1
                            intOption += 1
                            If Request.Form(lstSurvey.UniqueID & ":_ctl" & intQuestion.ToString & ":chkOptions:" & intOption.ToString) <> "" Then
                                blnValid = True
                            End If
                        Next
                End Select
            Next

            If blnValid Then
                intQuestion = -1
                For intSurvey = 0 To arrSurveys.Count - 1
                    objSurvey = CType(arrSurveys(intSurvey), SurveyInfo)
                    intQuestion += 1
                    Select Case objSurvey.OptionType
                        Case "R"
                            If Request.Form(lstSurvey.UniqueID & ":_ctl" & intQuestion.ToString & ":optOptions") <> "" Then
                                objSurveyOptions.AddSurveyResult(Int32.Parse(Request.Form(lstSurvey.UniqueID & ":_ctl" & intQuestion.ToString & ":optOptions")))
                            End If
                        Case "C"
                            intOption = -1
                            Dim arrSurveyOptions As ArrayList = objSurveyOptions.GetSurveyOptions(objSurvey.SurveyId)
                            For intSurveyOption = 0 To arrSurveyOptions.Count - 1
                                objSurveyOption = CType(arrSurveyOptions(intSurveyOption), SurveyOptionInfo)
                                intOption += 1
                                If Request.Form(lstSurvey.UniqueID & ":_ctl" & intQuestion.ToString & ":chkOptions:" & intOption.ToString) <> "" Then
                                    objSurveyOptions.AddSurveyResult(objSurveyOption.SurveyOptionId)
                                End If
                            Next
                    End Select
                Next

                If blnPersonal = True Then
                    ' This means the module vote tracking is using personalization, so set the profile to show they have voted
                    DotNetNuke.Services.Personalization.Personalization.SetProfile(ModuleId.ToString, "Voted", True)
                    DisplayResults()
                Else
                    ' Store a cookie to show the chart after the submit
                    Dim objCookie As HttpCookie = New HttpCookie("_Module" & ModuleId.ToString & "_Survey")
                    objCookie.Value = "True"
                    objCookie.Expires = DateTime.MaxValue       ' never expires
                    Response.AppendCookie(objCookie)
                    Response.Redirect(Request.RawUrl, True)
                    DisplayResults()
                End If

            Else
                DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("SurveyIncomplete", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
            End If

        End Sub

        Private Sub cmdResults_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdResults.Click

            DisplayResults()

        End Sub

        Private Sub lstResults_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataListItemEventArgs) Handles lstResults.ItemDataBound

            Dim objSurveys As New SurveyController
            Dim objSurvey As SurveyInfo
            Dim intSurvey As Integer
            Dim objSurveyOptions As New SurveyOptionController
            Dim objSurveyOption As SurveyOptionInfo
            Dim intSurveyOption As Integer
            Dim strHTML As String
            Dim intGraphWidth As Integer = 400

            If CType(Settings("surveygraphwidth"), String) <> "" Then
                intGraphWidth = Int32.Parse(CType(Settings("surveygraphwidth"), String))
            End If

            strHTML += "<BR><TABLE BORDER=""0"" CELLPADDING=""2"" CELLSPACING=""0"" WIDTH=""100%"">"

            objSurvey = objSurveys.GetSurvey(Int32.Parse(lstResults.DataKeys(e.Item.ItemIndex).ToString), ModuleId)
            If Not objSurvey Is Nothing Then
                Dim arrSurveyOptions As ArrayList = objSurveyOptions.GetSurveyOptions(objSurvey.SurveyId)
                For intSurveyOption = 0 To arrSurveyOptions.Count - 1
                    objSurveyOption = CType(arrSurveyOptions(intSurveyOption), SurveyOptionInfo)

                    Dim dblPercent As Double = 0
                    If objSurvey.Votes <> 0 Then
                        dblPercent = Convert.ToDouble(objSurveyOption.Votes / objSurvey.Votes)
                    End If
                    strHTML += "<TR>"
                    strHTML += "<TD VALIGN=""top"" CLASS=""YourCompanyNameSurveyResults"">" & objSurveyOption.OptionName & "&nbsp;(" & objSurveyOption.Votes.ToString & ")</TD>"
                    strHTML += "<TD ALIGN=""left"" VALIGN=""top"" CLASS=""Normal"" NOWRAP><IMG SRC=""" & Me.TemplateSourceDirectory & "/red.gif"" WIDTH=""" & (intGraphWidth * dblPercent) & """ BORDER=""0"" HEIGHT=""15"">&nbsp;" & CInt(dblPercent * 100).ToString & "%</TD>"
                    strHTML += "</TR>"
                Next
            End If

            strHTML += "</TABLE>"

            Dim lblResults As Label = CType(e.Item.FindControl("lblResults"), Label)
            lblResults.Text = strHTML
        End Sub

        Private Sub cmdSurvey_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSurvey.Click

            If blnPersonal Then
                ' This means the module vote tracking is using personalization, so check the database to see if this user has voted
                ' We first must make sure the user is a registered user who is logged in
                If UserId <> -1 Then
                    ' Check if the user has voted before
                    If Not DotNetNuke.Services.Personalization.Personalization.GetProfile(ModuleId.ToString, "Voted") Is Nothing Then
                        blnVoted = CType(DotNetNuke.Services.Personalization.Personalization.GetProfile(ModuleId.ToString, "Voted"), Boolean)
                    Else
                        blnVoted = False
                    End If
                    'If not voted before show the Survey items, otherwise just show the results
                    If blnVoted = False Then
                        DisplaySurvey()
                    Else
                        ' The User is not logged in and the module is using personalization, so let the user know they have already voted
                        DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("Survey_AlreadyVoted", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                        ' Hide the submit button because they have already voted
                        cmdSubmit.Visible = False
                        DisplaySurvey()
                    End If
                Else
                    ' The User is not logged in and the module is using personalization, so present the user a message that he needs to login first
                    DotNetNuke.UI.Skins.Skin.AddModuleMessage(Me, Localization.GetString("Survey_MustBeSignedIn", Me.LocalResourceFile), DotNetNuke.UI.Skins.Controls.ModuleMessage.ModuleMessageType.YellowWarning)
                    cmdSubmit.Visible = False
                    DisplaySurvey()
                End If
            Else
                ' Not using personalization tracking so just show it and the cookie will take care of business if necessary
                DisplaySurvey()
            End If

        End Sub

#Region "Optional Interfaces"

        Public ReadOnly Property ModuleActions() As DotNetNuke.Entities.Modules.Actions.ModuleActionCollection Implements DotNetNuke.Entities.Modules.IActionable.ModuleActions
            Get
                Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
                Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.AddContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", EditUrl(), False, Security.SecurityAccessLevel.Edit, True, False)
                Return Actions
            End Get
        End Property

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace