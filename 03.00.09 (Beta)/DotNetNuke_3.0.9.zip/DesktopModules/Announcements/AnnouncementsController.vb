'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.Services.Search
Imports System
Imports System.Configuration
Imports System.Data
Imports System.XML

Namespace DotNetNuke.Modules.Announcements

    ''' -----------------------------------------------------------------------------
    ''' Namespace:  DotNetNuke.Modules.Announcements
    ''' Project:    DotNetNuke
    ''' Class:      AnnouncementsController
    ''' -----------------------------------------------------------------------------
    ''' <summary>
	''' The AnnouncementsController Class represents the Announcments Business Layer
	''' Methods in this class call methods in the Data Layer
	''' </summary>
	''' <returns></returns>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[cnurse]	9/20/2004	Moved Announcements to a separate Project
	''' </history>
	''' -----------------------------------------------------------------------------
	Public Class AnnouncementsController
        Implements Entities.Modules.ISearchable
		Implements Entities.Modules.IPortable

#Region "Public Methods"

		Public Sub AddAnnouncement(ByVal objAnnouncement As AnnouncementInfo)

            DataProvider.Instance().AddAnnouncement(objAnnouncement.ModuleId, objAnnouncement.CreatedByUser, objAnnouncement.Title, objAnnouncement.Url, objAnnouncement.ExpireDate, objAnnouncement.Description, objAnnouncement.ViewOrder)

		End Sub

		Public Sub DeleteAnnouncement(ByVal ItemID As Integer)

			DataProvider.Instance().DeleteAnnouncement(ItemID)

		End Sub

		Public Function GetAnnouncement(ByVal ItemId As Integer, ByVal ModuleId As Integer) As AnnouncementInfo

			Return CType(CBO.FillObject(DataProvider.Instance().GetAnnouncement(ItemId, ModuleId), GetType(AnnouncementInfo)), AnnouncementInfo)

		End Function

		Public Function GetAnnouncements(ByVal ModuleId As Integer) As ArrayList

			Return CBO.FillCollection(DataProvider.Instance().GetAnnouncements(ModuleId), GetType(AnnouncementInfo))

		End Function

		Public Sub UpdateAnnouncement(ByVal objAnnouncement As AnnouncementInfo)

            DataProvider.Instance().UpdateAnnouncement(objAnnouncement.ItemId, objAnnouncement.CreatedByUser, objAnnouncement.Title, objAnnouncement.Url, objAnnouncement.ExpireDate, objAnnouncement.Description, objAnnouncement.ViewOrder)

		End Sub

#End Region

#Region "Optional Interfaces"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetSearchItems implements the ISearchable Interface
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModInfo">The ModuleInfo for the module to be Indexed</param>
        ''' <history>
        '''		[cnurse]	11/17/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            Dim SearchItemCollection As New SearchItemInfoCollection

            Dim Announcements As ArrayList = GetAnnouncements(ModInfo.ModuleID)

            Dim objAnnouncement As Object
            For Each objAnnouncement In Announcements
                Dim SearchItem As SearchItemInfo
                With CType(objAnnouncement, AnnouncementInfo)
                    Dim UserId As Integer = Null.NullInteger
                    If IsNumeric(.CreatedByUser) Then
                        UserId = Integer.Parse(.CreatedByUser)
                    End If
                    SearchItem = New SearchItemInfo(ModInfo.ModuleTitle & " - " & .Title, .Description, UserId, .CreatedDate, ModInfo.ModuleID, .ItemId.ToString, .Description, "ItemId=" & .ItemId.ToString)
                    SearchItemCollection.Add(SearchItem)
                End With
            Next

            Return SearchItemCollection
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ExportModule implements the IPortable ExportModule Interface
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModuleID">The Id of the module to be exported</param>
        ''' <history>
        '''		[cnurse]	11/17/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule

            Dim strXML As String = ""

            Dim arrAnnouncements As ArrayList = GetAnnouncements(ModuleID)
            If arrAnnouncements.Count <> 0 Then
                strXML += "<announcements>"
                Dim objAnnouncement As AnnouncementInfo
                For Each objAnnouncement In arrAnnouncements
                    strXML += "<announcement>"
                    strXML += "<title>" & XMLEncode(objAnnouncement.Title) & "</title>"
                    strXML += "<url>" & XMLEncode(objAnnouncement.Url) & "</url>"
                    strXML += "<expiredate>" & XMLEncode(objAnnouncement.ExpireDate.ToString) & "</expiredate>"
                    strXML += "<description>" & XMLEncode(objAnnouncement.Description) & "</description>"
                    strXML += "<vieworder>" & XMLEncode(objAnnouncement.ViewOrder.ToString) & "</vieworder>"
                    strXML += "</announcement>"
                Next
                strXML += "</announcements>"
            End If

            Return strXML

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ImportModule implements the IPortable ImportModule Interface
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModuleID">The Id of the module to be imported</param>
        ''' <history>
        '''		[cnurse]	11/17/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserId As Integer) Implements Entities.Modules.IPortable.ImportModule

            Dim xmlAnnouncement As XmlNode
            Dim xmlAnnouncements As XmlNode = GetContent(Content, "announcements")
            For Each xmlAnnouncement In xmlAnnouncements
                Dim objAnnouncement As New AnnouncementInfo
                objAnnouncement.ModuleId = ModuleID
                objAnnouncement.Title = xmlAnnouncement.Item("title").InnerText
                objAnnouncement.Url = ImportUrl(ModuleID, xmlAnnouncement.Item("url").InnerText)
                objAnnouncement.ExpireDate = Date.Parse(xmlAnnouncement.Item("expiredate").InnerText)
                objAnnouncement.Description = xmlAnnouncement.Item("description").InnerText
                objAnnouncement.ViewOrder = Integer.Parse(xmlAnnouncement.Item("vieworder").InnerText)
                objAnnouncement.CreatedByUser = UserId.ToString
                AddAnnouncement(objAnnouncement)
            Next

        End Sub

#End Region

    End Class


End Namespace

