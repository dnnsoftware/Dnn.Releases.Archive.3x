'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data
Imports Microsoft.ScalableHosting.Security


Namespace DotNetNuke.Security.Roles


	Public Class RoleController

		Public Sub SynchronizeRoles(ByVal PortalID As Integer)
			Dim OriginalApplicationName As String = Common.Globals.GetApplicationName
			Dim Roles As String()
			Dim objRoleController As New RoleController

			Try
                Common.Globals.SetApplicationName(PortalID)
				Roles = Microsoft.ScalableHosting.Security.Roles.GetAllRoles()
            Finally
                'Reset the Application Name
                Common.Globals.SetApplicationName(OriginalApplicationName)
            End Try

            Dim i As Integer
            For i = 0 To Roles.Length - 1
                If objRoleController.GetRoleByName(PortalID, Roles(i)) Is Nothing Then
                    Dim objRoleInfo As New RoleInfo
                    objRoleInfo.PortalID = PortalID
                    objRoleInfo.RoleName = Roles(i)
                    objRoleController.AddRole(objRoleInfo, True)
                End If
            Next

		End Sub

		Public Function GetPortalRolesByUser(ByVal UserId As Integer, ByVal PortalId As Integer) As String()

			Dim strRoles As String = ""
			Dim dr As IDataReader
			Try
				dr = DataProvider.Instance.GetRolesByUser(UserId, PortalId)
				While dr.Read
					strRoles += CType(dr("RoleName"), String) + "|"
				End While
				If strRoles.IndexOf("|") > 0 Then
					Return Split(Left(strRoles, strRoles.Length - 1), "|")
				Else
					Return Nothing
				End If
			Finally
				If Not dr Is Nothing Then
					dr.Close()
				End If
			End Try
		End Function

		Public Function GetUsersInRole(ByVal PortalID As Integer, ByVal RoleName As String) As ArrayList
			Dim OriginalApplicationName As String = Common.Globals.GetApplicationName
			Dim Users() As String
			Dim arr As New ArrayList

            Try
                Common.Globals.SetApplicationName(PortalID)
                Users = Microsoft.ScalableHosting.Security.Roles.GetUsersInRole(RoleName)
            Finally
                'Reset the Application Name
                Common.Globals.SetApplicationName(OriginalApplicationName)
            End Try

            Dim objRoleController As New RoleController
            Dim objRoleInfo As RoleInfo

            objRoleInfo = objRoleController.GetRoleByName(PortalID, RoleName)

            Dim arrUserRoles As ArrayList
            Dim objUserRole As UserRoleInfo

            Dim i As Integer
            For i = 0 To Users.Length - 1
                arrUserRoles = objRoleController.GetUserRolesByUsername(PortalID, Users(i), RoleName)
                For Each objUserRole In arrUserRoles
                    arr.Add(objUserRole)
                Next
            Next
            Return arr

		End Function

		Public Function GetRolesByUser(ByVal UserId As Integer, ByVal PortalId As Integer) As String()
			Dim OriginalApplicationName As String = Common.Globals.GetApplicationName

            Try
                Common.Globals.SetApplicationName(PortalId)

                Dim objUserController As New UserController
                Dim objUserInfo As UserInfo = objUserController.GetUser(PortalId, UserId)

                Return Microsoft.ScalableHosting.Security.Roles.GetRolesForUser(objUserInfo.Membership.Username)
            Finally
                'Reset the Application Name
                Common.Globals.SetApplicationName(OriginalApplicationName)
            End Try

        End Function

        Public Function GetRoleNames(ByVal PortalID As Integer) As String()
            Dim originalAppName As String = Common.Globals.GetApplicationName()


            Try
                Common.Globals.SetApplicationName(PortalID)
                Dim objRolesController As New Microsoft.ScalableHosting.Security.Roles
                Return objRolesController.GetAllRoles()
            Catch exc As Exception    ' an unexpected error occurred
                LogException(exc)
            Finally
                Common.Globals.SetApplicationName(originalAppName)
            End Try

        End Function

        Public Function GetPortalRoles(ByVal PortalId As Integer) As ArrayList
            Return GetPortalRoles(PortalId, False)
        End Function

        Public Function GetPortalRoles(ByVal PortalId As Integer, ByVal SynchronizeRoles As Boolean) As ArrayList

            If SynchronizeRoles Then
                Me.SynchronizeRoles(PortalId)
            End If
            Return CBO.FillCollection(DataProvider.Instance().GetPortalRoles(PortalId), GetType(RoleInfo))

        End Function


        Public Function GetRoles() As ArrayList

            Return CBO.FillCollection(DataProvider.Instance().GetRoles(), GetType(RoleInfo))

        End Function

        Public Function GetRole(ByVal RoleID As Integer, ByVal PortalID As Integer) As RoleInfo

            Return CType(CBO.FillObject(DataProvider.Instance().GetRole(RoleID, PortalID), GetType(RoleInfo)), RoleInfo)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Obtains a role given the role name
        ''' </summary>
        ''' <param name="PortalId">Portal indentifier</param>
        ''' <param name="RoleName">Name of the role to be found</param>
        ''' <returns>A RoleInfo object is the role is found</returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[VMasanas]	27/08/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetRoleByName(ByVal PortalId As Integer, ByVal RoleName As String) As RoleInfo
            Return GetRoleByName(PortalId, RoleName, False)
        End Function
        Public Function GetRoleByName(ByVal PortalId As Integer, ByVal RoleName As String, ByVal SynchronizeRoles As Boolean) As RoleInfo

            If SynchronizeRoles Then
                Me.SynchronizeRoles(PortalId)
            End If
            Return CType(CBO.FillObject(DataProvider.Instance().GetRoleByName(PortalId, RoleName), GetType(RoleInfo)), RoleInfo)
        End Function
        Public Function AddRole(ByVal objRoleInfo As RoleInfo) As Integer
            Return AddRole(objRoleInfo, False)
        End Function
        Public Function AddRole(ByVal objRoleInfo As RoleInfo, ByVal SynchronizationMode As Boolean) As Integer

            Dim originalAppName As String = Common.Globals.GetApplicationName()
            Try
                If Not SynchronizationMode Then
                    Common.Globals.SetApplicationName(objRoleInfo.PortalID)
                    Microsoft.ScalableHosting.Security.Roles.CreateRole(objRoleInfo.RoleName)
                End If

                Dim RoleId As Integer = -1
                RoleId = DataProvider.Instance().AddRole(objRoleInfo.PortalID, objRoleInfo.RoleName, objRoleInfo.Description, objRoleInfo.ServiceFee, objRoleInfo.BillingPeriod.ToString, objRoleInfo.BillingFrequency, objRoleInfo.TrialFee, objRoleInfo.TrialPeriod, objRoleInfo.TrialFrequency, objRoleInfo.IsPublic, objRoleInfo.AutoAssignment)

                If objRoleInfo.AutoAssignment Then
                    ' loop through users for portal and add to role
                    Dim dr As IDataReader = DataProvider.Instance().GetUsers(objRoleInfo.PortalID)
                    While dr.Read
                        Try
                            DataProvider.Instance().AddUserRole(objRoleInfo.PortalID, Convert.ToInt32(dr("UserId")), RoleId, Null.NullDate)
                        Catch ex As Exception
                            ' user already belongs to role
                        End Try
                    End While
                    dr.Close()
                End If

                Return RoleId
            Finally
                'Reset the Application Name
                Common.Globals.SetApplicationName(originalAppName)
            End Try

        End Function


        Public Sub DeleteRole(ByVal RoleId As Integer, ByVal PortalId As Integer)

            Dim originalAppName As String = Common.Globals.GetApplicationName()
            Try
                Dim objRole As RoleInfo = GetRole(RoleId, PortalId)

                Common.Globals.SetApplicationName(PortalId)
                Microsoft.ScalableHosting.Security.Roles.DeleteRole(objRole.RoleName)

                DataProvider.Instance().DeleteRole(RoleId)
            Finally
                'Reset the Application Name
                Common.Globals.SetApplicationName(originalAppName)
            End Try

        End Sub


        Public Sub UpdateRole(ByVal objRoleInfo As RoleInfo)

            DataProvider.Instance().UpdateRole(objRoleInfo.RoleID, objRoleInfo.Description, objRoleInfo.ServiceFee, objRoleInfo.BillingPeriod.ToString, objRoleInfo.BillingFrequency, objRoleInfo.TrialFee, objRoleInfo.TrialPeriod, objRoleInfo.TrialFrequency, objRoleInfo.IsPublic, objRoleInfo.AutoAssignment)

            If objRoleInfo.AutoAssignment Then
                Dim dr As IDataReader = DataProvider.Instance().GetUsers(objRoleInfo.PortalID)
                While dr.Read
                    Try
                        DataProvider.Instance().AddUserRole(objRoleInfo.PortalID, Convert.ToInt32(dr("UserId")), objRoleInfo.RoleID, Null.NullDate)
                    Catch
                        ' user role already exists
                    End Try
                End While
                dr.Close()
            End If


        End Sub


        Public Function GetUserRole(ByVal PortalID As Integer, ByVal UserId As Integer, ByVal RoleId As Integer) As UserRoleInfo

            Return CType(CBO.FillObject(DataProvider.Instance().GetUserRole(PortalID, UserId, RoleId), GetType(UserRoleInfo)), UserRoleInfo)

        End Function

        Public Function GetUserRolesByUsername(ByVal PortalID As Integer, ByVal Username As String, ByVal Rolename As String) As ArrayList

            Return CBO.FillCollection(DataProvider.Instance().GetUserRolesByUsername(PortalID, Username, Rolename), GetType(UserRoleInfo))

        End Function


        Public Sub AddUserRole(ByVal PortalID As Integer, ByVal UserId As Integer, ByVal RoleId As Integer, ByVal ExpiryDate As Date)

            Dim originalAppName As String = ""
            Try
                Dim objUserController As New UserController
                Dim objUser As UserInfo = objUserController.GetUser(PortalID, UserId)
                Dim objUserRole As UserRoleInfo = GetUserRole(PortalID, UserId, RoleId)

                If objUserRole Is Nothing Then
                    originalAppName = Common.Globals.GetApplicationName
                    Common.Globals.SetApplicationName(PortalID)
                    DataProvider.Instance().AddUserRole(PortalID, UserId, RoleId, ExpiryDate)
                    objUserRole = GetUserRole(PortalID, UserId, RoleId)
                    Microsoft.ScalableHosting.Security.Roles.AddUserToRole(objUser.Membership.Username, objUserRole.RoleName)
                Else
                    DataProvider.Instance().UpdateUserRole(objUserRole.UserRoleID, ExpiryDate)
                End If
            Finally
                If originalAppName <> "" Then
                    'Reset the Application Name
                    Common.Globals.SetApplicationName(originalAppName)
                End If
            End Try


        End Sub


        Public Function DeleteUserRole(ByVal PortalId As Integer, ByVal UserId As Integer, ByVal RoleId As Integer) As Boolean

            Dim originalAppName As String = Common.Globals.GetApplicationName
            Try
                Dim objUserController As New UserController
                Dim objUser As UserInfo = objUserController.GetUser(PortalId, UserId)
                Dim objUserRole As UserRoleInfo = GetUserRole(PortalId, UserId, RoleId)


                Dim objPortals As New PortalController
                Dim blnDelete As Boolean = True

                Dim objPortal As PortalInfo = objPortals.GetPortal(PortalId)
                If Not objPortal Is Nothing Then
                    If (objPortal.AdministratorId <> UserId Or objPortal.AdministratorRoleId <> RoleId) And objPortal.RegisteredRoleId <> RoleId Then
                        Common.Globals.SetApplicationName(PortalId)
                        Microsoft.ScalableHosting.Security.Roles.RemoveUserFromRole(objUser.Membership.Username, objUserRole.RoleName)
                        DataProvider.Instance().DeleteUserRole(UserId, RoleId)
                    Else
                        blnDelete = False
                    End If
                End If

                Return blnDelete
            Finally
                'Reset the Application Name
                Common.Globals.SetApplicationName(originalAppName)
            End Try

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary></summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        ''' <history>
        ''' 	[Nik Kalyani]	10/15/2004	Created multiple signatures to eliminate Optional parameters
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetServices(ByVal PortalId As Integer) As ArrayList
            Return GetServices(PortalId, -1)
        End Function
        Public Function GetServices(ByVal PortalId As Integer, ByVal UserId As Integer) As ArrayList

            Return CBO.FillCollection(DataProvider.Instance().GetServices(PortalId, UserId), GetType(UserRoleInfo))

        End Function


        ''' -----------------------------------------------------------------------------
        ''' <summary></summary>
        ''' <returns></returns>
        ''' <remarks></remarks>
        ''' <history>
        ''' 	[Nik Kalyani]	10/15/2004	Created multiple signatures to eliminate Optional parameters
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub UpdateService(ByVal PortalId As Integer, ByVal UserId As Integer, ByVal RoleId As Integer)
            UpdateService(PortalId, UserId, RoleId, False)
        End Sub

        Public Sub UpdateService(ByVal PortalId As Integer, ByVal UserId As Integer, ByVal RoleId As Integer, ByVal Cancel As Boolean)

            If Cancel Then
                DataProvider.Instance().DeleteUserRole(UserId, RoleId)
            Else
                Dim dr As IDataReader

                Dim UserRoleId As Integer = -1
                Dim ExpiryDate As Date = Now
                Dim IsTrialUsed As Boolean = False
                Dim Period As Integer
                Dim Frequency As String

                dr = DataProvider.Instance().GetUserRole(PortalId, UserId, RoleId)
                If dr.Read Then
                    UserRoleId = Convert.ToInt32(dr("UserRoleId"))
                    If Not IsDBNull(dr("ExpiryDate")) Then
                        ExpiryDate = Convert.ToDateTime(dr("ExpiryDate"))
                    End If
                    If Not IsDBNull(dr("IsTrialUsed")) Then
                        IsTrialUsed = Convert.ToBoolean(dr("IsTrialUsed"))
                    End If
                End If
                dr.Close()

                dr = DataProvider.Instance().GetRole(RoleId, PortalId)
                If dr.Read Then
                    If IsTrialUsed = False And dr("TrialFrequency").ToString <> "N" Then
                        Period = Convert.ToInt32(dr("TrialPeriod"))
                        Frequency = dr("TrialFrequency").ToString
                    Else
                        Period = Convert.ToInt32(dr("BillingPeriod"))
                        Frequency = dr("BillingFrequency").ToString
                    End If
                End If
                dr.Close()

                If ExpiryDate < Now Then
                    ExpiryDate = Now
                End If

                Select Case Frequency
                    Case "N" : ExpiryDate = Null.NullDate
                    Case "O" : ExpiryDate = New System.DateTime(9999, 12, 31)
                    Case "D" : ExpiryDate = DateAdd(DateInterval.Day, Period, Convert.ToDateTime(ExpiryDate))
                    Case "W" : ExpiryDate = DateAdd(DateInterval.Day, (Period * 7), Convert.ToDateTime(ExpiryDate))
                    Case "M" : ExpiryDate = DateAdd(DateInterval.Month, Period, Convert.ToDateTime(ExpiryDate))
                    Case "Y" : ExpiryDate = DateAdd(DateInterval.Year, Period, Convert.ToDateTime(ExpiryDate))
                End Select

                If UserRoleId <> -1 Then
                    DataProvider.Instance().UpdateUserRole(UserRoleId, ExpiryDate)
                Else
                    DataProvider.Instance().AddUserRole(PortalId, UserId, RoleId, ExpiryDate)
                End If
            End If

        End Sub


    End Class

End Namespace
