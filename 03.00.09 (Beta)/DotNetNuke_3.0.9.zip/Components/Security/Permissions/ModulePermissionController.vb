'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System
Imports System.Data
Imports DotNetNuke

Namespace DotNetNuke.Security.Permissions


#Region "ModulePermissionController"
	Public Class ModulePermissionController

		Public Shared Function HasModulePermission(ByVal objModulePermissions As Security.Permissions.ModulePermissionCollection, ByVal PermissionKey As String) As Boolean
			Dim m As Security.Permissions.ModulePermissionCollection = objModulePermissions
			Dim i As Integer
			For i = 0 To m.Count - 1
				Dim mp As Security.Permissions.ModulePermissionInfo
				mp = m(i)
				If mp.PermissionKey = PermissionKey AndAlso PortalSecurity.IsInRoles(mp.RoleName) Then
					Return True
				End If
			Next
			Return False
		End Function


		Public Function GetModulePermission(ByVal modulePermissionID As Integer) As ModulePermissionInfo

			Return CType(CBO.FillObject(DataProvider.Instance().GetModulePermission(modulePermissionID), GetType(ModulePermissionInfo)), ModulePermissionInfo)

		End Function

		Public Function GetModulePermissionsByModuleID(ByVal moduleID As Integer) As ArrayList

			Return CBO.FillCollection(DataProvider.Instance().GetModulePermissionsByModuleID(moduleID, -1), GetType(ModulePermissionInfo))

		End Function

		Public Function GetModulePermissionsByPortal(ByVal PortalID As Integer) As ArrayList
			Dim objModulePermissionController As New Security.Permissions.ModulePermissionController
			Dim arrModulePermissions As ArrayList
			If Not Common.Globals.PerformanceSetting = Common.Globals.PerformanceSettings.NoCaching Then
				arrModulePermissions = CType(DataCache.GetCache("GetModulePermissionsByPortal" & PortalID.ToString), ArrayList)
			End If
			If arrModulePermissions Is Nothing Then
				arrModulePermissions = CBO.FillCollection(DataProvider.Instance().GetModulePermissionsByPortal(PortalID), GetType(ModulePermissionInfo))
				If Not Common.Globals.PerformanceSetting = Common.Globals.PerformanceSettings.NoCaching Then
					DataCache.SetCache("GetModulePermissionsByPortal" & PortalID.ToString, arrModulePermissions)
				End If
			End If
			Return arrModulePermissions
		End Function

		Public Function GetModulePermissionsCollectionByModuleID(ByVal moduleID As Integer) As Security.Permissions.ModulePermissionCollection
			Dim objModulePermissionCollection As IList = New Security.Permissions.ModulePermissionCollection
			CBO.FillCollection(DataProvider.Instance().GetModulePermissionsByModuleID(moduleID, -1), GetType(ModulePermissionInfo), objModulePermissionCollection)
			Return CType(objModulePermissionCollection, Security.Permissions.ModulePermissionCollection)
		End Function

		Public Function GetModulePermissionsCollectionByModuleID(ByVal arrModulePermissions As ArrayList, ByVal moduleID As Integer) As Security.Permissions.ModulePermissionCollection
			Dim objModulePermissionCollection As New Security.Permissions.ModulePermissionCollection(arrModulePermissions, moduleID)
			Return objModulePermissionCollection
		End Function


		Public Sub DeleteModulePermissionsByModuleID(ByVal ModuleID As Integer)

			DataProvider.Instance().DeleteModulePermissionsByModuleID(ModuleID)

		End Sub

		Public Sub DeleteModulePermission(ByVal modulePermissionID As Integer)

			DataProvider.Instance().DeleteModulePermission(modulePermissionID)

		End Sub

		Public Function AddModulePermission(ByVal objModulePermission As ModulePermissionInfo) As Integer

			Return CType(DataProvider.Instance().AddModulePermission(objModulePermission.ModuleID, objModulePermission.PermissionID, objModulePermission.RoleID, objModulePermission.AllowAccess), Integer)

		End Function

		Public Sub UpdateModulePermission(ByVal objModulePermission As ModulePermissionInfo)

			DataProvider.Instance().UpdateModulePermission(objModulePermission.ModulePermissionID, objModulePermission.ModuleID, objModulePermission.PermissionID, objModulePermission.RoleID, objModulePermission.AllowAccess)

		End Sub


		Public Function GetModulePermissionsByModuleID(ByVal arrModulePermissions As ArrayList, ByVal ModuleID As Integer, ByVal PermissionKey As String) As String

			Dim strRoles As String = ";"
			Dim i As Integer
			For i = 0 To arrModulePermissions.Count - 1
				Dim objModulePermission As Security.Permissions.ModulePermissionInfo = CType(arrModulePermissions(i), Security.Permissions.ModulePermissionInfo)
				If objModulePermission.ModuleID = ModuleID AndAlso objModulePermission.AllowAccess = True AndAlso objModulePermission.PermissionKey = PermissionKey Then
					strRoles += GetRoleName(objModulePermission.RoleID) + ";"
				End If
			Next
			Return strRoles
		End Function

		Public Function GetModulePermissionsByModuleID(ByVal arrModulePermissions As ArrayList, ByVal ModuleID As Integer) As Security.Permissions.ModulePermissionCollection

			Dim p As New Security.Permissions.ModulePermissionCollection

			Dim i As Integer
			For i = 0 To arrModulePermissions.Count - 1
				Dim objModulePermission As Security.Permissions.ModulePermissionInfo = CType(arrModulePermissions(i), Security.Permissions.ModulePermissionInfo)
				If objModulePermission.ModuleID = ModuleID Then
					p.Add(objModulePermission)
				End If
			Next
			Return p
		End Function




		Public Function GetRoleNamesFromRoleIDs(ByVal Roles As String) As String

			Dim strRoles As String = ""
			If Roles.IndexOf(";") > 0 Then
				Dim arrRoles As String() = Split(Roles, ";")
				Dim i As Integer
				For i = 0 To arrRoles.Length - 1
					If IsNumeric(arrRoles(i)) Then
						strRoles += GetRoleName(Convert.ToInt32(arrRoles(i))) + ";"
					End If
				Next
			ElseIf Roles.Trim.Length > 0 Then
				strRoles = GetRoleName(Convert.ToInt32(Roles.Trim))
			End If
			If Not strRoles.StartsWith(";") Then
				strRoles += ";"
			End If
			Return strRoles
		End Function


	End Class
#End Region


End Namespace
