'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports DotNetNuke.Entities.Modules.Actions

Namespace DotNetNuke.UI.Containers
	''' -----------------------------------------------------------------------------
	''' Project	 : DotNetNuke
	''' Class	 : Containers.Icon
	''' 
	''' -----------------------------------------------------------------------------
	''' <summary>
	''' Contains the attributes of an Icon.  
	''' These are read into the PortalModuleBase collection as attributes for the icons within the module controls.
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[sun1]	        2/1/2004	Created
	''' 	[Nik Kalyani]	10/15/2004	Replaced public members with properties and removed
	'''                                 brackets from property names
	''' </history>
	''' -----------------------------------------------------------------------------
	Public MustInherit Class PrintModule

        Inherits UI.Skins.SkinObjectBase

#Region " Web Form Designer Generated Code "


		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                Dim objActionBase As ActionBase = FindActionControl(Me.Parent)
                Dim _UserInfo As UserInfo = UserController.GetCurrentUserInfo
                Dim objPortalModule As Entities.Modules.PortalModuleBase = Container.GetPortalModuleBase(Me)

                If Not objActionBase Is Nothing Then

                    Dim action As ModuleAction
                    For Each action In objActionBase.ActionRoot.Actions
                        If action.CommandName = ModuleActionType.PrintModule Then
                            If action.Visible = True And PortalSecurity.HasNecessaryPermission(action.Secure, PortalSettings, objActionBase.ModuleConfiguration, _UserInfo.UserID.ToString) = True Then
                                Dim blnPreview As Boolean = False
                                If Not Request.Cookies("_Tab_Admin_Preview" & PortalSettings.PortalId.ToString) Is Nothing Then
                                    blnPreview = Boolean.Parse(Request.Cookies("_Tab_Admin_Preview" & PortalSettings.PortalId.ToString).Value)
                                End If
                                If blnPreview = False Or (action.Secure = SecurityAccessLevel.Anonymous Or action.Secure = SecurityAccessLevel.View) Then

                                    If objPortalModule.ModuleConfiguration.DisplayPrint Then
                                        Dim ModuleActionIcon As New ImageButton
                                        ModuleActionIcon.ImageUrl = "~/images/" & action.Icon
                                        ModuleActionIcon.ToolTip = action.Title
                                        ModuleActionIcon.ID = "ico" & action.ID.ToString
                                        ModuleActionIcon.CausesValidation = False

                                        AddHandler ModuleActionIcon.Click, AddressOf IconAction_Click

                                        Me.Controls.Add(ModuleActionIcon)
                                    End If

                                End If
                            End If
                        End If
                    Next

                    ' set visibility
                    If Me.Controls.Count > 0 Then
                        Me.Visible = True
                    Else
                        Me.Visible = False
                    End If

                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

        Private Function FindActionControl(ByVal objContainer As Control) As ActionBase

            Dim objChildControl As Control

            For Each objChildControl In objContainer.Controls

                ' check if control is an action control
                If TypeOf objChildControl Is Containers.ActionBase Then
                    Return CType(objChildControl, ActionBase)
                End If

                If objChildControl.HasControls Then
                    ' recursive call for child controls
                    Dim objFoundControl As Control = FindActionControl(objChildControl)

                    If Not (objFoundControl Is Nothing) Then
                        Return CType(objFoundControl, ActionBase)
                    End If
                End If
            Next

            Return Nothing

        End Function

        Private Sub IconAction_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
            Try
                Dim objActionBase As ActionBase = FindActionControl(Me.Parent)
                objActionBase.ProcessAction(DirectCast(sender, ImageButton).ID.Substring(3))
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

    End Class

End Namespace
