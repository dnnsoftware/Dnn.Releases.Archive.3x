'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports DotNetNuke.Services.Search
Imports DotNetNuke.Entities.Modules
Imports System.Text

Namespace DotNetNuke.Common.Utilities

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' The LinkClick Page processes links
	''' </summary>
	''' <returns></returns>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' </history>
	''' -----------------------------------------------------------------------------
    Public MustInherit Class RSS

        Inherits Framework.PageBase

#Region "Controls"

        Protected XML As System.Web.UI.WebControls.Label

#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded.
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            Try
                Dim intPortalId As Integer = PortalSettings.PortalId
                Dim intTabId As Integer = Null.NullInteger
                Dim intModuleId As Integer = Null.NullInteger

                If Not Request.QueryString("tabid") Is Nothing Then
                    intTabId = CType(Request.QueryString("tabid"), Integer)
                End If
                If Not Request.QueryString("moduleid") Is Nothing Then
                    intModuleId = CType(Request.QueryString("moduleid"), Integer)
                End If

                Response.Write(BuildRSS(intPortalId, intTabId, intModuleId))

            Catch exc As Exception

            End Try

        End Sub

#End Region

#Region "Private Methods"

        Private Function BuildRSS(ByVal PortalId As Integer, ByVal TabId As Integer, ByVal ModuleId As Integer) As String

            Dim objModules As New ModuleController
            Dim objModule As ModuleInfo

            Dim sb As New StringBuilder(1024)

            ' build header
            sb.Append("<?xml version=""1.0"" ?>" & ControlChars.CrLf)
            sb.Append("<rss version=""2.0"">" & ControlChars.CrLf)

            ' build channel
            sb.Append(WriteElement("channel", 1))
            sb.Append(WriteElement("title", PortalSettings.PortalName, 2))
            sb.Append(WriteElement("link", Request.Url.Host, 2))
            sb.Append(WriteElement("description", PortalSettings.PortalName, 2))
            sb.Append(WriteElement("language", PortalSettings.DefaultLanguage, 2))
            sb.Append(WriteElement("copyright", PortalSettings.FooterText, 2))
            sb.Append(WriteElement("webMaster", PortalSettings.Email, 2))

            ' build items
            Dim objResults As SearchResultsInfoCollection = SearchDataStoreProvider.Instance.GetSearchItems(PortalId, TabId, ModuleId)
            Dim objResult As SearchResultsInfo
            For Each objResult In objResults
                If PortalSecurity.IsInRoles(PortalSettings.ActiveTab.AuthorizedRoles) Then
                    If PortalSettings.ActiveTab.StartDate < Now And PortalSettings.ActiveTab.EndDate > Now Then
                        objModule = objModules.GetModule(objResult.ModuleId, objResult.TabId)
                        If objModule.DisplaySyndicate = True And objModule.IsDeleted = False Then
                            If PortalSecurity.IsInRoles(objModule.AuthorizedViewRoles) = True Then
                                If CType(IIf(objModule.StartDate = Null.NullDate, Date.MinValue, objModule.StartDate), Date) < Now And CType(IIf(objModule.EndDate = Null.NullDate, Date.MaxValue, objModule.EndDate), Date) > Now Then
                                    sb.Append(BuildItem(objResult, 2))
                                End If
                            End If
                        End If
                    End If
                End If
            Next

            ' close document
            sb.Append(WriteElement("/channel", 1))
            sb.Append("</rss>")

            Return sb.ToString

        End Function

        Private Function BuildItem(ByVal objResult As SearchResultsInfo, ByVal Indent As Integer) As String

            Dim sb As New StringBuilder(1024)

            Dim URL As String = NavigateURL(objResult.TabId)
            If URL.IndexOf(Request.Url.Host) = -1 Then
                URL = AddHTTP(Request.Url.Host) & URL
            End If

            sb.Append(WriteElement("item", Indent))

            sb.Append(WriteElement("title", objResult.Title, Indent + 1))
            sb.Append(WriteElement("description", objResult.Description, Indent + 1))
            sb.Append(WriteElement("link", URL, Indent + 1))
            sb.Append(WriteElement("author", objResult.AuthorName, Indent + 1))
            sb.Append(WriteElement("pubdate", objResult.PubDate.ToString, Indent + 1))
            sb.Append(WriteElement("guid", URL & CType(IIf(objResult.Guid <> "", "&" & objResult.Guid, ""), String), Indent + 1))

            sb.Append(WriteElement("/item", Indent))

            Return sb.ToString

        End Function

        Private Function WriteElement(ByVal Element As String, ByVal Indent As Integer) As String
            Dim InputLength As Integer = Element.Trim.Length + 20
            Dim sb As New StringBuilder(InputLength)
            sb.Append(ControlChars.CrLf.PadRight(Indent + 2, ControlChars.Tab))
            sb.Append("<").Append(Element).Append(">")
            Return sb.ToString
        End Function

        Private Function WriteElement(ByVal Element As String, ByVal ElementValue As String, ByVal Indent As Integer) As String
            Dim InputLength As Integer = Element.Trim.Length + ElementValue.Trim.Length + 20
            Dim sb As New StringBuilder(InputLength)
            sb.Append(ControlChars.CrLf.PadRight(Indent + 2, ControlChars.Tab))
            sb.Append("<").Append(Element).Append(">")
            sb.Append(CleanXmlString(ElementValue))
            sb.Append("</").Append(Element).Append(">")
            Return sb.ToString
        End Function

        Private Function CleanXmlString(ByVal XmlString As String) As String
            XmlString = Replace(XmlString, "&", "&amp;")
            XmlString = Replace(XmlString, "<", "&lt;")
            XmlString = Replace(XmlString, ">", "&gt;")
            Return XmlString
        End Function

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

    End Class

End Namespace
