'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports System.Web
Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Common
Imports DotNetNuke.Framework.Providers
Imports FreeTextBoxControls

Namespace DotNetNuke.HtmlEditor
    Public Class Ftb3HtmlEditorProvider

        Inherits DotNetNuke.Modules.HTMLEditorProvider.HtmlEditorProvider

        Dim cntlFtb As New FreeTextBoxControls.FreeTextBox

        Private Const ProviderType As String = "htmlEditor"

        Private _providerConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration(ProviderType)
        Private _providerPath As String
        Private MyModuleID As Integer


#Region " Provider "

        Public Sub New()

            Dim _portalSettings As PortalSettings = DotNetNuke.Entities.Portals.PortalController.GetCurrentPortalSettings

            'Dim objMyPortalModuleControl As PortalModuleControl = CType(HttpContext.Current.Items("PortalModuleControl"), PortalModuleControl)

            ' Read the configuration specific information for this provider
            Dim objProvider As Provider = CType(_providerConfiguration.Providers(_providerConfiguration.DefaultProvider), Provider)

            _providerPath = objProvider.Attributes("providerPath")

        End Sub


        Public ReadOnly Property ProviderPath() As String
            Get
                Return _providerPath
            End Get
        End Property

#End Region



        Public Overrides Sub Initialize()
            cntlFtb = New FreeTextBoxControls.FreeTextBox

            Dim _portalSettings As PortalSettings = DotNetNuke.Entities.Portals.PortalController.GetCurrentPortalSettings

            'initialize the control
            cntlFtb.ImageGalleryPath = RootImageDirectory

            'AddStyleChooser()
            'AddImageGallery()

            cntlFtb.ButtonImagesLocation = ResourceLocation.ExternalFile
            cntlFtb.JavaScriptLocation = ResourceLocation.ExternalFile
            cntlFtb.ToolbarImagesLocation = ResourceLocation.ExternalFile
            cntlFtb.SupportFolder = DotNetNuke.Common.Globals.ResolveUrl("~/Providers/HtmlEditorProviders/Ftb3HtmlEditorProvider/ftb3/")

            cntlFtb.ToolbarStyleConfiguration = ToolbarStyleConfiguration.Office2003

        End Sub




#Region " Overriding Properties "
        Private _RootImageDirectory As String

        Public Overrides ReadOnly Property HtmlEditorControl() As System.Web.UI.Control
            Get
                Return cntlFtb
            End Get
        End Property

        Public Overrides Property Text() As String
            Get
                Text = cntlFtb.Text
            End Get
            Set(ByVal Value As String)
                cntlFtb.Text = Value
            End Set
        End Property

        Public Overrides Property ControlID() As String
            Get
                ControlID = cntlFtb.ID
            End Get
            Set(ByVal Value As String)
                cntlFtb.ID = Value
            End Set
        End Property

        Public Overrides Property AdditionalToolbars() As ArrayList
            Get

            End Get
            Set(ByVal Value As ArrayList)

            End Set
        End Property

        Public Overrides Property RootImageDirectory() As String
            Get
                If _RootImageDirectory = "" Then
                    Dim _portalSettings As PortalSettings = DotNetNuke.Entities.Portals.PortalController.GetCurrentPortalSettings

					RootImageDirectory = _portalSettings.HomeDirectory.Substring(_portalSettings.HomeDirectory.IndexOf("/Portals/"))
                Else
                    RootImageDirectory = _RootImageDirectory
                End If

            End Get
            Set(ByVal Value As String)
                _RootImageDirectory = Value
            End Set
        End Property

        Public Overrides Property Width() As System.Web.UI.WebControls.Unit
            Get
                'Width = _Width
                Width = cntlFtb.Width
            End Get
            Set(ByVal Value As System.Web.UI.WebControls.Unit)
                '_Width = Value
                cntlFtb.Width = Value
            End Set
        End Property

        Public Overrides Property Height() As System.Web.UI.WebControls.Unit
            Get
                'Height = _Height
                Height = cntlFtb.Height
            End Get
            Set(ByVal Value As System.Web.UI.WebControls.Unit)
                '_Height = Value
                cntlFtb.Height = Value
            End Set
        End Property

#End Region






#Region " Orverriding Subs "

        Public Overrides Sub AddToolbar()

        End Sub

#End Region





#Region " Configuration Helpers "

        Private Sub AddImageGallery()

            Dim myButton As New ToolbarButton("Image Gallery", "FTB_InsertImage3", "insertimage")

			Dim uploadPath As String

            uploadPath = RootImageDirectory


            'ftb.imagegallery.aspx
            myButton.ScriptBlock = "window.open(""~/Providers/HtmlEditorProviders/Ftb3HtmlEditorProvider/ftb3/ftb.imagegallery.aspx?textboxname="" + this.ftb.id + ""&rif=" + uploadPath + "&cif=" + uploadPath + """, ""window"", 'width=600,height=470');"


            Dim tb As New Toolbar
            tb.Items.Add(myButton)

            cntlFtb.Toolbars.Add(tb)
        End Sub

        Private Sub AddStyleChooser()
            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)

            If File.Exists(_portalSettings.HomeDirectory.ToString & "portal.css") Then

                Dim styleMenu As New StylesMenu

                Dim objStreamReader As StreamReader
                Dim strStyleLine As String
                Dim alStyles As New ArrayList
                Dim i As Integer

                cntlFtb.DesignModeCss = _portalSettings.HomeDirectory.ToString & "portal.css"
                objStreamReader = File.OpenText(HttpContext.Current.Server.MapPath(_portalSettings.HomeDirectory.ToString) & "portal.css")

                While objStreamReader.Peek() <> -1
                    strStyleLine = objStreamReader.ReadLine()

                    If Left(Trim(strStyleLine), 1) = "." Then
                        i = strStyleLine.IndexOf(" ")

                        If i <> -1 Then
                            strStyleLine = strStyleLine.Substring(0, i)
                        End If

                        i = strStyleLine.IndexOf("{")

                        If i <> -1 Then
                            strStyleLine = strStyleLine.Substring(0, i)
                        End If

                        alStyles.Add(strStyleLine.Substring(1))
                    End If
                End While

                objStreamReader.Close()

                alStyles.Sort()

                For i = 0 To alStyles.Count - 1
                    Dim myListItem As New FreeTextBoxControls.ToolbarListItem
                    myListItem.Text = CType(alStyles.Item(i), String)
                    myListItem.Value = CType(alStyles.Item(i), String)
                    styleMenu.Items.Add(myListItem)
                Next

                Dim tb As New Toolbar
                tb.Items.Add(styleMenu)

                cntlFtb.Toolbars.Add(tb)

            End If
        End Sub

#End Region





    End Class
End Namespace
