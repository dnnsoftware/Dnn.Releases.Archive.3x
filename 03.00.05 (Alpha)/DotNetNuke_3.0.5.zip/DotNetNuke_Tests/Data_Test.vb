'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Option Explicit On 
Imports System
Imports NUnit.Framework

Namespace DotNetNuke.Diagnostic.Tests

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' CopyrightCop verifies compliance with the copyight notice
	''' that must be included at the top of every *.vb file.
	''' </summary>
	''' <remarks>
	''' CopyrightCop uses the Copyright.txt file in the root
	''' DotNetNuke folder.  All *.vb files must include the
	''' contents of Copyright.txt at the very top of each file.
	''' </remarks>
	''' <history>
	''' 	[dan.caron]	11/11/2004	Created
	''' </history>
	''' -----------------------------------------------------------------------------
	<TestFixture()> Public Class CopyrightCop

#Region "Private Constants"
		Private Const CopyrightTemplate = "../DotNetNuke_Tests/CopyrightTemplate.txt"
#End Region

#Region "Private Variables"

		Private CopyrightErrorCount As Integer = 0
		Private CopyrightDoc As New Hashtable
		Private CopyrightDocLineCount As Integer

#End Region

#Region "Public Methods"

		Public Sub New()
			MyBase.New()
		End Sub

		<SetUp()> Public Sub SetUp()
			LoadCopyrightTemplate()
			CopyrightDocLineCount = CopyrightDoc.Count
		End Sub
		<TearDown()> Public Sub TearDown()

		End Sub
#End Region

#Region "Tests"

		<Test()> Public Sub VerifyCopyrightCompliance()
			Dim Dir As String = "../"

			Dim str As String = RecursiveDirectoryScan(Dir, New System.Text.StringBuilder)

			Assert.AreEqual("", str, str)

		End Sub
#End Region

#Region "Private Methods"

		Private Function RecursiveDirectoryScan(ByVal sourceDir As String, ByVal Errors As System.Text.StringBuilder) As String
			Dim sDir As String
			Dim sFile As String
			Dim sDirInfo As IO.DirectoryInfo

			If Not sourceDir.EndsWith(System.IO.Path.DirectorySeparatorChar.ToString()) Then
				sourceDir &= System.IO.Path.DirectorySeparatorChar
			End If

			For Each sDir In System.IO.Directory.GetDirectories(sourceDir)
				sDirInfo = New System.IO.DirectoryInfo(sDir)
				RecursiveDirectoryScan(sDirInfo.FullName, Errors)
				sDirInfo = Nothing
			Next

			For Each sFile In System.IO.Directory.GetFiles(sourceDir, "*.vb")
				Dim sr As System.IO.StreamReader
				Try
					sr = System.IO.File.OpenText(sFile)
					Dim i As Integer = 1
					Dim Matches As Boolean = True
					Dim OffendingLines As String
					Do While sr.Peek() >= 0
						Dim FileLine As String = sr.ReadLine()
						Dim CorrectLine As String = GetCopyright(i)
						Dim NextCorrectLines(1) As String

						If i + 1 <= CopyrightDocLineCount Then
							NextCorrectLines(0) = (i + 1).ToString + ": " + GetCopyright(i + 1)
							If i + 2 <= CopyrightDocLineCount Then
								NextCorrectLines(1) = (i + 2).ToString + ": " + GetCopyright(i + 2)
							End If
						End If
						If FileLine <> CorrectLine Then
							Matches = False
							OffendingLines = "--> found the following line <--" + vbCrLf + vbTab + i.ToString + ": " + FileLine + vbCrLf + "--> but expected the following lines <--" + vbCrLf + vbTab + i.ToString + ": " + CorrectLine + vbCrLf + vbTab + NextCorrectLines(0) + vbCrLf + vbTab + NextCorrectLines(1)
							Exit Do
						End If
						i += 1
						If i > CopyrightDocLineCount Then Exit Do
					Loop
					If Not Matches Then
						CopyrightErrorCount += 1
						Dim Separator As String = "----------------------------------------------------------------------------------------------------"
						Dim strError As String = vbCrLf + "ERROR #" + CopyrightErrorCount.ToString + ": Invalid Copyright found in " + sFile + ": Line:" + i.ToString + vbCrLf + OffendingLines + vbCrLf + vbCrLf + Separator
						Errors.Append(strError)
						Console.WriteLine(strError)
					End If
				Finally
					sr.Close()
				End Try
			Next
			Return Errors.ToString

		End Function
		Private Function GetCopyright(ByVal LineNumber As Integer) As String
			Return CopyrightDoc(LineNumber.ToString)
		End Function
		Private Function LoadCopyrightTemplate()
			Dim sr As System.IO.StreamReader

			Try
				sr = System.IO.File.OpenText(CopyrightTemplate)
				Dim i As Integer = 0
				Do While sr.Peek() >= 0
					i += 1
					CopyrightDoc.Add(i.ToString, sr.ReadLine())
				Loop
			Finally
				sr.Close()
			End Try

		End Function
#End Region

	End Class
End Namespace
