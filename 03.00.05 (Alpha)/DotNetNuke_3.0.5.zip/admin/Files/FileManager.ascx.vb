'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports ICSharpCode.SharpZipLib.Zip
Imports DotNetNuke.Services.FileSystem.FileManagerFunctions
Imports DotNetNuke
Imports DotNetNuke.UI.WebControls
Imports DotNetNuke.Common.Utilities.FileSystemUtils
Imports DotNetNuke.Services.Localization

Namespace DotNetNuke.Modules.Admin.FileSystem
    ''' -----------------------------------------------------------------------------
    ''' Project	 : DotNetNuke
    ''' Class	 : FileManager
    ''' 
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' Supplies the functionality for uploading files to the Portal
    ''' Synchronizing Files within the folder and the database
    ''' and Provides status of available disk space for the portal
    ''' as well as limiting uploads to the restricted allocated file space
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[DYNST]	2/1/2004	Created
    '''     [Jon Henning]	11/1/2004	Updated to use ClientAPI/DNNTree
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public MustInherit Class FileManager
        Inherits DotNetNuke.Entities.Modules.PortalModuleBase
        Protected WithEvents pnlMainScripts As System.Web.UI.WebControls.Panel
        Protected WithEvents ctrlScripts1 As System.Web.UI.WebControls.Literal
        Protected WithEvents lnkSelectFolder As System.Web.UI.WebControls.LinkButton
        'Protected WithEvents txtCurFolderID As System.Web.UI.WebControls.TextBox
        'Protected WithEvents txtFldScrollPos As System.Web.UI.WebControls.TextBox
        Protected WithEvents pnlScripts As System.Web.UI.WebControls.Panel
        Protected WithEvents txtNewFolder As System.Web.UI.WebControls.TextBox
        Protected WithEvents lnkAddFolder As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lnkDeleteFolder As System.Web.UI.WebControls.LinkButton
        Protected WithEvents Label7 As System.Web.UI.WebControls.Label
        Protected WithEvents lnkRefresh As System.Web.UI.WebControls.LinkButton
        Protected WithEvents Label6 As System.Web.UI.WebControls.Label
        Protected WithEvents lblCopy As System.Web.UI.WebControls.Label
        Protected WithEvents pnlCopyButton As System.Web.UI.WebControls.Panel
        Protected WithEvents lblMove As System.Web.UI.WebControls.Label
        Protected WithEvents lnkUpload As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblUpload As System.Web.UI.WebControls.Label
        Protected WithEvents lblDelete As System.Web.UI.WebControls.Label
        Protected WithEvents pnlEditButtons As System.Web.UI.WebControls.Panel
        Protected WithEvents lnkFilter As System.Web.UI.WebControls.LinkButton
        Protected WithEvents txtFilter As System.Web.UI.WebControls.TextBox
        Protected WithEvents Label5 As System.Web.UI.WebControls.Label
        Protected WithEvents dgFileList As System.Web.UI.WebControls.DataGrid
        Protected WithEvents lblCurPage As System.Web.UI.WebControls.Label
        Protected WithEvents lnkMoveFirst As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lnkMovePrevious As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lnkMoveNext As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lnkMoveLast As System.Web.UI.WebControls.LinkButton
        'Protected WithEvents lnkGetFolderProperties As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblCurFolder As System.Web.UI.WebControls.Label
        ' Protected WithEvents selBrowseMaxReadDepth As System.Web.UI.WebControls.DropDownList
        Protected WithEvents lblItemsPerPage As System.Web.UI.WebControls.Label
        Protected WithEvents selPageSize As System.Web.UI.WebControls.DropDownList
        Protected WithEvents lnkGetMoreNodes As System.Web.UI.WebControls.LinkButton
        Protected WithEvents txtMailData As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtMailText As System.Web.UI.WebControls.TextBox
        'Protected WithEvents txtSourcePath As System.Web.UI.WebControls.TextBox
        'Protected WithEvents txtDestPath As System.Web.UI.WebControls.TextBox
        'Protected WithEvents txtMoveFiles As System.Web.UI.WebControls.TextBox
        'Protected WithEvents txtisMoveing As System.Web.UI.WebControls.TextBox
        Protected WithEvents lnkMoveFiles As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lnkDeleteAllCheckedFiles As System.Web.UI.WebControls.LinkButton
        'Protected WithEvents txtLastPath As System.Web.UI.WebControls.TextBox
        Protected WithEvents lnkCancelMoveFiles As System.Web.UI.WebControls.LinkButton
        'Protected WithEvents txtMoveStartIndex As System.Web.UI.WebControls.TextBox
        Protected WithEvents lnkUploadRedir As System.Web.UI.WebControls.HyperLink
        Protected WithEvents pnlScripts2 As System.Web.UI.WebControls.Panel
        Protected WithEvents tblToolBarFolders As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents Table1 As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents pnlFolders As System.Web.UI.HtmlControls.HtmlGenericControl
        Protected WithEvents tblMessagePager As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents lnkUnzip As System.Web.UI.WebControls.ImageButton
        Protected WithEvents lnkDLFile As LinkButton
        Protected WithEvents lnkEditFile As System.Web.UI.WebControls.ImageButton
        Protected WithEvents lnkOkRename As System.Web.UI.WebControls.ImageButton
        Protected WithEvents lnkDeleteFile As System.Web.UI.WebControls.ImageButton
        Protected WithEvents lnkCancelRename As System.Web.UI.WebControls.ImageButton
        Private _CurRootFolder As String
        Protected WithEvents pnlTreeInitScripts As System.Web.UI.WebControls.Panel
        'Protected WithEvents txtOpenFolders As System.Web.UI.WebControls.TextBox
        Protected WithEvents dgPermissions As DotNetNuke.Security.Permissions.Controls.FolderPermissionsGrid
        Protected WithEvents tblSecurity As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents DNNTree As DotNetNuke.UI.WebControls.DnnTree
        Protected WithEvents txtFldScrollPos As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtLastPath As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtCurFolderID As System.Web.UI.WebControls.TextBox
        Private _DisplayingMessage As Boolean

        Private Enum eImageType
            Folder = 0
            Page = 1
        End Enum

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

            'MyBase.Actions.Add(GetNextActionID, "Add New File(s)", "", URL:=EditURL(, , ), secure:=SecurityAccessLevel.Admin, Visible:=True)
        End Sub

#End Region

        Private m_strParentFolderName As String

        Public ReadOnly Property FolderPortalID() As Integer
            Get
                If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                    Return Null.NullInteger
                Else
                    Return PortalId
                End If
            End Get
        End Property

        Public ReadOnly Property ResourceFile() As String
            Get
                Return Services.Localization.Localization.GetResourceFile(Me, "FileManager.ascx")
            End Get
        End Property

        Public Property Sort() As String
            Get
                Return ViewState("strSort").ToString()
            End Get
            Set(ByVal Value As String)
                ViewState.Add("strSort", Value)
            End Set
        End Property
        Public Property LastSort() As String
            Get
                Return ViewState("strLastSort").ToString()
            End Get
            Set(ByVal Value As String)
                ViewState.Add("strLastSort", Value)
            End Set
        End Property
        Public Property FilterFiles() As String
            Get
                Return ViewState("strFilterFiles").ToString()
            End Get
            Set(ByVal Value As String)
                ViewState.Add("strFilterFiles", Value)
            End Set
        End Property
        Public Property LastPath() As String
            Get
                Return UnMaskPath(DotNetNuke.UI.Utilities.ClientAPI.GetClientVariable(Me.Page, "LastPath"))
            End Get
            Set(ByVal Value As String)
                Value = MaskPath(Value)
                DotNetNuke.UI.Utilities.ClientAPI.RegisterClientVariable(Me.Page, "LastPath", Value, True)
            End Set
        End Property

        Public Property DestPath() As String
            Get
                Return DotNetNuke.UI.Utilities.ClientAPI.GetClientVariable(Me.Page, "DestPath")
            End Get
            Set(ByVal Value As String)
                DotNetNuke.UI.Utilities.ClientAPI.RegisterClientVariable(Me.Page, "DestPath", Value, True)
            End Set
        End Property

        Public Property SourcePath() As String
            Get
                Return DotNetNuke.UI.Utilities.ClientAPI.GetClientVariable(Me.Page, "SourcePath")
            End Get
            Set(ByVal Value As String)
                DotNetNuke.UI.Utilities.ClientAPI.RegisterClientVariable(Me.Page, "SourcePath", Value, True)
            End Set
        End Property

        Public Property MoveFiles() As String
            Get
                Return DotNetNuke.UI.Utilities.ClientAPI.GetClientVariable(Me.Page, "MoveFiles")
            End Get
            Set(ByVal Value As String)
                DotNetNuke.UI.Utilities.ClientAPI.RegisterClientVariable(Me.Page, "MoveFiles", Value, True)
            End Set
        End Property

        Public Property IsRefresh() As Boolean
            Get
                Return CBool(DotNetNuke.UI.Utilities.ClientAPI.GetClientVariable(Me.Page, "IsRefresh"))
            End Get
            Set(ByVal Value As Boolean)
                DotNetNuke.UI.Utilities.ClientAPI.RegisterClientVariable(Me.Page, "IsRefresh", CStr(CInt(Value)), True)
            End Set
        End Property

        Public Property DisabledButtons() As Boolean
            Get
                Return CBool(DotNetNuke.UI.Utilities.ClientAPI.GetClientVariable(Me.Page, "DisabledButtons"))
            End Get
            Set(ByVal Value As Boolean)
                DotNetNuke.UI.Utilities.ClientAPI.RegisterClientVariable(Me.Page, "DisabledButtons", CStr(CInt(Value)), True)
            End Set
        End Property

        Public Property MoveStatus() As String
            Get
                Return DotNetNuke.UI.Utilities.ClientAPI.GetClientVariable(Me.Page, "MoveStatus")
            End Get
            Set(ByVal Value As String)
                DotNetNuke.UI.Utilities.ClientAPI.RegisterClientVariable(Me.Page, "MoveStatus", Value, True)
            End Set
        End Property

        Public ReadOnly Property ParentFolderName() As String
            Get
                If m_strParentFolderName Is Nothing Then
                    If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                        m_strParentFolderName = Request.MapPath(Common.Globals.HostPath)
                    Else
                        m_strParentFolderName = Request.MapPath(PortalSettings.HomeDirectory)
                    End If
                End If
                Return m_strParentFolderName
            End Get
        End Property

        Public Property LastFolderPath() As String
            Get
                If Not ViewState("LastFolderPath") Is Nothing Then
                    Return ViewState("LastFolderPath").ToString
                End If
            End Get
            Set(ByVal Value As String)
                ViewState("LastFolderPath") = Value
                'ViewState("FolderPath") = Me.StripFolderPath(Value) 'PermissionsGrid LoadViewState() NEEDS THIS TO BE SET
            End Set
        End Property

        Public ReadOnly Property PageSize() As Integer
            Get
                Return CInt(selPageSize.SelectedValue)
            End Get
        End Property

        Public Property PageIndex() As Integer
            Get
                If Not ViewState("PageIndex") Is Nothing Then
                    Return CInt(ViewState("PageIndex"))
                End If
            End Get
            Set(ByVal Value As Integer)
                If Value >= 0 AndAlso Value < Me.dgFileList.PageCount Then ViewState("PageIndex") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' The Page_Load server event handler on this user control is used
        ''' to populate the current files from the appropriate PortalUpload Directory or the HostFolder
        ''' and binds this list to the Datagrid
        ''' </summary>
        ''' <param name="sender"></param>
        ''' <param name="e"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[DYNST]	2/1/2004	Created
        '''     [Jon Henning]	11/1/2004	Updated to use ClientAPI/DNNTree
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            Try
                'FileManager requires at a bare minimum the dnn namespace, so regardless of wheter the ClientAPI is disabled of not we 
                'need to register it.
                DotNetNuke.UI.Utilities.ClientAPI.RegisterClientReference(Me.Page, DotNetNuke.UI.Utilities.ClientAPI.ClientNamespaceReferences.dnn)

                DotNetNuke.UI.Utilities.DNNClientAPI.AddBodyOnloadEventHandler(Me.Page, "initFileManager();")
                DotNetNuke.UI.Utilities.ClientAPI.RegisterClientVariable(Me.Page, "UCPrefixID", DNNTree.ClientID.Replace(DNNTree.ID, ""), True)
                DotNetNuke.UI.Utilities.ClientAPI.RegisterClientVariable(Me.Page, "UCPrefixName", DNNTree.UniqueID.Replace(DNNTree.ID, ""), True)
                If DNNTree.IsDownLevel Then
                    Me.DisabledButtons = True
                Else
                    Me.DisabledButtons = False
                End If

                If Page.IsPostBack = False Then

                    InitializeTree()
                    BindData()
                    MoveFiles = ""
                    Me.IsRefresh = True

                    tblToolBarFolders.Visible = True
                    Sort = "FileName"
                    LastSort = "FileName"
                    MoveStatus = ""
                    FilterFiles = ""
                    DestPath = "0\"
                    ReBindFiles()

                End If

                If LastFolderPath <> DestPath Then
                    Me.PageIndex = 0
                    GeneratePermissionsGrid()
                End If
                LastFolderPath = DestPath

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Sets common properties on DNNTree control
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Jon Henning]	11/1/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub InitializeTree()
            DNNTree.SystemImagesPath = ResolveUrl("~/images/")
            DNNTree.ImageList.Add(ResolveUrl("~/images/folder.gif"))
            DNNTree.ImageList.Add(ResolveUrl("~/images/file.gif"))
            DNNTree.IndentWidth = 10
            DNNTree.CollapsedNodeImage = ResolveUrl("~/images/max.gif")
            DNNTree.ExpandedNodeImage = ResolveUrl("~/images/min.gif")
        End Sub

        Private Sub GeneratePermissionsGrid()
            dgPermissions.FolderPath = StripFolderPath(DestPath)
            dgPermissions.GenerateDataGrid()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' The BindData helper method is used to bind the list of
        ''' files for this portal or for the hostfolder, to an asp:DATAGRID server control
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[DYNST]	2/1/2004	Created
        '''     [Jon Henning]	11/1/2004	Updated to use ClientAPI/DNNTree
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Sub BindData()
            If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                _CurRootFolder = Request.MapPath(Common.Globals.HostPath)
            Else
                _CurRootFolder = Request.MapPath(PortalSettings.HomeDirectory)
            End If
            DNNTree.TreeNodes.Clear()
            Dim objNode As TreeNode = AddNode("Portal Root", MaskPath(_CurRootFolder), eImageType.Folder, DNNTree.TreeNodes)
            PopulateTree(objNode.TreeNodes, _CurRootFolder)
            If DNNTree.SelectedTreeNodes.Count = 0 Then objNode.Selected = True
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Populates DNNTree control with folder hiearachy
        ''' </summary>
        ''' <param name="objNodes">Node collection to add children to</param>
        ''' <param name="strPath">Path of parent node</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Jon Henning]	10/26/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub PopulateTree(ByVal objNodes As TreeNodeCollection, ByVal strPath As String)
            Dim aryFolders As String() = Directory.GetDirectories(strPath)
            Dim strFolder As String
            Dim objFile As IO.FileInfo
            Dim objFolder As DirectoryInfo
            Dim objNode As TreeNode
            Dim objOrigFolder As DirectoryInfo = New System.IO.DirectoryInfo(strPath)
            For Each strFolder In aryFolders
                objFolder = New System.IO.DirectoryInfo(strFolder)
                objNode = AddNode(objFolder.Name, MaskPath(objFolder.FullName), eImageType.Folder, objNodes)
                PopulateTree(objNode.TreeNodes, strFolder)
            Next
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Adds node to tree
        ''' </summary>
        ''' <param name="strName">Name of folder to display</param>
        ''' <param name="strKey">Masked Key of folder location</param>
        ''' <param name="eImage">Type of image</param>
        ''' <param name="objNodes">Node collection to add to</param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Jon Henning]	10/26/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddNode(ByVal strName As String, ByVal strKey As String, ByVal eImage As eImageType, ByVal objNodes As TreeNodeCollection) As TreeNode
            Dim objNode As TreeNode
            objNode = New TreeNode(strName)
            objNode.Key = strKey
            objNode.ToolTip = strName
            objNode.ImageIndex = eImage
            objNode.JSFunction = "nodeSelected();"
            objNodes.Add(objNode)
            Return objNode
        End Function

        Private Function UnMaskPath(ByVal strOrigPath As String) As String

            Dim strRootPath As String
            If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                strRootPath = Request.MapPath(Common.Globals.HostPath)
            Else
                strRootPath = Request.MapPath(PortalSettings.HomeDirectory)
            End If
            'If strOrigPath.IndexOf("\") <> -1 Then
            '    strOrigPath = Replace(strOrigPath, "0\", AddTrailingSlash(strRootPath), 1, 1)
            'Else
            '    strOrigPath = Replace(strOrigPath, "0", AddTrailingSlash(strRootPath), 1, 1)
            'End If
            strOrigPath = AddTrailingSlash(strRootPath) & StripFolderPath(strOrigPath)
            Return strOrigPath

        End Function

        Private Function MaskPath(ByVal strOrigPath As String) As String
            Dim strRootPath As String
            If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                strRootPath = Request.MapPath(Common.Globals.HostPath)
            Else
                strRootPath = Request.MapPath(PortalSettings.HomeDirectory)
            End If
            Return Replace(strOrigPath, RemoveTrailingSlash(strRootPath), "0")

        End Function

        Private Function StripFolderPath(ByVal strOrigPath As String) As String
            If strOrigPath.IndexOf("\") <> -1 Then
                Return Replace(strOrigPath, "0\", "", 1, 1)
            Else
                Return Replace(strOrigPath, "0", "", 1, 1)
            End If
        End Function

        Private Function MaskString(ByVal strSource As String) As String
            '_CurRootFolder
            If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                _CurRootFolder = Request.MapPath(Common.Globals.HostPath)
            Else
                _CurRootFolder = Request.MapPath(PortalSettings.HomeDirectory)
            End If
            Return CReplace(strSource, RemoveTrailingSlash(_CurRootFolder), "Portal Root", 1)

        End Function

        Protected Sub lnkDLFile_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs) Handles lnkDLFile.Command
            DotNetNuke.Common.Utilities.FileSystemUtils.DownloadFile(LastPath & "\" & e.CommandArgument.ToString())
            BindData()
        End Sub

        Protected Sub lnkEditFile_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs) Handles lnkEditFile.Command
            dgFileList.EditItemIndex = CType(e.CommandName, Integer)
            ReBindFiles()
            dgFileList.Columns(1).Visible = False

            dgFileList.Columns(2).HeaderStyle.Width = System.Web.UI.WebControls.Unit.Percentage(15)
            SetEditMode()
            MoveFiles = ""
        End Sub

        Protected Sub lnkOkRename_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs) Handles lnkOkRename.Command
            Dim strSourcePath As String
            ' Dim intCurFolderID As Integer = GetCurrentFolderID()
            Dim intItemID As Integer = CType(e.CommandName, Integer)
            strSourcePath = AddTrailingSlash(UnMaskPath(DestPath))

            Dim strFileName As String = e.CommandArgument.ToString()
            Dim txtEdit As TextBox
            txtEdit = CType(dgFileList.Items(intItemID).FindControl("txtEditFileName"), TextBox)

            Dim strSourceFile As String

            strSourceFile = strSourcePath & e.CommandArgument.ToString()

            Dim strDestFile As String = strSourcePath & txtEdit.Text
            Dim strReturn As String = ""
            Dim strFileRenameError As String = ""
            Dim strSetAttributeError As String = ""
            If strSourceFile <> strDestFile Then
                MoveStatus = "move"
                strFileRenameError = Me.MoveFile(strSourceFile, strDestFile)
                strSourceFile = strDestFile
                MoveStatus = ""
            End If
            If strFileRenameError = "" Then
                Dim chkReadOnly As CheckBox = CType(dgFileList.Items(intItemID).FindControl("chkReadOnly"), CheckBox)
                Dim chkHidden As CheckBox = CType(dgFileList.Items(intItemID).FindControl("chkHidden"), CheckBox)
                Dim chkSystem As CheckBox = CType(dgFileList.Items(intItemID).FindControl("chkSystem"), CheckBox)
                Dim chkArchive As CheckBox = CType(dgFileList.Items(intItemID).FindControl("chkArchive"), CheckBox)
                'Dim test = chkArchive.Attributes("original")
                If (chkReadOnly.Attributes("original") <> chkReadOnly.Checked.ToString) Or _
                 (chkHidden.Attributes("original") <> chkHidden.Checked.ToString) Or _
                 (chkSystem.Attributes("original") <> chkSystem.Checked.ToString) Or _
                 (chkArchive.Attributes("original") <> chkArchive.Checked.ToString) Then
                    '  Attributes were change, update 'dem
                    Dim iAttr As Integer
                    If chkReadOnly.Checked Then iAttr += FileAttributes.ReadOnly
                    If chkHidden.Checked Then iAttr += FileAttributes.Hidden
                    If chkSystem.Checked Then iAttr += FileAttributes.System
                    If chkArchive.Checked Then iAttr += FileAttributes.Archive

                    Try
                        DotNetNuke.Common.Utilities.FileSystemUtils.ChangeFileAttributes(strSourceFile, iAttr)
                    Catch ex As Exception
                        strSetAttributeError = ex.Message
                    End Try

                End If
            End If

            If strFileRenameError <> "" Then
                strFileRenameError = "Error Renaming File: <BR>" & strFileRenameError
                ShowErrorMessage(MaskString(strFileRenameError))
            End If
            If strSetAttributeError <> "" Then
                strSetAttributeError = "Errors Occured While Attempting to Change File Attributes"
                ShowErrorMessage(strSetAttributeError)
            End If

            dgFileList.EditItemIndex = -1
            ReBindFiles()
            dgFileList.Columns(1).Visible = True
            dgFileList.Columns(2).HeaderStyle.Width = System.Web.UI.WebControls.Unit.Percentage(7)

        End Sub

        Protected Sub DeleteFiles(ByVal strFiles As String)
            Dim arFiles() As String = Split(strFiles, ";")
            Dim i As Integer
            If arFiles.Length = 0 Then
                Exit Sub
            End If
            Dim strSourcePath As String
            Dim strErrorMessage As String = ""
            Dim strCurError As String
            ' Dim intCurFolderID As Integer = GetCurrentFolderID()
            strSourcePath = AddTrailingSlash(LastPath)

            For i = 0 To arFiles.Length - 1
                If arFiles(i) <> "" Then
                    strCurError = DeleteFile(strSourcePath & arFiles(i))
                    If strCurError <> "" Then
                        strErrorMessage = strErrorMessage & Localization.GetString("ErrorDeletingFile", Me.ResourceFile) & _
                         AddTrailingSlash(UnMaskPath(DestPath)) & arFiles(i) & "<BR>&nbsp;&nbsp;&nbsp;" & strCurError & "<BR>"
                    End If
                End If
            Next
            If strErrorMessage = "" Then
                MoveFiles = ""
                ReBindFiles()
            Else
                strErrorMessage = MaskString(strErrorMessage)
                ShowErrorMessage(strErrorMessage)

                MoveFiles = ""
                ReBindFiles()

            End If
        End Sub

        Public Function DeleteFile(ByVal strSourceFile As String) As String
            Try
                DotNetNuke.Common.Utilities.FileSystemUtils.DeleteFile(strSourceFile)
            Catch ex As Exception
                Return ex.Message
            End Try
        End Function

        Public Function MoveFile(ByVal strSourceFile As String, ByVal strDestFile As String) As String
            Dim result As String = ""

            Try
                Dim finfo As New System.IO.FileInfo(strSourceFile)
                If MoveStatus = "copy" Then
                    finfo.CopyTo(strDestFile)
                ElseIf MoveStatus = "move" Then
                    Dim strFileName As String = System.IO.Path.GetFileName(strDestFile)
                    Dim strExtension As String = Path.GetExtension(strFileName).Replace(".", "")
                    Dim imgImage As System.Drawing.Image
                    Dim imageWidth As Integer
                    Dim imageHeight As Integer
                    Dim strContentType As String
                    Select Case strExtension
                        Case "txt" : strContentType = "text/plain"
                        Case "htm", "html" : strContentType = "text/html"
                        Case "rtf" : strContentType = "text/richtext"
                        Case "jpg", "jpeg" : strContentType = "image/jpeg"
                        Case "gif" : strContentType = "image/gif"
                        Case "bmp" : strContentType = "image/bmp"
                        Case "mpg", "mpeg" : strContentType = "video/mpeg"
                        Case "avi" : strContentType = "video/avi"
                        Case "pdf" : strContentType = "application/pdf"
                        Case "doc", "dot" : strContentType = "application/msword"
                        Case "csv", "xls", "xlt" : strContentType = "application/x-msexcel"
                        Case Else : strContentType = "application/octet-stream"
                    End Select

                    If Convert.ToBoolean(InStr(1, glbImageFileTypes & ",", strExtension.ToLower & ",")) Then
                        Try
                            imgImage = imgImage.FromFile(strSourceFile)
                            imageHeight = imgImage.Height
                            imageWidth = imgImage.Width
                            imgImage.Dispose()
                        Catch
                            ' error loading image file
                            strContentType = "application/octet-stream"
                        End Try
                    End If

                    Dim ParentFolderName As String
                    If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                        ParentFolderName = Request.MapPath(Common.Globals.HostPath)
                    Else
                        ParentFolderName = Request.MapPath(PortalSettings.HomeDirectory)
                    End If
                    Dim SourceFolderName As String = strSourceFile.Replace(strFileName, "")
                    SourceFolderName = SourceFolderName.Replace(ParentFolderName, "").Replace("\", "/")

                    Dim DestFolderName As String = strDestFile.Replace(strFileName, "")
                    DestFolderName = DestFolderName.Replace(ParentFolderName, "").Replace("\", "/")

                    Dim objFileController As New DotNetNuke.Services.FileSystem.FileController
                    objFileController.UpdateFile(PortalId, strFileName, strExtension, finfo.Length, imageWidth, imageHeight, strContentType, SourceFolderName, DestFolderName)
                    finfo.MoveTo(strDestFile)
                ElseIf MoveStatus = "unzip" Then
                    Dim strReturn As String = UnzipFile(strSourceFile, UnMaskPath(DestPath))
                    BindData()
                    Return strReturn
                End If

            Catch ex As Exception
                Return ex.Message

            End Try

        End Function

        Public Sub SetEditMode()
            'called when rename-file
            If dgFileList.EditItemIndex > -1 Then
                Dim intCount As Integer = dgFileList.Items.Count
                Dim chkFile2 As CheckBox
                Dim chkFile As CheckBox
                Dim lnkDeleteFile As ImageButton
                Dim lnkEditFile As ImageButton
                Dim i As Integer
                For i = 0 To intCount - 1
                    If i <> dgFileList.EditItemIndex Then
                        chkFile2 = CType(dgFileList.Items(i).FindControl("chkFile2"), CheckBox)
                        chkFile = CType(dgFileList.Items(i).FindControl("chkFile"), CheckBox)
                        lnkDeleteFile = CType(dgFileList.Items(i).FindControl("lnkDeleteFile"), ImageButton)
                        lnkEditFile = CType(dgFileList.Items(i).FindControl("lnkEditFile"), ImageButton)
                        If Not (chkFile2) Is Nothing Then chkFile2.Enabled = False
                        If Not (chkFile) Is Nothing Then chkFile.Enabled = False
                        If Not (lnkDeleteFile) Is Nothing Then
                            lnkDeleteFile.Enabled = False
                            lnkDeleteFile.ImageUrl = "~/images/FileManager/DNNExplorer_trash_disabled.gif"
                            lnkDeleteFile.AlternateText = ""

                        End If
                        If Not (lnkEditFile) Is Nothing Then
                            lnkEditFile.Enabled = False
                            lnkEditFile.ImageUrl = "~/images/FileManager/DNNExplorer_Edit_disabled.gif"
                            lnkEditFile.AlternateText = ""


                        End If
                        chkFile2 = Nothing
                        chkFile = Nothing
                        lnkDeleteFile = Nothing
                        lnkEditFile = Nothing

                    End If
                Next
                Me.DisabledButtons = True

            Else

            End If


        End Sub

        Public Function GetCheckAllString() As String
            Dim intCount As Integer = dgFileList.Items.Count

            Dim chkFile As CheckBox
            Dim i As Integer
            Dim strResult As String
            strResult = "setMoveFiles('');" & vbCrLf
            For i = 0 To intCount - 1
                chkFile = CType(dgFileList.Items(i).FindControl("chkFile"), CheckBox)
                If Not (chkFile) Is Nothing Then
                    strResult = strResult & "var chk1 = dnn.dom.getById('" & chkFile.ClientID & "');"
                    strResult = strResult & "chk1.checked = blValue;" & vbCrLf
                    strResult = strResult & "if (!chk1.onclick) {chk1.parentElement.onclick();}else{chk1.onclick();}" & vbCrLf
                End If
            Next
            strResult = "function CheckAllFiles(blValue) {" & strResult & "}" & vbCrLf
            strResult = strResult & "function gridCheckAll(sender) {" & vbCrLf
            strResult = strResult & "var blValue;" & vbCrLf
            strResult = strResult & "if (!blAllFilesChecked) {blValue=true;blAllFilesChecked=true;CheckAllFiles(true);sender.src=sender.src.replace('checked', 'unchecked');} else {blValue=false;CheckAllFiles(false);blAllFilesChecked=false;sender.src=sender.src.replace('unchecked', 'checked');}" & vbCrLf
            strResult = strResult & "return false;" & vbCrLf
            strResult = strResult & "}" & vbCrLf

            strResult = "<script language=javascript>" & strResult & "</script>"

            Return strResult
        End Function

        Protected Overrides Sub Render(ByVal output As System.Web.UI.HtmlTextWriter)

            Dim strTemp As String = GetCheckAllString()

            pnlScripts2.Controls.Add(New LiteralControl(strTemp))
            If dgFileList.Items.Count <= 10 And dgFileList.PageCount = 1 Then
                dgFileList.PagerStyle.Visible = False
            End If

            MyBase.Render(output)
        End Sub
        Public Sub SetToolbarEditMode()
            EnableCopyButton(True)
            SetFileEditMode(True)
            SetFolderEditMode(True)
        End Sub
        Public Sub EnableCopyButton(ByVal blValue As Boolean)
            pnlCopyButton.Visible = blValue
            dgFileList.Columns(6).Visible = blValue
        End Sub
        Public Sub SetFileEditMode(ByVal blValue As Boolean)
            pnlEditButtons.Visible = blValue
            dgFileList.Columns(1).HeaderStyle.HorizontalAlign = HorizontalAlign.Right
            dgFileList.Columns(2).Visible = blValue
            dgFileList.Columns(4).Visible = blValue
            dgFileList.Columns(5).Visible = blValue
        End Sub
        Public Sub SetFolderEditMode(ByVal blValue As Boolean)
            tblToolBarFolders.Visible = blValue
        End Sub

        Protected Sub lnkDeleteFile_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs) Handles lnkDeleteFile.Command
            DeleteFiles(e.CommandName)
        End Sub

        Protected Sub lnkMoveNext_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs) Handles lnkMoveNext.Command
            Me.PageIndex += 1
            Me.ReBindFiles()
        End Sub

        Protected Sub lnkMovePrevious_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs) Handles lnkMovePrevious.Command
            Me.PageIndex -= 1
            Me.ReBindFiles()
        End Sub

        Protected Sub lnkMoveFirst_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs) Handles lnkMoveFirst.Command
            Me.PageIndex = 0
            Me.ReBindFiles()
        End Sub

        Protected Sub lnkMoveLast_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs) Handles lnkMoveLast.Command
            Me.PageIndex = Me.dgFileList.PageCount - 1
            Me.ReBindFiles()
        End Sub

        Private Sub selPageSize_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles selPageSize.SelectedIndexChanged
            ReBindFiles()
        End Sub

        Protected Sub ReBindFiles()
            Dim strSourcePath As String = UnMaskPath(DestPath)
            LastPath = strSourcePath

            dgFileList.PageSize = Me.PageSize
            dgFileList.CurrentPageIndex = Me.PageIndex

            GetFilesByFolder(AddTrailingSlash(strSourcePath))

            If dgFileList.PageCount > 1 Then
                tblMessagePager.Visible = True
                lblCurPage.Text = "Page " & (dgFileList.CurrentPageIndex + 1) & _
                 " of " & (dgFileList.PageCount) & "."
            Else
                tblMessagePager.Visible = False
            End If
        End Sub

        Public Sub GetFilesByFolder(ByVal strFolderName As String)

            SetToolbarEditMode()    'Need to exit sub if SetToolBarEdit mode cannot verify folder
            Dim tblFiles As DataTable = GetFileTable()
            Dim objFile As FileInfo
            Dim objDir As DirectoryInfo = New DirectoryInfo(strFolderName)
            Dim dv As DataView = New DataView

            For Each objFile In objDir.GetFiles()
                AddFileToTable(tblFiles, objFile)
            Next

            dv.Table = tblFiles
            dv.Sort = Sort
            If FilterFiles <> "" Then
                dv.RowFilter = "FileName like '%" & Me.FilterFiles & "%'"
            End If

            Me.dgFileList.DataSource = dv
            dgFileList.DataBind()

            If dgFileList.PageCount > 1 Then
                tblMessagePager.Visible = True
                lblCurPage.Text = "Page " & (dgFileList.CurrentPageIndex + 1) & _
                 " of " & (dgFileList.PageCount) & "."
            Else
                tblMessagePager.Visible = False
            End If
        End Sub

        Private Sub AddFileToTable(ByVal tblFiles As DataTable, ByVal objFile As FileInfo)
            Dim dRow As DataRow
            dRow = tblFiles.NewRow
            dRow("FileName") = objFile.Name

            dRow("FileSize") = Microsoft.VisualBasic.Format(objFile.Length, "##,##0")
            dRow("intFileSize") = objFile.Length
            If Not objFile.Extension = "" Or Not objFile.Extension Is Nothing Then
                dRow("Extention") = objFile.Extension
            Else
                dRow("Extention") = "none"
            End If
            dRow("DateModified") = objFile.LastWriteTime
            'strAttributes = GetAttributeString(finfo.Attributes.ToString)
            dRow("Archive") = objFile.Attributes And FileAttributes.Archive
            dRow("ReadOnly") = objFile.Attributes And FileAttributes.ReadOnly
            dRow("Hidden") = objFile.Attributes And FileAttributes.Hidden
            dRow("System") = objFile.Attributes And FileAttributes.System
            'dRow("AttributeString") = strAttributes
            tblFiles.Rows.Add(dRow)

        End Sub

        Private Function GetFileTable() As DataTable
            Dim tblFiles As New DataTable("Files")
            Dim myColumns As New DataColumn
            Dim dRow As DataRow
            myColumns.DataType = System.Type.GetType("System.String")
            myColumns.ColumnName = "FileName"
            tblFiles.Columns.Add(myColumns)
            myColumns = New DataColumn

            myColumns.DataType = System.Type.GetType("System.String")

            myColumns.ColumnName = "FileSize"
            tblFiles.Columns.Add(myColumns)


            myColumns = New DataColumn
            myColumns.DataType = System.Type.GetType("System.Int32")
            myColumns.ColumnName = "IntFileSize"
            tblFiles.Columns.Add(myColumns)

            myColumns = New DataColumn
            myColumns.DataType = System.Type.GetType("System.DateTime")
            myColumns.ColumnName = "DateModified"
            tblFiles.Columns.Add(myColumns)

            myColumns = New DataColumn
            myColumns.DataType = System.Type.GetType("System.Boolean")
            myColumns.ColumnName = "ReadOnly"
            tblFiles.Columns.Add(myColumns)

            myColumns = New DataColumn
            myColumns.DataType = System.Type.GetType("System.Boolean")
            myColumns.ColumnName = "Hidden"
            tblFiles.Columns.Add(myColumns)

            myColumns = New DataColumn
            myColumns.DataType = System.Type.GetType("System.Boolean")
            myColumns.ColumnName = "System"
            tblFiles.Columns.Add(myColumns)

            myColumns = New DataColumn
            myColumns.DataType = System.Type.GetType("System.Boolean")
            myColumns.ColumnName = "Archive"
            tblFiles.Columns.Add(myColumns)

            myColumns = New DataColumn
            myColumns.DataType = System.Type.GetType("System.String")
            myColumns.ColumnName = "AttributeString"
            tblFiles.Columns.Add(myColumns)

            myColumns = New DataColumn
            myColumns.DataType = System.Type.GetType("System.String")
            myColumns.ColumnName = "Extention"
            tblFiles.Columns.Add(myColumns)

            Return tblFiles

        End Function

        Public Function GetAttributeString(ByVal strSource As String) As String
            Dim strResult As String = strSource
            strResult = Replace(strResult, "ReadOnly", "R")
            strResult = Replace(strResult, "Hidden", "H")
            strResult = Replace(strResult, "System", "S")
            strResult = Replace(strResult, "Archive", "A")
            strResult = Replace(strResult, ",", "")
            strResult = Replace(strResult, "Normal", "")
            Return strResult
        End Function

        Public Sub ShowErrorMessage(ByVal strMessage As String)
            strMessage = Replace(strMessage, "\", "\\")
            strMessage = Replace(strMessage, "'", "\'")
            strMessage = Replace(strMessage, vbCrLf, "\n")
            strMessage = "<TABLE><TR><TD height=100% class=NormalRed>" & strMessage & _
             "</TD></TR><TR valign=bottom><TD align=center><INPUT id=btnClearError onclick=clearErrorMessage(); type=button value=OK>" & _
             "<TD><TR></TABLE>"

            _DisplayingMessage = True
            DotNetNuke.UI.Utilities.ClientAPI.RegisterClientVariable(Me.Page, "ErrorMessage", strMessage, True)
        End Sub

        Private Sub lnkSelectFolder_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs) Handles lnkSelectFolder.Command
            dgFileList.CurrentPageIndex = 0

            Dim strSourcePath As String

            strSourcePath = DestPath
            Dim strFriendlyPath As String = Replace(strSourcePath, "0\", "Portal Root\")

            lnkDeleteFolder.Attributes.Add("onclick", "return confirm('Delete Folder: " & _
             strFriendlyPath & " ?');")

            strSourcePath = UnMaskPath(strSourcePath.Replace("\\", "\"))

            LastPath = strSourcePath
            GetFilesByFolder(AddTrailingSlash(strSourcePath))

        End Sub

        Private Sub dgFileList_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataGridItemEventArgs) Handles dgFileList.ItemDataBound
            Dim imgFileICO As System.Web.UI.WebControls.Image
            Dim lnkEditFile As ImageButton
            Dim chkFile As CheckBox

            Dim lnkDeleteFile As ImageButton
            Dim lnkUnzip As ImageButton
            Dim lnkOkRename As ImageButton
            Dim strExtention As String = ""
            Dim blEnabled As Boolean = True
            Dim strInternalPath As String = "~/images/FileManager/Icons/"
            If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.EditItem Or e.Item.ItemType = ListItemType.AlternatingItem Or e.Item.ItemType = ListItemType.SelectedItem Then
                chkFile = CType(e.Item.FindControl("chkFile"), CheckBox)
                If Not chkFile Is Nothing Then
                    If e.Item.ItemType = ListItemType.AlternatingItem Then
                        chkFile.Attributes.Add("onclick", "addFileToMoveList('" & chkFile.Attributes("filename") & _
                        "', this, '#" & GetColorFromARGBColor(dgFileList.SelectedItemStyle.BackColor) & _
                        "', '#" & GetColorFromARGBColor(dgFileList.AlternatingItemStyle.BackColor) & _
                        "');")
                    Else
                        chkFile.Attributes.Add("onclick", "addFileToMoveList('" & chkFile.Attributes("filename") & _
                        "', this, '#" & GetColorFromARGBColor(dgFileList.SelectedItemStyle.BackColor) & _
                        "', '#" & GetColorFromARGBColor(dgFileList.ItemStyle.BackColor) & _
                        "');")
                    End If

                End If

                lnkEditFile = CType(e.Item.FindControl("lnkEditFile"), System.Web.UI.WebControls.ImageButton)
                If Not lnkEditFile Is Nothing Then
                    lnkEditFile.CommandName = e.Item.ItemIndex.ToString
                End If
                lnkUnzip = CType(e.Item.FindControl("lnkUnzip"), System.Web.UI.WebControls.ImageButton)
                If Not lnkUnzip Is Nothing Then

                    If lnkUnzip.Attributes("extension") <> ".zip" Then
                        lnkUnzip.Visible = False
                    Else
                        If e.Item.ItemType = ListItemType.EditItem Then
                            lnkUnzip.Visible = False

                        Else
                            lnkUnzip.Attributes.Add("onclick", "return unzipFile('" & chkFile.Attributes("filename") & "');")
                        End If


                    End If
                End If
                lnkDeleteFile = CType(e.Item.FindControl("lnkDeleteFile"), System.Web.UI.WebControls.ImageButton)
                If Not lnkDeleteFile Is Nothing Then
                    'lnkDeleteFile.CommandName = e.Item.ItemIndex
                    If dgFileList.EditItemIndex = -1 Then
                        lnkDeleteFile.Attributes.Add("onclick", "return confirm('Delete File: " & _
                        lnkDeleteFile.CommandName & " ?');")

                    End If
                End If
                lnkOkRename = CType(e.Item.FindControl("lnkOkRename"), System.Web.UI.WebControls.ImageButton)
                If Not lnkOkRename Is Nothing Then
                    lnkOkRename.CommandName = e.Item.ItemIndex.ToString
                End If

                imgFileICO = CType(e.Item.FindControl("imgFileICO"), System.Web.UI.WebControls.Image)
                If imgFileICO Is Nothing Then
                    imgFileICO = CType(e.Item.FindControl("imgFileEditICO"), System.Web.UI.WebControls.Image)

                End If
                If Not imgFileICO Is Nothing Then
                    'NOTE: Due to MediumTrust issues, we are no longer using registry calls and unmanaged code calls to get icon.  For now always use same icon.

                    'strExtention = imgFileICO.Attributes.Item("Extention")
                    'Dim fInfo As New System.IO.FileInfo(Server.MapPath(strInternalPath) & "fm_16" & strExtention & "_icon.png")


                    'If fInfo.Exists = False Then
                    '    'create image from resource
                    '    Dim arResource() As String = arGetIconResource("test" & strExtention)
                    '    Dim Icon1 As Icon       '("32", "32", PixelFormat.Format32bppArgb)
                    '    Icon1 = imgGetIconAsBitMapFromResource(arResource(0), CType(arResource(1), Integer))
                    '    Dim bm1 As New Bitmap(Icon1.Size.Width, Icon1.Size.Height, PixelFormat.Format32bppArgb)
                    '    bm1 = Icon1.ToBitmap

                    '    bm1.MakeTransparent(Icon1.ToBitmap.GetPixel(0, 0))


                    '    Dim dlg As System.Drawing.Image.GetThumbnailImageAbort
                    '    Dim intptr1 As IntPtr
                    '    intptr1 = IntPtr.Zero



                    '    Dim dinfo As New DirectoryInfo(Server.MapPath(strInternalPath))

                    '    If Not dinfo.Exists Then dinfo.Create()


                    '    bm1.GetThumbnailImage(16, 16, dlg, intptr1).Save(Server.MapPath(strInternalPath) & "fm_16" & strExtention & "_icon.png")

                    '    bm1.Dispose()

                    'End If
                    imgFileICO.ImageUrl = ResolveUrl("~/images/file.gif") 'strInternalPath & "fm_16" & strExtention & "_icon.png"
                End If
            End If    '

        End Sub

        Private Sub lnkMoveFiles_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs) Handles lnkMoveFiles.Command
            Dim arFiles() As String
            arFiles = Split(MoveFiles, ";")
            Dim i As Integer
            Dim strSourceFile As String
            Dim strDestFile As String
            Dim strErrorMessages As String = ""
            Dim strCurErrorMessage As String = ""
            Dim intSize As Long
            Dim Finfo As System.IO.FileInfo

            Dim strSourcePath As String
            Dim strDestPath As String
            strDestPath = AddTrailingSlash(UnMaskPath(DestPath))

            strSourcePath = AddTrailingSlash(UnMaskPath(SourcePath))


            'Dim intCurFolderID As Integer = 0

            If MoveStatus = "unzip" Then
                Dim intTempSize As Long
                For i = 0 To arFiles.Length - 1
                    If arFiles(i) <> "" Then

                        intTempSize = GetZipFileExtractSize(strSourcePath & arFiles(i))

                        If intTempSize = -1 Then

                            Exit Sub        'GetZipFileExtractSize errored (should have error message ready...)
                        Else
                            intSize = intSize + intTempSize
                        End If
                    End If
                Next

            Else
                For i = 0 To arFiles.Length - 1
                    If arFiles(i) <> "" Then
                        Finfo = New System.IO.FileInfo(strSourcePath & arFiles(i))
                        intSize = intSize + Finfo.Length
                    End If
                Next
            End If

            strErrorMessages = CheckDestFolderAccess(intSize)
            If strErrorMessages <> "" Then
                ShowErrorMessage(MaskString(strErrorMessages))
                MoveFiles = ""
                MoveStatus = ""
                SourcePath = ""
                'txtMoveStartIndex.Text = "false"

                Exit Sub
            End If

            For i = 0 To arFiles.Length - 1
                If arFiles(i) <> "" Then

                    'strSourceFile = Server.MapPath(txtSourcePath.Text) & "\" & arFiles(i)
                    strSourceFile = strSourcePath & arFiles(i)
                    strDestFile = strDestPath & arFiles(i)

                    strCurErrorMessage = ""
                    strCurErrorMessage = MoveFile(strSourceFile, strDestFile)


                    If strCurErrorMessage <> "" Then
                        'Unmask paths here, remask with title before showining error message
                        If MoveStatus = "copy" Then
                            strErrorMessages = strErrorMessages & Localization.GetString("ErrorCopyingFile", Me.ResourceFile) & _
                             AddTrailingSlash(UnMaskPath(SourcePath)) & arFiles(i) & "&nbsp;&nbsp; to " & _
                             AddTrailingSlash(UnMaskPath(DestPath)) & "<BR>&nbsp;&nbsp;&nbsp;" & strCurErrorMessage & "<BR>"
                        Else
                            strErrorMessages = strErrorMessages & Localization.GetString("ErrorMovingFile", Me.ResourceFile) & _
                             AddTrailingSlash(UnMaskPath(SourcePath)) & arFiles(i) & "&nbsp;&nbsp; to " & _
                             AddTrailingSlash(UnMaskPath(DestPath)) & "<BR>&nbsp;&nbsp;&nbsp;" & strCurErrorMessage & "<BR>"
                        End If

                    End If
                End If
            Next

            If strErrorMessages = "" Then
                LastPath = RemoveTrailingSlash(DestPath)
                ReBindFiles()
            Else

                'SJS
                'If MoveStatus = "copy" Then
                '    strErrorMessages = Replace(strErrorMessages, "Moving", "Copying")
                'End If
                strErrorMessages = MaskString(strErrorMessages)
                strErrorMessages = MaskString(strErrorMessages)

                ShowErrorMessage(strErrorMessages)
                'txtMoveStartIndex.Text = "false"
                ReBindFiles()

            End If
            MoveFiles = ""
            MoveStatus = ""
            SourcePath = ""


        End Sub
        Private Function GetZipFileExtractSize(ByVal strFileName As String) As Long

            Dim objZipEntry As ZipEntry
            Dim objZipInputStream As ZipInputStream
            Try
                objZipInputStream = New ZipInputStream(File.OpenRead(strFileName))

            Catch ex As Exception
                ShowErrorMessage(MaskString(ex.Message))
                Return -1


            End Try

            objZipEntry = objZipInputStream.GetNextEntry
            Dim iTemp As Long

            While Not objZipEntry Is Nothing
                iTemp = iTemp + objZipEntry.Size
                objZipEntry = objZipInputStream.GetNextEntry
            End While
            objZipInputStream.Close()
            Return iTemp




        End Function

        Private Sub lnkAddFolder_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs) Handles lnkAddFolder.Command
            If Me.txtNewFolder.Text = "" Then
                Exit Sub
            End If
            Dim strSourcePath As String

            strSourcePath = UnMaskPath(DestPath)

            Dim dinfo As New System.IO.DirectoryInfo(strSourcePath)
            Dim dinfoNew As System.IO.DirectoryInfo
            ';Dim str1 as 

            Try
                dinfoNew = New System.IO.DirectoryInfo(strSourcePath & txtNewFolder.Text)

                If dinfoNew.Exists Then
                    Throw New ArgumentException("Directory Already Exists")
                End If
                Dim strResult As String = dinfo.CreateSubdirectory(txtNewFolder.Text).FullName
                'str1 = dinfo.CreateSubdirectory(txtNewFolder.Text).FullName
                DestPath = DestPath & txtNewFolder.Text
                BindData()

                Dim FolderPath As String = ""
                FolderPath = strResult.Substring(ParentFolderName.Length).Replace("\", "/")

                Dim objFolderController As New DotNetNuke.Services.FileSystem.FolderController
                Dim objFolderInfo As New DotNetNuke.Services.FileSystem.FolderInfo
                Dim FolderID As Integer = -1

                objFolderInfo = CType(CBO.InitializeObject(objFolderInfo, GetType(DotNetNuke.Services.FileSystem.FolderInfo)), DotNetNuke.Services.FileSystem.FolderInfo)
                objFolderInfo.FolderPath = FolderPath
                objFolderInfo.PortalID = FolderPortalID
                FolderID = objFolderController.AddFolder(objFolderInfo)

                Dim objPermissionController As New DotNetNuke.Security.Permissions.PermissionController
                Dim Permissions As ArrayList = objPermissionController.GetPermissionsByFolder(FolderPortalID, "")
                Dim objPermssionsInfo As DotNetNuke.Security.Permissions.PermissionInfo
                Dim objFolderPermissionController As New DotNetNuke.Security.Permissions.FolderPermissionController
                For Each objPermssionsInfo In Permissions
                    Dim objFolderPermissionInfo As New DotNetNuke.Security.Permissions.FolderPermissionInfo
                    objFolderPermissionInfo = CType(CBO.InitializeObject(objFolderPermissionInfo, GetType(DotNetNuke.Security.Permissions.FolderPermissionInfo)), DotNetNuke.Security.Permissions.FolderPermissionInfo)
                    objFolderPermissionInfo.FolderID = FolderID
                    objFolderPermissionInfo.PermissionID = objPermssionsInfo.PermissionID
                    objFolderPermissionInfo.RoleID = PortalSettings.AdministratorRoleId
                    objFolderPermissionInfo.AllowAccess = True
                    objFolderPermissionController.AddFolderPermission(objFolderPermissionInfo)
                Next

                Me.txtNewFolder.Text = ""

            Catch ex As Exception

                Dim strErrorMessage As String = MaskString(ex.Message)
                ShowErrorMessage(strErrorMessage)
                BindData()

            End Try

        End Sub

        Private Sub lnkDeleteFolder_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs) Handles lnkDeleteFolder.Command
            Dim strSourcePath As String
            Dim strErrorMessage As String
            Dim ctrlError As New LiteralControl

            'Dim intCurFolderID As Integer = GetCurrentFolderID()

            'If txtCurFolderID.Text = "tttbr1" Then
            If DestPath = DNNTree.TreeNodes(0).Key Then
                'Delete Root Node?  Then what? :/
                strErrorMessage = "<TABLE><TR><TD height=100% class=NormalRed>" & Localization.GetString("NotAllowedToDeleteRootFolder", Me.ResourceFile) & "<BR>" & _
                 "</TD></TR><TR valign=bottom><TD align=center>" & _
                 "<TD><TR></TABLE>"
                ShowErrorMessage(strErrorMessage)
                'strErrorMessage = "<script language=javascript>ShowErrorMessage('" & _
                ' strErrorMessage & "');</script>"
                'ctrlError = New LiteralControl(strErrorMessage)
                ReBindFiles()
                'pnlScripts2.Controls.Add(ctrlError)
                Exit Sub

            Else

                strSourcePath = UnMaskPath(DestPath)


            End If

            Dim dinfo As New System.IO.DirectoryInfo(strSourcePath)
            If dinfo.Exists = False Then
                'ODD...
                strErrorMessage = "<TABLE><TR><TD height=100% class=NormalRed>" & Localization.GetString("FolderAlreadyRemoved", Me.ResourceFile) & "<BR>" & _
                  "</TD></TR><TR valign=bottom><TD align=center>" & _
                  "<TD><TR></TABLE>"
                ShowErrorMessage(strErrorMessage)
                'strErrorMessage = "<script language=javascript>ShowErrorMessage('" & _
                ' strErrorMessage & "');</script>"
                'ctrlError = New LiteralControl(strErrorMessage)
                'RefreshRootFolder()
                ReBindFiles()

                'pnlScripts2.Controls.Add(ctrlError)

                Exit Sub
            End If

            If (System.IO.Directory.GetDirectories(strSourcePath).Length > 0) _
            Or (dgFileList.Items.Count > 0) Then
                'Files and/or folders exist in directory..
                'Files in current folder, make them delete first
                'Recursive Folder-delete can be enabled by adjusting this Sub
                strErrorMessage = "<TABLE><TR><TD height=100% class=NormalRed>" & Localization.GetString("PleaseRemoveFilesBeforeDeleting", Me.ResourceFile) & "<BR>" & _
                 "</TD></TR><TR valign=bottom><TD align=center>" & _
                 "<TD><TR></TABLE>"
                ShowErrorMessage(strErrorMessage)
                'strErrorMessage = "<script language=javascript>ShowErrorMessage('" & _
                ' strErrorMessage & "');</script>"
                'ctrlError = New LiteralControl(strErrorMessage)
                'RefreshRootFolder()
                ReBindFiles()
                'pnlScripts2.Controls.Add(ctrlError)

                Exit Sub

            End If



            Dim dinfoNew As System.IO.DirectoryInfo


            Try
                'Not going to implement recursive-delete, change here if you really want it...
                dinfo.Delete(False)
                Dim intEnd As Integer '= InStrRev(Me.txtCurFolderID.Text, "_")
                'txtCurFolderID.Text = txtCurFolderID.Text.Substring(0, intEnd - 1)
                'If txtCurFolderID.Text = "0" Then txtCurFolderID.Text = "-1"
                intEnd = InStrRev(DestPath, "\")
                DestPath = DestPath.Substring(0, intEnd - 1)

                ' RefreshRootFolder()

                'since we removed folder, we will select parent folder
                Dim colNodes As Collection = DNNTree.SelectedTreeNodes()
                If colNodes.Count > 0 Then
                    Dim objNode As TreeNode = CType(colNodes(1), TreeNode)
                    objNode.Selected = False
                    objNode.Parent.Selected = True
                End If

                BindData()
                ReBindFiles()



            Catch ex As Exception


                strErrorMessage = ex.Message

                strErrorMessage = "<TABLE><TR><TD height=100% class=NormalRed>Error Deleting Folder:<BR>" & strErrorMessage & _
                 "</TD></TR><TR valign=bottom><TD align=center>" & _
                 "<TD><TR></TABLE>"
                ShowErrorMessage(strErrorMessage)
                'strErrorMessage = "<script language=javascript>ShowErrorMessage('" & _
                ' strErrorMessage & "');</script>"
                'strErrorMessage = Replace(strErrorMessage, "\", "\\")
                'ctrlError = New LiteralControl(strErrorMessage)

                ReBindFiles()
                'pnlScripts2.Controls.Add(ctrlError)

            End Try

        End Sub

        Private Sub lnkDeleteAllCheckedFiles_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs) Handles lnkDeleteAllCheckedFiles.Command
            If Me.MoveFiles <> "" Then
                DeleteFiles(MoveFiles)

            End If
        End Sub
        Public Function CheckDestFolderAccess(ByVal intSize As Long) As String
            'Checks to make sure file copy/move operation will not exceed portal available space

            If Request.IsAuthenticated Then
                Dim strDestFolder As String = AddTrailingSlash(UnMaskPath(DestPath))

                Dim objPortalController As New PortalController

                If ((((objPortalController.GetPortalSpaceUsed(FolderPortalID) + intSize) / 1000000) <= PortalSettings.HostSpace) Or PortalSettings.HostSpace = 0) Or (PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId) Then
                    Return ""
                Else
                    Return "Not Enough avaialble Portal Space"
                End If

            Else
                'Not Logged in????
                Return "Please login before copying/moving files"

            End If

        End Function
        Private Sub lnkFilter_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs) Handles lnkFilter.Command
            Me.dgFileList.CurrentPageIndex = 0
            FilterFiles = txtFilter.Text
            ReBindFiles()
        End Sub

        Private Sub lnkRefresh_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs) Handles lnkRefresh.Command
            BindData()
            MoveFiles = ""
            'txtFldScrollPos.Text = "0"
            Me.IsRefresh = True

            tblToolBarFolders.Visible = True
            Sort = "FileName"
            LastSort = "FileName"
            MoveStatus = ""
            FilterFiles = ""
            'DestPath = "0"
            ReBindFiles()

        End Sub

        Private Sub lnkUpload_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs) Handles lnkUpload.Command
            '"&SelectFolder=" & txtCurFolderID.Text)
            Dim strDestPath As String = DestPath.Replace("0\", "")
            '& "&SelectFolder=" & txtCurFolderID.Text)
            Response.Redirect("~/Default.aspx?tabid=" & TabId & "&mid=" & ModuleId & "&ctl=Edit&dest=" & strDestPath)
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Try
                Response.Redirect(NavigateURL(), True)

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click
            Dim strFolderPath As String = StripFolderPath(Me.LastFolderPath)
            Dim objFolderController As New DotNetNuke.Services.FileSystem.FolderController
            Dim objFolderInfo As DotNetNuke.Services.FileSystem.FolderInfo = objFolderController.GetFolder(FolderPortalID, strFolderPath)

            Dim objFolderPermissionController As New DotNetNuke.Security.Permissions.FolderPermissionController
            Dim objCurrentFolderPermissions As DotNetNuke.Security.Permissions.FolderPermissionCollection
            objCurrentFolderPermissions = objFolderPermissionController.GetFolderPermissionsCollectionByFolderPath(FolderPortalID, strFolderPath)
            If Not objCurrentFolderPermissions.CompareTo(dgPermissions.Permissions) Then
                objFolderPermissionController.DeleteFolderPermissionsByFolder(FolderPortalID, strFolderPath)
                Dim objFolderPermission As DotNetNuke.Security.Permissions.FolderPermissionInfo
                For Each objFolderPermission In dgPermissions.Permissions
                    objFolderPermission.FolderID = objFolderInfo.FolderID
                    If objFolderPermission.AllowAccess Then
                        objFolderPermissionController.AddFolderPermission(objFolderPermission)
                    End If
                Next
            End If
        End Sub

        Private Sub DNNTree_NodeClick(ByVal source As Object, ByVal e As DNNTreeNodeClickEventArgs) Handles DNNTree.NodeClick
            'Me.BindData()

            If DNNTree.IsDownLevel Then
                DestPath = e.Node.Key
                LastPath = e.Node.Key
            End If

            ReBindFiles()
        End Sub

        Protected Sub lnkCancelRename_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs) Handles lnkCancelRename.Command
            Me.dgFileList.EditItemIndex = -1
            ReBindFiles()
        End Sub
        Public Sub NavigateButton_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs)
        End Sub
        Protected Sub lnkUnzip_Command(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.CommandEventArgs) Handles lnkUnzip.Command
        End Sub

    End Class

End Namespace
