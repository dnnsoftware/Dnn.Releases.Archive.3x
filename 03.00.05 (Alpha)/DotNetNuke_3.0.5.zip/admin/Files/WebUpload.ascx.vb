'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.Services.FileSystem
Imports ICSharpCode.SharpZipLib.Zip
Imports System.IO
Imports DotNetNuke.Entities.Modules


Namespace DotNetNuke.Modules.Admin.FileSystem

	''' -----------------------------------------------------------------------------
	''' Project	 : DotNetNuke
	''' Class	 : WebUpload
	''' 
	''' -----------------------------------------------------------------------------
	''' <summary>
	''' Supplies the functionality for uploading files to the Portal
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	'''   [cnurse] 16/9/2004  Updated for localization, Help and 508
	''' </history>
	''' -----------------------------------------------------------------------------
    Public MustInherit Class WebUpload
		Inherits DotNetNuke.Entities.Modules.PortalModuleBase

#Region "Controls"

        Protected WithEvents pnlUpload As System.Web.UI.WebControls.Panel

        'Upload
        Protected WithEvents tblUpload As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents lblRootType As System.Web.UI.WebControls.Label
        Protected WithEvents lblRootFolder As System.Web.UI.WebControls.Label
        Protected WithEvents optFileType As System.Web.UI.WebControls.RadioButtonList
        Protected WithEvents cmdBrowse As System.Web.UI.HtmlControls.HtmlInputFile
        Protected WithEvents lstFiles As System.Web.UI.WebControls.ListBox
        Protected WithEvents cmdAdd As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdRemove As System.Web.UI.WebControls.LinkButton
        Protected WithEvents chkUnzip As System.Web.UI.WebControls.CheckBox
        Protected WithEvents cmdUpload As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
		Protected WithEvents ddlFolders As System.Web.UI.WebControls.DropDownList

		'Message
		Protected WithEvents lblMessage As System.Web.UI.WebControls.Label

		'Upload Log
		Protected WithEvents tblLogs As System.Web.UI.HtmlControls.HtmlTable
		Protected WithEvents lblLogTitle As System.Web.UI.WebControls.Label
		Protected WithEvents phPaLogs As System.Web.UI.WebControls.PlaceHolder
		Protected WithEvents cmdReturn1 As System.Web.UI.WebControls.LinkButton
		Protected WithEvents cmdReturn2 As System.Web.UI.WebControls.LinkButton

#End Region

#Region "Members"

		Public Shared arrFiles As ArrayList = New ArrayList
		Public Shared arrTypes As ArrayList = New ArrayList
		Private FileType As String = "F"		  ' content files
		Private DestinationFolder As String = String.Empty		  ' content files

#End Region

#Region "Private Methods"
        ''' -----------------------------------------------------------------------------
		''' <summary>
		''' PaLogsToTable Outputs the Log from a Skin/Container/Module Install
		''' </summary>
		''' <param name="Source">The Log as an ArrayList</param>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''   [cnurse] 16/9/2004  Updated for localization, Help and 508
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Function PaLogsToTable(ByVal Source As ArrayList) As HtmlTable
			Dim arrayTable As New HtmlTable

			Dim LogEntry As DotNetNuke.Modules.Admin.ResourceInstaller.PaLogEntry

			For Each LogEntry In Source
				Dim tr As New HtmlTableRow
				Dim tdType As New HtmlTableCell
				tdType.InnerText = LogEntry.Type.ToString
				Dim tdDescription As New HtmlTableCell
				tdDescription.InnerText = LogEntry.Description
				tr.Cells.Add(tdType)
				tr.Cells.Add(tdDescription)
				Select Case LogEntry.Type
					Case DotNetNuke.Modules.Admin.ResourceInstaller.PaLogType.Failure, DotNetNuke.Modules.Admin.ResourceInstaller.PaLogType.Warning
						tr.Attributes.Add("class", "NormalRed")
					Case DotNetNuke.Modules.Admin.ResourceInstaller.PaLogType.StartJob, DotNetNuke.Modules.Admin.ResourceInstaller.PaLogType.EndJob
						tr.Attributes.Add("class", "NormalBold")
				End Select
				arrayTable.Rows.Add(tr)
			Next

			Return arrayTable
		End Function
		''' -----------------------------------------------------------------------------
		''' <summary>
		''' This routine populates the Folder List Drop Down
		'''There is no reference to permissions here as all folders should be available to the admin.
		''' </summary>
		''' <param name="ChildDir"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''   [Philip Beadle] 5/10/2004  Added
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub LoadFolders(ByVal ChildDir As DirectoryInfo)
			Dim CurrentDir As DirectoryInfo
			Dim ChildDirs As DirectoryInfo()
			Dim ChildDirirectory As DirectoryInfo
			Dim ParentFolderName As String = ChildDir.FullName.Substring(lblRootFolder.Text.Length)

			CurrentDir = ChildDir
			ChildDirs = CurrentDir.GetDirectories
			For Each ChildDirirectory In ChildDirs
				Dim FolderItem As New ListItem
                Dim ItemText As String = ParentFolderName & "/" & ChildDirirectory.Name
                If ItemText.StartsWith("/") Then
                    ItemText = ItemText.Remove(0, 1)
                End If
                Dim ItemValue As String = ItemText & "/"
                FolderItem.Text = ItemText
                FolderItem.Value = ItemValue
                ddlFolders.Items.Add(FolderItem)
                If ChildDirirectory.GetDirectories.Length > 0 Then
                    LoadFolders(ChildDirirectory)
                End If
            Next
		End Sub

#End Region

#Region "Event Handlers"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' The Page_Load runs when the page loads
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''   [cnurse] 16/9/2004  Updated for localization, Help and 508
		'''   [VMasanas]  9/28/2004   Changed redirect to Access Denied
		'''   [Philip Beadle]  5/10/2004  Added folder population section.
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try

				'Get localized Strings
				Dim strHost As String = Services.Localization.Localization.GetString("HostRoot", Me.LocalResourceFile)
				Dim strPortal As String = Services.Localization.Localization.GetString("PortalRoot", Me.LocalResourceFile)
				Dim strContent As String = Services.Localization.Localization.GetString("Content", Me.LocalResourceFile)
				Dim strSkin As String = Services.Localization.Localization.GetString("Skin", Me.LocalResourceFile)
				Dim strContainer As String = Services.Localization.Localization.GetString("Container", Me.LocalResourceFile)
				Dim strModule As String = Services.Localization.Localization.GetString("Module", Me.LocalResourceFile)

				If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
					lblRootType.Text = strHost & ":"
					lblRootFolder.Text = Request.MapPath(Common.Globals.HostPath)
				Else
					lblRootType.Text = strPortal & ":"
					lblRootFolder.Text = Request.MapPath(PortalSettings.HomeDirectory)
				End If

				' get Destination Folder
				If Not (Request.QueryString("dest") Is Nothing) Then
                    DestinationFolder = Request.QueryString("dest").Replace("\", "/")
				End If

				Dim objModules As New ModuleController
				Dim settings As Hashtable = PortalSettings.GetModuleSettings(objModules.GetModuleByDefinition(PortalId, "File Manager").ModuleID)
				Dim UploadRoles As String = ""
				If Not CType(settings("uploadroles"), String) Is Nothing Then
					UploadRoles = CType(settings("uploadroles"), String)
				End If

				If PortalSecurity.IsInRole(PortalSettings.AdministratorRoleName.ToString) = False And PortalSecurity.IsInRoles(UploadRoles) = False Then
					Response.Redirect(NavigateURL("Access Denied"), True)
				End If

				If Not Page.IsPostBack Then
					ddlFolders.Items.Clear()
					Dim FolderItem As New ListItem
					FolderItem.Text = "Root"
					FolderItem.Value = String.Empty
					ddlFolders.Items.Add(FolderItem)
					Dim Root As New DirectoryInfo(lblRootFolder.Text)
					LoadFolders(Root)
					If Not DestinationFolder = String.Empty Then
						If Not ddlFolders.Items.FindByText(DestinationFolder) Is Nothing Then
							ddlFolders.Items.FindByText(DestinationFolder).Selected = True
						End If
					End If
					arrFiles.Clear()
					arrTypes.Clear()

					optFileType.Items.Add(New ListItem(strContent, "F"))
					chkUnzip.Checked = False

					Select Case Convert.ToString(PortalSettings.HostSettings("SkinUpload"))
						Case "G"						 ' host
							If UserInfo.IsSuperUser Then
								optFileType.Items.Add(New ListItem(strSkin, "S"))
								optFileType.Items.Add(New ListItem(strContainer, "C"))
							End If
						Case "", "L"						 ' portal
							If PortalSecurity.IsInRole(PortalSettings.AdministratorRoleName.ToString) = True Then
								optFileType.Items.Add(New ListItem(strSkin, "S"))
								optFileType.Items.Add(New ListItem(strContainer, "C"))
							End If
					End Select
					If UserInfo.IsSuperUser Then
						optFileType.Items.Add(New ListItem(strModule, "M"))
					End If

					If Not (Request.QueryString("filetype") Is Nothing) Then
						FileType = Request.QueryString("filetype")
					End If

					optFileType.Items.FindByValue(FileType).Selected = True
					If FileType <> "F" Then
						chkUnzip.Enabled = False
					End If
				End If

			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' The cmdAdd_Click runs when the Add Button is clicked
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''   [cnurse] 16/9/2004  Updated for localization, Help and 508
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdAdd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAdd.Click
			Try
				If Page.IsPostBack Then
					If cmdBrowse.PostedFile.FileName <> "" Then
						arrFiles.Add(cmdBrowse)
						arrTypes.Add(optFileType.SelectedItem.Value)
						lstFiles.Items.Add(optFileType.SelectedItem.Text & " - " & cmdBrowse.PostedFile.FileName)
					End If
				End If

			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' The cmdCancel_Click runs when the Cancel Button is clicked
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''   [cnurse] 16/9/2004  Updated for localization, Help and 508
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
			Response.Redirect(NavigateURL(), True)
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' The cmdRemove_Click runs when the Remove Button is clicked
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''   [cnurse] 16/9/2004  Updated for localization, Help and 508
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdRemove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRemove.Click
			Try
				If Not lstFiles.SelectedItem Is Nothing Then
					arrFiles.RemoveAt(lstFiles.SelectedIndex)
					arrTypes.RemoveAt(lstFiles.SelectedIndex)
					lstFiles.Items.Remove(lstFiles.SelectedItem.Text)
				End If

			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' The cmdReturn_Click runs when the Return Button is clicked
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''   [cnurse] 16/9/2004  Updated for localization, Help and 508
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdReturn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdReturn1.Click, cmdReturn2.Click
			Response.Redirect(NavigateURL(), True)
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' The cmdUpload_Click runs when the Upload Button is clicked
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''   [cnurse] 16/9/2004  Updated for localization, Help and 508
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdUpload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUpload.Click
			Try
				Dim strFileName As String
				Dim strFileNamePath As String
				Dim strExtension As String = ""
				Dim strMessage As String = ""

				Dim objHtmlInputFile As System.Web.UI.HtmlControls.HtmlInputFile
				Dim intItem As Integer

				'Get localized Strings
				Dim strInvalid As String = Services.Localization.Localization.GetString("InvalidExt", Me.LocalResourceFile)
				Dim strSkin As String = Services.Localization.Localization.GetString("Skin", Me.LocalResourceFile)
				Dim strContainer As String = Services.Localization.Localization.GetString("Container", Me.LocalResourceFile)
				Dim strModule As String = Services.Localization.Localization.GetString("Module", Me.LocalResourceFile)

				For intItem = 0 To arrFiles.Count - 1
					objHtmlInputFile = CType(arrFiles(intItem), HtmlInputFile)

					strFileName = System.IO.Path.GetFileName(objHtmlInputFile.PostedFile.FileName)
					strExtension = Path.GetExtension(strFileName)

					Select Case arrTypes(intItem)
						Case "F"						 ' content files
                            strMessage += UploadFile(lblRootFolder.Text & ddlFolders.SelectedItem.Value.Replace("/", "\"), objHtmlInputFile.PostedFile, chkUnzip.Checked)
						Case "S"						 ' skin package
							If strExtension.ToLower = ".zip" Then
								Dim objSkins As New UI.Skins.SkinController
								Dim objSkin As UI.Skins.SkinInfo
								Dim objLbl As New Label
								objLbl.Text = objSkins.UploadSkin(lblRootFolder.Text, objSkin.RootSkin, Path.GetFileNameWithoutExtension(objHtmlInputFile.PostedFile.FileName), objHtmlInputFile.PostedFile.InputStream)
								phPaLogs.Controls.Add(objLbl)
							Else
								strMessage += strInvalid & " " & strSkin & " " & strFileName
							End If
						Case "C"						 ' container package
							If strExtension.ToLower = ".zip" Then
								Dim objSkins As New UI.Skins.SkinController
								Dim objSkin As UI.Skins.SkinInfo
								Dim objLbl As New Label
								objLbl.Text = objSkins.UploadSkin(lblRootFolder.Text, objSkin.RootContainer, Path.GetFileNameWithoutExtension(objHtmlInputFile.PostedFile.FileName), objHtmlInputFile.PostedFile.InputStream)
								phPaLogs.Controls.Add(objLbl)
							Else
								strMessage += strInvalid & " " & strContainer & " " & strFileName
							End If
						Case "M"						 ' custom module
							If strExtension.ToLower = ".zip" Then
								phPaLogs.Visible = True
								Dim pa As New DotNetNuke.Modules.Admin.ResourceInstaller.PaInstaller(CType(objHtmlInputFile.PostedFile.InputStream, Stream), Request.MapPath("."))

								pa.Install()

								phPaLogs.Controls.Add(PaLogsToTable(pa.InstallerInfo.Log.Logs))
							Else
								strMessage += strInvalid & " " & strModule & " " & strFileName
							End If
					End Select
				Next

				If phPaLogs.Controls.Count > 0 Then
					tblUpload.Visible = False
					tblLogs.Visible = True
				ElseIf strMessage = "" Then
					Response.Redirect(NavigateURL(), True)
				Else
					lblMessage.Text = strMessage
				End If

			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' The optFileType_SelectedIndexChanged runs when the File Type Radio Button
		''' is changed
		''' </summary>
		''' <param name="sender"></param>
		''' <param name="e"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		'''   [cnurse] 16/9/2004  Updated for localization, Help and 508
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub optFileType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles optFileType.SelectedIndexChanged
			chkUnzip.Checked = False
			If optFileType.SelectedItem.Value = "F" Then
				chkUnzip.Enabled = True
			Else
				chkUnzip.Enabled = False
			End If
		End Sub

#End Region

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

	End Class

End Namespace
