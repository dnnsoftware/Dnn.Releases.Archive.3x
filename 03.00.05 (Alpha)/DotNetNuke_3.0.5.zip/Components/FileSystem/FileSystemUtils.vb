'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports ICSharpCode.SharpZipLib.Zip

Namespace DotNetNuke.Common.Utilities
    Public Class FileSystemUtils
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Moved directly from FileManager code, probably should make extension lookup more generic
        ''' </summary>
        ''' <param name="FileLoc">File Location</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Jon Henning]	11/1/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub DownloadFile(ByVal FileLoc As String)
            Dim objFile As New System.IO.FileInfo(FileLoc)
            Dim objResponse As System.Web.HttpResponse = System.Web.HttpContext.Current.Response
            If objFile.Exists Then
                objResponse.ClearContent()
                objResponse.ClearHeaders()
                objResponse.AppendHeader("content-disposition", "attachment; filename=" + objFile.Name.ToString)

                Dim strContentType As String
                Select Case objFile.Extension
                    Case "txt" : strContentType = "text/plain"
                    Case "htm", "html" : strContentType = "text/html"
                    Case "rtf" : strContentType = "text/richtext"
                    Case "jpg", "jpeg" : strContentType = "image/jpeg"
                    Case "gif" : strContentType = "image/gif"
                    Case "bmp" : strContentType = "image/bmp"
                    Case "mpg", "mpeg" : strContentType = "video/mpeg"
                    Case "avi" : strContentType = "video/avi"
                    Case "pdf" : strContentType = "application/pdf"
                    Case "doc", "dot" : strContentType = "application/msword"
                    Case "csv", "xls", "xlt" : strContentType = "application/x-msexcel"
                    Case Else : strContentType = "application/octet-stream"
                End Select
                objResponse.ContentType = strContentType
                objResponse.WriteFile(objFile.FullName)

                objResponse.Flush()
                objResponse.Close()
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Deletes a file
        ''' </summary>
        ''' <param name="FileLoc"></param>
        ''' <remarks>
        ''' This method is probably overkill, since it is relying on a single statement to 
        ''' delete the file, thus the user could have called it directly.  The advantage of putting
        ''' it here is that we will have more control, guaranteeing medium trust along with the possiblity
        ''' of performing additional rule checking...
        ''' </remarks>
        ''' <history>
        ''' 	[Jon Henning]	11/1/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub DeleteFile(ByVal FileLoc As String)
            System.IO.File.Delete(FileLoc)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Assigns 1 or more attributes to a file
        ''' </summary>
        ''' <param name="FileLoc">File Location</param>
        ''' <param name="FileAttributesOn">Pass in Attributes you wish to switch on (i.e. FileAttributes.Hidden + FileAttributes.ReadOnly)</param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[Jon Henning]	11/1/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub ChangeFileAttributes(ByVal FileLoc As String, ByVal FileAttributesOn As Integer)
            System.IO.File.SetAttributes(FileLoc, CType(FileAttributesOn, FileAttributes))
        End Sub

        Public Shared Function AddTrailingSlash(ByVal strSource As String) As String
            If Not strSource.EndsWith("\") Then strSource = strSource & "\"
            Return strSource
        End Function
        Public Shared Function RemoveTrailingSlash(ByVal strSource As String) As String
            If strSource = "" Then Return ""
            If Mid(strSource, Len(strSource), 1) = "\" Then
                Return strSource.Substring(0, Len(strSource) - 1)
            Else
                Return strSource
            End If
        End Function


        Public Shared Function UnzipFile(ByVal FileLoc As String, ByVal DestFolder As String) As String
            DestFolder = AddTrailingSlash(DestFolder)

            Dim objZipEntry As ZipEntry
            Dim objZipInputStream As ZipInputStream
            Try
                objZipInputStream = New ZipInputStream(File.OpenRead(FileLoc))
            Catch ex As Exception
                Return ex.Message
            End Try

            objZipEntry = objZipInputStream.GetNextEntry
            While Not objZipEntry Is Nothing
                If objZipEntry.IsDirectory Then
                    Try
                        System.IO.Directory.CreateDirectory(DestFolder & objZipEntry.Name)
                    Catch ex As Exception
                        objZipInputStream.Close()
                        Return ex.Message
                    End Try

                End If
                objZipEntry = objZipInputStream.GetNextEntry

            End While
            objZipInputStream = New ZipInputStream(File.OpenRead(FileLoc))
            objZipEntry = objZipInputStream.GetNextEntry
            While Not objZipEntry Is Nothing
                If Not objZipEntry.IsDirectory Then
                    Try

                        Dim Dinfo As New DirectoryInfo(System.IO.Path.GetDirectoryName(DestFolder & Replace(objZipEntry.Name, "/", "\")))
                        If Not Dinfo.Exists Then
                            Dinfo.Create()
                        End If
                        Dim objFileStream As FileStream
                        Try
                            objFileStream = File.Create(DestFolder & Replace(objZipEntry.Name, "/", "\"))

                        Catch ex As Exception
                            If Not objFileStream Is Nothing Then
                                objFileStream.Close()
                            End If
                            Return ex.Message

                        End Try

                        Dim intSize As Integer = 2048
                        Dim arrData(2048) As Byte

                        intSize = objZipInputStream.Read(arrData, 0, arrData.Length)
                        While intSize > 0
                            objFileStream.Write(arrData, 0, intSize)
                            intSize = objZipInputStream.Read(arrData, 0, arrData.Length)
                        End While

                        objFileStream.Close()
                    Catch ex As Exception
                        If Not objZipInputStream Is Nothing Then
                            objZipInputStream.Close()
                        End If

                        Return ex.Message
                    End Try
                End If

                objZipEntry = objZipInputStream.GetNextEntry
            End While

            objZipInputStream.Close()
            Return ""
        End Function



    End Class
End Namespace
