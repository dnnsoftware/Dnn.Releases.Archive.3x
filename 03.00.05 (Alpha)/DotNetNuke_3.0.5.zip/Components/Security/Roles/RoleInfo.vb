'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data
Imports Microsoft.ScalableHosting.Security
Imports System.Xml.Serialization

Namespace DotNetNuke.Security.Roles


	<XmlRoot("role", IsNullable:=False)> Public Class RoleInfo
		Private _RoleID As Integer
		Private _PortalID As Integer
		Private _RoleName As String
		Private _Description As String
		Private _ServiceFee As Single
		Private _BillingFrequency As String
		Private _TrialPeriod As Integer
		Private _TrialFrequency As String
		Private _BillingPeriod As Integer
		Private _TrialFee As Single
		Private _IsPublic As Boolean
		Private _AutoAssignment As Boolean

		<XmlIgnore()> Public Property RoleID() As Integer
			Get
				Return _RoleID
			End Get
			Set(ByVal Value As Integer)
				_RoleID = Value
			End Set
		End Property
		<XmlIgnore()> Public Property PortalID() As Integer
			Get
				Return _PortalID
			End Get
			Set(ByVal Value As Integer)
				_PortalID = Value
			End Set
		End Property
		<XmlElement("rolename")> Public Property RoleName() As String
			Get
				Return _RoleName
			End Get
			Set(ByVal Value As String)
				_RoleName = Value
			End Set
		End Property
		<XmlElement("description")> Public Property Description() As String
			Get
				Return _Description
			End Get
			Set(ByVal Value As String)
				_Description = Value
			End Set
		End Property
		<XmlElement("billingfrequency")> Public Property BillingFrequency() As String
			Get
				Return _BillingFrequency
			End Get
			Set(ByVal Value As String)
				_BillingFrequency = Value
			End Set
		End Property
		<XmlElement("servicefee")> Public Property ServiceFee() As Single
			Get
				Return _ServiceFee
			End Get
			Set(ByVal Value As Single)
				_ServiceFee = Value
			End Set
		End Property
		<XmlElement("trialfrequency")> Public Property TrialFrequency() As String
			Get
				Return _TrialFrequency
			End Get
			Set(ByVal Value As String)
				_TrialFrequency = Value
			End Set
		End Property
		<XmlElement("trialperiod")> Public Property TrialPeriod() As Integer
			Get
				Return _TrialPeriod
			End Get
			Set(ByVal Value As Integer)
				_TrialPeriod = Value
			End Set
		End Property
		<XmlElement("billingperiod")> Public Property BillingPeriod() As Integer
			Get
				Return _BillingPeriod
			End Get
			Set(ByVal Value As Integer)
				_BillingPeriod = Value
			End Set
		End Property
		<XmlElement("trialfee")> Public Property TrialFee() As Single
			Get
				Return _TrialFee
			End Get
			Set(ByVal Value As Single)
				_TrialFee = Value
			End Set
		End Property
		<XmlElement("ispublic")> Public Property IsPublic() As Boolean
			Get
				Return _IsPublic
			End Get
			Set(ByVal Value As Boolean)
				_IsPublic = Value
			End Set
		End Property
		<XmlElement("autoassignment")> Public Property AutoAssignment() As Boolean
			Get
				Return _AutoAssignment
			End Get
			Set(ByVal Value As Boolean)
				_AutoAssignment = Value
			End Set
		End Property

	End Class


End Namespace
