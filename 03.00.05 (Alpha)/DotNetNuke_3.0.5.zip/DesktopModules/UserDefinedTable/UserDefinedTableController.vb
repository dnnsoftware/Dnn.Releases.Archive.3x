'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.Services.Search
Imports System
Imports System.Configuration
Imports System.Data

Namespace DotNetNuke.Modules.UserDefinedTable

    Public Class UserDefinedTableController
        Implements Entities.Modules.ISearchable


        Public Function GetUserDefinedFields(ByVal ModuleId As Integer) As IDataReader

            Return DataProvider.Instance().GetUserDefinedFields(ModuleId)

        End Function


        Public Function GetUserDefinedField(ByVal UserDefinedFieldId As Integer) As IDataReader

            Return DataProvider.Instance().GetUserDefinedField(UserDefinedFieldId)

        End Function


        Public Function GetUserDefinedRow(ByVal UserDefinedRowId As Integer, ByVal ModuleId As Integer) As IDataReader

            Return DataProvider.Instance().GetUserDefinedRow(UserDefinedRowId, ModuleId)

        End Function


        Public Sub DeleteUserDefinedField(ByVal ModuleId As Integer, ByVal UserDefinedFieldID As Integer)

            ' delete all data in the field first
            Dim dr As IDataReader
            dr = DataProvider.Instance().GetUserDefinedRows(ModuleId)
            While dr.Read
                DataProvider.Instance().DeleteUserDefinedData(Convert.ToInt32(dr("UserDefinedRowId")), UserDefinedFieldID)
            End While
            dr.Close()

            DataProvider.Instance().DeleteUserDefinedField(UserDefinedFieldID)

        End Sub


        Public Sub AddUserDefinedField(ByVal ModuleID As Integer, ByVal FieldTitle As String, ByVal Visible As Boolean, ByVal FieldType As String)

            Dim intUserDefinedField As Integer = DataProvider.Instance().AddUserDefinedField(ModuleID, FieldTitle, Visible, FieldType)

            ' set the fieldorder
            Dim dr As IDataReader
            Dim UserDefinedFields As Integer
            dr = DataProvider.Instance().GetUserDefinedFields(ModuleID)
            While dr.Read
                UserDefinedFields += 1
            End While
            dr.Close()

            If UserDefinedFields > 0 Then
                DataProvider.Instance().UpdateUserDefinedFieldOrder(intUserDefinedField, UserDefinedFields - 1)
            End If



        End Sub


        Public Sub UpdateUserDefinedField(ByVal UserDefinedFieldID As Integer, ByVal FieldTitle As String, ByVal Visible As Boolean, ByVal FieldType As String)

            DataProvider.Instance().UpdateUserDefinedField(UserDefinedFieldID, FieldTitle, Visible, FieldType)

        End Sub


        Public Function GetUserDefinedRows(ByVal ModuleId As Integer) As DataSet

            Dim strFields As String
            Dim dr As IDataReader = GetUserDefinedFields(ModuleId)
            While dr.Read
                strFields += Convert.ToString(IIf(strFields <> "", ",", "")) & Convert.ToString(dr("FieldTitle")) & "|" & Convert.ToString(dr("FieldType"))
            End While
            dr.Close()

            dr = DataProvider.Instance().GetUserDefinedRows(ModuleId)
            GetUserDefinedRows = BuildCrossTabDataSet("UserDefinedData", dr, "UserDefinedRowId|Int32", strFields, "UserDefinedRowId", "FieldTitle", "", "FieldValue", "")
            dr.Close()

        End Function


        Public Sub DeleteUserDefinedRow(ByVal UserDefinedRowID As Integer)

            DataProvider.Instance().DeleteUserDefinedRow(UserDefinedRowID)

        End Sub


        Public Function AddUserDefinedRow(ByVal ModuleId As Integer) As Integer

            Return DataProvider.Instance().AddUserDefinedRow(ModuleId)

        End Function


        Public Sub UpdateUserDefinedRow(ByVal UserDefinedRowID As Integer, ByVal ModuleId As Integer)

            Dim OK As Boolean = True
            Dim dr As IDataReader = DataProvider.Instance().GetUserDefinedRows(ModuleId)
            While dr.Read
                If Convert.ToInt32(dr("UserDefinedRowID")) = UserDefinedRowID Then
                    OK = False
                End If
            End While
            dr.Close()

            If OK Then
                DataProvider.Instance().DeleteUserDefinedRow(UserDefinedRowID)
            End If

        End Sub


        Public Sub UpdateUserDefinedData(ByVal UserDefinedRowID As Integer, ByVal UserDefinedFieldID As Integer)
            UpdateUserDefinedData(UserDefinedRowID, UserDefinedFieldID, "")
        End Sub

        Public Sub UpdateUserDefinedData(ByVal UserDefinedRowID As Integer, ByVal UserDefinedFieldID As Integer, ByVal FieldValue As String)

            Dim dr As IDataReader

            If FieldValue = "" Then
                dr = DataProvider.Instance().GetUserDefinedData(UserDefinedRowID, UserDefinedFieldID)
                If dr.Read Then
                    DataProvider.Instance().DeleteUserDefinedData(UserDefinedRowID, UserDefinedFieldID)
                End If
                dr.Close()
            Else
                dr = DataProvider.Instance().GetUserDefinedData(UserDefinedRowID, UserDefinedFieldID)
                If dr.Read Then
                    DataProvider.Instance().UpdateUserDefinedData(UserDefinedRowID, UserDefinedFieldID, FieldValue)
                Else
                    DataProvider.Instance().AddUserDefinedData(UserDefinedRowID, UserDefinedFieldID, FieldValue)
                End If
                dr.Close()
            End If

        End Sub


        Public Sub UpdateUserDefinedFieldOrder(ByVal ModuleId As Integer, ByVal UserDefinedFieldID As Integer, ByVal Direction As Integer)

            Dim dr As IDataReader
            Dim FieldOrder As Integer
            Dim NewFieldOrder As Integer

            Dim SwapUserDefinedFieldId As Integer
            dr = DataProvider.Instance().GetUserDefinedField(UserDefinedFieldID)
            While dr.Read
                FieldOrder = Convert.ToInt32(dr("FieldOrder"))
                NewFieldOrder = FieldOrder + Direction
            End While
            dr.Close()

            Dim UserDefinedFields As Integer = -1
            dr = DataProvider.Instance().GetUserDefinedFields(ModuleId)
            While dr.Read
                UserDefinedFields += 1
                If Convert.ToInt32(dr("FieldOrder")) = NewFieldOrder Then
                    SwapUserDefinedFieldId = Convert.ToInt32(dr("UserDefinedFieldId"))
                End If
            End While
            dr.Close()

            dr = DataProvider.Instance().GetUserDefinedField(UserDefinedFieldID)
            If dr.Read Then
                If (Direction = -1 And FieldOrder > 0) Or (Direction = 1 And FieldOrder < UserDefinedFields) Then

                    DataProvider.Instance().UpdateUserDefinedFieldOrder(SwapUserDefinedFieldId, FieldOrder)

                    DataProvider.Instance().UpdateUserDefinedFieldOrder(UserDefinedFieldID, NewFieldOrder)

                End If
            End If
            dr.Close()

        End Sub

#Region "Optional Interfaces"

        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            Dim SearchItemCollection As New SearchItemInfoCollection

            Dim dsUserDefinedRows As DataSet = GetUserDefinedRows(ModInfo.ModuleID)

            Dim intCounter As Integer
            For intCounter = 0 To dsUserDefinedRows.Tables(0).Rows.Count - 1
                Dim SearchItem As SearchItemInfo = New SearchItemInfo(ModInfo.ModuleTitle & "-" & intCounter, dsUserDefinedRows.Tables(0).Rows(intCounter).Item("FieldTitle ").ToString(), Null.NullInteger, Now, ModInfo.ModuleID, "UDT" & ModInfo.ModuleID & "-" & intCounter, dsUserDefinedRows.Tables(0).Rows(intCounter).Item("FieldValue ").ToString())
                SearchItemCollection.Add(SearchItem)
            Next

            dsUserDefinedRows.Dispose()

            Return SearchItemCollection
        End Function

#End Region

    End Class


End Namespace

