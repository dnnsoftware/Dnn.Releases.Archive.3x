'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.Web.UI.WebControls
Imports DotNetNuke

Namespace DotNetNuke.Modules.Links

    ''' -----------------------------------------------------------------------------
    ''' <summary>
	''' The EditLinks PortalModuleBase is used to manage the Links
	''' </summary>
	''' <returns></returns>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[cnurse]	9/23/2004	Moved Links to a separate Project
	''' 	[cnurse]	9/23/2004	Updated to reflect design changes for Help, 508 support
	'''                       and localisation
	''' </history>
	''' -----------------------------------------------------------------------------
	Public MustInherit Class EditLinks
		Inherits Entities.Modules.PortalModuleBase

#Region "Controls"

		Protected plTitle As UI.UserControls.LabelControl
		Protected WithEvents txtTitle As System.Web.UI.WebControls.TextBox
		Protected WithEvents valTitle As System.Web.UI.WebControls.RequiredFieldValidator
		Protected plURL As UI.UserControls.LabelControl
		Protected WithEvents ctlURL As UI.UserControls.UrlControl
		Protected plDescription As UI.UserControls.LabelControl
		Protected WithEvents txtDescription As System.Web.UI.WebControls.TextBox
		Protected plViewOrder As UI.UserControls.LabelControl
		Protected WithEvents txtViewOrder As System.Web.UI.WebControls.TextBox
		Protected WithEvents valViewOrder As System.Web.UI.WebControls.RegularExpressionValidator

		Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
		Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
		Protected WithEvents cmdDelete As System.Web.UI.WebControls.LinkButton

		Protected WithEvents ctlAudit As UI.UserControls.ModuleAuditControl
		Protected WithEvents ctlTracking As UI.UserControls.URLTrackingControl

#End Region

#Region "Private Members"

		Private itemId As Integer = -1

#End Region

#Region "Event Handlers"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Page_Load runs when the control is loaded
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/23/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try
				Dim objModules As New Entities.Modules.ModuleController

				' Determine ItemId of Link to Update
                If Not (Request.QueryString("ItemId") Is Nothing) Then
                    itemId = Int32.Parse(Request.QueryString("ItemId"))
                End If

                ' If the page is being requested the first time, determine if an
                ' link itemId value is specified, and if so populate page
                ' contents with the link details
                If Page.IsPostBack = False Then

                    cmdDelete.Attributes.Add("onClick", "javascript:return confirm('Are You Sure You Wish To Delete This Item ?');")

                    If itemId <> -1 Then

                        ' Obtain a single row of link information
                        Dim objLinks As New LinkController
                        Dim objLink As LinkInfo = objLinks.GetLink(itemId, ModuleId)

                        If Not objLink Is Nothing Then

                            txtTitle.Text = objLink.Title.ToString
                            ctlURL.Url = objLink.Url
                            txtDescription.Text = objLink.Description.ToString
                            If (Common.Utilities.Null.IsNull(objLink.ViewOrder) = False) Then
                                txtViewOrder.Text = Convert.ToString(objLink.ViewOrder)
                            End If

                            ctlAudit.CreatedByUser = objLink.CreatedByUser.ToString
                            ctlAudit.CreatedDate = objLink.CreatedDate.ToString

                            ctlTracking.URL = objLink.Url
                            ctlTracking.ModuleID = ModuleId

                        Else       ' security violation attempt to access item not related to this Module
                            Response.Redirect(NavigateURL(), True)
                        End If
                    Else
                        cmdDelete.Visible = False
                        ctlAudit.Visible = False
                        ctlTracking.Visible = False
                    End If

                End If
            Catch exc As Exception    'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdCancel_Click runs when the cancel button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/23/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
			Try
				Response.Redirect(NavigateURL(), True)
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdDelete_Click runs when the delete button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/23/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdDelete.Click
			Try
				If itemId <> -1 Then

					Dim links As New LinkController
					links.DeleteLink(itemId)

				End If

				' Redirect back to the portal home page
				Response.Redirect(NavigateURL(), True)
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdUpdate_Click runs when the update button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/23/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
			Try

				If Page.IsValid = True And ctlURL.Url <> "" Then

					Dim objLink As New LinkInfo

					objLink = CType(CBO.InitializeObject(objLink, GetType(LinkInfo)), LinkInfo)

					'bind text values to object
					objLink.ItemId = itemId
					objLink.ModuleId = ModuleId
					objLink.CreatedByUser = UserInfo.UserID.ToString
					objLink.Title = txtTitle.Text
					objLink.Url = ctlURL.Url
					If (txtViewOrder.Text.Length > 0) Then
						objLink.ViewOrder = Convert.ToInt32(txtViewOrder.Text)
					End If
					objLink.Description = txtDescription.Text

					' Create an instance of the Link DB component
					Dim objLinks As New LinkController

					If Common.Utilities.Null.IsNull(itemId) Then
						objLinks.AddLink(objLink)
					Else
						objLinks.UpdateLink(objLink)
					End If

					' url tracking
					Dim objUrls As New UrlController
                    objUrls.UpdateUrl(PortalId, ctlURL.Url, ctlURL.UrlType, ctlURL.Log, ctlURL.Track, ModuleId, ctlURL.NewWindow)

					' Redirect back to the portal home page
					Response.Redirect(NavigateURL(), True)
				End If
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

#End Region

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

	End Class

End Namespace
