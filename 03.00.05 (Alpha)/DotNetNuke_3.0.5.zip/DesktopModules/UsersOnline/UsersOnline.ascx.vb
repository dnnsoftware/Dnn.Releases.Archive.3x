'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke

Namespace DotNetNuke.Modules.UsersOnline

    Public MustInherit Class UsersOnline
        Inherits DotNetNuke.Entities.Modules.PortalModuleBase

        Protected WithEvents pnlModuleContent As System.Web.UI.WebControls.Panel
        Protected WithEvents lblNewToday As System.Web.UI.WebControls.Label
        Protected WithEvents lblNewYesterday As System.Web.UI.WebControls.Label
        Protected WithEvents lblUserCount As System.Web.UI.WebControls.Label
        Protected WithEvents lblGuestCount As System.Web.UI.WebControls.Label
        Protected WithEvents lblMemberCount As System.Web.UI.WebControls.Label
        Protected WithEvents lblTotalCount As System.Web.UI.WebControls.Label
        Protected WithEvents lblLatestUserName As System.Web.UI.WebControls.Label
        Protected WithEvents pnlMembership As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlUsersOnline As System.Web.UI.WebControls.Panel
        Protected WithEvents pnlOnlineNow As System.Web.UI.WebControls.Panel
        Protected WithEvents MembershipLabel As System.Web.UI.WebControls.Label
        Protected WithEvents LatestUserLabel As System.Web.UI.WebControls.Label
        Protected WithEvents NewTodayLabel As System.Web.UI.WebControls.Label
        Protected WithEvents NewYesterdayLabel As System.Web.UI.WebControls.Label
        Protected WithEvents OverallLabel As System.Web.UI.WebControls.Label
        Protected WithEvents PeopleOnlineLabel As System.Web.UI.WebControls.Label
        Protected WithEvents VisitorsLabel As System.Web.UI.WebControls.Label
        Protected WithEvents MembersLabel As System.Web.UI.WebControls.Label
        Protected WithEvents TotalLabel As System.Web.UI.WebControls.Label
        Protected WithEvents imgMembership As System.Web.UI.HtmlControls.HtmlImage
        Protected WithEvents imgLatest As System.Web.UI.HtmlControls.HtmlImage
        Protected WithEvents imgNewToday As System.Web.UI.HtmlControls.HtmlImage
        Protected WithEvents imgNewYesterday As System.Web.UI.HtmlControls.HtmlImage
        Protected WithEvents imgUserCount As System.Web.UI.HtmlControls.HtmlImage
        Protected WithEvents imgPeopleOnline As System.Web.UI.HtmlControls.HtmlImage
        Protected WithEvents imgVisitors As System.Web.UI.HtmlControls.HtmlImage
        Protected WithEvents imgMemberCount As System.Web.UI.HtmlControls.HtmlImage
        Protected WithEvents imgTotalCount As System.Web.UI.HtmlControls.HtmlImage
        Protected WithEvents rptOnlineNow As System.Web.UI.WebControls.Repeater

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            Try
                Dim provider As DataProvider = DataProvider.Instance()
                Dim statistics As Hashtable = provider.GetStatistics(PortalSettings.PortalId)

                If (ShowMembership()) Then
                    ' Show the Panel 
                    pnlMembership.Visible = True

                    ' Bind the Labels
                    lblNewToday.Text = CType(statistics("MembershipToday"), String)
                    lblNewYesterday.Text = CType(statistics("MembershipYesterday"), String)
                    lblUserCount.Text = CType(statistics("MembershipCount"), String)
                    lblLatestUserName.Text = CType(statistics("LastUsername"), String)
                End If


                If (ShowPeopleOnline()) Then
                    ' Show the Panel 
                    pnlUsersOnline.Visible = True

                    ' Bind the Labels
                    lblMemberCount.Text = CType(statistics("OnlineUserCount"), String)
                    lblGuestCount.Text = CType(statistics("AnonymousUserCount"), String)
                    lblTotalCount.Text = (Convert.ToInt32(lblMemberCount.Text) + Convert.ToInt32(lblGuestCount.Text)).ToString()
                End If

                If (ShowUsersOnline()) Then
                    ' Show the Panel
                    pnlOnlineNow.Visible = True

                    ' Bind the Repeater
                    Dim reader As IDataReader = provider.GetOnlineUsers(PortalSettings.PortalId)
                    rptOnlineNow.DataSource = reader
                    rptOnlineNow.DataBind()
                    reader.Close()
                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

        Private Function ShowMembership() As Boolean

            ' Lookup the setting if it exists
            If Not (Settings("ShowMembership") Is Nothing) Then
                Return (CType(Settings("ShowMembership"), Boolean))
            End If

            ' Show if the Setting has not been set..
            Return True

        End Function

        Private Function ShowPeopleOnline() As Boolean

            ' Lookup the setting if it exists
            If Not (Settings("ShowPeopleOnline") Is Nothing) Then
                Return (CType(Settings("ShowPeopleOnline"), Boolean))
            End If

            ' Show if the Setting has not been set..
            Return True

        End Function

        Private Function ShowUsersOnline() As Boolean

            ' Lookup the setting if it exists
            If Not (Settings("ShowUsersOnline") Is Nothing) Then
                Return (CType(Settings("ShowUsersOnline"), Boolean))
            End If

            ' Show if the Setting has not been set..
            Return True

        End Function

        Private Sub rptOnlineNow_ItemDataBound(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles rptOnlineNow.ItemDataBound
            Dim lblUserNumber As System.Web.UI.WebControls.Label = CType(e.Item.FindControl("lblUserNumber"), System.Web.UI.WebControls.Label)

            If Not (lblUserNumber Is Nothing) Then
                Dim userNumber As String = (e.Item.ItemIndex + 1).ToString()

                If (userNumber.Length = 1) Then
                    userNumber = "0" & userNumber
                End If

                lblUserNumber.Text = userNumber
            End If
        End Sub

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

        End Sub

#End Region

    End Class

End Namespace