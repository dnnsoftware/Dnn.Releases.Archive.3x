'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports DotNetNuke.Services.Search
Imports System
Imports System.Configuration
Imports System.Data
Imports System.XML


Namespace DotNetNuke.Modules.FAQs

    ''' -----------------------------------------------------------------------------
    ''' Namespace:  DotNetNuke.Modules.FAQs
    ''' Project:    DotNetNuke
    ''' Class:      FAQsController
    ''' -----------------------------------------------------------------------------
    ''' <summary>
  ''' The EventController Class represents the Events Business Layer
  ''' Methods in this class call methods in the Data Layer
  ''' </summary>
  ''' <returns></returns>
  ''' <remarks>
  ''' </remarks>
  ''' <history>
  ''' 	[cnurse]	9/22/2004	Moved Events to a separate Project
  ''' </history>
  ''' -----------------------------------------------------------------------------
    Public Class FAQsController
        Implements Entities.Modules.ISearchable
        Implements Entities.Modules.IPortable

#Region "Public Methods"

        Public Sub AddFAQ(ByVal objFAq As FAQsInfo)

            DataProvider.Instance().AddFAQ(objFAq.ModuleId, objFAq.CreatedByUser, objFAq.Question, objFAq.Answer)

        End Sub

        Public Sub DeleteFAQ(ByVal ItemID As Integer)

            DataProvider.Instance().DeleteFAQ(ItemID)

        End Sub

        Public Function GetFAQ(ByVal ItemId As Integer, ByVal ModuleId As Integer) As FAQsInfo

            Return CType(CBO.FillObject(DataProvider.Instance().GetFAQ(ItemId, ModuleId), GetType(FAQsInfo)), FAQsInfo)

        End Function

        Public Function GetFAQs(ByVal ModuleId As Integer) As ArrayList

            Return CBO.FillCollection(DataProvider.Instance().GetFAQs(ModuleId), GetType(FAQsInfo))

        End Function

        Public Sub UpdateFAQ(ByVal objFAQ As FAQsInfo)

            DataProvider.Instance().UpdateFAQ(objFAQ.ItemId, objFAQ.CreatedByUser, objFAQ.Question, objFAQ.Answer)

        End Sub

#End Region

#Region "Optional Interfaces"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetSearchItems implements the ISearchable Interface
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModInfo">The ModuleInfo for the module to be Indexed</param>
        ''' <history>
        '''		[cnurse]	11/17/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems

            Dim SearchItemCollection As New SearchItemInfoCollection

            Dim FAQs As ArrayList = GetFAQs(ModInfo.ModuleID)

            Dim objFaq As Object
            For Each objFaq In FAQs
                Dim SearchItem As SearchItemInfo
                With CType(objFaq, FAQsInfo)                    '
                    Dim UserId As Integer = Null.NullInteger
                    If IsNumeric(.CreatedByUser) Then
                        UserId = Integer.Parse(.CreatedByUser)
                    End If
                    SearchItem = New SearchItemInfo(ModInfo.ModuleTitle, .Question, UserId, .CreatedDate, ModInfo.ModuleID, .ItemId.ToString, .Question & " " & .Answer, "ItemId=" & .ItemId.ToString)
                    SearchItemCollection.Add(SearchItem)
                End With
            Next

            Return SearchItemCollection
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ExportModule implements the IPortable ExportModule Interface
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModuleID">The Id of the module to be exported</param>
        ''' <history>
        '''		[cnurse]	11/17/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
            Dim strXML As String = ""

            Dim arrFAQs As ArrayList = GetFAQs(ModuleID)
            If arrFAQs.Count <> 0 Then
                strXML += "<faqs>"
                Dim objFAQs As FAQsInfo
                For Each objFAQs In arrFAQs
                    strXML += "<faq>"
                    strXML += "<question>" & XMLEncode(objFAQs.Question) & "</question>"
                    strXML += "<answer>" & XMLEncode(objFAQs.Answer) & "</answer>"
                    strXML += "</faq>"
                Next
                strXML += "</faqs>"
            End If

            Return strXML

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' ImportModule implements the IPortable ImportModule Interface
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ModuleID">The Id of the module to be imported</param>
        ''' <history>
        '''		[cnurse]	11/17/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserId As Integer) Implements Entities.Modules.IPortable.ImportModule
            Dim xmlFAQ As XmlNode
            Dim xmlFAQs As XmlNode = GetContent(Content, "faqs")
            For Each xmlFAQ In xmlFAQs.SelectNodes("faq")
                Dim objFAQs As New FAQsInfo
                objFAQs.ModuleId = ModuleID
                objFAQs.Question = xmlFAQ.Item("question").InnerText
                objFAQs.Answer = xmlFAQ.Item("answer").InnerText
                objFAQs.CreatedByUser = UserId.ToString
                AddFAQ(objFAQs)
            Next

        End Sub

#End Region

    End Class

End Namespace
