'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2004
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data

Namespace DotNetNuke.Modules.FAQs

  ''' -----------------------------------------------------------------------------
  ''' <summary>
  ''' The FAQsInfo Class provides the FAQs Business Object
  ''' </summary>
  ''' <returns></returns>
  ''' <remarks>
  ''' </remarks>
  ''' <history>
  ''' 	[cnurse]	9/22/2004	Moved FAQs to a separate Project
  ''' </history>
  ''' -----------------------------------------------------------------------------
  Public Class FAQsInfo

#Region "Private members"

    Private _ItemId As Integer
    Private _ModuleId As Integer
    Private _CreatedByUser As String
    Private _CreatedDate As Date
    Private _Question As String
    Private _Answer As String

#End Region

#Region "Constructors"

    Public Sub New()
    End Sub

#End Region

#Region "Properties"

    Public Property ItemId() As Integer
      Get
        Return _ItemId
      End Get
      Set(ByVal Value As Integer)
        _ItemId = Value
      End Set
    End Property

    Public Property ModuleId() As Integer
      Get
        Return _ModuleId
      End Get
      Set(ByVal Value As Integer)
        _ModuleId = Value
      End Set
    End Property

    Public Property CreatedByUser() As String
      Get
        Return _CreatedByUser
      End Get
      Set(ByVal Value As String)
        _CreatedByUser = Value
      End Set
    End Property

    Public Property CreatedDate() As Date
      Get
        Return _CreatedDate
      End Get
      Set(ByVal Value As Date)
        _CreatedDate = Value
      End Set
    End Property

    Public Property Question() As String
      Get
        Return _Question
      End Get
      Set(ByVal Value As String)
        _Question = Value
      End Set
    End Property

    Public Property Answer() As String
      Get
        Return _Answer
      End Get
      Set(ByVal Value As String)
        _Answer = Value
      End Set
    End Property

#End Region

  End Class

 

End Namespace
