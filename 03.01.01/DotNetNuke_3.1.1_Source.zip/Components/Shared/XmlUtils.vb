'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports System.XML
Imports System.Xml.Serialization
Imports System.Net


Namespace DotNetNuke.Common.Utilities

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The XmlUtils class provides Shared/Static methods for manipulating xml files
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	11/08/2004	created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class XmlUtils

        Public Shared Sub AppendElement(ByRef objDoc As XmlDocument, ByVal objNode As XmlNode, ByVal attName As String, ByVal attValue As String, ByVal includeIfEmpty As Boolean)

            If attValue = "" And Not includeIfEmpty Then
                Exit Sub
            End If
            objNode.AppendChild(CreateElement(objDoc, attName, attValue))

        End Sub

        Public Shared Function CreateAttribute(ByVal objDoc As XmlDocument, ByVal attName As String, ByVal attValue As String) As XmlAttribute

            Dim attribute As XmlAttribute = objDoc.CreateAttribute(attName)
            attribute.Value = attValue

            Return attribute

        End Function

        Public Shared Function CreateElement(ByVal objDoc As XmlDocument, ByVal NodeName As String, ByVal NodeValue As String) As XmlElement

            Dim element As XmlElement = objDoc.CreateElement(NodeName)
            element.InnerText = NodeValue

            Return element

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the value of node
        ''' </summary>
        ''' <param name="objNode">Parent node</param>
        ''' <param name="NodeName">Child node to look for</param>
        ''' <param name="DefaultValue">Default value to return</param>
        ''' <returns></returns>
        ''' <remarks>
        ''' If the node does not exist or it causes any error the default value will be returned.
        ''' </remarks>
        ''' <history>
        ''' 	[VMasanas]	09/09/2004	Created
        ''' 	[cnurse]	11/08/2004	moved from PortalController and made Public Shared
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetNodeValue(ByVal objNode As XmlNode, ByVal NodeName As String, Optional ByVal DefaultValue As String = "") As String
            Dim strValue As String = DefaultValue

            Try
                strValue = objNode.Item(NodeName).InnerText

                If strValue = "" And DefaultValue <> "" Then
                    strValue = DefaultValue
                End If
            Catch
                ' node does not exist - legacy issue
            End Try

            Return strValue

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the value of node
        ''' </summary>
        ''' <param name="objNode">Parent node</param>
        ''' <param name="NodeName">Child node to look for</param>
        ''' <param name="DefaultValue">Default value to return</param>
        ''' <returns></returns>
        ''' <remarks>
        ''' If the node does not exist or it causes any error the default value will be returned.
        ''' </remarks>
        ''' <history>
        ''' 	[VMasanas]	09/09/2004	Added new method to return converted values
        ''' 	[cnurse]	11/08/2004	moved from PortalController and made Public Shared
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetNodeValueBoolean(ByVal objNode As XmlNode, ByVal NodeName As String, Optional ByVal DefaultValue As Boolean = False) As Boolean
            Dim bValue As Boolean = DefaultValue

            Try
                bValue = Convert.ToBoolean(objNode.Item(NodeName).InnerText)
            Catch
                ' node does not exist / data conversion error - legacy issue: use default value
            End Try

            Return bValue

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the value of node
        ''' </summary>
        ''' <param name="objNode">Parent node</param>
        ''' <param name="NodeName">Child node to look for</param>
        ''' <param name="DefaultValue">Default value to return</param>
        ''' <returns></returns>
        ''' <remarks>
        ''' If the node does not exist or it causes any error the default value will be returned.
        ''' </remarks>
        ''' <history>
        ''' 	[VMasanas]	09/09/2004	Added new method to return converted values
        ''' 	[cnurse]	11/08/2004	moved from PortalController and made Public Shared
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetNodeValueDate(ByVal objNode As XmlNode, ByVal NodeName As String, ByVal DefaultValue As DateTime) As DateTime
            Dim dateValue As DateTime = DefaultValue

            Try
                If objNode.Item(NodeName).InnerText <> "" Then

                    dateValue = Convert.ToDateTime(objNode.Item(NodeName).InnerText)
                    If dateValue.Date.Equals(Null.NullDate.Date) Then
                        dateValue = Null.NullDate
                    End If
                End If
            Catch
                ' node does not exist / data conversion error - legacy issue: use default value
            End Try

            Return dateValue

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the value of node
        ''' </summary>
        ''' <param name="objNode">Parent node</param>
        ''' <param name="NodeName">Child node to look for</param>
        ''' <param name="DefaultValue">Default value to return</param>
        ''' <returns></returns>
        ''' <remarks>
        ''' If the node does not exist or it causes any error the default value will be returned.
        ''' </remarks>
        ''' <history>
        ''' 	[VMasanas]	09/09/2004	Added new method to return converted values
        ''' 	[cnurse]	11/08/2004	moved from PortalController and made Public Shared
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetNodeValueInt(ByVal objNode As XmlNode, ByVal NodeName As String, Optional ByVal DefaultValue As Integer = 0) As Integer
            Dim intValue As Integer = DefaultValue

            Try
                intValue = Convert.ToInt32(objNode.Item(NodeName).InnerText)
            Catch
                ' node does not exist / data conversion error - legacy issue: use default value
            End Try

            Return intValue

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Gets the value of node
        ''' </summary>
        ''' <param name="objNode">Parent node</param>
        ''' <param name="NodeName">Child node to look for</param>
        ''' <param name="DefaultValue">Default value to return</param>
        ''' <returns></returns>
        ''' <remarks>
        ''' If the node does not exist or it causes any error the default value will be returned.
        ''' </remarks>
        ''' <history>
        ''' 	[VMasanas]	09/09/2004	Added new method to return converted values
        ''' 	[cnurse]	11/08/2004	moved from PortalController and made Public Shared
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetNodeValueSingle(ByVal objNode As XmlNode, ByVal NodeName As String, Optional ByVal DefaultValue As Single = 0) As Single
            Dim sValue As Single = DefaultValue

            Try
                sValue = Convert.ToSingle(objNode.Item(NodeName).InnerText)
            Catch
                ' node does not exist / data conversion error - legacy issue: use default value
            End Try

            Return sValue

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetXMLContent loads the xml content into an Xml Document
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ContentUrl">The url to the xml text</param>
        ''' <returns>An XmlDocument</returns>
        ''' <history>
        ''' 	[cnurse]	9/23/2004	Moved XML to a separate Project
        '''     [cnurse]    1/21/2005   Moved to XmlUtils class
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetXMLContent(ByVal ContentUrl As String) As XmlDocument
            'This function reads an Xml document via a Url and returns it as an XmlDocument object

            GetXMLContent = New XmlDocument
            Dim req As WebRequest = WebRequest.Create(ContentUrl)
            Dim result As WebResponse = req.GetResponse()
            Dim ReceiveStream As Stream = result.GetResponseStream()
            Dim objXmlReader As XmlReader = New XmlTextReader(result.GetResponseStream())
            GetXMLContent.Load(objXmlReader)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetXSLContent loads the xsl content into an Xsl Transform
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="ContentUrl">The url to the xsl text</param>
        ''' <returns>An XslTransform</returns>
        ''' <history>
        ''' 	[cnurse]	9/23/2004	Moved XML to a separate Project
        '''     [cnurse]    1/21/2005   Moved to XmlUtils class
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetXSLContent(ByVal ContentURL As String) As Xsl.XslTransform

            GetXSLContent = New Xsl.XslTransform
            Dim req As WebRequest = WebRequest.Create(ContentURL)
            Dim result As WebResponse = req.GetResponse()
            Dim ReceiveStream As Stream = result.GetResponseStream()
            Dim objXSLTransform As XmlReader = New XmlTextReader(result.GetResponseStream)
            GetXSLContent.Load(objXSLTransform, Nothing, Nothing)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Serializes an object to Xml using the XmlAttributes
        ''' </summary>
        ''' <param name="obj">The object to Serialize</param>
        ''' <returns></returns>
        ''' <remarks>
        ''' An Xml representation of the object.
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	11/25/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function Serialize(ByVal obj As Object) As String

            Dim xmlDoc As New XmlDocument
            Dim xser As XmlSerializer
            Dim sw As StringWriter

            xser = New XmlSerializer(obj.GetType)
            sw = New StringWriter
            xser.Serialize(sw, obj)

            xmlDoc.LoadXml(sw.GetStringBuilder().ToString())
            Dim xmlDocEl As XmlNode = xmlDoc.DocumentElement
            xmlDocEl.Attributes.Remove(xmlDocEl.Attributes.ItemOf("xmlns:xsd"))
            xmlDocEl.Attributes.Remove(xmlDocEl.Attributes.ItemOf("xmlns:xsi"))

            Return xmlDocEl.OuterXml
        End Function

    End Class
End Namespace