'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Web.UI


Namespace DotNetNuke.UI.WebControls

	''' <summary>
	''' ITreeNodeWriter interface declaration. All the objects which want to implement
	''' a writer class for the TreeNode should inherit from this interface.
	''' </summary>
	Friend Interface ITreeNodeWriter
		''' <summary>
		''' When implemented renders an Node inside the tree.
		''' </summary>
		''' <param name="writer"></param>
		''' <param name="Node"></param>
		Sub RenderNode(ByVal writer As HtmlTextWriter, ByVal Node As TreeNode)
	End Interface	'ITreeNodeWriter

	''' <summary>
	''' IDNNTreeWriter interface declaration. All the objects which want to implement
	''' a writer class for the DNNTree should inherit from this interface.
	''' </summary>
	Friend Interface IDNNTreeWriter
		''' <summary>
		''' When implemented renders the tree.
		''' </summary>
		''' <param name="writer"></param>
		''' <param name="tree"></param>
		Sub RenderTree(ByVal writer As HtmlTextWriter, ByVal tree As DNNTree)
	End Interface
End Namespace