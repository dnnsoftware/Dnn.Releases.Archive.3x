'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.ComponentModel
Imports System.Web.UI
Imports System.Web.UI.WebControls
Namespace DotNetNuke.UI.WebControls

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' 
	''' </summary>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[jbrinkman]	5/6/2004	Created
	''' </history>
	''' -----------------------------------------------------------------------------
	Public Enum eNodeType
		designTimeNode
		runTimeNode
	End Enum

    Public Enum eClickAction
        PostBack
        Expand
        None
    End Enum

    Public Class TreeNode
        Implements IStateManager
        Friend Shared ReadOnly _separator As Char = ":"c
        Friend Shared ReadOnly _checkboxIDSufix As String = "checkbox"
        Shared ReadOnly _idPrefix As String = "Node"
        Private _id As String
        Private _clientID As String
        Private _level As Integer
        Private _nodes As TreeNodeCollection
        Private _parent As TreeNode
        Private _DNNTree As DNNTree
        Private _state As StateBag
        Private _nodeType As eNodeType
        Private _marked As Boolean = False

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public ReadOnly Property ID() As String
            Get
                If Not (_id Is Nothing) AndAlso _id.Length > 0 Then
                    Return _id
                End If
                _id = Parent.ID & _separator & _idPrefix & Parent.TreeNodes.IndexOf(Me)
                Return _id
            End Get
        End Property

        Public ReadOnly Property ClientID() As String
            Get
                Return Me.ID.Replace(":", "_")
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(""), PersistenceMode(PersistenceMode.Attribute)> _
          Public Property Text() As String
            Get
                Dim _text As String = CType(ViewState("Text"), String)
                Return (_text)
            End Get
            Set(ByVal Value As String)
                ViewState("Text") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Browsable(True), PersistenceMode(PersistenceMode.InnerProperty)> _
          Public ReadOnly Property TreeNodes() As TreeNodeCollection
            Get
                If _nodes Is Nothing Then
                    _nodes = New TreeNodeCollection(Me)
                End If
                Return _nodes
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Browsable(False)> _
          Public ReadOnly Property Parent() As TreeNode
            Get
                Return _parent
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Browsable(False)> _
          Public ReadOnly Property DNNTree() As DNNTree
            Get
                Return _DNNTree
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <DefaultValue(False), Browsable(False)> _
          Public ReadOnly Property IsExpanded() As Boolean
            Get
                Dim _expanded As Object
                If DNNTree.IsDownLevel = False Then
                    Dim sExpanded As String = DotNetNuke.UI.Utilities.ClientAPI.GetClientVariable(_DNNTree.Page, _DNNTree.ClientID & "_" & Me.ClientID & ":expanded")
                    If Len(sExpanded) > 0 Then
                        _expanded = CBool(sExpanded)
                    Else
                        _expanded = ViewState("IsExpanded")
                    End If
                Else
                    _expanded = ViewState("IsExpanded")
                End If
                Return CType(_expanded, Boolean)
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <DefaultValue(False), Browsable(False)> _
          Public ReadOnly Property HasNodes() As Boolean
            Get
                Return (Not (_nodes Is Nothing) AndAlso _nodes.Count > 0)
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Browsable(False)> _
          Public ReadOnly Property Level() As Integer
            Get
                Return _level
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <DefaultValue(False), Browsable(False)> _
          Public Property Selected() As Boolean
            Get
                'If we don't show checkboxes, then return false
                If Me.CheckBox OrElse Me._DNNTree.CheckBoxes Then
                    Dim _checked As Object = ViewState("Selected")
                    Return CType(_checked, Boolean)
                Else
                    Dim sSelected As String = DotNetNuke.UI.Utilities.ClientAPI.GetClientVariable(_DNNTree.Page, _DNNTree.ClientID & ":selected")
                    If Len(sSelected) > 0 AndAlso Me.ClientID = sSelected Then
                        Return True
                    Else
                        Return False
                    End If
                End If
            End Get
            Set(ByVal Value As Boolean)
                'Don't store the selected property if we don't show checkboxes
                If Me.CheckBox OrElse Me._DNNTree.CheckBoxes Then
                    ViewState("Selected") = Value
                Else
                    If Value Then
                        DotNetNuke.UI.Utilities.ClientAPI.RegisterClientVariable(_DNNTree.Page, _DNNTree.ClientID & ":selected", Me.ClientID, True)
                    Else
                        DotNetNuke.UI.Utilities.ClientAPI.RegisterClientVariable(_DNNTree.Page, _DNNTree.ClientID & ":selected", "", True)
                    End If
                End If
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), Browsable(True), DefaultValue(""), PersistenceMode(PersistenceMode.Attribute)> _
          Public Property Key() As String
            Get
                Dim _key As String = CType(ViewState("Key"), String)
                Return (_key)
            End Get
            Set(ByVal Value As String)
                ViewState("Key") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(""), PersistenceMode(PersistenceMode.Attribute)> _
          Public Property NavigateUrl() As String
            Get
                Dim _navigateUrl As String = CType(ViewState("NavigateUrl"), String)
                Return (_navigateUrl)
            End Get
            Set(ByVal Value As String)
                ViewState("NavigateUrl") = Value
            End Set
        End Property

        <Bindable(True), DefaultValue(""), PersistenceMode(PersistenceMode.Attribute)> _
          Public Property JSFunction() As String
            Get
                Dim _JSFunction As String = CType(ViewState("JSFunction"), String)
                Return (_JSFunction)
            End Get
            Set(ByVal Value As String)
                ViewState("JSFunction") = Value
            End Set
        End Property

        <Bindable(True), DefaultValue(eClickAction.PostBack), PersistenceMode(PersistenceMode.Attribute)> _
          Public Property ClickAction() As eClickAction
            Get
                If Len(ViewState("ClickAction")) > 0 Then
                    Dim eAction As eClickAction = CType(ViewState("ClickAction"), eClickAction)
                    Return (eAction)
                Else
                    Return eClickAction.PostBack
                End If
            End Get
            Set(ByVal Value As eClickAction)
                ViewState("ClickAction") = Value
            End Set
        End Property


        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(""), PersistenceMode(PersistenceMode.Attribute)> _
          Public Property Target() As String
            Get
                Dim _target As String = CType(ViewState("Target"), String)
                Return (_target)
            End Get
            Set(ByVal Value As String)
                ViewState("Target") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(False), PersistenceMode(PersistenceMode.Attribute)> _
          Public Property CheckBox() As Boolean
            Get
                Dim _checkBox As Object = ViewState("CheckBox")
                Return CType(_checkBox, Boolean)
            End Get
            Set(ByVal Value As Boolean)
                ViewState("CheckBox") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(""), PersistenceMode(PersistenceMode.Attribute)> _
          Public Property ToolTip() As String
            Get
                Dim _toolTip As String = CType(ViewState("ToolTip"), String)
                Return (_toolTip)
            End Get
            Set(ByVal Value As String)
                ViewState("ToolTip") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(True), PersistenceMode(PersistenceMode.Attribute)> _
          Public Property Enabled() As Boolean
            Get
                Dim _enabled As Object = ViewState("Enabled")
                Return CType(_enabled, Boolean)
            End Get
            Set(ByVal Value As Boolean)
                ViewState("Enabled") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(""), PersistenceMode(PersistenceMode.Attribute)> _
          Public Property CssClass() As String
            Get
                Dim _cssClass As String = CType(ViewState("CssClass"), String)
                Return (_cssClass)
            End Get
            Set(ByVal Value As String)
                ViewState("CssClass") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(""), PersistenceMode(PersistenceMode.Attribute)> _
          Public Property CssClassOver() As String
            Get
                Dim _cssClassOver As String = CType(ViewState("CssClassOver"), String)
                Return (_cssClassOver)
            End Get
            Set(ByVal Value As String)
                ViewState("CssClassOver") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <value></value>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        <Bindable(True), DefaultValue(-1), PersistenceMode(PersistenceMode.Attribute)> _
          Public Property ImageIndex() As Integer
            Get
                Dim _index As Object = ViewState("ImageIndex")
                Return CType(_index, Integer)
            End Get
            Set(ByVal Value As Integer)
                ViewState("ImageIndex") = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private ReadOnly Property NodeWriter() As ITreeNodeWriter
            Get
                If _DNNTree.IsDownLevel Then
                    Return New TreeNodeWriter
                Else
                    Return New TreeNodeUpLevelWriter
                End If
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Friend ReadOnly Property ViewState() As StateBag
            Get
                If _state Is Nothing Then
                    _state = New StateBag(True)
                    If CType(Me, IStateManager).IsTrackingViewState Then
                        CType(_state, IStateManager).TrackViewState()
                    End If
                End If
                Return _state
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Friend Property NodeType() As eNodeType
            Get
                Return _nodeType
            End Get
            Set(ByVal Value As eNodeType)
                _nodeType = Value
            End Set
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub New()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="NodeText"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub New(ByVal NodeText As String)
            If NodeText Is Nothing Then
                Throw New ArgumentNullException
            End If
            CType(Me, IStateManager).TrackViewState()
            Me.Text = NodeText
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="NodeText"></param>
        ''' <param name="navigateUrl"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub New(ByVal NodeText As String, ByVal navigateUrl As String)
            If NodeText Is Nothing OrElse navigateUrl Is Nothing Then
                Throw New ArgumentNullException
            End If
            CType(Me, IStateManager).TrackViewState()
            Text = NodeText
            navigateUrl = navigateUrl
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub Expand()
            If HasNodes Then
                ViewState("IsExpanded") = True
                DNNTree.OnExpand(New DNNTreeEventArgs(Me))
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub Collapse()
            If HasNodes Then
                ViewState("IsExpanded") = False
                DNNTree.OnCollapse(New DNNTreeEventArgs(Me))
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub Click()
            Me.Selected = True
            DNNTree.OnNodeClick(New DNNTreeNodeClickEventArgs(Me))
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Forces this node to be visible
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	12/7/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub MakeNodeVisible()
            If Not Me.Parent Is Nothing Then
                Me.Parent.Expand()
                Me.Parent.MakeNodeVisible()
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="ID"></param>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function FindNode(ByVal ID As String) As TreeNode
            Dim ReturnNode As TreeNode

            'Check all sibling nodes before performing recursion
            Dim TempNode As TreeNode
            For Each TempNode In TreeNodes
                If TempNode.ID = ID Then
                    ReturnNode = TempNode
                    Exit For
                End If
            Next
            'If you didn't find sibling, start recursing tree
            If ReturnNode Is Nothing Then
                For Each TempNode In TreeNodes
                    Dim FoundNode As TreeNode = TempNode.FindNode(ID)
                    If Not (FoundNode Is Nothing) Then
                        ReturnNode = FoundNode
                        Exit For
                    End If
                Next
            End If

            Return ReturnNode
        End Function

        Public Function FindNodeByKey(ByVal Key As String) As TreeNode
            Dim ReturnNode As TreeNode

            'Check all sibling nodes before performing recursion
            Dim TempNode As TreeNode
            For Each TempNode In TreeNodes
                If TempNode.Key = Key Then
                    ReturnNode = TempNode
                    Exit For
                End If
            Next
            'If you didn't find sibling, start recursing tree
            If ReturnNode Is Nothing Then
                For Each TempNode In TreeNodes
                    Dim FoundNode As TreeNode = TempNode.FindNodeByKey(Key)
                    If Not (FoundNode Is Nothing) Then
                        ReturnNode = FoundNode
                        Exit For
                    End If
                Next
            End If

            Return ReturnNode
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="writer"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overridable Sub Render(ByVal writer As HtmlTextWriter)
            NodeWriter.RenderNode(writer, Me)
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="NodeID"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Friend Sub SetNodeID(ByVal NodeID As String)
            _id = NodeID
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="parent"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Friend Sub SetParent(ByVal parent As TreeNode)
            _parent = parent
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="DNNTree"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Friend Sub SetDNNTree(ByVal DNNTree As DNNTree)
            _DNNTree = DNNTree
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="level"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Friend Sub SetLevel(ByVal level As Integer)
            _level = level
        End Sub

#Region "IStateManager Interface"
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public ReadOnly Property IsTrackingViewState() As Boolean Implements IStateManager.IsTrackingViewState
            Get
                Return _marked
            End Get
        End Property

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <param name="state"></param>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub LoadViewState(ByVal state As Object) Implements IStateManager.LoadViewState
            If Not (state Is Nothing) Then
                Dim _newState As Object() = CType(state, Object())
                If Not (_newState(0) Is Nothing) Then
                    CType(ViewState, IStateManager).LoadViewState(_newState(0))
                End If
                If Not (_newState(1) Is Nothing) Then
                    CType(TreeNodes, IStateManager).LoadViewState(_newState(1))
                End If
            End If
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function SaveViewState() As Object Implements IStateManager.SaveViewState
            Dim _stateState As Object = Nothing
            If Not (_state Is Nothing) Then
                _stateState = CType(_state, IStateManager).SaveViewState
            End If
            Dim _NodesState As Object = Nothing
            If Not (_nodes Is Nothing) Then
                _NodesState = CType(_nodes, IStateManager).SaveViewState
            End If
            If _stateState Is Nothing AndAlso _NodesState Is Nothing Then
                Return Nothing
            End If
            Dim _newState(2 - 1) As Object
            _newState(0) = _stateState
            _newState(1) = _NodesState
            Return _newState
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' 
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Sub TrackViewState() Implements IStateManager.TrackViewState
            _marked = True
            If Not (_state Is Nothing) Then
                CType(_state, IStateManager).TrackViewState()
            End If
            If Not (_nodes Is Nothing) Then
                CType(_nodes, IStateManager).TrackViewState()
            End If
        End Sub
#End Region

    End Class
End Namespace
