'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Diagnostics
Namespace DotNetNuke.UI.WebControls

	Friend Class TreeNodeWriter
		Implements ITreeNodeWriter
		Shared ReadOnly _expcol As String() = New String(1) {"+", "-"}
		Private _Node As TreeNode

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <param name="writer"></param>
		''' <param name="Node"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Sub RenderNode(ByVal writer As HtmlTextWriter, ByVal Node As TreeNode) Implements ITreeNodeWriter.RenderNode
			_Node = Node
			Render(writer)
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <param name="writer"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Protected Sub Render(ByVal writer As HtmlTextWriter)
            Dim NodeClass As String = "Child"

            If Len(_Node.CssClass) > 0 Then
                NodeClass = _Node.CssClass
            ElseIf Len(_Node.DNNTree.DefaultChildNodeCssClass) > 0 Then
                NodeClass = _Node.DNNTree.DefaultChildNodeCssClass
            End If

            RenderContents(writer)
            If _Node.HasNodes AndAlso _Node.IsExpanded Then
                writer.AddAttribute(HtmlTextWriterAttribute.Class, NodeClass)
                writer.RenderBeginTag(HtmlTextWriterTag.Div)
                RenderChildren(writer)
                writer.RenderEndTag()
            End If
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <param name="writer"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Protected Sub RenderContents(ByVal writer As HtmlTextWriter)

			RenderOpenTag(writer)

			If _Node.Level > 0 AndAlso _Node.DNNTree.IndentWidth > 0 Then
				RenderSpacer(writer, _Node.Level * _Node.DNNTree.IndentWidth)
			End If

			RenderExpandNodeIcon(writer)

			RenderNodeCheckbox(writer)

			RenderNodeIcon(writer)

			RenderNodeText(writer)

			writer.RenderEndTag()

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <param name="writer"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Protected Sub RenderOpenTag(ByVal writer As HtmlTextWriter)
			Dim NodeClass As String = "Node"

			If Len(_Node.CssClass) > 0 Then
				NodeClass = _Node.CssClass
			ElseIf Len(_Node.DNNTree.DefaultNodeCssClass) > 0 Then
				NodeClass = _Node.DNNTree.DefaultNodeCssClass
			End If

			writer.AddAttribute(HtmlTextWriterAttribute.Class, NodeClass)
			writer.AddAttribute(HtmlTextWriterAttribute.Name, _Node.ID)
			writer.AddAttribute(HtmlTextWriterAttribute.Id, _Node.ID.Replace(_Node._separator, "_"))
			writer.RenderBeginTag(HtmlTextWriterTag.Div)
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <param name="writer"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Protected Sub RenderExpandNodeIcon(ByVal writer As HtmlTextWriter)
			If _Node.HasNodes Then
				Dim _link As HyperLink = New HyperLink
				Dim _image As Image = New Image
				If _Node.IsExpanded Then
					_link.Text = _expcol(1)
					If Len(_Node.DNNTree.ExpandedNodeImage) > 0 Then
						_image.ImageUrl = _Node.DNNTree.ExpandedNodeImage
					End If
				Else
					_link.Text = _expcol(0)
					If Len(_Node.DNNTree.CollapsedNodeImage) > 0 Then
						_image.ImageUrl = _Node.DNNTree.CollapsedNodeImage
					End If
				End If
				_link.NavigateUrl = _Node.DNNTree.Page.GetPostBackClientHyperlink(_Node.DNNTree, _Node.ID)
				If Len(_image.ImageUrl) > 0 Then
					_link.RenderBeginTag(writer)
					_image.RenderControl(writer)
					_link.RenderEndTag(writer)
				Else
					_link.RenderControl(writer)
				End If
				_image = Nothing
				_link = Nothing
			Else
				RenderSpacer(writer, 9)
			End If
			writer.Write("&nbsp;")
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <param name="writer"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Protected Sub RenderNodeCheckbox(ByVal writer As HtmlTextWriter)
			If _Node.DNNTree.CheckBoxes OrElse _Node.CheckBox Then
				Dim _checkbox As CheckBox = New CheckBox
				_checkbox.ID = _Node.ID + TreeNode._separator + TreeNode._checkboxIDSufix
				_checkbox.Checked = _Node.Selected
				_checkbox.RenderControl(writer)
				_checkbox = Nothing
				writer.Write("&nbsp;")
			End If
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <param name="writer"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Protected Sub RenderNodeIcon(ByVal writer As HtmlTextWriter)
			If _Node.ImageIndex > -1 Then
				Dim _NodeImage As NodeImage = _Node.DNNTree.ImageList(_Node.ImageIndex)
				If Not (_NodeImage Is Nothing) Then
					Dim _image As Image = New Image
					_image.ImageUrl = _NodeImage.ImageUrl
					_image.RenderControl(writer)
					writer.Write("&nbsp;")
				End If
			End If
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <param name="writer"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
        ''' 	[jbrinkman]	5/6/2004	Created
        '''     [cnurse]    12/8/2004   Modified so that if NavigateUrl property is set
        '''                             we will use that rather than a postback
		''' </history>
		''' -----------------------------------------------------------------------------
		Protected Sub RenderNodeText(ByVal writer As HtmlTextWriter)
            Dim _link As HyperLink = New HyperLink
            Dim NodeClass As String = "NodeText"

            If Len(_Node.CssClass) > 0 Then
                NodeClass = _Node.CssClass
            End If

            _link.Text = _Node.Text
            If _Node.NavigateUrl <> "" Then
                _link.NavigateUrl = _Node.NavigateUrl
                If _Node.Target <> "" Then
                    _link.Target = _Node.Target
                End If
            Else
                _link.NavigateUrl = _Node.DNNTree.Page.GetPostBackClientHyperlink(_Node.DNNTree, _Node.ID & ",Click")
            End If

            If Len(_Node.ToolTip) > 0 Then
                _link.ToolTip = _Node.ToolTip
            End If
            _link.CssClass = NodeClass
            _link.RenderControl(writer)
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <param name="writer"></param>
		''' <param name="Width"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Protected Sub RenderSpacer(ByVal writer As HtmlTextWriter, ByVal Width As Integer)
            writer.AddStyleAttribute("width:", Width.ToString & "px; height:1px;")
            writer.AddAttribute("src", _Node.DNNTree.SystemImagesPath & "spacer.gif")
            writer.RenderBeginTag(HtmlTextWriterTag.Img)
			writer.RenderEndTag()
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' 
		''' </summary>
		''' <param name="writer"></param>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[jbrinkman]	5/6/2004	Created
		''' </history>
		''' -----------------------------------------------------------------------------
		Protected Sub RenderChildren(ByVal writer As HtmlTextWriter)
			For Each _elem As TreeNode In _Node.TreeNodes
				_elem.Render(writer)
			Next
		End Sub

	End Class
End Namespace
