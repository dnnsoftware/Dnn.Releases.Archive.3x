'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports FreeTextBoxControls
Imports DotNetNuke.Common
Imports DotNetNuke.Common.Utilities
Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Security

Namespace DotNetNuke.HtmlEditor

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The FTBImageGallery Class provides the Image Gallery for the FTB Provider
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	12/14/2004  documented and updated to work with FTB3.0
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class FTBImageGallery
        Inherits DotNetNuke.Framework.PageBase

        Protected WithEvents imgGallery As FreeTextBoxControls.ImageGallery

        Public Title As String = ""

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' set page title
            Dim strTitle As String = PortalSettings.PortalName & " > Image Gallery"

            ' show copyright credits?
            If GetHashValue(Common.Globals.HostSettings("Copyright"), "Y") = "Y" Then
                strTitle += " ( DNN " & PortalSettings.Version & " )"
            End If
            Title = strTitle

            Dim AllowAccess As Boolean
            Try
                Dim strCurrentFolder As String = Server.MapPath(imgGallery.CurrentImagesFolder)
                If Not strCurrentFolder.EndsWith("\") Then
                    strCurrentFolder &= "\"
                End If
                If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                    strCurrentFolder = strCurrentFolder.Substring(Common.Globals.HostMapPath.Length)
                Else
                    strCurrentFolder = strCurrentFolder.Substring(PortalSettings.HomeDirectoryMapPath.Length)
                End If
                If strCurrentFolder.EndsWith("\") Then
                    strCurrentFolder = strCurrentFolder.Substring(0, strCurrentFolder.Length - 1)
                End If

                ' Check permissions for current directory
                Dim roles As String = FileSystemUtils.GetRoles(strCurrentFolder.Replace("\", "/"), PortalSettings.PortalId, "WRITE")
                If PortalSecurity.IsInRoles(roles) Then
                    AllowAccess = True
                Else
                    AllowAccess = False
                End If
            Catch ex As Exception 'wrong directory
                AllowAccess = False
            End Try

            ' Set rights
            imgGallery.AllowDirectoryCreate = AllowAccess
            imgGallery.AllowDirectoryDelete = AllowAccess
            imgGallery.AllowImageDelete = AllowAccess
            imgGallery.AllowImageUpload = AllowAccess
            imgGallery.JavaScriptLocation = ResourceLocation.ExternalFile
            imgGallery.UtilityImagesLocation = ResourceLocation.ExternalFile
            imgGallery.SupportFolder = DotNetNuke.Common.Globals.ResolveUrl("~/Providers/HtmlEditorProviders/Ftb3HtmlEditorProvider/ftb3/")

        End Sub

        Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender

            'Get the list of sub-directories
            Dim strDirectories As String() = System.IO.Directory.GetDirectories(Server.MapPath(imgGallery.CurrentImagesFolder), "*")
            Dim alDirectories As ArrayList = New ArrayList
            Dim strDirectory As String
            Dim roles As String
            Dim i As Integer

            'Parse directories (only adding those we have permission for
            For i = 0 To strDirectories.Length - 1
                If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                    strDirectory = strDirectories(i).Substring(Common.Globals.HostMapPath.Length)
                Else
                    strDirectory = strDirectories(i).Substring(PortalSettings.HomeDirectoryMapPath.Length)
                End If

                roles = FileSystemUtils.GetRoles(strDirectory.Replace("\", "/"), PortalSettings.PortalId, "READ")

                If PortalSecurity.IsInRoles(roles) Then
                    alDirectories.Add(strDirectory)
                End If
            Next
            imgGallery.CurrentDirectories = CType(alDirectories.ToArray(GetType(System.String)), String())

            'Verify access to current folder
            Dim currentfolder As String = Server.MapPath(imgGallery.CurrentImagesFolder)
            If Not currentfolder.EndsWith("\") Then
                currentfolder &= "\"
            End If
            If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
                strDirectory = currentfolder.Substring(Common.Globals.HostMapPath.Length)
            Else
                strDirectory = currentfolder.Substring(PortalSettings.HomeDirectoryMapPath.Length)
            End If
            If strDirectory.EndsWith("\") Then
                strDirectory = strDirectory.Substring(0, strDirectory.Length - 1)
            End If
            roles = FileSystemUtils.GetRoles(strDirectory.Replace("\", "/"), PortalSettings.PortalId, "READ")
            If Not PortalSecurity.IsInRoles(roles) Then
                Dim noimage() As System.IO.FileInfo = New System.IO.FileInfo() {}
                imgGallery.CurrentImages = noimage
            End If


        End Sub

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region


    End Class

End Namespace

