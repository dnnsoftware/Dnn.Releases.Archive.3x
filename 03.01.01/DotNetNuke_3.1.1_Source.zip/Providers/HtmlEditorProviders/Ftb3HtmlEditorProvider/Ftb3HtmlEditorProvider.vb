'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports System.Web
Imports DotNetNuke.Entities.Portals
Imports DotNetNuke.Common
Imports DotNetNuke.Framework.Providers
Imports FreeTextBoxControls

Namespace DotNetNuke.HtmlEditor

    ''' -----------------------------------------------------------------------------
    ''' Class:  TextEditor
    ''' Project: Provider.FtbHtmlEditorProvider
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' Ftb3HtmlEditorProvider implements an Html Editor Provider for FTB (FreeTextBox) 3
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	12/13/2004	Documented
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class Ftb3HtmlEditorProvider

        Inherits DotNetNuke.Modules.HTMLEditorProvider.HtmlEditorProvider

        Dim cntlFtb As New FreeTextBoxControls.FreeTextBox

        Private Const ProviderType As String = "htmlEditor"

        Private _AdditionalToolbars As New ArrayList
        Private _RootImageDirectory As String
        Private _ControlID As String
        Private _providerConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration(ProviderType)
        Private _providerPath As String
        Private _styles As ArrayList
        Private _enableProFeatures As Boolean
        Private _spellCheck As String
        Private _toolbarStyle As String

#Region " Provider "

        Public Sub New()

            Dim _portalSettings As PortalSettings = DotNetNuke.Entities.Portals.PortalController.GetCurrentPortalSettings

            'Dim objMyPortalModuleControl As PortalModuleControl = CType(HttpContext.Current.Items("PortalModuleControl"), PortalModuleControl)

            ' Read the configuration specific information for this provider
            Dim objProvider As Provider = CType(_providerConfiguration.Providers(_providerConfiguration.DefaultProvider), Provider)

            _providerPath = objProvider.Attributes("providerPath")
            _spellCheck = objProvider.Attributes("spellCheck")
            _enableProFeatures = Boolean.Parse(objProvider.Attributes("enableProFeatures"))
            _toolbarStyle = objProvider.Attributes("toolbarStyle")

        End Sub


        Public ReadOnly Property ProviderPath() As String
            Get
                Return _providerPath
            End Get
        End Property

#End Region

#Region "Properties "

        Public Overrides ReadOnly Property HtmlEditorControl() As System.Web.UI.Control
            Get
                Return cntlFtb
            End Get
        End Property

        Public Overrides Property Text() As String
            Get
                Text = cntlFtb.Text
            End Get
            Set(ByVal Value As String)
                cntlFtb.Text = Value
            End Set
        End Property

        Public Overrides Property ControlID() As String
            Get
                ControlID = _ControlID
            End Get
            Set(ByVal Value As String)
                _ControlID = Value
            End Set
        End Property

        Public Overrides Property AdditionalToolbars() As ArrayList
            Get
                Return _AdditionalToolbars
            End Get
            Set(ByVal Value As ArrayList)
                _AdditionalToolbars = Value
            End Set
        End Property

        Public Overrides Property RootImageDirectory() As String
            Get
                If _RootImageDirectory = "" Then
                    Dim _portalSettings As PortalSettings = DotNetNuke.Entities.Portals.PortalController.GetCurrentPortalSettings

                    RootImageDirectory = _portalSettings.HomeDirectory.Substring(_portalSettings.HomeDirectory.IndexOf("/Portals/"))
                Else
                    RootImageDirectory = _RootImageDirectory
                End If

            End Get
            Set(ByVal Value As String)
                _RootImageDirectory = Value
            End Set
        End Property

        Public Overrides Property Width() As System.Web.UI.WebControls.Unit
            Get
                Width = cntlFtb.Width
            End Get
            Set(ByVal Value As System.Web.UI.WebControls.Unit)
                cntlFtb.Width = Value
            End Set
        End Property

        Public Overrides Property Height() As System.Web.UI.WebControls.Unit
            Get
                Height = cntlFtb.Height
            End Get
            Set(ByVal Value As System.Web.UI.WebControls.Unit)
                cntlFtb.Height = Value
            End Set
        End Property

#End Region

#Region "Private Helper Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Color ToolBar
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A FreeTextBox ToolBar</returns>
        ''' <history>
        ''' 	[cnurse]	12/13/2004	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddColorToolBar() As FreeTextBoxControls.Toolbar

            Dim tb As New FreeTextBoxControls.Toolbar
            tb.Items.Add(New FontForeColorsMenu)
            tb.Items.Add(New FontForeColorPicker)
            tb.Items.Add(New FontBackColorsMenu)
            tb.Items.Add(New FontBackColorPicker)

            Return tb
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Edit ToolBar
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A FreeTextBox ToolBar</returns>
        ''' <history>
        ''' 	[cnurse]	12/13/2004	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddEditToolBar() As FreeTextBoxControls.Toolbar

            Dim tb As New FreeTextBoxControls.Toolbar
            tb.Items.Add(New Cut)
            tb.Items.Add(New Copy)
            tb.Items.Add(New Paste)
            tb.Items.Add(New Delete)
            tb.Items.Add(New ToolbarSeparator)
            tb.Items.Add(New Undo)
            tb.Items.Add(New Redo)

            Return tb

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Format ToolBar
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A FreeTextBox ToolBar</returns>
        ''' <history>
        ''' 	[cnurse]	12/13/2004	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddFormatToolBar() As FreeTextBoxControls.Toolbar

            Dim tb As New FreeTextBoxControls.Toolbar
            tb.Items.Add(New JustifyLeft)
            tb.Items.Add(New JustifyCenter)
            tb.Items.Add(New JustifyRight)
            tb.Items.Add(New JustifyFull)
            tb.Items.Add(New ToolbarSeparator)
            tb.Items.Add(New BulletedList)
            tb.Items.Add(New NumberedList)
            tb.Items.Add(New Indent)
            tb.Items.Add(New Outdent)

            Return tb

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Insert ToolBar
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A FreeTextBox ToolBar</returns>
        ''' <history>
        ''' 	[cnurse]	12/13/2004	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddInsertToolBar() As FreeTextBoxControls.Toolbar

            Dim tb As New FreeTextBoxControls.Toolbar
            tb.Items.Add(New SymbolsMenu)
            tb.Items.Add(New InsertRule)
            tb.Items.Add(New InsertDate)
            tb.Items.Add(New InsertTime)
            tb.Items.Add(New ToolbarSeparator)
            tb.Items.Add(New CreateLink)
            tb.Items.Add(New Unlink)
            tb.Items.Add(New InsertImageFromGallery)

            Return tb

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Insert ToolBar
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A FreeTextBox ToolBar</returns>
        ''' <history>
        ''' 	[cnurse]	12/13/2004	Documented
        ''' 	[JWhite]	2/25/2005	Added SpellCheck
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddSpecialToolBar() As FreeTextBoxControls.Toolbar

            Dim tb As New FreeTextBoxControls.Toolbar
            tb.Items.Add(New Preview)
            tb.Items.Add(New SelectAll)
            Select Case _spellCheck
                Case "NetSpell"
                    tb.Items.Add(New NetSpell) 'requires NetSpell library
                Case "IeSpellCheck"
                    tb.Items.Add(New IeSpellCheck)
            End Select
            If _enableProFeatures Then
                tb.Items.Add(New WordClean) 'pro only
            Else
                Dim WordCleanScript As String
                WordCleanScript = "wordContent = this.ftb.designEditor.document.body.innerHTML; "
                WordCleanScript += "wordContent = String(wordContent).replace(/ class=[^\s|>]*/gi,''); "
                WordCleanScript += "wordContent = String(wordContent).replace(/ style=\'[^>]*\'/gi,''); "
                WordCleanScript += "wordContent = String(wordContent).replace(/ align=[^\s|>]*/gi,''); "
                WordCleanScript += "wordContent = String(wordContent).replace(/<p [^>]*>/gi,'<p>'); "
                WordCleanScript += "wordContent = String(wordContent).replace(/<b [^>]*>/gi,'<b>'); "
                WordCleanScript += "wordContent = String(wordContent).replace(/<i [^>]*>/gi,'<i>'); "
                WordCleanScript += "wordContent = String(wordContent).replace(/<ul [^>]*>/gi,'<ul>'); "
                WordCleanScript += "wordContent = String(wordContent).replace(/<li [^>]*>/gi,'<li>'); "
                WordCleanScript += "wordContent = String(wordContent).replace(/<b>/gi,'<strong>'); "
                WordCleanScript += "wordContent = String(wordContent).replace(/<\/b>/gi,'</strong>'); "
                WordCleanScript += "wordContent = String(wordContent).replace(/<em>/gi,'<i>'); "
                WordCleanScript += "wordContent = String(wordContent).replace(/<\/em>/gi,'</i>'); "
                WordCleanScript += "wordContent = String(wordContent).replace(/<\?xml:[^>]*>/g, ''); "
                WordCleanScript += "wordContent = String(wordContent).replace(/<\/?st1:[^>]*>/g,''); "
                WordCleanScript += "wordContent = String(wordContent).replace(/<\/?[a-z]\:[^>]*>/g,''); "
                WordCleanScript += "wordContent = String(wordContent).replace(/<\/?span[^>]*>/gi,''); "
                WordCleanScript += "wordContent = String(wordContent).replace(/<\/?div[^>]*>/gi,''); "
                WordCleanScript += "wordContent = String(wordContent).replace(/<\/?font[^>]*>/gi,''); "
                WordCleanScript += "wordContent = String(wordContent).replace(/<\/?pre[^>]*>/gi,''); "
                WordCleanScript += "wordContent = String(wordContent).replace(/<\/?h[1-6][^>]*>/gi,''); "
                WordCleanScript += "this.ftb.designEditor.document.body.innerHTML = wordContent;"

                Dim dnnWordClean As New ToolbarButton
                'TODO localize this if possible
                dnnWordClean.Title = DotNetNuke.Services.Localization.Localization.GetString("WordCleanButton")
                dnnWordClean.ButtonImage = "wordclean"
                dnnWordClean.ScriptBlock = WordCleanScript
                tb.Items.Add(dnnWordClean)
            End If
            Return tb

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Styles Menu
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A FreeTextBox StylesMenu</returns>
        ''' <history>
        ''' 	[cnurse]	12/13/2004	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddStylesMenu() As FreeTextBoxControls.StylesMenu

            Dim _portalSettings As PortalSettings = CType(HttpContext.Current.Items("PortalSettings"), PortalSettings)
            Dim styleMenu As New StylesMenu
            Dim i As Integer

            _styles = New ArrayList

            'Parse default css
            ParseStyleSheet(Common.Globals.HostPath & "default.css")

            'Parse skin stylesheet(s)
            ParseStyleSheet(PortalSettings.ActiveTab.SkinPath & "skin.css")
            ParseStyleSheet(Replace(PortalSettings.ActiveTab.SkinSrc, ".ascx", ".css"))

            'Parse portal stylesheet
            ParseStyleSheet(PortalSettings.HomeDirectory & "portal.css")

            _styles.Sort()

            For i = 0 To _styles.Count - 1
                Dim myListItem As New FreeTextBoxControls.ToolbarListItem
                myListItem.Text = CType(_styles.Item(i), String)
                myListItem.Value = CType(_styles.Item(i), String)
                styleMenu.Items.Add(myListItem)
            Next

            Return styleMenu

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Style ToolBar
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A FreeTextBox ToolBar</returns>
        ''' <history>
        ''' 	[cnurse]	12/13/2004	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddStyleToolBar() As FreeTextBoxControls.Toolbar

            Dim tb As New FreeTextBoxControls.Toolbar
            tb.Items.Add(AddStylesMenu)
            tb.Items.Add(New ParagraphMenu)
            tb.Items.Add(New FontFacesMenu)
            tb.Items.Add(New FontSizesMenu)

            Return tb

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Text ToolBar
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A FreeTextBox ToolBar</returns>
        ''' <history>
        ''' 	[cnurse]	12/13/2004	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddTextToolBar() As FreeTextBoxControls.Toolbar

            Dim tb As New FreeTextBoxControls.Toolbar
            tb.Items.Add(New Bold)
            tb.Items.Add(New Italic)
            tb.Items.Add(New Underline)
            tb.Items.Add(New StrikeThrough)
            tb.Items.Add(New SuperScript)
            tb.Items.Add(New SubScript)
            tb.Items.Add(New RemoveFormat)

            Return tb

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Table ToolBar in FreeTextBox 
        ''' (Pro edition only)
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A FreeTextBox ToolBar</returns>
        ''' <history>
        ''' 	[JWhite]	2/25/2005	Added/Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddTableToolBar() As FreeTextBoxControls.Toolbar

            Dim tb As New FreeTextBoxControls.Toolbar 
            tb.Items.Add(New InsertTable) 
            tb.Items.Add(New EditTable) 
            If _enableProFeatures Then
                tb.Items.Add(New InsertTableColumnAfter) 'pro only
                tb.Items.Add(New InsertTableColumnBefore) 'pro only
                tb.Items.Add(New InsertTableRowBefore) 'pro only
                tb.Items.Add(New InsertTableRowAfter) 'pro only
                tb.Items.Add(New DeleteTableColumn) 'pro only
                tb.Items.Add(New DeleteTableRow) 'pro only
            End If
            Return tb 
            
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Creates the Form ToolBar in FreeTextBox 
        ''' (Pro edition only)
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <returns>A FreeTextBox ToolBar</returns>
        ''' <history>
        ''' 	[JWhite]	2/27/2005	Added/Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function AddFormToolBar() As FreeTextBoxControls.Toolbar

            Dim tb As New FreeTextBoxControls.Toolbar 
            tb.Items.Add(New InsertForm) 'pro only
            tb.Items.Add(New InsertTextBox) 'pro only
            tb.Items.Add(New InsertTextArea) 'pro only
            tb.Items.Add(New InsertRadioButton) 'pro only
            tb.Items.Add(New InsertCheckBox) 'pro only
            tb.Items.Add(New InsertDropDownList) 'pro only
            tb.Items.Add(New InsertButton) 'pro only
            
            Return tb 
            
        End Function        
        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Parses the Stylesheet looking for styles
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="strCssFile">Stylesheet to parse</param>
        ''' <history>
        ''' 	[cnurse]	12/13/2004	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub ParseStyleSheet(ByVal strCssFile As String)

            If File.Exists(HttpContext.Current.Server.MapPath(strCssFile)) Then

                Dim objStreamReader As StreamReader
                Dim strStyleLine As String
                Dim alStyles As New ArrayList
                Dim i As Integer

                objStreamReader = File.OpenText(HttpContext.Current.Server.MapPath(strCssFile))

                While objStreamReader.Peek() <> -1
                    strStyleLine = objStreamReader.ReadLine()

                    If Left(Trim(strStyleLine), 1) = "." Then
                        i = strStyleLine.IndexOf(" ")

                        If i <> -1 Then
                            strStyleLine = strStyleLine.Substring(0, i)
                        End If

                        i = strStyleLine.IndexOf("{")

                        If i <> -1 Then
                            strStyleLine = strStyleLine.Substring(0, i)
                        End If

                        If Not _styles.Contains(strStyleLine.Substring(1)) Then
                            _styles.Add(strStyleLine.Substring(1))
                        End If
                    End If

                End While

                objStreamReader.Close()

            End If
        End Sub

#End Region

#Region "Public Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Adds additional toolbar(s) to the FTB control
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	01/12/2005	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Sub AddToolbar()

            Dim tb As New FreeTextBoxControls.Toolbar

            For Each tb In AdditionalToolbars
                cntlFtb.Toolbars.Add(tb)
            Next

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Initialises the control
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	12/13/2004	Documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Overrides Sub Initialize()

            'initialize the control
            cntlFtb = New FreeTextBoxControls.FreeTextBox
            cntlFtb.Language = System.Threading.Thread.CurrentThread.CurrentUICulture.Name
            cntlFtb.ButtonImagesLocation = ResourceLocation.ExternalFile
            cntlFtb.JavaScriptLocation = ResourceLocation.ExternalFile
            cntlFtb.ToolbarImagesLocation = ResourceLocation.ExternalFile
            cntlFtb.ID = ControlID
            cntlFtb.AutoGenerateToolbarsFromString = False

            'Build the Standard ToolBar Collection
            cntlFtb.Toolbars.Clear()
            cntlFtb.Toolbars.Add(AddStyleToolBar)
            cntlFtb.Toolbars.Add(AddColorToolBar)
            cntlFtb.Toolbars.Add(AddTextToolBar)
            cntlFtb.Toolbars.Add(AddFormatToolBar)
            cntlFtb.Toolbars.Add(AddEditToolBar)
            cntlFtb.Toolbars.Add(AddInsertToolBar)
            cntlFtb.Toolbars.Add(AddTableToolBar)
            If _enableProFeatures Then cntlFtb.Toolbars.Add(AddFormToolBar)
            cntlFtb.Toolbars.Add(AddSpecialToolBar)

            cntlFtb.ImageGalleryUrl = DotNetNuke.Common.Globals.ResolveUrl("~/Providers/HtmlEditorProviders/Ftb3HtmlEditorProvider/ftb3/ftb.imagegallery.aspx?cif=~" & RootImageDirectory & "&rif=~" & RootImageDirectory & "&portalid=" & PortalSettings.PortalId)
            cntlFtb.SupportFolder = DotNetNuke.Common.Globals.ResolveUrl("~/Providers/HtmlEditorProviders/Ftb3HtmlEditorProvider/ftb3/")
            Select Case _toolbarStyle
                Case "OfficeMac"
                    cntlFtb.ToolbarStyleConfiguration = ToolbarStyleConfiguration.OfficeMac
                Case "Office2000"
                    cntlFtb.ToolbarStyleConfiguration = ToolbarStyleConfiguration.Office2000
                Case "OfficeMac"
                    cntlFtb.ToolbarStyleConfiguration = ToolbarStyleConfiguration.OfficeXP
                Case "Office2003"
                    cntlFtb.ToolbarStyleConfiguration = ToolbarStyleConfiguration.Office2003
                Case Else
                    cntlFtb.ToolbarStyleConfiguration = ToolbarStyleConfiguration.NotSet
            End Select

        End Sub

#End Region

    End Class

End Namespace
