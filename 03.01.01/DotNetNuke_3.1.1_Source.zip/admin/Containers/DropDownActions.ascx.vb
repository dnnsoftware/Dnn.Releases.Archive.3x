'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Diagnostics
Imports Solpart.WebControls
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Modules.Actions

Namespace DotNetNuke.UI.Containers
    Public MustInherit Class DropDownActions
        Inherits UI.Containers.ActionBase

        Protected WithEvents cboActions As System.Web.UI.WebControls.DropDownList
        Protected WithEvents cmdGo As System.Web.UI.WebControls.ImageButton

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            'Put user code to initialize the page here
			Me.cmdGo.Attributes.Add("onclick", "if (cmdGo_OnClick(dnn.dom.getById('" & Me.cboActions.ClientID & "')) == false) return false;")
        End Sub

        Private Sub Page_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.PreRender
            Try
                BindDropDown()

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub cmdGo_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdGo.Click
            Try
                If cboActions.SelectedIndex <> -1 Then
                    ProcessAction(cboActions.SelectedItem.Value)
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

        End Sub

        Public Sub BindDropDown()

            With _menuActionRoot
                ' Is Root Menu visible?
                If .Visible Then
                    ' Clear old Actions...  
                    ' The module may have added/removed actions during postback
                    cboActions.Items.Clear()
                    AddChildActions(_menuActionRoot, "")
                End If
            End With

            'Need to determine if the dropdown actually has any menu items.
            If cboActions.Items.Count > 0 Then
                Me.Visible = True
            Else
                Me.Visible = False
            End If

        End Sub

        Public Sub AddChildActions(ByVal Parent As ModuleAction, ByVal level As String)

            ' Add Menu Items
            Dim action As ModuleAction
            For Each action In Parent.Actions
                If action.Title = "~" Then
                    cboActions.Items.Add("-------------------")
                Else
					Dim _UserInfo As UserInfo = UserController.GetCurrentUserInfo
					If Len(action.ClientScript) > 0 Then
						DotNetNuke.UI.Utilities.ClientAPI.RegisterClientVariable(Me.Page, "__dnn_CSAction_" & Me.cboActions.ClientID & "_" & action.ID, action.ClientScript, True)
					End If
					If action.Visible And PortalSecurity.HasNecessaryPermission(action.Secure, CType(HttpContext.Current.Items("PortalSettings"), PortalSettings), ModuleConfiguration, _UserInfo.UserID.ToString) Then
                        If (EditMode = True And _PortalModule.PortalSettings.ActiveTab.IsAdminTab = False And IsAdminControl() = False) Or (action.Secure <> SecurityAccessLevel.Anonymous And action.Secure <> SecurityAccessLevel.View) Then
                            cboActions.Items.Add(New ListItem(level & action.Title, action.ID.ToString))
                        End If
                    End If
					If action.HasChildren Then
						AddChildActions(action, level & "_")
					End If
					End If
            Next
        End Sub

    End Class
End Namespace
