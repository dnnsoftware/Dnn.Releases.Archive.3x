'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports System.Xml.Serialization
Imports ICSharpCode.SharpZipLib.Zip
Imports ICSharpCode.SharpZipLib.Checksums
Imports ICSharpCode.SharpZipLib.GZip
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Modules.Admin.ResourceInstaller

Namespace DotNetNuke.Services.Localization
	Public Class LanguagePack
		Inherits DotNetNuke.Entities.Modules.PortalModuleBase

#Region "Controls"
		Protected WithEvents cboLanguage As System.Web.UI.WebControls.DropDownList
		Protected WithEvents cmdCreate As System.Web.UI.WebControls.LinkButton
		Protected pnlLogs As System.Web.UI.WebControls.Panel
		Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
		Protected WithEvents lblLink As System.Web.UI.WebControls.Label
		Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
		Protected divLog As System.Web.UI.HtmlControls.HtmlGenericControl
#End Region

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		'NOTE: The following placeholder declaration is required by the Web Form Designer.
		'Do not delete or move it.
		Private designerPlaceholderDeclaration As System.Object

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

#Region "Event Handlers"
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			'Put user code to initialize the page here
			If Not Page.IsPostBack Then
				BindLanguages()
			End If
		End Sub

		Private Sub cmdCreate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCreate.Click
			If cboLanguage.SelectedIndex > -1 Then
				Dim LangPackWriter As New LocaleFilePackWriter

				Dim LocaleCulture As New Locale
				LocaleCulture.Code = cboLanguage.SelectedValue
				LocaleCulture.Text = cboLanguage.SelectedItem.Text

				Dim LangPackName As String = LangPackWriter.SaveLanguagePack(LocaleCulture)

				If LangPackWriter.ProgressLog.Valid Then
					lblMessage.Text = String.Format(Localization.GetString("LOG.MESSAGE.Success", LocalResourceFile), LangPackName)
					lblMessage.CssClass = "Head"
				Else
					lblMessage.Text = Localization.GetString("LOG.MESSAGE.Error", LocalResourceFile)
					lblMessage.CssClass = "NormalRed"
				End If

				Dim FileManagerModule As ModuleInfo = (New ModuleController).GetModuleByDefinition(Null.NullInteger, "File Manager")

				If Not FileManagerModule Is Nothing Then
					lblLink.Text = String.Format(Localization.GetString("lblLink", LocalResourceFile), NavigateURL(FileManagerModule.TabID))
				End If
				divLog.Controls.Add(LangPackWriter.ProgressLog.GetLogsTable)
				pnlLogs.Visible = True
			End If
		End Sub
#End Region

#Region "Private Methods"
		Private Sub BindLanguages()
			Dim locales As LocaleCollection = Localization.GetSupportedLocales()
			cboLanguage.DataSource = New LocaleCollectionWrapper(locales)
			cboLanguage.DataTextField = "Text"
			cboLanguage.DataValueField = "Code"
			cboLanguage.DataBind()
			cboLanguage.Items.Insert(0, New ListItem("English", ""))
		End Sub
#End Region

		Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
			Try
				Response.Redirect(NavigateURL())
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub
	End Class
End Namespace