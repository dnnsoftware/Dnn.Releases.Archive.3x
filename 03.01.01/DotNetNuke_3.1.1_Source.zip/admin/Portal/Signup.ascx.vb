'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.Xml
Imports System.IO
Imports System.Xml.Schema
Imports ICSharpCode.SharpZipLib.Zip

Namespace DotNetNuke.Modules.Admin.PortalManagement

    Public MustInherit Class Signup
		Inherits DotNetNuke.Entities.Modules.PortalModuleBase

#Region "Controls"

        Protected WithEvents lblInstructions As System.Web.UI.WebControls.Label
        Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
        Protected WithEvents lstResults As System.Web.UI.WebControls.DataList

        Protected dshPortal As UI.UserControls.SectionHeadControl
        Protected WithEvents tblPortal As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents rowType As System.Web.UI.HtmlControls.HtmlTableRow
        Protected WithEvents optType As System.Web.UI.WebControls.RadioButtonList
        Protected WithEvents txtPortalName As System.Web.UI.WebControls.TextBox
        Protected WithEvents valPortalName As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtTitle As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtDescription As System.Web.UI.WebControls.TextBox
        Protected WithEvents txtKeyWords As System.Web.UI.WebControls.TextBox
        Protected WithEvents cboTemplate As System.Web.UI.WebControls.DropDownList

        Protected dshSecurity As UI.UserControls.SectionHeadControl
        Protected WithEvents tblSecurity As System.Web.UI.HtmlControls.HtmlTable
        Protected WithEvents txtFirstName As System.Web.UI.WebControls.TextBox
        Protected WithEvents valFirstName As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtLastName As System.Web.UI.WebControls.TextBox
        Protected WithEvents valLastName As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtUsername As System.Web.UI.WebControls.TextBox
        Protected WithEvents valUsername As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtPassword As System.Web.UI.WebControls.TextBox
        Protected WithEvents valPassword As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtConfirm As System.Web.UI.WebControls.TextBox
        Protected WithEvents valConfirm As System.Web.UI.WebControls.RequiredFieldValidator
        Protected WithEvents txtEmail As System.Web.UI.WebControls.TextBox
        Protected WithEvents valEmail As System.Web.UI.WebControls.RequiredFieldValidator

        Protected WithEvents cmdUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCancel As System.Web.UI.WebControls.LinkButton
		Protected WithEvents txtHomeDirectory As System.Web.UI.WebControls.TextBox
		Protected WithEvents btnCustomizeHomeDir As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblTemplateDescription As System.Web.UI.WebControls.Label
        Protected WithEvents valTemplate As System.Web.UI.WebControls.RequiredFieldValidator

        Protected WithEvents lblNote As System.Web.UI.WebControls.Label

#End Region

#Region "Event Handlers"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Page_Load runs when the control is loaded.
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	5/10/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try
				Dim strFolder As String
				Dim strFileName As String
				Dim strMessage As String

				' ensure portal signup is allowed
				If (PortalSettings.ActiveTab.ParentId <> PortalSettings.SuperTabId Or UserInfo.IsSuperUser = False) And Convert.ToString(Common.Globals.HostSettings("DemoSignup")) <> "Y" Then
					Response.Redirect(NavigateURL("Access Denied"), True)
				End If

				If Not Page.IsPostBack Then

					strFolder = Common.Globals.HostMapPath
					If System.IO.Directory.Exists(strFolder) Then
						' admin.template and a portal template are required at minimum
						Dim fileEntries As String() = System.IO.Directory.GetFiles(strFolder, "*.template")
						lblMessage.Text = Services.Localization.Localization.GetString("AdminMissing", Me.LocalResourceFile)
						cmdUpdate.Enabled = False

						For Each strFileName In fileEntries
							If Path.GetFileNameWithoutExtension(strFileName) = "admin" Then
								lblMessage.Text = ""
								cmdUpdate.Enabled = True
							Else
								cboTemplate.Items.Add(Path.GetFileNameWithoutExtension(strFileName))
							End If
						Next

						If cboTemplate.Items.Count = 0 Then
							lblMessage.Text = Services.Localization.Localization.GetString("PortalMissing", Me.LocalResourceFile)
							cmdUpdate.Enabled = False
						End If
						cboTemplate.Items.Insert(0, New ListItem(Services.Localization.Localization.GetString("None_Specified"), "-1"))
						cboTemplate.SelectedIndex = 0
					End If

					If PortalSettings.ActiveTab.ParentId = PortalSettings.SuperTabId Then
						rowType.Visible = True
						optType.SelectedValue = "P"
					Else
						rowType.Visible = False
						strMessage = String.Format(Services.Localization.Localization.GetString("DemoMessage", Me.LocalResourceFile), Convert.ToString(IIf(Convert.ToString(Common.Globals.HostSettings("DemoPeriod")) <> "", " for " & Convert.ToString(Common.Globals.HostSettings("DemoPeriod")) & " days", "")), GetDomainName(Request))
                        lblInstructions.Text = strMessage
                        btnCustomizeHomeDir.Visible = False
					End If

					txtHomeDirectory.Text = "Portals/[PortalID]"
					txtHomeDirectory.Enabled = False

				End If

			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdCancel_Click runs when the Cancel button is clicked
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	5/10/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
			Try
				Response.Redirect(GetPortalDomainName(PortalAlias.HTTPAlias, Request), True)

			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdUpdate_Click runs when the Update button is clicked
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	5/10/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdUpdate.Click

			If Page.IsValid Then
				Try
					Dim blnChild As Boolean
					Dim strMessage As String
					Dim strPortalAlias As String
					Dim intCounter As Integer
					Dim intPortalId As Integer
					Dim strServerPath As String
					Dim strBody As String
					Dim strChildPath As String

					Dim objPortalController As New PortalController
					Dim objSecurity As New PortalSecurity

					' check template validity
					Dim xval As New PortalTemplateValidator
					Dim messages As New ArrayList
					xval.SetXML(Common.Globals.HostMapPath & cboTemplate.SelectedItem.Text & ".template")
					Dim filename As String = Server.MapPath("admin/Portal/portal.template.xsd")
					xval.LoadSchema(filename)
					If Not xval.IsValid Then
						strMessage = Services.Localization.Localization.GetString("InvalidTemplate", Me.LocalResourceFile)
						lblMessage.Text = String.Format(strMessage, cboTemplate.SelectedItem.Text & ".template")
						messages.AddRange(xval.Errors)
						lstResults.Visible = True
						lstResults.DataSource = messages
						lstResults.DataBind()
						Exit Sub
					End If

					'Set Portal Name
					txtPortalName.Text = LCase(txtPortalName.Text)
					txtPortalName.Text = Replace(txtPortalName.Text, "http://", "")

					'Validate Portal Name
					If PortalSettings.ActiveTab.ParentId <> PortalSettings.SuperTabId Then
						blnChild = True

						' child portal
						For intCounter = 1 To txtPortalName.Text.Length
							If InStr(1, "abcdefghijklmnopqrstuvwxyz0123456789-", Mid(txtPortalName.Text, intCounter, 1)) = 0 Then
								strMessage &= "<br>" & Services.Localization.Localization.GetString("InvalidName", Me.LocalResourceFile)
							End If
						Next intCounter

						strPortalAlias = txtPortalName.Text
					Else
						blnChild = (optType.SelectedValue = "C")

						If blnChild Then
							strPortalAlias = Mid(txtPortalName.Text, InStrRev(txtPortalName.Text, "/") + 1)
						Else
							strPortalAlias = txtPortalName.Text
						End If

						Dim strValidChars As String = "abcdefghijklmnopqrstuvwxyz0123456789-"
						If Not blnChild Then
                            strValidChars += "./:"
						End If

						For intCounter = 1 To strPortalAlias.Length
							If InStr(1, strValidChars, Mid(strPortalAlias, intCounter, 1)) = 0 Then
								strMessage &= "<br>" & Services.Localization.Localization.GetString("InvalidName", Me.LocalResourceFile)
							End If
						Next intCounter
					End If

					'Validate Password
					If txtPassword.Text <> txtConfirm.Text Then
						strMessage &= "<br>" & Services.Localization.Localization.GetString("InvalidPassword", Me.LocalResourceFile)
					End If

					strServerPath = GetAbsoluteServerPath(Request)

					'Set Portal Alias for Child Portals
					If strMessage = "" Then
						If blnChild Then
							strChildPath = strServerPath & strPortalAlias

							If System.IO.Directory.Exists(strChildPath) Then
								strMessage = Services.Localization.Localization.GetString("ChildExists", Me.LocalResourceFile)
							Else
								If PortalSettings.ActiveTab.ParentId <> PortalSettings.SuperTabId Then
									strPortalAlias = GetDomainName(Request) & "/" & strPortalAlias
								Else
									strPortalAlias = txtPortalName.Text
								End If
							End If
						End If
					End If

					'Get Home Directory
					Dim HomeDir As String
					If txtHomeDirectory.Text <> "Portals/[PortalID]" Then
						HomeDir = txtHomeDirectory.Text
					Else
						HomeDir = ""
					End If


					'Create Portal
					If strMessage = "" Then

						Dim strTemplateFile As String = cboTemplate.SelectedItem.Text & ".template"

						intPortalId = objPortalController.CreatePortal(txtTitle.Text, txtFirstName.Text, txtLastName.Text, txtUsername.Text, objSecurity.Encrypt(Convert.ToString(Common.Globals.HostSettings("EncryptionKey")), txtPassword.Text), txtEmail.Text, txtDescription.Text, txtKeyWords.Text, Common.Globals.HostMapPath, strTemplateFile, HomeDir, strPortalAlias, strServerPath, strChildPath, blnChild)

						If intPortalId <> -1 Then

							' notification
							Dim objUsers As New UserController
							Dim objUser As UserInfo = objUsers.GetUserByUsername(intPortalId, txtUsername.Text)

							'Create a Portal Settings object for the new Portal
							Dim newSettings As New PortalSettings
							newSettings.PortalAlias = New PortalAliasInfo
							newSettings.PortalAlias.HTTPAlias = strPortalAlias
							newSettings.PortalId = intPortalId

							If PortalSettings.ActiveTab.ParentId <> PortalSettings.SuperTabId Then
                                SendNotification(PortalSettings.Email, txtEmail.Text, PortalSettings.Email & ";" & Convert.ToString(PortalSettings.HostSettings("HostEmail")), Services.Localization.Localization.GetSystemMessage(newSettings, "EMAIL_PORTAL_SIGNUP_SUBJECT", objUser), Services.Localization.Localization.GetSystemMessage(newSettings, "EMAIL_PORTAL_SIGNUP_BODY", objUser))
							Else
                                SendNotification(Convert.ToString(PortalSettings.HostSettings("HostEmail")), txtEmail.Text, Convert.ToString(PortalSettings.HostSettings("HostEmail")), Services.Localization.Localization.GetSystemMessage(newSettings, "EMAIL_PORTAL_SIGNUP_SUBJECT", objUser), Services.Localization.Localization.GetSystemMessage(newSettings, "EMAIL_PORTAL_SIGNUP_BODY", objUser))
							End If

							Dim objEventLog As New Services.Log.EventLog.EventLogController
							objEventLog.AddLog(objPortalController.GetPortal(intPortalId), PortalSettings, UserId, "", Services.Log.EventLog.EventLogController.EventLogType.PORTAL_CREATED)

							' Redirect to this new site
							Response.Redirect(AddHTTP(strPortalAlias), True)
						Else
							strMessage = Services.Localization.Localization.GetString("CreateError", Me.LocalResourceFile)
						End If
					End If

					lblMessage.Text = "<br>" & strMessage & "<br><br>"

				Catch exc As Exception				'Module failed to load
					ProcessModuleLoadException(Me, exc)
				End Try
			End If
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' optType_SelectedIndexChanged runs when the Portal Type is changed
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	5/10/2004	Updated to reflect design changes for Help, 508 support
		'''                       and localisation
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub optType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles optType.SelectedIndexChanged
			Try
				If optType.SelectedValue = "C" Then
					txtPortalName.Text = GetDomainName(Request) & "/"
				End If
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		Private Sub btnCustomizeHomeDir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCustomizeHomeDir.Click
			Try
				If txtHomeDirectory.Enabled Then
					btnCustomizeHomeDir.Text = Services.Localization.Localization.GetString("Customize", LocalResourceFile)
					txtHomeDirectory.Text = "Portals/[PortalID]"
					txtHomeDirectory.Enabled = False
				Else
					btnCustomizeHomeDir.Text = Services.Localization.Localization.GetString("AutoGenerate", LocalResourceFile)
					txtHomeDirectory.Text = ""
					txtHomeDirectory.Enabled = True
				End If
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		Private Sub cboTemplate_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboTemplate.SelectedIndexChanged
			Try
				Dim filename As String

				If cboTemplate.SelectedIndex > 0 Then
					filename = Common.Globals.HostMapPath & cboTemplate.SelectedItem.Text & ".template"
					Dim xmldoc As New XmlDocument
					Dim node As XmlNode
					xmldoc.Load(filename)
					node = xmldoc.SelectSingleNode("//portal/description")
					If Not node Is Nothing AndAlso node.InnerXml <> "" Then
						lblTemplateDescription.Visible = True
						lblTemplateDescription.Text = Server.HtmlDecode(node.InnerXml)
					Else
						lblTemplateDescription.Visible = False
					End If
				Else
					lblTemplateDescription.Visible = False
				End If
			Catch exc As Exception			 'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try

		End Sub

#End Region

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

	End Class

End Namespace
