'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System.IO
Imports System.Drawing.Imaging
Imports System.XML
Imports DotNetNuke.UI.Skins
Imports DotNetNuke.Services.Wizards
Imports DotNetNuke.UI.UserControls


Namespace DotNetNuke.Modules.Admin.PortalManagement

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' The SiteWizard Wizard is a user-friendly Wizard that leads the user through the
	'''	process of setting up a new site
	''' </summary>
	''' <returns></returns>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[cnurse]	10/8/2004	created
	''' </history>
	''' -----------------------------------------------------------------------------
	Public Class SiteWizard
		Inherits DotNetNuke.Services.Wizards.Wizard

        Public Enum ContainerType
            Host = 0
            Portal = 1
            Folder = 2
            All = 3
        End Enum


#Region "Controls"

		'Wizard Framework Controls
		Protected WithEvents Wizard As System.Web.UI.HtmlControls.HtmlTable
		Protected WithEvents WizardBody As System.Web.UI.HtmlControls.HtmlTableCell

		'Page 1 Controls
        Protected WithEvents pnlTemplate As System.Web.UI.WebControls.Panel
        Protected WithEvents lblTemplateTitle As LabelControl
        Protected WithEvents chkTemplate As System.Web.UI.WebControls.CheckBox
        Protected WithEvents lstTemplate As System.Web.UI.WebControls.ListBox
		Protected WithEvents lblTemplateMessage As System.Web.UI.WebControls.Label
		Protected WithEvents lblMergeTitle As System.Web.UI.WebControls.Label
		Protected WithEvents optMerge As System.Web.UI.WebControls.RadioButtonList
		Protected WithEvents lblMergeWarning As System.Web.UI.WebControls.Label

        'Page 2 Controls
        Protected WithEvents pnlSkin As System.Web.UI.WebControls.Panel
        Protected WithEvents lblSkinTitle As LabelControl
		Protected WithEvents lblSkinDetail As System.Web.UI.WebControls.Label
		Protected WithEvents ctlPortalSkin As UI.Skins.SkinThumbNailControl

        'Page 3 Controls
        Protected WithEvents pnlContainer As System.Web.UI.WebControls.Panel
        Protected WithEvents lblContainerTitle As LabelControl
        Protected WithEvents lblContainerDetail As System.Web.UI.WebControls.Label
        Protected WithEvents chkIncludeAll As System.Web.UI.WebControls.CheckBox
        Protected WithEvents ctlPortalContainer As UI.Skins.SkinThumbNailControl

        'Page 4 Controls
		Protected WithEvents pnlDetails As System.Web.UI.WebControls.Panel
        Protected WithEvents lblDetailsTitle As LabelControl
        Protected WithEvents lblDetailsDetail As System.Web.UI.WebControls.Label
        Protected WithEvents lblPortalName As LabelControl
		Protected WithEvents txtPortalName As System.Web.UI.WebControls.TextBox
        Protected WithEvents lblDescription As LabelControl
		Protected WithEvents txtDescription As System.Web.UI.WebControls.TextBox
        Protected WithEvents lblKeyWords As LabelControl
		Protected WithEvents txtKeyWords As System.Web.UI.WebControls.TextBox

        'Page 5 Controls
        Protected WithEvents pnlLogo As System.Web.UI.WebControls.Panel
        Protected WithEvents lblLogoTitle As LabelControl
        Protected WithEvents lblLogo As LabelControl
		Protected WithEvents urlLogo As UI.UserControls.UrlControl

#End Region

#Region "Private Members"


#End Region

#Region "Private Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' BindContainers manages the containers
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	12/15/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub BindContainers()

            ctlPortalContainer.Clear()

            If chkIncludeAll.Checked Then
                GetContainers(ContainerType.All, "", "")
            Else
                If ctlPortalSkin.SkinSrc <> "" Then
                    Dim strFolder As String
                    Dim strContainerFolder As String = ctlPortalSkin.SkinSrc.Substring(0, ctlPortalSkin.SkinSrc.LastIndexOf("/"))
                    If strContainerFolder.StartsWith("[G]") Then
                        strContainerFolder = strContainerFolder.Replace("[G]Skins/", "Containers\")
						strFolder = Common.Globals.HostMapPath & strContainerFolder
                        GetContainers(ContainerType.Folder, "[G]", strFolder)
                    Else
                        strContainerFolder = strContainerFolder.Replace("[L]Skins/", "Containers\")
						strFolder = PortalSettings.HomeDirectoryMapPath & strContainerFolder
                        GetContainers(ContainerType.Folder, "[L]", strFolder)
                    End If
                Else
                    GetContainers(ContainerType.Portal, "", "")
                End If
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetContainers gets the containers and binds the lists to the controls
        '''	the buttons
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="type">An enum indicating what type of containers to load</param>
        ''' <param name="skinType">A string that identifies whether the skin is Host "[G]" or Site "[L]"</param>
        ''' <param name="strFolder">The folder to search for skins</param>
        ''' <history>
        ''' 	[cnurse]	12/14/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub GetContainers(ByVal type As ContainerType, ByVal skinType As String, ByVal strFolder As String)

            Dim objSkins As New UI.Skins.SkinController
            Dim objSkin As UI.Skins.SkinInfo

            'Configure SkinControl
            ctlPortalContainer.Width = "500px"
            ctlPortalContainer.Height = "250px"
            ctlPortalContainer.Border = "black 1px solid"
            ctlPortalContainer.Columns = 3
            ctlPortalContainer.SkinRoot = SkinInfo.RootContainer
            Select Case type
                Case ContainerType.Folder
                    ctlPortalContainer.LoadSkins(strFolder, skinType, False)
                Case ContainerType.Portal
                    ctlPortalContainer.LoadPortalSkins(False)
                Case ContainerType.Host
                    ctlPortalContainer.LoadHostSkins(False)
                Case ContainerType.All
                    ctlPortalContainer.LoadAllSkins(False)
            End Select

            'Get current container and set selected skin
            objSkin = objSkins.GetSkin(SkinInfo.RootContainer, PortalId, DotNetNuke.UI.Skins.SkinType.Portal)
            If Not objSkin Is Nothing Then
                If objSkin.PortalId = PortalId Then
                    ctlPortalContainer.SkinSrc = objSkin.SkinSrc
                End If
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetSkins gets the skins and containers and binds the lists to the controls
        '''	the buttons
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	11/04/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub GetSkins()

            Dim objSkins As New UI.Skins.SkinController
            Dim objSkin As UI.Skins.SkinInfo

            'Configure SkinControl
            ctlPortalSkin.Width = "500px"
            ctlPortalSkin.Height = "250px"
            ctlPortalSkin.Border = "black 1px solid"
            ctlPortalSkin.Columns = 3
            ctlPortalSkin.SkinRoot = SkinInfo.RootSkin
            ctlPortalSkin.LoadAllSkins(False)

            'Get current skin and set selected skin
            objSkin = objSkins.GetSkin(SkinInfo.RootSkin, PortalId, SkinType.Portal)
            If Not objSkin Is Nothing Then
                If objSkin.PortalId = PortalId Then
                    ctlPortalSkin.SkinSrc = objSkin.SkinSrc
                End If
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' GetTemplates gets the skins and containers and binds the lists to the control
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	11/04/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub GetTemplates()

            Dim strFolder As String
            Dim strFileName As String

			strFolder = Common.Globals.HostMapPath
            If System.IO.Directory.Exists(strFolder) Then
                ' admin.template and a portal template are required at minimum
                Dim fileEntries As String() = System.IO.Directory.GetFiles(strFolder, "*.template")
                Me.EnableCommand(WizardCommand.NextPage, False)
                Me.EnableCommand(WizardCommand.Finish, False)

                For Each strFileName In fileEntries
                    If Path.GetFileNameWithoutExtension(strFileName) = "admin" Then
                        Me.EnableCommand(WizardCommand.NextPage, True)
                        Me.EnableCommand(WizardCommand.Finish, True)
                    Else
                        lstTemplate.Items.Add(Path.GetFileNameWithoutExtension(strFileName))
                    End If
                Next

                If lstTemplate.Items.Count = 0 Then
                    Me.EnableCommand(WizardCommand.NextPage, False)
                    Me.EnableCommand(WizardCommand.Finish, False)
                End If
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' UseTemplate sets the page ready to select a Template
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	11/04/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub UseTemplate()
            lstTemplate.Enabled = chkTemplate.Checked
            optMerge.Enabled = chkTemplate.Checked
            lblMergeTitle.Enabled = chkTemplate.Checked
            lblMergeWarning.Enabled = chkTemplate.Checked
            lblTemplateMessage.Text = ""
        End Sub

#End Region

#Region "Public Methods"

#End Region

#Region "Event Handlers"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Page_Load runs when the control is loaded
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	10/11/2004	created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try

                Me.AddPage(DotNetNuke.Services.Localization.Localization.GetString("ChooseTemplate.Title", Me.LocalResourceFile), "~/images/icon_portals_40px.gif", pnlTemplate, DotNetNuke.Services.Localization.Localization.GetString("Template.Help", Me.LocalResourceFile))
                Me.AddPage(DotNetNuke.Services.Localization.Localization.GetString("ChooseSkin.Title", Me.LocalResourceFile), "~/images/icon_skins_36px.gif", pnlSkin, DotNetNuke.Services.Localization.Localization.GetString("Skin.Help", Me.LocalResourceFile))
                Me.AddPage(DotNetNuke.Services.Localization.Localization.GetString("ChooseContainer.Title", Me.LocalResourceFile), "~/images/icon_skins_36px.gif", pnlContainer, DotNetNuke.Services.Localization.Localization.GetString("Container.Help", Me.LocalResourceFile))
                Me.AddPage(DotNetNuke.Services.Localization.Localization.GetString("Details.Title", Me.LocalResourceFile), "~/images/icon_sitesettings_36px.gif", pnlDetails, DotNetNuke.Services.Localization.Localization.GetString("Details.Help", Me.LocalResourceFile))
                Me.AddPage(DotNetNuke.Services.Localization.Localization.GetString("Logo.Title", Me.LocalResourceFile), "~/images/icon_sitesettings_36px.gif", pnlLogo, DotNetNuke.Services.Localization.Localization.GetString("Logo.Help", Me.LocalResourceFile))

				If Not Page.IsPostBack Then

					'Get Templates for Page 1
					GetTemplates()
					chkTemplate.Checked = False
					lstTemplate.Enabled = False

                    'Get Skins for Pages 2
					GetSkins()

                    'Get Details for Page 4
					Dim objPortalController As New PortalController
					Dim objPortal As PortalInfo = objPortalController.GetPortal(PortalId)
					txtPortalName.Text = objPortal.PortalName
					txtDescription.Text = objPortal.Description
					txtKeyWords.Text = objPortal.KeyWords

                    'Get Details for Page 5
                    urlLogo.Url = objPortal.LogoFile
                    urlLogo.FileFilter = glbImageFileTypes

					Me.CurrentPage = 0
					Me.FinishPage = 2

					Me.DisplayCurrentPage()

                    UseTemplate()
                End If


            Catch exc As Exception    'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
        ''' Page_AfterPageChanged runs when a Wizard page has already been changed
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	10/12/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_AfterPageChanged(ByVal sender As Object, ByVal we As Services.Wizards.WizardEventArgs) Handles MyBase.AfterPageChanged

            Select Case we.PageNo
                Case 2    'Page 3 (Containers)
                    BindContainers()
            End Select

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
		''' Page_BeforePageChanged runs when a Wizard page is about to be changed.  It provides
		'''	a mechanism for cancelling the page change if certain conditions aren't met.
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	10/12/2004	created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_BeforePageChanged(ByVal sender As Object, ByVal we As WizardCancelEventArgs) Handles MyBase.BeforePageChanged

			Dim strMessage As String

			Select Case we.PageNo
                Case 0    'Page 1
                    'Before we leave Page 1, the user must have selected a Portal
                    If lstTemplate.SelectedIndex = -1 Then
                        If chkTemplate.Checked Then
                            we.Cancel = True
                            lblTemplateMessage.Text = Services.Localization.Localization.GetString("TemplateRequired", Me.LocalResourceFile)
                        End If
                    Else
                        'Check Template Validity before proceeding
                        Dim xval As New PortalTemplateValidator
						xval.SetXML(Common.Globals.HostMapPath & lstTemplate.SelectedItem.Text & ".template")
                        Dim filename As String = Server.MapPath("admin/Portal/portal.template.xsd")
                        xval.LoadSchema(filename)
                        If Not xval.IsValid Then
                            strMessage = Services.Localization.Localization.GetString("InvalidTemplate", Me.LocalResourceFile)
                            lblTemplateMessage.Text = String.Format(strMessage, lstTemplate.SelectedItem.Text & ".template")
                            'Cancel Page move if invalid template
                            we.Cancel = True
                        End If
                    End If

            End Select
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Page_FinishWizard runs when the Finish Button on the Wizard is clicked.
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	10/12/2004	created
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_FinishWizard(ByVal sender As Object, ByVal we As WizardEventArgs) Handles MyBase.FinishWizard

			Dim objPortalController As New PortalController

            ' use Portal Template to update portal content pages
			If lstTemplate.SelectedIndex <> -1 Then
				Dim strTemplateFile As String = lstTemplate.SelectedItem.Text & ".template"

                ' process zip resource file if present
                objPortalController.ProcessResourceFile(PortalSettings.HomeDirectoryMapPath, Common.Globals.HostMapPath & strTemplateFile)

                'Process Template
                Select Case optMerge.SelectedValue
                    Case "Ignore"
                        objPortalController.ParseTemplate(PortalId, Common.Globals.HostMapPath, strTemplateFile, PortalSettings.AdministratorId, PortalTemplateModuleAction.Ignore, False)
                    Case "Replace"
                        objPortalController.ParseTemplate(PortalId, Common.Globals.HostMapPath, strTemplateFile, PortalSettings.AdministratorId, PortalTemplateModuleAction.Replace, False)
                    Case "Merge"
                        objPortalController.ParseTemplate(PortalId, Common.Globals.HostMapPath, strTemplateFile, PortalSettings.AdministratorId, PortalTemplateModuleAction.Merge, False)
                End Select
            End If


			' update Portal info in the database
            Dim objPortal As PortalInfo = objPortalController.GetPortal(PortalId)
            objPortal.Description = txtDescription.Text
			objPortal.KeyWords = txtKeyWords.Text
			objPortal.PortalName = txtPortalName.Text
			objPortal.LogoFile = urlLogo.Url
			objPortalController.UpdatePortalInfo(objPortal)

            Dim objSkins As New UI.Skins.SkinController

            'Set Portal Skin
            objSkins.SetSkin(SkinInfo.RootSkin, PortalId, SkinType.Portal, ctlPortalSkin.SkinSrc)
            objSkins.SetSkin(SkinInfo.RootSkin, PortalId, SkinType.Admin, ctlPortalSkin.SkinSrc)

            'Set Portal Container
            objSkins.SetSkin(SkinInfo.RootContainer, PortalId, SkinType.Portal, ctlPortalContainer.SkinSrc)
            objSkins.SetSkin(SkinInfo.RootContainer, PortalId, SkinType.Admin, ctlPortalContainer.SkinSrc)

            Me.DisplaySuccessPage(DotNetNuke.Services.Localization.Localization.GetString("SuccessMessage", Me.LocalResourceFile))

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' chkIncludeAll_CheckedChanged runs when include all containers checkbox status is changed
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	12/15/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub chkIncludeAll_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkIncludeAll.CheckedChanged
            BindContainers()
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' chkTemplate_CheckedChanged runs when use template checkbox status is changed
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	10/13/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub chkTemplate_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkTemplate.CheckedChanged

            If chkTemplate.Checked Then
                lstTemplate.SelectedIndex = -1
            End If

            UseTemplate()

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' lstTemplate_SelectedIndexChanged runs when the selected template is changed
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	11/04/2004	created
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub lstTemplate_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstTemplate.SelectedIndexChanged

            If lstTemplate.SelectedIndex > -1 Then
                Dim xmlDoc As New XmlDocument
                Dim node As XmlNode
				Dim strTemplatePath As String = Common.Globals.HostMapPath
                Dim strTemplateFile As String = lstTemplate.SelectedItem.Text & ".template"

                ' open the XML file
                Try
                    xmlDoc.Load(strTemplatePath & strTemplateFile)
                    node = xmlDoc.SelectSingleNode("//portal/description")
                    If Not node Is Nothing Then
                        lblTemplateMessage.Text = node.InnerText
                    Else
                        lblTemplateMessage.Text = ""
                    End If
                Catch    ' error
                    lblTemplateMessage.Text = "Error Loading Template description"
                End Try
            Else
                lblTemplateMessage.Text = ""
            End If
        End Sub

#End Region

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.

            InitializeComponent()

        End Sub

#End Region

    End Class

End Namespace

