'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports ICSharpCode.SharpZipLib.Zip
Imports ICSharpCode.SharpZipLib.Checksums
Imports ICSharpCode.SharpZipLib.GZip
Imports System.IO
Imports System.Xml
Imports System.Xml.Serialization
Imports DotNetNuke.Modules.Admin.ResourceInstaller
Imports DotNetNuke.Entities.Modules.Definitions
Imports DotNetNuke.Services.Localization
Imports DotNetNuke.Framework.Providers

Namespace DotNetNuke.Entities.Modules

    ''' -----------------------------------------------------------------------------
    ''' Project	 : DotNetNuke
    ''' Class	 : PaWriter
    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The PaWriter class packages a Module as a Private Assembly.
    ''' </summary>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    '''		[cnurse]	01/13/2005	created
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public Class PaWriter

#Region "Private Members"

        Private _ProgressLog As New PaLogger

        'Source Folder of PA
        Private _Folder As String

        'Name of PA
        Private _Name As String

        'List of Files to include in PA
        Private _Files As New ArrayList


#End Region

#Region "Public Properties"

        Public ReadOnly Property ProgressLog() As PaLogger
            Get
                Return _ProgressLog
            End Get
        End Property

#End Region

#Region "Private Methods"

        Private Sub CreateDnnManifest(ByVal objDesktopModule As DesktopModuleInfo)

            Dim filename As String

            'Create Manifest Document
            Dim xmlManifest As New XmlDocument

            'Root Element
            Dim nodeRoot As XmlNode = xmlManifest.CreateElement("dotnetnuke")
            nodeRoot.Attributes.Append(XmlUtils.CreateAttribute(xmlManifest, "version", "3.0"))
            nodeRoot.Attributes.Append(XmlUtils.CreateAttribute(xmlManifest, "type", "Module"))

            'Folders Element
            Dim nodeFolders As XmlNode = xmlManifest.CreateElement("folders")
            nodeRoot.AppendChild(nodeFolders)

            'Folder Element
            Dim nodeFolder As XmlNode = xmlManifest.CreateElement("folder")
            nodeFolders.AppendChild(nodeFolder)

            'Desktop Module Info
            _Name = objDesktopModule.FriendlyName
            nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "name", _Name))
            nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "friendlyname", _Name))
            nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "description", objDesktopModule.Description))
            If objDesktopModule.Version = Null.NullString Then
                objDesktopModule.Version = "01.00.00"
            End If
            nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "version", objDesktopModule.Version))
            nodeFolder.AppendChild(XmlUtils.CreateElement(xmlManifest, "businesscontrollerclass", objDesktopModule.BusinessControllerClass))

            'Modules Element
            Dim nodeModules As XmlNode = xmlManifest.CreateElement("modules")
            nodeFolder.AppendChild(nodeModules)

            'Get the Module Definitions for this Module
            Dim objModuleDefinitionController As New ModuleDefinitionController
            Dim arrModuleDefinitions As ArrayList = objModuleDefinitionController.GetModuleDefinitions(objDesktopModule.DesktopModuleID)

            'Iterate through Module Definitions
            For Each objModuleInfo As ModuleDefinitionInfo In arrModuleDefinitions
                Dim nodeModule As XmlNode = xmlManifest.CreateElement("module")

                'Add module definition properties
                nodeModule.AppendChild(XmlUtils.CreateElement(xmlManifest, "friendlyname", objModuleInfo.FriendlyName))

                'Get the Module Controls for this Module Definition
                Dim objModuleControlController As New ModuleControlController
                Dim arrModuleControls As ArrayList = objModuleControlController.GetModuleControls(objModuleInfo.ModuleDefID)

                'Controls Element
                Dim nodeControls As XmlNode = xmlManifest.CreateElement("controls")
                nodeModule.AppendChild(nodeControls)

                'Iterate through Module Controls
                For Each objModuleControl As ModuleControlInfo In arrModuleControls
                    Dim nodeControl As XmlNode = xmlManifest.CreateElement("control")

                    'Dim src As String = objModuleControl.ControlSrc.Replace("DesktopModules/" & _Name & "/", "")

                    'Add module control properties
                    XmlUtils.AppendElement(xmlManifest, nodeControl, "key", objModuleControl.ControlKey, False)
                    XmlUtils.AppendElement(xmlManifest, nodeControl, "title", objModuleControl.ControlTitle, False)

                    XmlUtils.AppendElement(xmlManifest, nodeControl, "src", objModuleControl.ControlSrc, True)
                    XmlUtils.AppendElement(xmlManifest, nodeControl, "iconfile", objModuleControl.IconFile, False)
                    XmlUtils.AppendElement(xmlManifest, nodeControl, "type", objModuleControl.ControlType.ToString, True)
                    XmlUtils.AppendElement(xmlManifest, nodeControl, "helpurl", objModuleControl.HelpURL, False)

                    'Add control Node to controls
                    nodeControls.AppendChild(nodeControl)

                    'Determine the filename for the Manifest file (It should be saved witht the other Module files)
                    If filename = "" Then
                        Dim controlSrc As String = objModuleControl.ControlSrc.Replace("/", "\")
                        Dim strFolderpath As String = controlSrc.Substring(0, controlSrc.LastIndexOf("\"))

                        _Folder = Common.Globals.ApplicationMapPath & "\" & strFolderpath
                        filename = _Folder & "\" & objDesktopModule.FriendlyName + ".dnn"

                    End If
                Next

                'Add module Node to modules
                nodeModules.AppendChild(nodeModule)
            Next

            'Create File List
            CreateFileList()

            'Files Element
            Dim nodeFiles As XmlNode = xmlManifest.CreateElement("files")
            nodeFolder.AppendChild(nodeFiles)

            'Add the files
            For Each file As PaFileInfo In _Files
                Dim nodeFile As XmlNode = xmlManifest.CreateElement("file")

                'Add file properties
                XmlUtils.AppendElement(xmlManifest, nodeFile, "path", file.Path, False)
                XmlUtils.AppendElement(xmlManifest, nodeFile, "name", file.Name, False)

                'Add file Node to files
                nodeFiles.AppendChild(nodeFile)
            Next

            'Add Root element to document
            xmlManifest.AppendChild(nodeRoot)

            'Save Manifest file
            xmlManifest.Save(filename)

            'Add Manifest file to file list
            _Files.Add(New PaFileInfo(objDesktopModule.FriendlyName & ".dnn", "", _Folder))

        End Sub

        Private Sub CreateFileList()

            Dim assemblyName As String
            Dim assemblyFolder As String = ApplicationMapPath & "/bin"

            'Create the DirectoryInfo object
            Dim folder As New DirectoryInfo(_Folder)

            'Get the Project File in the folder
            Dim files As FileInfo() = folder.GetFiles("*.??proj")

            'Parse the Project files (probably only one)
            For Each projFile As FileInfo In files

                'Create and load the Project file xml
                Dim xmlProject As New XmlDocument
                xmlProject.Load(files(0).FullName)

                'Get the Assembly Name and add to File List
                Dim xmlSettings As XmlNode = xmlProject.SelectSingleNode("//Settings")
                assemblyName = xmlSettings.Attributes("AssemblyName").Value
                _Files.Add(New PaFileInfo(assemblyName & ".dll", "", assemblyFolder))

                Dim xmlFiles As XmlNodeList = xmlProject.SelectNodes("//File")

                'Iterate through files
                For Each xmlFile As XmlNode In xmlFiles
                    Dim attributeBuildAction As XmlAttribute = xmlFile.Attributes("BuildAction")
                    Dim attributeDependUpon As XmlAttribute = xmlFile.Attributes("DependentUpon")

                    Dim bIncludeFile As Boolean = False
                    If attributeBuildAction.Value = "None" Then bIncludeFile = True
                    If attributeBuildAction.Value = "Content" Then
                        If attributeDependUpon Is Nothing Then bIncludeFile = True
                    End If

                    If bIncludeFile Then
                        Dim relPath As String = xmlFile.Attributes("RelPath").Value.Replace("/", "\")
                        Dim path As String = ""
                        Dim name As String = relPath
                        Dim fullPath As String = _Folder
                        If relPath.LastIndexOf("\") > -1 Then
                            path = relPath.Substring(0, relPath.LastIndexOf("\"))
                            name = relPath.Replace(path & "\", "")
                            fullPath = fullPath & "\" & path
                        End If

                        _Files.Add(New PaFileInfo(name, path, fullPath))
                    End If
                Next
            Next

            'Get the Localization Files
            If Directory.Exists(_Folder & "\App_LocalResources") Then
                Dim localFolder As New DirectoryInfo(_Folder & "\App_LocalResources")
                Dim localFiles As FileInfo() = localFolder.GetFiles("*.resx")

                For Each localFile As FileInfo In localFiles
                    _Files.Add(New PaFileInfo(localFile.Name, "App_LocalResources", localFolder.FullName))
                Next
            End If

            'Get the Data Provider Files
            Dim objProviderConfiguration As ProviderConfiguration = ProviderConfiguration.GetProviderConfiguration("data")

            For Each entry As DictionaryEntry In objProviderConfiguration.Providers
                Dim strName As String = CType(entry.Key, String)
                Dim objProvider As Provider = CType(entry.Value, Provider)
                Dim providerName As String = objProvider.Name

                'Assume the scripts are located in Providers\DataProviders\ProviderName\*.ProviderName
                Dim providerPath As String = _Folder & "\Providers\DataProviders\" & providerName
                If Directory.Exists(providerPath) Then
                    'Add Provider Assembly
                    _Files.Add(New PaFileInfo(assemblyName & "." & providerName & ".dll", "", assemblyFolder))

                    Dim scriptFolder As New DirectoryInfo(providerPath)
                    Dim scripts As FileInfo() = scriptFolder.GetFiles("*." & providerName)

                    For Each script As FileInfo In scripts
                        _Files.Add(New PaFileInfo(script.Name, "", scriptFolder.FullName))
                    Next
                End If
            Next
        End Sub

        Private Function CreateZipFile() As String
            Dim CompressionLevel As Integer = 9
            Dim BlockSize As Integer = 4096
            Dim ZipFileName As String
            Dim ZipFileShortName As String = _Name
            Dim paZipEntry As ZipEntry
            ZipFileName = Common.Globals.HostMapPath & ZipFileShortName & ".zip"

            Dim strmZipFile As FileStream
            Try
                ProgressLog.AddInfo(String.Format(Localization.GetString("LOG.PAWriter.CreateArchive"), ZipFileShortName))
                strmZipFile = File.Create(ZipFileName)

                Dim strmZipStream As ZipOutputStream
                Try
                    strmZipStream = New ZipOutputStream(strmZipFile)
                    strmZipStream.SetLevel(CompressionLevel)

                    For Each PaFile As PaFileInfo In _Files
                        'Open File Stream
                        Dim fs As FileStream = File.OpenRead(PaFile.FullName)

                        'Read file into byte array buffer
                        Dim buffer As Byte()
                        ReDim buffer(Convert.ToInt32(fs.Length) - 1)
                        fs.Read(buffer, 0, buffer.Length)

                        'Create Zip Entry
                        Dim entry As ZipEntry = New ZipEntry(PaFile.Name)
                        Dim crc As Crc32 = New Crc32
                        entry.DateTime = DateTime.Now
                        entry.Size = fs.Length
                        fs.Close()
                        crc.Reset()
                        crc.Update(buffer)
                        entry.Crc = crc.Value

                        'Compress file and add to Zip file
                        strmZipStream.PutNextEntry(entry)
                        strmZipStream.Write(buffer, 0, buffer.Length)

                        ProgressLog.AddInfo(String.Format(Localization.GetString("LOG.PAWriter.SavedFile"), PaFile.Name))
                    Next
                Catch ex As Exception
                    LogException(ex)
                    ProgressLog.AddFailure(String.Format(Localization.GetString("LOG.PAWriter.ERROR.SavingFile"), ex))
                Finally
                    strmZipStream.Finish()
                    strmZipStream.Close()
                End Try
            Catch ex As Exception
                LogException(ex)
                ProgressLog.AddFailure(String.Format(Localization.GetString("LOG.PAWriter.ERROR.SavingFile"), ex))
            Finally
                strmZipFile.Close()
            End Try

            Return ZipFileName
        End Function

#End Region

#Region "Public Methods"

        Public Function CreatePrivateAssembly(ByVal DesktopModuleId As Integer) As String

            Dim Result As String

            'Get the Module Definition File for this Module
            Dim objDesktopModuleController As New DesktopModuleController
            Dim objModule As DesktopModuleInfo = objDesktopModuleController.GetDesktopModule(DesktopModuleId)


            ProgressLog.StartJob(String.Format(Localization.GetString("LOG.PAWriter.CreateManifest"), objModule.FriendlyName))
            CreateDnnManifest(objModule)
            ProgressLog.EndJob((String.Format(Localization.GetString("LOG.PAWriter.CreateManifest"), objModule.FriendlyName)))

            ProgressLog.StartJob(String.Format(Localization.GetString("LOG.PAWriter.CreateZipFile"), objModule.FriendlyName))
            CreateZipFile()
            ProgressLog.EndJob((String.Format(Localization.GetString("LOG.PAWriter.CreateZipFile"), objModule.FriendlyName)))

            Return Result
        End Function

#End Region

    End Class
End Namespace