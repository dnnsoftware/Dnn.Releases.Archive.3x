'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data
Imports System.Globalization
Imports System.Xml.Serialization

Namespace DotNetNuke.Entities.Modules

	Public Enum VisibilityState
		Maximized
		Minimized
		None
	End Enum

	<XmlRoot("module", IsNullable:=False)> Public Class ModuleInfo

		Private _PortalID As Integer
        Private _TabID As Integer
        Private _TabModuleID As Integer
		Private _ModuleID As Integer
		Private _ModuleDefID As Integer
		Private _ModuleOrder As Integer
		Private _PaneName As String
		Private _ModuleTitle As String
		Private _AuthorizedEditRoles As String
		Private _CacheTime As Integer
		Private _AuthorizedViewRoles As String
		Private _Alignment As String
		Private _Color As String
		Private _Border As String
		Private _IconFile As String
		Private _AllTabs As Boolean
		Private _Visibility As VisibilityState
		Private _AuthorizedRoles As String
		Private _IsDeleted As Boolean
		Private _Header As String
		Private _Footer As String
		Private _StartDate As Date
		Private _EndDate As Date
        Private _ContainerSrc As String
        Private _DisplayTitle As Boolean
        Private _DisplayPrint As Boolean
        Private _DisplaySyndicate As Boolean
        Private _InheritViewPermissions As Boolean
		Private _ModulePermissions As Security.Permissions.ModulePermissionCollection
		Private _DesktopModuleID As Integer
		Private _FriendlyName As String
		Private _Description As String
		Private _Version As String
		Private _IsPremium As Boolean
		Private _IsAdmin As Boolean
		Private _BusinessControllerClass As String
        Private _ModuleControlId As Integer
        Private _ControlSrc As String
        Private _ControlType As SecurityAccessLevel
        Private _ControlTitle As String
        Private _HelpUrl As String
        Private _ContainerPath As String
        Private _PaneModuleIndex As Integer
        Private _PaneModuleCount As Integer
        Private _IsDefaultModule As Boolean
        Private _AllModules As Boolean

		Public Sub New()
			'initialize the properties that can be null
            'in the database
            _PortalID = Null.NullInteger
            _TabID = Null.NullInteger
            _TabModuleID = Null.NullInteger
            _ModuleID = Null.NullInteger
            _ModuleDefID = Null.NullInteger
			_ModuleTitle = Null.NullString
			_AuthorizedEditRoles = Null.NullString
			_AuthorizedViewRoles = Null.NullString
			_Alignment = Null.NullString
			_Color = Null.NullString
			_Border = Null.NullString
			_IconFile = Null.NullString
			_Header = Null.NullString
			_Footer = Null.NullString
			_StartDate = Null.NullDate
            _EndDate = Null.NullDate
            _ContainerSrc = Null.NullString
            _DisplayTitle = True
            _DisplayPrint = True
            _DisplaySyndicate = False
		End Sub

		<XmlIgnore()> Public Property PortalID() As Integer
			Get
				Return _PortalID
			End Get
			Set(ByVal Value As Integer)
				_PortalID = Value
			End Set
		End Property
		<XmlIgnore()> Public Property TabID() As Integer
			Get
				Return _TabID
			End Get
			Set(ByVal Value As Integer)
				_TabID = Value
			End Set
		End Property
        <XmlIgnore()> Public Property TabModuleID() As Integer
            Get
                Return _TabModuleID
            End Get
            Set(ByVal Value As Integer)
                _TabModuleID = Value
            End Set
        End Property
        <XmlElement("moduleID")> Public Property ModuleID() As Integer
            Get
                Return _ModuleID
            End Get
            Set(ByVal Value As Integer)
                _ModuleID = Value
            End Set
        End Property
        <XmlIgnore()> Public Property ModuleDefID() As Integer
            Get
                Return _ModuleDefID
            End Get
            Set(ByVal Value As Integer)
                _ModuleDefID = Value
            End Set
        End Property
        <XmlIgnore()> Public Property ModuleOrder() As Integer
            Get
                Return _ModuleOrder
            End Get
            Set(ByVal Value As Integer)
                _ModuleOrder = Value
            End Set
        End Property
        <XmlIgnore()> Public Property PaneName() As String
            Get
                Return _PaneName
            End Get
            Set(ByVal Value As String)
                _PaneName = Value
            End Set
        End Property
        <XmlElement("title")> Public Property ModuleTitle() As String
            Get
                Return _ModuleTitle
            End Get
            Set(ByVal Value As String)
                _ModuleTitle = Value
            End Set
        End Property
        <XmlIgnore()> Public Property AuthorizedEditRoles() As String
            Get
                Return _AuthorizedEditRoles
            End Get
            Set(ByVal Value As String)
                _AuthorizedEditRoles = Value
            End Set
        End Property
        <XmlElement("cachetime")> Public Property CacheTime() As Integer
            Get
                Return _CacheTime
            End Get
            Set(ByVal Value As Integer)
                _CacheTime = Value
            End Set
        End Property
        <XmlIgnore()> Public Property AuthorizedViewRoles() As String
            Get
                Return _AuthorizedViewRoles
            End Get
            Set(ByVal Value As String)
                _AuthorizedViewRoles = Value
            End Set
        End Property
        <XmlElement("alignment")> Public Property Alignment() As String
            Get
                Return _Alignment
            End Get
            Set(ByVal Value As String)
                _Alignment = Value
            End Set
        End Property
        <XmlElement("color")> Public Property Color() As String
            Get
                Return _Color
            End Get
            Set(ByVal Value As String)
                _Color = Value
            End Set
        End Property
        <XmlElement("border")> Public Property Border() As String
            Get
                Return _Border
            End Get
            Set(ByVal Value As String)
                _Border = Value
            End Set
        End Property
        <XmlElement("iconfile")> Public Property IconFile() As String
            Get
                Return _IconFile
            End Get
            Set(ByVal Value As String)
                _IconFile = Value
            End Set
        End Property
        <XmlElement("alltabs")> Public Property AllTabs() As Boolean
            Get
                Return _AllTabs
            End Get
            Set(ByVal Value As Boolean)
                _AllTabs = Value
            End Set
        End Property
        <XmlElement("visibility")> Public Property Visibility() As VisibilityState
            Get
                Return _Visibility
            End Get
            Set(ByVal Value As VisibilityState)
                _Visibility = Value
            End Set
        End Property
        'should be deprecated due to roles being abstracted
        <XmlIgnore()> Public Property AuthorizedRoles() As String
            Get
                Return _AuthorizedRoles
            End Get
            Set(ByVal Value As String)
                _AuthorizedRoles = Value
            End Set
        End Property
        <XmlIgnore()> Public Property IsDeleted() As Boolean
            Get
                Return _IsDeleted
            End Get
            Set(ByVal Value As Boolean)
                _IsDeleted = Value
            End Set
        End Property
        <XmlElement("header")> Public Property Header() As String
            Get
                Return _Header
            End Get
            Set(ByVal Value As String)
                _Header = Value
            End Set
        End Property
        <XmlElement("footer")> Public Property Footer() As String
            Get
                Return _Footer
            End Get
            Set(ByVal Value As String)
                _Footer = Value
            End Set
        End Property
        <XmlElement("startdate")> Public Property StartDate() As Date
            Get
                Return _StartDate
            End Get
            Set(ByVal Value As Date)
                _StartDate = Value
            End Set
        End Property
        <XmlElement("enddate")> Public Property EndDate() As Date
            Get
                Return _EndDate
            End Get
            Set(ByVal Value As Date)
                _EndDate = Value
            End Set
        End Property
        <XmlElement("containersrc")> Public Property ContainerSrc() As String
            Get
                Return _ContainerSrc
            End Get
            Set(ByVal Value As String)
                _ContainerSrc = Value
            End Set
        End Property
        <XmlElement("displaytitle")> Public Property DisplayTitle() As Boolean
            Get
                Return _DisplayTitle
            End Get
            Set(ByVal Value As Boolean)
                _DisplayTitle = Value
            End Set
        End Property
        <XmlElement("displayprint")> Public Property DisplayPrint() As Boolean
            Get
                Return _DisplayPrint
            End Get
            Set(ByVal Value As Boolean)
                _DisplayPrint = Value
            End Set
        End Property
        <XmlElement("displaysyndicate")> Public Property DisplaySyndicate() As Boolean
            Get
                Return _DisplaySyndicate
            End Get
            Set(ByVal Value As Boolean)
                _DisplaySyndicate = Value
            End Set
        End Property
        <XmlElement("inheritviewpermissions")> Public Property InheritViewPermissions() As Boolean
            Get
                Return _InheritViewPermissions
            End Get
            Set(ByVal Value As Boolean)
                _InheritViewPermissions = Value
            End Set
        End Property
        <XmlArray("modulepermissions"), XmlArrayItem("permission")> Public Property ModulePermissions() As Security.Permissions.ModulePermissionCollection
            Get
                Return _ModulePermissions
            End Get
            Set(ByVal Value As Security.Permissions.ModulePermissionCollection)
                _ModulePermissions = Value
            End Set
        End Property
        <XmlIgnore()> Public Property DesktopModuleID() As Integer
            Get
                Return _DesktopModuleID
            End Get
            Set(ByVal Value As Integer)
                _DesktopModuleID = Value
            End Set
        End Property
        <XmlIgnore()> Public Property FriendlyName() As String
            Get
                Return _FriendlyName
            End Get
            Set(ByVal Value As String)
                _FriendlyName = Value
            End Set
        End Property
        <XmlIgnore()> Public Property Description() As String
            Get
                Return _Description
            End Get
            Set(ByVal Value As String)
                _Description = Value
            End Set
        End Property
        <XmlIgnore()> Public Property Version() As String
            Get
                Return _Version
            End Get
            Set(ByVal Value As String)
                _Version = Value
            End Set
        End Property
        <XmlIgnore()> Public Property IsPremium() As Boolean
            Get
                Return _IsPremium
            End Get
            Set(ByVal Value As Boolean)
                _IsPremium = Value
            End Set
        End Property
        <XmlIgnore()> Public Property IsAdmin() As Boolean
            Get
                Return _IsAdmin
            End Get
            Set(ByVal Value As Boolean)
                _IsAdmin = Value
            End Set
        End Property
        <XmlIgnore()> Public Property BusinessControllerClass() As String
            Get
                Return _BusinessControllerClass
            End Get
            Set(ByVal Value As String)
                _BusinessControllerClass = Value
            End Set
        End Property
        <XmlIgnore()> Public Property ModuleControlId() As Integer
            Get
                Return _ModuleControlId
            End Get
            Set(ByVal Value As Integer)
                _ModuleControlId = Value
            End Set
        End Property
        <XmlIgnore()> Public Property ControlSrc() As String
            Get
                Return _ControlSrc
            End Get
            Set(ByVal Value As String)
                _ControlSrc = Value
            End Set
        End Property
        <XmlIgnore()> Public Property ControlType() As SecurityAccessLevel
            Get
                Return _ControlType
            End Get
            Set(ByVal Value As SecurityAccessLevel)
                _ControlType = Value
            End Set
        End Property
        <XmlIgnore()> Public Property ControlTitle() As String
            Get
                Return _ControlTitle
            End Get
            Set(ByVal Value As String)
                _ControlTitle = Value
            End Set
        End Property
        <XmlIgnore()> Public Property HelpUrl() As String
            Get
                Return _HelpUrl
            End Get
            Set(ByVal Value As String)
                _HelpUrl = Value
            End Set
        End Property
        <XmlIgnore()> Public Property ContainerPath() As String
            Get
                Return _ContainerPath
            End Get
            Set(ByVal Value As String)
                _ContainerPath = Value
            End Set
        End Property
        <XmlIgnore()> Public Property PaneModuleIndex() As Integer
            Get
                Return _PaneModuleIndex
            End Get
            Set(ByVal Value As Integer)
                _PaneModuleIndex = Value
            End Set
        End Property
        <XmlIgnore()> Public Property PaneModuleCount() As Integer
            Get
                Return _PaneModuleCount
            End Get
            Set(ByVal Value As Integer)
                _PaneModuleCount = Value
            End Set
        End Property
        <XmlIgnore()> Public Property IsDefaultModule() As Boolean
            Get
                Return _IsDefaultModule
            End Get
            Set(ByVal Value As Boolean)
                _IsDefaultModule = Value
            End Set
        End Property
        <XmlIgnore()> Public Property AllModules() As Boolean
            Get
                Return _AllModules
            End Get
            Set(ByVal Value As Boolean)
                _AllModules = Value
            End Set
        End Property

        Public Sub Initialize(ByVal PortalId As Integer)
            _PortalID = PortalId
            _TabID = -1
            _ModuleID = -1
            _ModuleDefID = -1
            _ModuleOrder = -1
            _PaneName = ""
            _ModuleTitle = ""
            _AuthorizedEditRoles = ""
            _CacheTime = -1
            _AuthorizedViewRoles = ""
            _Alignment = ""
            _Color = ""
            _Border = ""
            _IconFile = ""
            _AllTabs = False
            _Visibility = VisibilityState.Maximized
            _IsDeleted = False
            _Header = ""
            _Footer = ""
            _StartDate = Null.NullDate
            _EndDate = Null.NullDate
            _DisplayTitle = True
            _DisplayPrint = True
            _DisplaySyndicate = False
            _InheritViewPermissions = False
            _ContainerSrc = ""
            _DesktopModuleID = -1
            _FriendlyName = ""
            _Description = ""
            _Version = ""
            _IsPremium = False
            _IsAdmin = False
            _BusinessControllerClass = ""
            _ModuleControlId = -1
            _ControlSrc = ""
            _ControlType = SecurityAccessLevel.Anonymous
            _ControlTitle = ""
            _HelpUrl = ""
            _ContainerPath = ""
            _PaneModuleIndex = 0
            _PaneModuleCount = 0
            _IsDefaultModule = False
            _AllModules = False

            ' get default module settings
            Dim settings As Hashtable = PortalSettings.GetSiteSettings(PortalId)
            If Convert.ToString(settings("defaultmoduleid")) <> "" And Convert.ToString(settings("defaulttabid")) <> "" Then
                Dim objModules As New ModuleController
                Dim objModule As ModuleInfo = objModules.GetModule(Integer.Parse(Convert.ToString(settings("defaultmoduleid"))), Integer.Parse(Convert.ToString(settings("defaulttabid"))))
                If Not objModule Is Nothing Then
                    _CacheTime = objModule.CacheTime
                    _Alignment = objModule.Alignment
                    _Color = objModule.Color
                    _Border = objModule.Border
                    _IconFile = objModule.IconFile
                    _Visibility = objModule.Visibility
                    _ContainerSrc = objModule.ContainerSrc
                    _DisplayTitle = objModule.DisplayTitle
                    _DisplayPrint = objModule.DisplayPrint
                    _DisplaySyndicate = objModule.DisplaySyndicate
                End If
            End If
        End Sub

        Public Function Clone() As ModuleInfo

            ' create the object
            Dim objModuleInfo As New ModuleInfo

            ' assign the property values
            objModuleInfo.PortalID = Me.PortalID
            objModuleInfo.TabID = Me.TabID
            objModuleInfo.TabModuleID = Me.TabModuleID
            objModuleInfo.ModuleID = Me.ModuleID
            objModuleInfo.ModuleDefID = Me.ModuleDefID
            objModuleInfo.ModuleOrder = Me.ModuleOrder
            objModuleInfo.PaneName = Me.PaneName
            objModuleInfo.ModuleTitle = Me.ModuleTitle
            objModuleInfo.AuthorizedEditRoles = Me.AuthorizedEditRoles
            objModuleInfo.CacheTime = Me.CacheTime
            objModuleInfo.AuthorizedViewRoles = Me.AuthorizedViewRoles
            objModuleInfo.Alignment = Me.Alignment
            objModuleInfo.Color = Me.Color
            objModuleInfo.Border = Me.Border
            objModuleInfo.IconFile = Me.IconFile
            objModuleInfo.AllTabs = Me.AllTabs
            objModuleInfo.Visibility = Me.Visibility
            objModuleInfo.AuthorizedRoles = Me.AuthorizedRoles
            objModuleInfo.IsDeleted = Me.IsDeleted
            objModuleInfo.Header = Me.Header
            objModuleInfo.Footer = Me.Footer
            objModuleInfo.StartDate = Me.StartDate
            objModuleInfo.EndDate = Me.EndDate
            objModuleInfo.ContainerSrc = Me.ContainerSrc
            objModuleInfo.DisplayTitle = Me.DisplayTitle
            objModuleInfo.DisplayPrint = Me.DisplayPrint
            objModuleInfo.DisplaySyndicate = Me.DisplaySyndicate
            objModuleInfo.InheritViewPermissions = Me.InheritViewPermissions
            objModuleInfo.DesktopModuleID = Me.DesktopModuleID
            objModuleInfo.FriendlyName = Me.FriendlyName
            objModuleInfo.Description = Me.Description
            objModuleInfo.Version = Me.Version
            objModuleInfo.IsAdmin = Me.IsAdmin
            objModuleInfo.IsPremium = Me.IsPremium
            objModuleInfo.BusinessControllerClass = Me.BusinessControllerClass
            objModuleInfo.ModuleControlId = Me.ModuleControlId
            objModuleInfo.ControlSrc = Me.ControlSrc
            objModuleInfo.ControlType = Me.ControlType
            objModuleInfo.ControlTitle = Me.ControlTitle
            objModuleInfo.HelpUrl = Me.HelpUrl
            objModuleInfo.ContainerPath = Me.ContainerPath
            objModuleInfo.PaneModuleIndex = Me.PaneModuleIndex
            objModuleInfo.PaneModuleCount = Me.PaneModuleCount
            objModuleInfo.IsDefaultModule = Me.IsDefaultModule
            objModuleInfo.AllModules = Me.AllModules

            objModuleInfo.ModulePermissions = Me.ModulePermissions

            Return objModuleInfo

        End Function


    End Class


End Namespace
