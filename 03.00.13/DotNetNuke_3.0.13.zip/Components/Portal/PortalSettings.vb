'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data
Imports System.Web
Imports System.Collections
Imports System.IO
Imports System.Web.UI
Imports Microsoft.ScalableHosting.Security
Imports DotNetNuke.Entities.Tabs
Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.ui.Skins
Imports DotNetNuke.Entities.Modules.Definitions



Namespace DotNetNuke.Entities.Portals

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' PortalSettings Class
	'''
	''' This class encapsulates all of the settings for the Portal, as well
	''' as the configuration settings required to execute the current tab
	''' view within the portal.
	''' </summary>
	''' <returns></returns>
	''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[cnurse]	10/21/2004	documented
	''' 	[cnurse]	10/21/2004	added GetTabModuleSettings
	''' </history>
	''' -----------------------------------------------------------------------------
	Public Class PortalSettings

#Region "Private Members"

		Private _PortalId As Integer
        Private _PortalName As String
		Private _HomeDirectory As String
		Private _LogoFile As String
		Private _FooterText As String
		Private _ExpiryDate As Date
		Private _UserRegistration As Integer
		Private _BannerAdvertising As Integer
		Private _Currency As String
		Private _AdministratorId As Integer
		Private _Email As String
        Private _HostFee As Single
		Private _HostSpace As Integer
		Private _AdministratorRoleId As Integer
		Private _AdministratorRoleName As String
		Private _RegisteredRoleId As Integer
		Private _RegisteredRoleName As String
		Private _Description As String
		Private _KeyWords As String
		Private _BackgroundFile As String
		Private _SiteLogHistory As Integer
		Private _AdminTabId As Integer
		Private _SuperTabId As Integer
        Private _SplashTabId As Integer
        Private _HomeTabId As Integer
        Private _LoginTabId As Integer
		Private _UserTabId As Integer
		Private _DefaultLanguage As String
		Private _TimeZoneOffset As Integer
		Private _Version As String
        Private _DesktopTabs As ArrayList
		Private _ActiveTab As TabInfo
		Private _PortalAlias As PortalAliasInfo
#End Region

#Region "Public Properties"

		Public Property PortalId() As Integer
			Get
				Return _PortalId
			End Get
			Set(ByVal Value As Integer)
				_PortalId = Value
			End Set
		End Property
        Public Property PortalName() As String
            Get
                Return _PortalName
            End Get
            Set(ByVal Value As String)
                _PortalName = Value
            End Set
        End Property
        Public Property HomeDirectory() As String
            Get
                Return _HomeDirectory
            End Get
            Set(ByVal Value As String)
                _HomeDirectory = Value
            End Set
		End Property
		Public ReadOnly Property HomeDirectoryMapPath() As String
			Get
				Dim objFolderController As New Services.FileSystem.FolderController
                Return objFolderController.GetMappedDirectory(HomeDirectory)
			End Get

		End Property
		Public Property LogoFile() As String
			Get
				Return _LogoFile
			End Get
			Set(ByVal Value As String)
				_LogoFile = Value
			End Set
		End Property
		Public Property FooterText() As String
			Get
				Return _FooterText
			End Get
			Set(ByVal Value As String)
				_FooterText = Value
			End Set
		End Property
		Public Property ExpiryDate() As Date
			Get
				Return _ExpiryDate
			End Get
			Set(ByVal Value As Date)
				_ExpiryDate = Value
			End Set
		End Property
		Public Property UserRegistration() As Integer
			Get
				Return _UserRegistration
			End Get
			Set(ByVal Value As Integer)
				_UserRegistration = Value
			End Set
		End Property
		Public Property BannerAdvertising() As Integer
			Get
				Return _BannerAdvertising
			End Get
			Set(ByVal Value As Integer)
				_BannerAdvertising = Value
			End Set
		End Property
		Public Property Currency() As String
			Get
				Return _Currency
			End Get
			Set(ByVal Value As String)
				_Currency = Value
			End Set
		End Property
		Public Property AdministratorId() As Integer
			Get
				Return _AdministratorId
			End Get
			Set(ByVal Value As Integer)
				_AdministratorId = Value
			End Set
		End Property
		Public Property Email() As String
			Get
				Return _Email
			End Get
			Set(ByVal Value As String)
				_Email = Value
			End Set
		End Property
		Public Property HostFee() As Single
			Get
				Return _HostFee
			End Get
			Set(ByVal Value As Single)
				_HostFee = Value
			End Set
		End Property
		Public Property HostSpace() As Integer
			Get
				Return _HostSpace
			End Get
			Set(ByVal Value As Integer)
				_HostSpace = Value
			End Set
		End Property
		Public Property AdministratorRoleId() As Integer
			Get
				Return _AdministratorRoleId
			End Get
			Set(ByVal Value As Integer)
				_AdministratorRoleId = Value
			End Set
		End Property
		Public Property AdministratorRoleName() As String
			Get
				Return _AdministratorRoleName
			End Get
			Set(ByVal Value As String)
				_AdministratorRoleName = Value
			End Set
		End Property
		Public Property RegisteredRoleId() As Integer
			Get
				Return _RegisteredRoleId
			End Get
			Set(ByVal Value As Integer)
				_RegisteredRoleId = Value
			End Set
		End Property
		Public Property RegisteredRoleName() As String
			Get
				Return _RegisteredRoleName
			End Get
			Set(ByVal Value As String)
				_RegisteredRoleName = Value
			End Set
		End Property
		Public Property Description() As String
			Get
				Return _Description
			End Get
			Set(ByVal Value As String)
				_Description = Value
			End Set
		End Property
		Public Property KeyWords() As String
			Get
				Return _KeyWords
			End Get
			Set(ByVal Value As String)
				_KeyWords = Value
			End Set
		End Property
		Public Property BackgroundFile() As String
			Get
				Return _BackgroundFile
			End Get
			Set(ByVal Value As String)
				_BackgroundFile = Value
			End Set
		End Property
		Public Property SiteLogHistory() As Integer
			Get
				Return _SiteLogHistory
			End Get
			Set(ByVal Value As Integer)
				_SiteLogHistory = Value
			End Set
		End Property
		Public Property AdminTabId() As Integer
			Get
				Return _AdminTabId
			End Get
			Set(ByVal Value As Integer)
				_AdminTabId = Value
			End Set
		End Property
		Public Property SuperTabId() As Integer
			Get
				Return _SuperTabId
			End Get
			Set(ByVal Value As Integer)
				_SuperTabId = Value
			End Set
		End Property
		Public Property SplashTabId() As Integer
			Get
				Return _SplashTabId
			End Get
			Set(ByVal Value As Integer)
				_SplashTabId = Value
			End Set
		End Property
		Public Property HomeTabId() As Integer
			Get
				Return _HomeTabId
			End Get
			Set(ByVal Value As Integer)
				_HomeTabId = Value
			End Set
		End Property
		Public Property LoginTabId() As Integer
			Get
				Return _LoginTabId
			End Get
			Set(ByVal Value As Integer)
				_LoginTabId = Value
			End Set
		End Property
		Public Property UserTabId() As Integer
			Get
				Return _UserTabId
			End Get
			Set(ByVal Value As Integer)
				_UserTabId = Value
			End Set
		End Property
		Public Property DefaultLanguage() As String
			Get
				Return _DefaultLanguage
			End Get
			Set(ByVal Value As String)
				_DefaultLanguage = Value
			End Set
		End Property
		Public Property TimeZoneOffset() As Integer
			Get
				Return _TimeZoneOffset
			End Get
			Set(ByVal Value As Integer)
				_TimeZoneOffset = Value
			End Set
		End Property
		Public Property Version() As String
			Get
				Return _Version
			End Get
			Set(ByVal Value As String)
				_Version = Value
			End Set
		End Property
		Public Property DesktopTabs() As ArrayList
			Get
				Return _DesktopTabs
			End Get
			Set(ByVal Value As ArrayList)
				_DesktopTabs = Value
			End Set
		End Property
		Public Property ActiveTab() As TabInfo
			Get
				Return _ActiveTab
			End Get
			Set(ByVal Value As TabInfo)
				_ActiveTab = Value
			End Set
		End Property
		Public ReadOnly Property HostSettings() As Hashtable
			Get
				Return Common.Globals.HostSettings				'_HostSettings
			End Get
		End Property
		Public Property PortalAlias() As PortalAliasInfo
			Get
				Return _PortalAlias
			End Get
			Set(ByVal Value As PortalAliasInfo)
				_PortalAlias = Value
			End Set
		End Property

#End Region

#Region "Constructors"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' The PortalSettings Constructor encapsulates all of the logic
		''' necessary to obtain configuration settings necessary to render
		''' a Portal Tab view for a given request.
		''' </summary>
		''' <returns></returns>
		''' <remarks>
		''' </remarks>
		'''	<param name="tabId">The current tab</param>
		'''	<param name="PortalId">The current portal</param>
		''' <history>
		''' 	[cnurse]	10/21/2004	documented
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Sub New(ByVal tabId As Integer, ByVal objPortalAliasInfo As PortalAliasInfo)
            _DesktopTabs = New ArrayList
			_ActiveTab = New TabInfo
			GetPortalSettings(tabId, objPortalAliasInfo)
		End Sub

        Public Sub New()
        End Sub

#End Region

#Region "Private Methods"

        Private Sub GetBreadCrumbsRecursively(ByRef objBreadCrumbs As ArrayList, ByVal intTabId As Integer)

            ' find the tab in the desktoptabs collection
            Dim blnFound As Boolean = False
            Dim objTab As TabInfo
            For Each objTab In Me.DesktopTabs
                If objTab.TabID = intTabId Then
                    blnFound = True
                    Exit For
                End If
            Next

            ' if tab was found
            If blnFound Then
                ' add tab to breadcrumb collection
                objBreadCrumbs.Insert(0, objTab)

                ' get the tab parent
                If Not Null.IsNull(objTab.ParentId) Then
                    GetBreadCrumbsRecursively(objBreadCrumbs, objTab.ParentId)
                End If
            End If

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' The GetPortalSettings method builds the site Settings
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="TabId">The current tabs id</param>
        '''	<param name="objPortalAliasInfo">The Portal Alias object</param>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub GetPortalSettings(ByVal TabId As Integer, ByVal objPortalAliasInfo As PortalAliasInfo)
            Dim objPortals As New PortalController
            Dim objPortal As PortalInfo
            Dim objTabs As New TabController
            Dim arrTabs As ArrayList
            Dim objTab As TabInfo
            Dim objModules As New ModuleController
            Dim arrModules As ArrayList
            Dim objModule As ModuleInfo
            Dim objSkins As New UI.Skins.SkinController
            Dim objSkin As UI.Skins.SkinInfo

            ' data caching settings
            Dim intCacheTimeout As Integer
            ' calculate the cache settings based on the performance setting
            intCacheTimeout = 20 * Convert.ToInt32(Common.Globals.PerformanceSetting)

            PortalId = objPortalAliasInfo.PortalID

            ' get portal settings
            objPortal = CType(DataCache.GetCache("GetPortalSettings" & PortalId.ToString), PortalInfo)
            If objPortal Is Nothing Then
                ' get portal settings
                objPortal = objPortals.GetPortal(PortalId)
                If Not objPortal Is Nothing Then
                    ' set custom properties
                    If Null.IsNull(objPortal.HostSpace) Then
                        objPortal.HostSpace = 0
                    End If
                    If Null.IsNull(objPortal.DefaultLanguage) Then
                        objPortal.DefaultLanguage = Services.Localization.Localization.SystemLocale
                    End If
                    If Null.IsNull(objPortal.TimeZoneOffset) Then
                        objPortal.TimeZoneOffset = Services.Localization.Localization.SystemTimeZoneOffset
                    End If
                    objPortal.HomeDirectory = Common.Globals.ApplicationPath + "/" + objPortal.HomeDirectory + "/"

                    ' get application version
                    Dim arrVersion As Array = glbAppVersion.Split(CType(".", Char))
                    Dim intMajor As Integer = CType(arrVersion.GetValue((0)), Integer)
                    Dim intMinor As Integer = CType(arrVersion.GetValue((1)), Integer)
                    Dim intBuild As Integer = CType(arrVersion.GetValue((2)), Integer)
                    objPortal.Version = intMajor.ToString + "." + intMinor.ToString + "." + intBuild.ToString

                    ' get administrator email
                    Dim objUserController As New UserController
                    Dim objUser As UserInfo
                    objUser = objUserController.GetUser(objPortal.PortalID, objPortal.AdministratorId)
                    If Not objUser Is Nothing Then
                        objPortal.Email = objUser.Membership.Email
                    End If

                    ' cache object
                    If intCacheTimeout <> 0 Then
                        DataCache.SetCache("GetPortalSettings" & PortalId.ToString, objPortal, TimeSpan.FromMinutes(intCacheTimeout))
                    End If
                End If
            End If
            If Not objPortal Is Nothing Then
                Me.PortalAlias = objPortalAliasInfo
                Me.PortalId = objPortal.PortalID
                Me.PortalName = objPortal.PortalName
                Me.LogoFile = objPortal.LogoFile
                Me.FooterText = objPortal.FooterText
                Me.ExpiryDate = objPortal.ExpiryDate
                Me.UserRegistration = objPortal.UserRegistration
                Me.BannerAdvertising = objPortal.BannerAdvertising
                Me.Currency = objPortal.Currency
                Me.AdministratorId = objPortal.AdministratorId
                Me.Email = objPortal.Email
                Me.HostFee = objPortal.HostFee
                Me.HostSpace = objPortal.HostSpace
                Me.AdministratorRoleId = objPortal.AdministratorRoleId
                Me.AdministratorRoleName = objPortal.AdministratorRoleName
                Me.RegisteredRoleId = objPortal.RegisteredRoleId
                Me.RegisteredRoleName = objPortal.RegisteredRoleName
                Me.Description = objPortal.Description
                Me.KeyWords = objPortal.KeyWords
                Me.BackgroundFile = objPortal.BackgroundFile
                Me.SiteLogHistory = objPortal.SiteLogHistory
                Me.AdminTabId = objPortal.AdminTabId
                Me.SuperTabId = objPortal.SuperTabId
                Me.SplashTabId = objPortal.SplashTabId
                Me.HomeTabId = objPortal.HomeTabId
                Me.LoginTabId = objPortal.LoginTabId
                Me.UserTabId = objPortal.UserTabId
                Me.DefaultLanguage = objPortal.DefaultLanguage
                Me.TimeZoneOffset = objPortal.TimeZoneOffset
                Me.HomeDirectory = objPortal.HomeDirectory
                Me.Version = objPortal.Version
            End If

            ' get portal tabs
            arrTabs = CType(DataCache.GetCache("GetTabs" & Me.PortalId.ToString), ArrayList)
            If arrTabs Is Nothing Then
                arrTabs = objTabs.GetTabs(Me.PortalId)
                If Not arrTabs Is Nothing Then
                    ' set custom properties
                    For Each objTab In arrTabs
                        If objTab.TabOrder = 0 Then
                            objTab.TabOrder = 999
                        End If
                        If Null.IsNull(objTab.StartDate) Then
                            objTab.StartDate = Date.MinValue
                        End If
                        If Null.IsNull(objTab.EndDate) Then
                            objTab.EndDate = Date.MaxValue
                        End If
                        objTab.IsSuperTab = False
                    Next

                    ' host tab
                    objTab = objTabs.GetTab(Me.SuperTabId)
                    If Not objTab Is Nothing Then
                        ' set custom properties
                        objTab.PortalID = Me.PortalId
                        objTab.StartDate = Date.MinValue
                        objTab.EndDate = Date.MaxValue
                        objTab.IsSuperTab = True
                        arrTabs.Add(objTab)
                    End If

                    ' host child tabs
                    Dim arrHostTabs As ArrayList = objTabs.GetTabsByParentId(Me.SuperTabId)
                    If Not arrHostTabs Is Nothing Then
                        For Each objTab In arrHostTabs
                            ' set custom properties
                            objTab.PortalID = Me.PortalId
                            objTab.StartDate = Date.MinValue
                            objTab.EndDate = Date.MaxValue
                            objTab.IsSuperTab = True
                            arrTabs.Add(objTab)
                        Next
                    End If

                    ' cache collection
                    If intCacheTimeout <> 0 Then
                        DataCache.SetCache("GetTabs" & Me.PortalId.ToString, arrTabs, TimeSpan.FromMinutes(intCacheTimeout))
                    End If

                End If
            End If
            For Each objTab In arrTabs
                ' clone the tab object ( to avoid creating an object reference to the data cache )
                Me.DesktopTabs.Add(objTab.Clone())
            Next

            ' verify tab for portal
            Dim intTabId As Integer = VerifyPortalTab(PortalId, TabId)

            '  current tab settings
            objTab = CType(DataCache.GetCache("GetTab" & intTabId.ToString), TabInfo)
            If objTab Is Nothing Then
                objTab = objTabs.GetTab(intTabId)
                If Not objTab Is Nothing Then
                    ' set custom properties
                    If Null.IsNull(objTab.StartDate) Then
                        objTab.StartDate = Date.MinValue
                    End If
                    If Null.IsNull(objTab.EndDate) Then
                        objTab.EndDate = Date.MaxValue
                    End If
                    ' skin
                    If objTab.SkinSrc = "" Then
                        If IsAdminSkin(objTab.IsAdminTab) Then
                            objSkin = objSkins.GetSkin(SkinInfo.RootSkin, PortalId, SkinType.Admin)
                        Else
                            objSkin = objSkins.GetSkin(SkinInfo.RootSkin, PortalId, SkinType.Portal)
                        End If
                        If Not objSkin Is Nothing Then
                            objTab.SkinSrc = objSkin.SkinSrc
                        End If
                    End If
                    If objTab.SkinSrc = "" Then
                        If IsAdminSkin(objTab.IsAdminTab) Then
                            objTab.SkinSrc = "[G]" & SkinInfo.RootSkin & glbDefaultSkinFolder & glbDefaultAdminSkin
                        Else
                            objTab.SkinSrc = "[G]" & SkinInfo.RootSkin & glbDefaultSkinFolder & glbDefaultSkin
                        End If
                    End If
                    objTab.SkinSrc = objSkins.FormatSkinSrc(objTab.SkinSrc, Me)
                    objTab.SkinPath = objSkins.FormatSkinPath(objTab.SkinSrc)
                    ' container
                    If objTab.ContainerSrc = "" Then
                        If IsAdminSkin(objTab.IsAdminTab) Then
                            objSkin = objSkins.GetSkin(SkinInfo.RootContainer, PortalId, SkinType.Admin)
                        Else
                            objSkin = objSkins.GetSkin(SkinInfo.RootContainer, PortalId, SkinType.Portal)
                        End If
                        If Not objSkin Is Nothing Then
                            objTab.ContainerSrc = objSkin.SkinSrc
                        End If
                    End If
                    If objTab.ContainerSrc = "" Then
                        If IsAdminSkin(objTab.IsAdminTab) Then
                            objTab.ContainerSrc = "[G]" & SkinInfo.RootContainer & glbDefaultContainerFolder & glbDefaultAdminContainer
                        Else
                            objTab.ContainerSrc = "[G]" & SkinInfo.RootContainer & glbDefaultContainerFolder & glbDefaultContainer
                        End If
                    End If
                    objTab.ContainerSrc = objSkins.FormatSkinSrc(objTab.ContainerSrc, Me)
                    objTab.ContainerPath = objSkins.FormatSkinPath(objTab.ContainerSrc)

                    ' initialize collections
                    objTab.BreadCrumbs = New ArrayList
                    objTab.Panes = New ArrayList
                    objTab.Modules = New ArrayList
                    If objTab.ParentId = Me.SuperTabId Then
                        objTab.IsSuperTab = True
                    End If

                    ' get breadcrumbs for current tab
                    GetBreadCrumbsRecursively(objTab.BreadCrumbs, intTabId)

                    ' cache object
                    If intCacheTimeout <> 0 Then
                        DataCache.SetCache("GetTab" & intTabId.ToString, objTab, TimeSpan.FromMinutes(intCacheTimeout))
                    End If
                Else
                    Exit Sub
                End If
            End If
            If Not objTab Is Nothing Then
                ' clone the tab object ( to avoid creating an object reference to the data cache )
                Me.ActiveTab = objTab.Clone
            End If

            ' get current tab modules
            Dim objPaneModules As New Hashtable
            arrModules = CType(DataCache.GetCache("GetPortalTabModules" & intTabId.ToString), ArrayList)
            If arrModules Is Nothing Then
                arrModules = objModules.GetPortalTabModules(Me.PortalId, Me.ActiveTab.TabID)
                If Not arrModules Is Nothing Then
                    ' set custom properties
                    For Each objModule In arrModules
                        If Null.IsNull(objModule.StartDate) Then
                            objModule.StartDate = Date.MinValue
                        End If
                        If Null.IsNull(objModule.EndDate) Then
                            objModule.EndDate = Date.MaxValue
                        End If
                        ' container
                        If objModule.ContainerSrc = "" Then
                            objModule.ContainerSrc = Me.ActiveTab.ContainerSrc
                        End If
                        objModule.ContainerSrc = objSkins.FormatSkinSrc(objModule.ContainerSrc, Me)
                        objModule.ContainerPath = objSkins.FormatSkinPath(objModule.ContainerSrc)
                        ' process tab panes
                        If objPaneModules.ContainsKey(objModule.PaneName) = False Then
                            objPaneModules.Add(objModule.PaneName, 0)
                        End If
                        objModule.PaneModuleCount = 0
                        If Not objModule.IsDeleted Then
                            objPaneModules(objModule.PaneName) = CType(objPaneModules(objModule.PaneName), Integer) + 1
                            objModule.PaneModuleIndex = CType(objPaneModules(objModule.PaneName), Integer) - 1
                        End If
                    Next

                    ' set pane module count
                    For Each objModule In arrModules
                        objModule.PaneModuleCount = Convert.ToInt32(objPaneModules(objModule.PaneName))
                    Next

                    ' cache collection
                    If intCacheTimeout <> 0 Then
                        DataCache.SetCache("GetPortalTabModules" & intTabId.ToString, arrModules, TimeSpan.FromMinutes(intCacheTimeout))
                    End If
                End If
            End If
            For Each objModule In arrModules
                ' clone the module object ( to avoid creating an object reference to the data cache )
                Me.ActiveTab.Modules.Add(objModule.Clone)
            Next

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' The VerifyPortalTab method verifies that the TabId/PortalId combination
        ''' is allowed and returns default/home tab ids if not
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="PortalId">The Portal's id</param>
        '''	<param name="TabId">The current tab's id</param>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Function VerifyPortalTab(ByVal PortalId As Integer, ByVal TabId As Integer) As Integer

            Dim objTab As TabInfo
            VerifyPortalTab = -1

            If TabId <> -1 Then
                ' find the tab in the desktoptabs collection
                For Each objTab In Me.DesktopTabs
                    If objTab.TabID = TabId Then
                        'Check if Tab has been deleted (is in recycle bin)
                        If Not (objTab.IsDeleted) Then
                            VerifyPortalTab = objTab.TabID
                            Exit For
                        End If
                    End If
                Next
            End If

            ' if tab was not found 
            If VerifyPortalTab = -1 And Me.SplashTabId > 0 Then
                ' use the splash tab ( if specified )
                VerifyPortalTab = Me.SplashTabId
            End If

            ' if tab was not found 
            If VerifyPortalTab = -1 And Me.HomeTabId > 0 Then
                ' use the home tab ( if specified )
                VerifyPortalTab = Me.HomeTabId
            End If

            ' if tab was not found 
            If VerifyPortalTab = -1 Then
                ' get the first tab in the collection (that is valid)
                Dim i As Integer
                For i = 0 To Me.DesktopTabs.Count
                    objTab = CType(Me.DesktopTabs(i), TabInfo)
                    'Check if Tab has not been deleted (not in recycle bin) and is visible
                    If Not (objTab.IsDeleted) And objTab.IsVisible Then
                        VerifyPortalTab = objTab.TabID
                        Exit For
                    End If
                Next
            End If

        End Function

#End Region

#Region "Public Shared Methods"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' The GetHostSettings method returns a hashtable of
        ''' host settings from the database.
        ''' </summary>
        ''' <returns>A Hashtable of settings (key/value pairs)</returns>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetHostSettings() As Hashtable
            Return Common.Globals.HostSettings
        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' The GetSiteSettings method returns a hashtable of
        ''' portal specific settings from the database.  This method 
        ''' uses the Site Settings module as a convenient storage area for
        ''' portal-wide settings.
        ''' </summary>
        ''' <returns>A Hashtable of settings (key/value pairs)</returns>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="PortalId">The Portal</param>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetSiteSettings(ByVal PortalId As Integer) As Hashtable

            Dim objModules As New ModuleController

            Dim ModuleId As Integer = objModules.GetModuleByDefinition(PortalId, "Site Settings").ModuleID

            Return GetModuleSettings(ModuleId)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' The UpdatePortalSetting method updates a specific portal setting
        ''' in the database. Since this is a portal-wide storage area you must
        ''' be careful to avoid naming collisions on SettingNames.
        ''' </summary>
        ''' <returns></returns>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="PortalId">The Portal</param>
        '''	<param name="SettingName">The Setting Name</param>
        '''	<param name="SettingValue">The Setting Value</param>
        ''' <history>
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Sub UpdatePortalSetting(ByVal PortalId As Integer, ByVal SettingName As String, ByVal SettingValue As String)

            Dim objModules As New ModuleController

            Dim ModuleId As Integer = objModules.GetModuleByDefinition(PortalId, "Site Settings").ModuleID

            objModules.UpdateModuleSetting(ModuleId, SettingName, SettingValue)

        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' The GetModuleSettings Method returns a hashtable of
        ''' custom module specific settings from the database.  This method is
        ''' used by some user control modules (Xml, Image, etc) to access misc
        ''' settings.
        ''' </summary>
        ''' <returns>A Hashtable of settings (key/value pairs)</returns>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="ModuleId">The Module</param>
        ''' <history>
        ''' 	[cnurse]	10/21/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetModuleSettings(ByVal ModuleId As Integer) As Hashtable

            Dim _settings As New Hashtable

            Dim dr As IDataReader = DataProvider.Instance().GetModuleSettings(ModuleId)

            While dr.Read()

                If Not dr.IsDBNull(1) Then
                    _settings(dr.GetString(0)) = dr.GetString(1)
                Else
                    _settings(dr.GetString(0)) = ""
                End If

            End While

            dr.Close()

            Return _settings

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' The GetTabModuleSettings Method returns a hashtable of
        ''' custom module/tab specific settings from the database.  This method is
        ''' used by some user control modules (Xml, Image, etc) to access misc
        ''' settings.
        ''' </summary>
        ''' <returns>A Hashtable of settings (key/value pairs)</returns>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="tabId">The current tab</param>
        '''	<param name="ModuleId">The Module</param>
        ''' <history>
        ''' 	[cnurse]	10/21/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetTabModuleSettings(ByVal TabModuleId As Integer) As Hashtable

            Dim objModules As New ModuleController

            Return objModules.GetTabModuleSettings(TabModuleId)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' The GetTabModuleSettings Method returns a hashtable of
        ''' custom module/tab specific settings from the database.  This method is
        ''' used by some user control modules (Xml, Image, etc) to access misc
        ''' settings.
        ''' </summary>
        ''' <returns>A Hashtable of settings (key/value pairs)</returns>
        ''' <remarks>
        ''' </remarks>
        '''	<param name="tabId">The current tab</param>
        '''	<param name="ModuleId">The Module</param>
        '''	<param name="settings">A Hashtable to add the Settings to</param>
        ''' <history>
        ''' 	[cnurse]	10/21/2004	documented
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Shared Function GetTabModuleSettings(ByVal TabModuleId As Integer, ByVal settings As Hashtable) As Hashtable

            Dim dr As IDataReader = DataProvider.Instance().GetTabModuleSettings(TabModuleId)

            While dr.Read()

                If Not dr.IsDBNull(1) Then
                    settings(dr.GetString(0)) = dr.GetString(1)
                Else
                    settings(dr.GetString(0)) = ""
                End If

            End While

            dr.Close()

            Return settings

        End Function

        Public Shared Function GetPortalAliasInfo(ByVal PortalAlias As String) As PortalAliasInfo

            Dim strPortalAlias As String

            ' try the specified alias first
            Dim objPortalAliasInfo As PortalAliasInfo = GetPortalAliasLookup(PortalAlias.ToLower)

            ' domain.com and www.domain.com should be synonymous
            If objPortalAliasInfo Is Nothing Then
                If PortalAlias.ToLower.StartsWith("www.") Then
                    ' try alias without the "www." prefix
                    strPortalAlias = PortalAlias.Replace("www.", "")
                Else ' try the alias with the "www." prefix
                    strPortalAlias = PortalAlias.Concat("www.", PortalAlias)
                End If
                ' perform the lookup
                objPortalAliasInfo = GetPortalAliasLookup(strPortalAlias.ToLower)
            End If

            ' allow domain wildcards 
            If objPortalAliasInfo Is Nothing Then
                ' remove the domain prefix ( ie. anything.domain.com = domain.com )
                If PortalAlias.IndexOf(".") <> -1 Then
                    strPortalAlias = PortalAlias.Substring(PortalAlias.IndexOf(".") + 1)
                Else ' be sure we have a clean string (without leftovers from preceding 'if' block)
                    strPortalAlias = PortalAlias
                End If
                If objPortalAliasInfo Is Nothing Then
                    ' try an explicit lookup using the wildcard entry ( ie. *.domain.com )
                    objPortalAliasInfo = GetPortalAliasLookup("*." & strPortalAlias.ToLower)
                End If
                If objPortalAliasInfo Is Nothing Then
                    ' try a lookup using the raw domain
                    objPortalAliasInfo = GetPortalAliasLookup(strPortalAlias.ToLower)
                End If
                If objPortalAliasInfo Is Nothing Then
                    ' try a lookup using "www." + raw domain
                    objPortalAliasInfo = GetPortalAliasLookup("www." & strPortalAlias.ToLower)
                End If
            End If

            If objPortalAliasInfo Is Nothing Then
                ' check if this is a fresh install ( no alias values in collection )
                Dim objPortalAliasCollection As PortalAliasCollection = GetPortalAliasLookup()
                If Not objPortalAliasCollection.HasKeys OrElse _
                    (objPortalAliasCollection.Count = 1 And objPortalAliasCollection.Contains("_default")) Then
                    ' relate the PortalAlias to the default portal on a fresh database installation
                    DataProvider.Instance().UpdatePortalAlias(PortalAlias.ToLower)

                    'clear the cachekey "GetPortalByAlias" otherwise portalalias "_default" stays in cache after first install
                    DataCache.RemoveCache("GetPortalByAlias")

                    'try again
                    objPortalAliasInfo = GetPortalAliasLookup(PortalAlias.ToLower)
                End If
            End If

            Return objPortalAliasInfo

        End Function

        Public Shared Function GetPortalByID(ByVal PortalId As Integer, ByVal PortalAlias As String) As String

            ' get the portal alias collection from the cache
            Dim objPortalAliasCollection As PortalAliasCollection = GetPortalAliasLookup()
            Dim strHTTPAlias As String
            Dim bFound As Boolean = False

            'Do a specified PortalAlias check first
            Dim objPortalAliasInfo As PortalAliasInfo = objPortalAliasCollection(PortalAlias.ToLower)
            If Not objPortalAliasInfo Is Nothing Then
                If objPortalAliasInfo.PortalID = PortalId Then
                    ' set the alias
                    GetPortalByID = objPortalAliasInfo.HTTPAlias
                    bFound = True
                End If
            End If

            'No match so iterate through the alias keys
            If Not bFound Then
                For Each key As String In objPortalAliasCollection.Keys
                    ' check if the alias key starts with the portal alias value passed in - we use
                    ' StartsWith because child portals are redirected to the parent portal domain name
                    ' eg. child = 'www.domain.com/child' and parent is 'www.domain.com'
                    ' this allows the parent domain name to resolve to the child alias ( the tabid still identifies the child portalid )
                    objPortalAliasInfo = objPortalAliasCollection(key)

                    strHTTPAlias = objPortalAliasInfo.HTTPAlias.ToLower()
                    If strHTTPAlias.StartsWith(PortalAlias.ToLower) = True And objPortalAliasInfo.PortalID = PortalId Then
                        ' set the alias
                        GetPortalByID = objPortalAliasInfo.HTTPAlias
                        Exit For
                    End If

                    ' domain.com and www.domain.com should be synonymous
                    If strHTTPAlias.StartsWith("www.") Then
                        ' try alias without the "www." prefix
                        strHTTPAlias = strHTTPAlias.Replace("www.", "")
                    Else ' try the alias with the "www." prefix
                        strHTTPAlias = strHTTPAlias.Concat("www.", strHTTPAlias)
                    End If
                    If strHTTPAlias.StartsWith(PortalAlias.ToLower) = True And objPortalAliasInfo.PortalID = PortalId Then
                        ' set the alias
                        GetPortalByID = objPortalAliasInfo.HTTPAlias
                        Exit For
                    End If
                Next
            End If

            Return GetPortalByID

        End Function

        Public Shared Function GetPortalByTab(ByVal TabID As Integer, ByVal PortalAlias As String) As String

            Dim intPortalId As Integer = -2

            ' get the tab
            Dim objTabs As New TabController
            Dim objTab As TabInfo = objTabs.GetTab(TabID)
            If Not objTab Is Nothing Then
                ' ignore deleted tabs
                If Not objTab.IsDeleted Then
                    intPortalId = objTab.PortalID
                End If
            End If

            GetPortalByTab = Nothing

            Select Case intPortalId
                Case -2 ' tab does not exist
                Case -1 ' host tab
                    ' host tabs are not verified to determine if they belong to the portal alias
                    GetPortalByTab = PortalAlias
                Case Else ' portal tab
                    GetPortalByTab = GetPortalByID(intPortalId, PortalAlias)
            End Select

            Return GetPortalByTab

        End Function

        Public Shared Function GetPortalAliasLookup() As PortalAliasCollection

            Try
                Dim objPortalAliasCollection As PortalAliasCollection = CType(DataCache.GetCache("GetPortalByAlias"), PortalAliasCollection)

                If objPortalAliasCollection Is Nothing Then
                    Dim objPortalAliasController As New PortalAliasController
                    objPortalAliasCollection = objPortalAliasController.GetPortalAliases()
                    DataCache.SetCache("GetPortalByAlias", objPortalAliasCollection)
                End If

                Return objPortalAliasCollection

            Catch exc As Exception

                ' this is the first data access in Begin_Request and will catch any general connection issues
                Dim objHttpContext As HttpContext = HttpContext.Current
                Dim objStreamReader As StreamReader
                objStreamReader = File.OpenText(objHttpContext.Server.MapPath("~/500.htm"))
                Dim strHTML As String = objStreamReader.ReadToEnd
                objStreamReader.Close()
                strHTML = Replace(strHTML, "[MESSAGE]", "ERROR: Could not connect to database.<br><br>" & exc.Message)
                objHttpContext.Response.Write(strHTML)
                objHttpContext.Response.End()

            End Try
        End Function

        Public Shared Function GetDatabaseVersion() As IDataReader

            Return DataProvider.Instance().GetDatabaseVersion

        End Function

        Public Shared Sub UpdateDatabaseVersion(ByVal Major As Integer, ByVal Minor As Integer, ByVal Build As Integer)

            DataProvider.Instance().UpdateDatabaseVersion(Major, Minor, Build)

        End Sub

        Public Shared Sub UpgradeDatabaseSchema(ByVal Major As Integer, ByVal Minor As Integer, ByVal Build As Integer)

            DataProvider.Instance().UpgradeDatabaseSchema(Major, Minor, Build)

        End Sub

        Public Shared Function FindDatabaseVersion(ByVal Major As Integer, ByVal Minor As Integer, ByVal Build As Integer) As Boolean

            FindDatabaseVersion = False
            Dim dr As IDataReader = DataProvider.Instance().FindDatabaseVersion(Major, Minor, Build)
            If dr.Read Then
                FindDatabaseVersion = True
            End If
            dr.Close()

        End Function

        Public Shared Function GetProviderPath() As String

            Return DataProvider.Instance().GetProviderPath()

        End Function

        Public Shared Function ExecuteScript(ByVal strScript As String) As String

            Return DataProvider.Instance().ExecuteScript(strScript)

        End Function

        Public Shared Function ExecuteScript(ByVal strScript As String, ByVal UseTransactions As Boolean) As String

            Return DataProvider.Instance().ExecuteScript(strScript, UseTransactions)

        End Function

#End Region

    End Class

End Namespace
