'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports System
Imports System.Configuration
Imports System.Data
Imports DotNetNuke.Services.Search
Imports DotNetNuke
Imports System.XML

Namespace DotNetNuke.Modules.Images
    Public Class ImageController
        Implements Entities.Modules.ISearchable
		Implements Entities.Modules.IPortable

#Region "Optional Interfaces"
        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            Dim SearchItemCollection As New SearchItemInfoCollection

            Dim settings As Hashtable = Entities.Portals.PortalSettings.GetModuleSettings(ModInfo.ModuleID)
            Dim ImageAlt As String = CType(settings("alt"), String)

            Dim SearchItem As SearchItemInfo
            SearchItem = New SearchItemInfo(ModInfo.ModuleTitle & " - " & ImageAlt, ImageAlt, Null.NullInteger, Now, ModInfo.ModuleID, "Image" & ModInfo.ModuleID.ToString & "-" & ImageAlt, ImageAlt)
            SearchItemCollection.Add(SearchItem)

            Return SearchItemCollection

        End Function

        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule

            Dim strXML As String = ""

            Dim settings As Hashtable = Entities.Portals.PortalSettings.GetModuleSettings(ModuleID)

            strXML += "<image>"
            strXML += "<src>" & XMLEncode(CType(settings("src"), String)) & "</src>"
            strXML += "<alt>" & XMLEncode(CType(settings("alt"), String)) & "</alt>"
            strXML += "<width>" & XMLEncode(CType(settings("width"), String)) & "</width>"
            strXML += "<height>" & XMLEncode(CType(settings("height"), String)) & "</height>"
            strXML += "</image>"

            Return strXML

        End Function

        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserId As Integer) Implements Entities.Modules.IPortable.ImportModule

            Dim xmlImage As XmlNode = GetContent(Content, "image")

            Dim objModules As New Entities.Modules.ModuleController
            objModules.UpdateModuleSetting(ModuleID, "src", xmlImage.SelectSingleNode("src").InnerText)
            objModules.UpdateModuleSetting(ModuleID, "alt", xmlImage.SelectSingleNode("alt").InnerText)
            objModules.UpdateModuleSetting(ModuleID, "width", xmlImage.SelectSingleNode("width").InnerText)
            objModules.UpdateModuleSetting(ModuleID, "height", xmlImage.SelectSingleNode("height").InnerText)

        End Sub

#End Region

	End Class
End Namespace
