'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports DotNetNuke
Imports System.Web.UI

Namespace DotNetNuke.Modules.Html

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The HtmlModule Class provides the UI for displaying the Html
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
    ''' 	[cnurse]	9/23/2004	Moved Html to a separate Project
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public MustInherit Class HtmlModule
		Inherits Entities.Modules.PortalModuleBase
		Implements Entities.Modules.IActionable
        Implements Entities.Modules.IPortable
        Implements Entities.Modules.ISearchable

#Region "Controls"

        Protected WithEvents HtmlHolder As System.Web.UI.HtmlControls.HtmlContainerControl

#End Region

#Region "Private Methods"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' ManageUploadDirectory ensures that all image refs are to the correct directory
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/23/2004	Moved Html to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Function ManageUploadDirectory(ByVal strHTML As String, ByVal strUploadDirectory As String) As String

			Dim P As Integer

			P = InStr(1, strHTML.ToLower, "src=""")
			While P <> 0
				ManageUploadDirectory = ManageUploadDirectory & Left(strHTML, P + 4)

				strHTML = Mid(strHTML, P + 5)

				' add uploaddirectory if we are linking internally
				Dim strSRC As String = Left(strHTML, InStr(1, strHTML, """") - 1)
				If InStr(1, strSRC, "://") = 0 And Left(strSRC, 1) <> "/" And strSRC.IndexOf(strUploadDirectory.Substring(strUploadDirectory.IndexOf("Portals/"))) = -1 Then

					strHTML = strUploadDirectory & strHTML
				End If

				P = InStr(1, strHTML.ToLower, "src=""")
			End While

			ManageUploadDirectory = ManageUploadDirectory & strHTML

		End Function

#End Region

#Region "Event Handlers"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Page_Load runs when the control is loaded
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/23/2004	Moved Html to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try
				' Obtain the selected item from the HtmlText table
				Dim objHTML As New HtmlTextController
				Dim objDr As HtmlTextInfo = objHTML.GetHtmlText(ModuleId)

				If Not objDr Is Nothing Then			 'dr.Read() Then

					' Dynamically add the file content into the page
					Dim content As String = Server.HtmlDecode(CType(objDr.DeskTopHTML, String))

					HtmlHolder.Controls.Add(New LiteralControl(ManageUploadDirectory(content, PortalSettings.HomeDirectory)))

				End If

				'------------------------------------------------------------------------------------
				'-                        Menu Action Handler Registration                          -
				'------------------------------------------------------------------------------------
				'This finds a reference to the containing skin
				Dim ParentSkin As UI.Skins.Skin = UI.Skins.Skin.GetParentSkin(Me)
				'We should always have a ParentSkin, but need to make sure
				If Not ParentSkin Is Nothing Then
					'Register our EventHandler as a listener on the ParentSkin so that it may tell us 
					'when a menu has been clicked.
					ParentSkin.RegisterModuleActionEvent(Me.ModuleId, AddressOf ModuleAction_Click)
				End If
				'-------------------------------------------------------------------------------------

				' Close the datareader
				'dr.Close()
			Catch exc As Exception		  'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' ModuleAction_Click handles all ModuleAction events raised from the skin
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/23/2004	Moved Html to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Sub ModuleAction_Click(ByVal sender As Object, ByVal e As Entities.Modules.Actions.ActionEventArgs)

			'We could get much fancier here by declaring each ModuleAction with a
			'Command and then using a Select Case statement to handle the various
			'commands.
			If e.Action.Url.Length > 0 Then
				Response.Redirect(e.Action.Url, True)
			End If

		End Sub

#End Region

#Region "Optional Interfaces"

		Public ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
			Get
				Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
				Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.AddContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", EditURL(), False, Security.SecurityAccessLevel.Edit, True, False)
				Return Actions
			End Get
		End Property

		Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
			' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
		End Function

        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserId As Integer) Implements Entities.Modules.IPortable.ImportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Sub

        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
        End Function

#End Region

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

		End Sub

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()
		End Sub

#End Region

 	End Class

End Namespace
