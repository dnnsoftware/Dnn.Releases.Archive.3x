'
' DotNetNuke -  http://www.dotnetnuke.com
' Copyright (c) 2002-2005
' by Shaun Walker ( sales@perpetualmotion.ca ) of Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'
Imports System.Web.UI.WebControls
Imports DotNetNuke

Namespace DotNetNuke.Modules.Links

    ''' -----------------------------------------------------------------------------
    ''' <summary>
    ''' The Links Class provides the UI for displaying the Links
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks>
    ''' </remarks>
    ''' <history>
	''' 	[cnurse]	9/23/2004	Moved Links to a separate Project
	'''		[cnurse]	10/20/2004	Removed ViewOptions from Action menu
    ''' </history>
    ''' -----------------------------------------------------------------------------
    Public MustInherit Class Links
		Inherits Entities.Modules.PortalModuleBase
        Implements Entities.Modules.IActionable
        Implements Entities.Modules.IPortable
        Implements Entities.Modules.ISearchable

#Region "Controls"

		Protected WithEvents pnlList As System.Web.UI.WebControls.Panel
		Protected WithEvents lstLinks As System.Web.UI.WebControls.DataList
		Protected WithEvents pnlDropdown As System.Web.UI.WebControls.Panel
		Protected WithEvents cboLinks As System.Web.UI.WebControls.DropDownList
		Protected WithEvents cmdEdit As System.Web.UI.WebControls.ImageButton
		Protected WithEvents cmdInfo As System.Web.UI.WebControls.LinkButton
		Protected WithEvents cmdGo As System.Web.UI.WebControls.LinkButton
		Protected WithEvents lblDescription As System.Web.UI.WebControls.Label

#End Region

#Region "Public Methods"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' DisplayInfo displays the description/info on the link
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <returns>The description text</returns>
		''' <history>
		''' 	[cnurse]	9/23/2004	Moved Links to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Public Function DisplayInfo() As String
			Try
				If CType(Settings("displayinfo"), String) = "Y" Then
					Return "True"
				Else
					Return "False"
				End If
			Catch exc As Exception		  'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try
		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' DisplayToolTip gets the tooltip to display
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <param name="strDescription">The description</param>
		''' <returns>The tooltip text</returns>
		''' <history>
		''' 	[cnurse]	9/23/2004	Moved Links to a separate Project
        ''' 	[bonosoft]	11/3/2004	Added default option, if option not set. (DNN-115)
        ''' </history>
		''' -----------------------------------------------------------------------------
		Public Function DisplayToolTip(ByVal strDescription As String) As String
            Try
                If Settings("displayinfo") Is Nothing Then
                    ' Option not set, use default value
                    Return strDescription
                End If
                If CType(Settings("displayinfo"), String) = "N" Then
                    Return strDescription
                Else
                    Return ""
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
		End Function

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' FormatURL correctly formats the links url
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <param name="Link">The link</param>
		''' <returns>The correctly formatted url</returns>
		''' <history>
		''' 	[cnurse]	9/23/2004	Moved Links to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
        Public Function FormatURL(ByVal Link As String, ByVal TrackClicks As Boolean) As String

            Return Common.Globals.LinkClick(Link, TabId, ModuleId, TrackClicks)

        End Function

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' HtmlDecode decodes the html string
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <param name="strValue">The string to decode</param>
        ''' <returns>The decoded html</returns>
        ''' <history>
        ''' 	[cnurse]	9/23/2004	Moved Links to a separate Project
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Public Function HtmlDecode(ByVal strValue As String) As String
            Try
                HtmlDecode = Server.HtmlDecode(strValue)
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Function

#End Region

#Region "Event Handlers"

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' Page_Load runs when the control is loaded
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/23/2004	Moved Links to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
			Try

                If CType(Settings("linkcontrol"), String) = "D" Then
                    pnlList.Visible = False
                    pnlDropdown.Visible = True
                Else
                    pnlList.Visible = True
                    pnlDropdown.Visible = False
                End If

                If Not Page.IsPostBack Then

                    Dim objLinks As New LinkController

                    If CType(Settings("linkcontrol"), String) = "D" Then
                        If IsEditable Then
                            cmdEdit.Visible = True
                        Else
                            cmdEdit.Visible = False
                        End If
                        cmdGo.ToolTip = Localization.GetString("cmdGo")
                        If CType(Settings("displayinfo"), String) = "Y" Then
                            cmdInfo.Visible = True
                        Else
                            cmdInfo.Visible = False
                        End If
                        cmdInfo.ToolTip = Localization.GetString("cmdInfo", Me.LocalResourceFile)
                        cboLinks.DataSource = objLinks.GetLinks(ModuleId)
                        cboLinks.DataBind()
                    Else
                        If CType(Settings("linkview"), String) = "H" Then
                            lstLinks.RepeatDirection = RepeatDirection.Horizontal
                        Else
                            lstLinks.RepeatDirection = RepeatDirection.Vertical
                        End If
                        lstLinks.DataSource = objLinks.GetLinks(ModuleId)
                        lstLinks.DataBind()
                    End If
                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try

		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdEdit_Click runs when the edit button is clciked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/23/2004	Moved Links to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdEdit.Click
            Try
                If Not cboLinks.SelectedItem Is Nothing Then
                    Response.Redirect(EditUrl("ItemID", cboLinks.SelectedItem.Value), True)
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdGo_Click runs when the Go Button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/23/2004	Moved Links to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdGo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGo.Click
            Try
                If Not cboLinks.SelectedItem Is Nothing Then
                    Dim strURL As String = ""

                    Dim objLinks As New LinkController

                    Dim objLink As LinkInfo = objLinks.GetLink(Integer.Parse(cboLinks.SelectedValue), ModuleId)
                    If Not objLink Is Nothing Then
                        strURL = FormatURL(objLink.Url.ToString, objLink.TrackClicks)
                    End If

                    'use javascript to open a new window if the combobox link style is used
                    If Not objLink Is Nothing Then
                        If objLink.NewWindow = True Then
                            Response.Write("<script language=javascript>window.open('" + strURL + "','_blank')</script>")
                        Else
                            Response.Redirect(strURL, True)
                        End If
                    End If
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' cmdInfo_Click runs when the Info (...) button is clicked
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/23/2004	Moved Links to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub cmdInfo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdInfo.Click
            Try
                If Not cboLinks.SelectedItem Is Nothing Then
                    Dim objLinks As New LinkController

                    Dim objLink As LinkInfo = objLinks.GetLink(Integer.Parse(cboLinks.SelectedItem.Value), ModuleId)
                    If Not objLink Is Nothing Then
                        If lblDescription.Text = String.Empty Then
                            lblDescription.Text = HtmlDecode(objLink.Description.ToString)
                        Else
                            lblDescription.Text = ""
                        End If
                    End If
                End If
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
		End Sub

		''' -----------------------------------------------------------------------------
		''' <summary>
		''' lstLinks_Select runs when an item in the Links list is selected
		''' </summary>
		''' <remarks>
		''' </remarks>
		''' <history>
		''' 	[cnurse]	9/23/2004	Moved Links to a separate Project
		''' </history>
		''' -----------------------------------------------------------------------------
		Private Sub lstLinks_Select(ByVal Sender As Object, ByVal e As DataListCommandEventArgs) Handles lstLinks.ItemCommand
			Try
				lstLinks.Items(e.Item.ItemIndex).FindControl("pnlDescription").Visible = Not lstLinks.Items(e.Item.ItemIndex).FindControl("pnlDescription").Visible
			Catch exc As Exception		  'Module failed to load
				ProcessModuleLoadException(Me, exc)
			End Try

		End Sub

#End Region

#Region " Web Form Designer Generated Code "

		'This call is required by the Web Form Designer.
		<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

		Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
			'CODEGEN: This method call is required by the Web Form Designer
			'Do not modify it using the code editor.
			InitializeComponent()

		End Sub

#End Region

#Region "Optional Interfaces"

        Public ReadOnly Property ModuleActions() As Entities.Modules.Actions.ModuleActionCollection Implements Entities.Modules.IActionable.ModuleActions
            Get
                Dim Actions As New Entities.Modules.Actions.ModuleActionCollection
                Actions.Add(GetNextActionID, Localization.GetString(Entities.Modules.Actions.ModuleActionType.AddContent, LocalResourceFile), Entities.Modules.Actions.ModuleActionType.AddContent, "", "", EditUrl(), False, Security.SecurityAccessLevel.Edit, True, False)
                Return Actions
            End Get
        End Property

        Public Function ExportModule(ByVal ModuleID As Integer) As String Implements Entities.Modules.IPortable.ExportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Function

        Public Sub ImportModule(ByVal ModuleID As Integer, ByVal Content As String, ByVal Version As String, ByVal UserId As Integer) Implements Entities.Modules.IPortable.ImportModule
            ' included as a stub only so that the core knows this module Implements Entities.Modules.IPortable
        End Sub

        Public Function GetSearchItems(ByVal ModInfo As Entities.Modules.ModuleInfo) As Services.Search.SearchItemInfoCollection Implements Entities.Modules.ISearchable.GetSearchItems
            ' included as a stub only so that the core knows this module Implements Entities.Modules.ISearchable
        End Function

#End Region

    End Class

End Namespace
