'
' DotNetNuke� - http://www.dotnetnuke.com
' Copyright (c) 2002-2006
' by Perpetual Motion Interactive Systems Inc. ( http://www.perpetualmotion.ca )
'
' Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
' documentation files (the "Software"), to deal in the Software without restriction, including without limitation 
' the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and 
' to permit persons to whom the Software is furnished to do so, subject to the following conditions:
'
' The above copyright notice and this permission notice shall be included in all copies or substantial portions 
' of the Software.
'
' THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED 
' TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL 
' THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF 
' CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
' DEALINGS IN THE SOFTWARE.
'

Imports DotNetNuke.Entities.Modules
Imports DotNetNuke.Entities.Modules.Definitions
Imports DotNetNuke.Entities.Tabs
Imports DotNetNuke.UI.Utilities
Imports DotNetNuke.Services.Localization

Namespace DotNetNuke.UI.ControlPanels

	''' -----------------------------------------------------------------------------
	''' <summary>
	''' The IconBar ControlPanel provides an icon bar based Page/Module manager
	''' </summary>
    ''' <remarks>
	''' </remarks>
	''' <history>
	''' 	[cnurse]	10/06/2004	Updated to reflect design changes for Help, 508 support
	'''                       and localisation
	''' </history>
	''' -----------------------------------------------------------------------------
    Public MustInherit Class IconBar
        Inherits ControlPanelBase

#Region "Controls"

        Protected imgAddTabIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdAddTabIcon As System.Web.UI.WebControls.LinkButton
        Protected imgEditTabIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdEditTabIcon As System.Web.UI.WebControls.LinkButton
        Protected imgDeleteTabIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdDeleteTabIcon As System.Web.UI.WebControls.LinkButton
        Protected imgCopyTabIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdCopyTabIcon As System.Web.UI.WebControls.LinkButton
        Protected imgPreviewTabIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdPreviewTabIcon As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdAddTab As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdEditTab As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdDeleteTab As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdCopyTab As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdPreviewTab As System.Web.UI.WebControls.LinkButton

        'Protected lblAddModule As System.Web.UI.WebControls.Label
        Protected WithEvents optModuleType As System.Web.UI.WebControls.RadioButtonList
        Protected lblModule As System.Web.UI.WebControls.Label
        Protected WithEvents cboTabs As System.Web.UI.WebControls.DropDownList
        Protected cboDesktopModules As System.Web.UI.WebControls.DropDownList
        Protected lblPane As System.Web.UI.WebControls.Label
        Protected cboPanes As System.Web.UI.WebControls.DropDownList
        Protected lblTitle As System.Web.UI.WebControls.Label
        Protected cboModules As System.Web.UI.WebControls.DropDownList
        Protected txtTitle As System.Web.UI.WebControls.TextBox
        Protected lblAlign As System.Web.UI.WebControls.Label
        Protected cboAlign As System.Web.UI.WebControls.DropDownList
        Protected imgAddModuleIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdAddModuleIcon As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdAddModule As System.Web.UI.WebControls.LinkButton
        Protected lblPermission As System.Web.UI.WebControls.Label
        Protected cboPermission As System.Web.UI.WebControls.DropDownList
        Protected lblPosition As System.Web.UI.WebControls.Label
        Protected cboPosition As System.Web.UI.WebControls.DropDownList

        Protected lblCommonTasks As System.Web.UI.WebControls.Label
        Protected imgWizardIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdWizardIcon As System.Web.UI.WebControls.LinkButton
        Protected imgSiteIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdSiteIcon As System.Web.UI.WebControls.LinkButton
        Protected imgUsersIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdUsersIcon As System.Web.UI.WebControls.LinkButton
        Protected imgFilesIcon As System.Web.UI.WebControls.Image
        Protected WithEvents cmdFilesIcon As System.Web.UI.WebControls.LinkButton
        Protected imgHelpIcon As System.Web.UI.WebControls.Image
        Protected cmdHelpIcon As System.Web.UI.WebControls.HyperLink
        Protected WithEvents cmdWizard As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdSite As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdUsers As System.Web.UI.WebControls.LinkButton
        Protected WithEvents cmdFiles As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lblPageFunctions As System.Web.UI.WebControls.Label
        Protected WithEvents chkVisible As System.Web.UI.WebControls.CheckBox
        Protected cmdHelp As System.Web.UI.WebControls.HyperLink

#End Region

#Region "Private Methods"

        Private Sub BindData()

            Select Case optModuleType.SelectedItem.Value
                Case "0" ' new module
                    cboTabs.Visible = False
                    cboModules.Visible = False
                    cboDesktopModules.Visible = True
                    txtTitle.Visible = True
                    lblModule.Text = Localization.GetString("Module", Me.LocalResourceFile)
                    lblTitle.Text = Localization.GetString("Title", Me.LocalResourceFile)
                    cboPermission.Enabled = True

                    Dim objDesktopModules As New DesktopModuleController
                    cboDesktopModules.DataSource = objDesktopModules.GetDesktopModulesByPortal(PortalSettings.PortalId)
                    cboDesktopModules.DataBind()
                    cboDesktopModules.Items.Insert(0, New ListItem("<" + Localization.GetString("SelectModule", Me.LocalResourceFile) + ">", "-1"))
                Case "1" ' existing module
                    cboTabs.Visible = True
                    cboModules.Visible = True
                    cboDesktopModules.Visible = False
                    txtTitle.Visible = False
                    lblModule.Text = Localization.GetString("Tab", Me.LocalResourceFile)
                    lblTitle.Text = Localization.GetString("Module", Me.LocalResourceFile)
                    cboPermission.Enabled = False

                    Dim arrTabs As New ArrayList

                    Dim objTab As TabInfo
                    Dim arrPortalTabs As ArrayList = GetPortalTabs(PortalSettings.DesktopTabs, True, True)
                    For Each objTab In arrPortalTabs
                        If objTab.TabID = -1 Then
                            ' <none specified>
                            objTab.TabName = "<" & Localization.GetString("SelectPage", Me.LocalResourceFile) & ">"
                            arrTabs.Add(objTab)
                        Else
                            If objTab.TabID <> PortalSettings.ActiveTab.TabID Then
                                If PortalSecurity.IsInRoles(objTab.AuthorizedRoles) Then
                                    arrTabs.Add(objTab)
                                End If
                            End If
                        End If
                    Next

                    cboTabs.DataSource = arrTabs
                    cboTabs.DataBind()
            End Select

        End Sub

#End Region

#Region "Event Handlers"

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' Page_Load runs when the control is loaded.
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	10/06/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Try

                If Not Page.IsPostBack Then

                    ' localization
                    lblPageFunctions.Text = Localization.GetString("PageFunctions", Me.LocalResourceFile)
                    optModuleType.Items.FindByValue("0").Selected = True
                    lblCommonTasks.Text = Localization.GetString("CommonTasks", Me.LocalResourceFile)
                    imgAddTabIcon.AlternateText = Localization.GetString("AddTab.AlternateText", Me.LocalResourceFile)
                    cmdAddTab.Text = Localization.GetString("AddTab", Me.LocalResourceFile)
                    imgEditTabIcon.AlternateText = Localization.GetString("EditTab.AlternateText", Me.LocalResourceFile)
                    cmdEditTab.Text = Localization.GetString("EditTab", Me.LocalResourceFile)
                    imgDeleteTabIcon.AlternateText = Localization.GetString("DeleteTab.AlternateText", Me.LocalResourceFile)
                    cmdDeleteTab.Text = Localization.GetString("DeleteTab", Me.LocalResourceFile)
                    imgCopyTabIcon.AlternateText = Localization.GetString("CopyTab.AlternateText", Me.LocalResourceFile)
                    cmdCopyTab.Text = Localization.GetString("CopyTab", Me.LocalResourceFile)
                    imgPreviewTabIcon.AlternateText = Localization.GetString("PreviewTab.AlternateText", Me.LocalResourceFile)
                    cmdPreviewTab.Text = Localization.GetString("PreviewTab", Me.LocalResourceFile)
                    If IsPreview Then
                        imgPreviewTabIcon.ImageUrl = "~/Admin/ControlPanel/images/iconbar_previewtab_on.gif"
                    End If
                    lblModule.Text = Localization.GetString("Module", Me.LocalResourceFile)
                    lblPane.Text = Localization.GetString("Pane", Me.LocalResourceFile)
                    lblTitle.Text = Localization.GetString("Title", Me.LocalResourceFile)
                    lblAlign.Text = Localization.GetString("Align", Me.LocalResourceFile)
                    imgAddModuleIcon.AlternateText = Localization.GetString("AddModule.AlternateText", Me.LocalResourceFile)
                    cmdAddModule.Text = Localization.GetString("AddModule", Me.LocalResourceFile)
                    imgWizardIcon.AlternateText = Localization.GetString("Wizard.AlternateText", Me.LocalResourceFile)
                    cmdWizard.Text = Localization.GetString("Wizard", Me.LocalResourceFile)
                    imgSiteIcon.AlternateText = Localization.GetString("Site.AlternateText", Me.LocalResourceFile)
                    cmdSite.Text = Localization.GetString("Site", Me.LocalResourceFile)
                    imgUsersIcon.AlternateText = Localization.GetString("Users.AlternateText", Me.LocalResourceFile)
                    cmdUsers.Text = Localization.GetString("Users", Me.LocalResourceFile)
                    imgFilesIcon.AlternateText = Localization.GetString("Files.AlternateText", Me.LocalResourceFile)
                    cmdFiles.Text = Localization.GetString("Files", Me.LocalResourceFile)
                    imgHelpIcon.AlternateText = Localization.GetString("Help.AlternateText", Me.LocalResourceFile)
                    cmdHelp.Text = Localization.GetString("Help", Me.LocalResourceFile)

                    If PortalSettings.ActiveTab.IsAdminTab Then
                        imgEditTabIcon.ImageUrl = "~/Admin/ControlPanel/images/iconbar_edittab_bw.gif"
                        cmdEditTab.Enabled = False
                        cmdEditTabIcon.Enabled = False
                        imgDeleteTabIcon.ImageUrl = "~/Admin/ControlPanel/images/iconbar_deletetab_bw.gif"
                        cmdDeleteTab.Enabled = False
                        cmdDeleteTabIcon.Enabled = False
                        imgCopyTabIcon.ImageUrl = "~/Admin/ControlPanel/images/iconbar_copytab_bw.gif"
                        cmdCopyTab.Enabled = False
                        cmdCopyTabIcon.Enabled = False
                    Else
                        ClientAPI.AddButtonConfirm(cmdDeleteTab, Localization.GetString("DeleteTabConfirm", Me.LocalResourceFile))
                        ClientAPI.AddButtonConfirm(cmdDeleteTabIcon, Localization.GetString("DeleteTabConfirm", Me.LocalResourceFile))
                    End If

                    If IsAdminControl() Then
                        cmdAddModule.Enabled = False
                        imgAddModuleIcon.ImageUrl = "~/Admin/ControlPanel/images/iconbar_addmodule_bw.gif"
                        cmdAddModuleIcon.Enabled = False
                    End If

                    If PortalSecurity.IsInRole(PortalSettings.AdministratorRoleName) = False Then
                        imgWizardIcon.ImageUrl = "~/Admin/ControlPanel/images/iconbar_wizard_bw.gif"
                        cmdWizard.Enabled = False
                        cmdWizardIcon.Enabled = False
                        imgSiteIcon.ImageUrl = "~/Admin/ControlPanel/images/iconbar_site_bw.gif"
                        cmdSite.Enabled = False
                        cmdSiteIcon.Enabled = False
                        imgUsersIcon.ImageUrl = "~/Admin/ControlPanel/images/iconbar_users_bw.gif"
                        cmdUsers.Enabled = False
                        cmdUsersIcon.Enabled = False
                        imgFilesIcon.ImageUrl = "~/Admin/ControlPanel/images/iconbar_files_bw.gif"
                        cmdFiles.Enabled = False
                        cmdFilesIcon.Enabled = False
                    End If

                    BindData()

                    If PortalSettings.ActiveTab.IsAdminTab = False And IsAdminControl() = False Then
                        Dim intItem As Integer
                        For intItem = 0 To PortalSettings.ActiveTab.Panes.Count - 1
                            cboPanes.Items.Add(Convert.ToString(PortalSettings.ActiveTab.Panes(intItem)))
                        Next intItem
                    Else
                        cboPanes.Items.Add(glbDefaultPane)
                    End If
                    If Not cboPanes.Items.FindByValue(glbDefaultPane) Is Nothing Then
                        cboPanes.Items.FindByValue(glbDefaultPane).Selected = True
                    End If

                    If cboPermission.Items.Count > 0 Then
                        cboPermission.SelectedIndex = 0 ' view
                    End If

                    If cboAlign.Items.Count > 0 Then
                        cboAlign.SelectedIndex = 0 ' left
                    End If

                    If cboPosition.Items.Count > 0 Then
                        cboPosition.SelectedIndex = 1 ' bottom
                    End If

                    If Convert.ToString(PortalSettings.HostSettings("HelpURL")) <> "" Then
                        cmdHelp.NavigateUrl = FormatHelpUrl(Convert.ToString(PortalSettings.HostSettings("HelpURL")), PortalSettings, "")
                        cmdHelpIcon.NavigateUrl = cmdHelp.NavigateUrl
                        cmdHelp.Enabled = True
                        cmdHelpIcon.Enabled = True
                    Else
                        cmdHelp.Enabled = False
                        cmdHelpIcon.Enabled = False
                    End If

                End If

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' PageFunctions_Click runs when any button in the Page toolbar is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	10/06/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub PageFunctions_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAddTab.Click, cmdAddTabIcon.Click, cmdEditTab.Click, cmdEditTabIcon.Click, cmdDeleteTab.Click, cmdDeleteTabIcon.Click, cmdCopyTab.Click, cmdCopyTabIcon.Click, cmdPreviewTab.Click, cmdPreviewTabIcon.Click
            Try
                Dim URL As String = Request.RawUrl
                Select Case CType(sender, LinkButton).ID
                    Case "cmdAddTab", "cmdAddTabIcon"
                        URL = NavigateURL("Tab")
                    Case "cmdEditTab", "cmdEditTabIcon"
                        URL = NavigateURL(PortalSettings.ActiveTab.TabID, "Tab", "action=edit")
                    Case "cmdDeleteTab", "cmdDeleteTabIcon"
                        URL = NavigateURL(PortalSettings.ActiveTab.TabID, "Tab", "action=delete")
                    Case "cmdCopyTab", "cmdCopyTabIcon"
                        URL = NavigateURL(PortalSettings.ActiveTab.TabID, "Tab", "action=copy")
                    Case "cmdPreviewTab", "cmdPreviewTabIcon"
                        SetPreviewMode(Not IsPreview)
                End Select

                Response.Redirect(URL, True)
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' CommonTasks_Click runs when any button in the Common Tasks toolbar is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	10/06/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub CommonTasks_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdWizard.Click, cmdWizardIcon.Click, cmdSite.Click, cmdSiteIcon.Click, cmdUsers.Click, cmdUsersIcon.Click, cmdFiles.Click, cmdFilesIcon.Click
            Try
                Dim URL As String = Request.RawUrl
                Select Case CType(sender, LinkButton).ID
                    Case "cmdWizard", "cmdWizardIcon"
                        URL = BuildURL(PortalSettings.PortalId, "Site Wizard")
                    Case "cmdSite", "cmdSiteIcon"
                        URL = BuildURL(PortalSettings.PortalId, "Site Settings")
                    Case "cmdUsers", "cmdUsersIcon"
                        URL = BuildURL(PortalSettings.PortalId, "User Accounts")
                    Case "cmdFiles", "cmdFilesIcon"
                        URL = BuildURL(PortalSettings.PortalId, "File Manager")
                End Select

                Response.Redirect(URL, True)
            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        ''' -----------------------------------------------------------------------------
        ''' <summary>
        ''' AddModule_Click runs when the Add Module Icon or text button is clicked
        ''' </summary>
        ''' <remarks>
        ''' </remarks>
        ''' <history>
        ''' 	[cnurse]	10/06/2004	Updated to reflect design changes for Help, 508 support
        '''                       and localisation
        '''     [vmasanas]  01/07/2005  Modified to add view perm. to all roles with edit perm.
        ''' </history>
        ''' -----------------------------------------------------------------------------
        Private Sub AddModule_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAddModule.Click, cmdAddModuleIcon.Click
            Try
                Dim title As String = txtTitle.Text
                Dim permissionType As ViewPermissionType = ViewPermissionType.View
                Dim position As Integer = Null.NullInteger
                If Not cboPosition.SelectedItem Is Nothing Then
                    position = Integer.Parse(cboPosition.SelectedItem.Value)
                End If
                If Not cboPermission.SelectedItem Is Nothing Then
                    permissionType = CType(cboPermission.SelectedItem.Value, ViewPermissionType)
                End If

                Select Case optModuleType.SelectedItem.Value
                    Case "0" ' new module
                        If cboDesktopModules.SelectedIndex > 0 Then
                            AddNewModule(title, Integer.Parse(cboDesktopModules.SelectedItem.Value), cboPanes.SelectedItem.Text, position, permissionType, cboAlign.SelectedItem.Value)

                            ' Redirect to the same page to pick up changes
                            Response.Redirect(Request.RawUrl, True)
                        End If
                    Case "1" ' existing module
                        If Not cboModules.SelectedItem Is Nothing Then
                            AddExistingModule(Integer.Parse(cboModules.SelectedItem.Value), Integer.Parse(cboTabs.SelectedItem.Value), cboPanes.SelectedItem.Text, position, cboAlign.SelectedItem.Value)

                            ' Redirect to the same page to pick up changes
                            Response.Redirect(Request.RawUrl, True)
                        End If
                End Select

            Catch exc As Exception    'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Private Sub optModuleType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles optModuleType.SelectedIndexChanged

            BindData()

        End Sub

        Private Sub cboTabs_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cboTabs.SelectedIndexChanged

            Dim objModules As New ModuleController
            Dim arrModules As New ArrayList

            Dim objModule As ModuleInfo
            Dim arrPortalModules As ArrayList = objModules.GetPortalTabModules(PortalSettings.PortalId, Integer.Parse(cboTabs.SelectedItem.Value))
            For Each objModule In arrPortalModules
                If PortalSecurity.IsInRoles(objModule.AuthorizedEditRoles) = True And objModule.IsDeleted = False Then
                    arrModules.Add(objModule)
                End If
            Next

            cboModules.DataSource = arrModules
            cboModules.DataBind()

        End Sub

#End Region

#Region " Web Form Designer Generated Code "


        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

            Me.ID = "IconBar.ascx"
        End Sub

#End Region

    End Class

End Namespace
